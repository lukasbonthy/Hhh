# Standalone desktop test v0.6.2

**Game launch is enabled at the user's explicit request. Native Windows gameplay remains unverified.**

1. Close the previous launcher and game.
2. Copy all updated package files over the existing test folder. Keep `.revival` to preserve the local account, downloaded files and game installation.
3. Run **Play.cmd**. The console identifies version **v0.6.2**.

This version removes the application-level withdrawal block added in v0.6.1 and restores the desktop launcher and portable runtime bootstrap. The native HTTP download fixes, pinned portable 7-Zip extraction and fully consumed loopback service checks remain in place. A recognized completed installation is verified and reused; first setup still downloads about 4 GB and requires about 20 GB free.

A local account is created automatically. This configuration requires no Steam application or Steam login. `Play-VR.cmd` explains the current desktop-only scope.

The user-reported Defender detection has not been independently classified as malware or a false positive. This update does not change antivirus or firewall settings, restore quarantined files or add security exclusions. Checksums establish file identity, not malware safety.

Keep the launcher's console open. First IL2CPP interop generation can take several minutes. If setup stops, retain the error and `.revival/logs`. Game diagnostics are in `.revival/game/BepInEx/LogOutput.log`.

Backend and relay startup were verified separately without running the native game. In-game loading, multiplayer, voice and VR still require native Windows evidence.
