@echo off
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0revival\bootstrap.ps1"
set "result=%errorlevel%"
if not "%result%"=="0" echo The test stopped. Keep the error text above.
pause
exit /b %result%
