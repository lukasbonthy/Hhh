# Standalone desktop test

**Test candidate: native Windows gameplay has not been verified.** This configuration runs without the Steam application or a Steam account. Desktop mode is the current target.

1. Extract the complete ZIP into a writable folder on a Windows 10/11 x64 PC.
2. Double-click **Play.cmd** and keep its console open.
3. Allow first setup to finish. It downloads the exact April 2023 game, about 4 GB, plus its portable runtime, connector and server dependencies. Have about 20 GB free and internet access.

The first game launch also generates IL2CPP interop, which can take several minutes. Later launches reuse the installation and your local account. Close the game normally to let the launcher stop its own backend and relay processes. No administrator installation or .NET SDK is required by the launcher.

Version 0.6 uses the pinned official portable 7-Zip console executable for the `.7z` dependency, without relying on Windows tar for that step or requiring a 7-Zip installation. Missing or unreadable archives are identified directly. ZIP inputs are still extracted with the existing archive tool. The console starts with `Standalone Rec Room desktop test v0.6`.

Version 0.5's reproduced Node 24.22.1 download crash fix (`assert(!this.paused)`) is retained: downloads use native HTTP streams with checksum verification and resume support. A message about keeping Steam signed in or using Spacewar comes from an older launcher.

For an existing test folder, close its game and launchers, copy these updated package files over it, and **keep `.revival`**. An enrolled earlier installation can be upgraded without downloading the game again. Unknown native modifications are refused. The original native platform library is retained beside its replacement as `steam_api64.dll.pre-standalone`.

The game uses a local compatibility library with its own networking and overlay disabled. Login proves a randomly generated local password. Emulated platform tickets are never accepted as account identity. The compatibility library supplies the archived game's API locally; it does not require a Steam session or Spacewar.

The local profile is a new account on your own backend. This package does not recover official accounts, friends, purchases or online rooms. Preserve the whole `.revival` directory to retain your local data. Do not share `local-player.json`, `secrets.json`, databases or tokens.

If setup stops, retain the console error and `.revival/logs`. Game diagnostics are in `.revival/game/BepInEx/LogOutput.log`. Do not run separate Start-Server or Start-Relay windows with Play.cmd.

Backend, password login, connector scope and installation checks are automated. This environment blocked Wine initialization with `wineserver: socket: Operation not permitted`, before game startup. Native Windows scene loading, multiplayer, voice and VR remain unverified. Play-VR.cmd explains the current desktop-only scope.
