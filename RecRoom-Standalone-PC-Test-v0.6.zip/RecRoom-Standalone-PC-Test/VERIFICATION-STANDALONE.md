# Standalone verification record

Target: Windows x64 desktop, client 20230414, no Steam application/account dependency.

Verified component checks:

- Local worker integration: 16 tests, including real password-account picker/login, wrong credentials, another selected account and absence of a platform link.
- Connector: pinned upstream input, emitted IL inspection, 19 URI rewrite checks and 11 credential scope/header checks.
- Installer: original-library backup, networking disabled, repeat setup, native/settings tampering, symlink rejection, interrupted connector upgrade recovery, extra runtime inventory and download resume/cache checks.
- No cloud authentication grant or platform-ticket validator was weakened.

Download fix, v0.5:

- Reproduced the user's exact `assert(!this.paused)` stack under Node 24.22.1 in child processes, both when resuming a download and when rejecting a relay HTTP error. Both tests failed before the fix and pass with native HTTP streams.
- Removed fetch/Undici from external artifact and relay downloads. Rejected responses are explicitly closed, release redirects retain HTTPS, and an existing destination is replaced only after the downloaded bytes pass their pinned fingerprint.
- Verified the real Windows relay release download and its pinned SHA256. Redirected resume, ignored Range, interrupted transfer recovery, cache reuse and preservation of a previous destination are covered.
- A fresh read-only hotfix review found no blocking defects. Its minor timeout finding was fixed: small relay downloads retain their prior 60-second deadline. A stalled-response regression was observed failing before that correction and passing after it.
- All 30 Node launcher checks, 16 local worker integration checks, and the complete upstream suite of 1827 tests across 40 files passed. The upstream run emitted existing non-fatal source-map, RPC-disposal and stream-cleanup warnings.
- Review limits are explicit: native Windows execution and filesystem replacement need Windows evidence; no second full game download was needed to exercise this hotfix. The previous pinned full-archive verification remains the game-input evidence.
- Upstream issue: https://github.com/nodejs/undici/issues/5360. The bundled Node 24.22.1 Undici source was inspected and has the same paused-parser assertion and socket-end call path shown in the screenshot.
- The source was restored from the exact verified saved v0.4 archive after a workspace reset, then the reviewed production fix was reapplied. Network regression checks are repeated on the restored package before delivery.

Archive extraction update, v0.6:

- The screenshot establishes that Windows tar failed to open the cached `.7z` file. It does not establish whether that file was missing, inaccessible, or rejected by the reader. The update makes no claim that Windows tar universally lacks 7z support.
- The Windows `.7z` step now downloads and verifies the official portable 7zr 26.05 executable, then uses argument arrays, UTF-8 listing, the archive directory as its working directory, and a relative archive filename. ZIP inputs retain their existing extraction tool.
- Missing, nonregular or unreadable archives receive a direct error before extraction. The file check is repeated after a failed listing/extraction command so a disappearing download is identified. Existing download-layer filesystem errors retain their original Node error details.
- Three new regressions were observed failing before the change and passing afterward: missing archive diagnosis, Unicode/space filenames without a functioning host tar command, and refusal of absolute archive member paths before extraction.
- All 33 Node checks passed with no skipped tests using both official Linux 7zz and a reduced 7zr compiled from checksum-verified official 26.05 source. Both extracted the entire real pinned dependency archive, including Delta, BCJ2 and LZMA2 entries, and produced the exact expected regular x64 library fingerprint. The Windows executable's release size and SHA256 were also verified.
- The 16 local worker integration checks passed again. A fresh read-only archive review found no blocking or minor issues requiring changes. Archive inputs remain checksum-pinned and listed paths are checked before extraction.
- The fresh full upstream run passed 1826 tests; `apps/rooms/src/test/integration/api.test.ts > Studio source revision permissions > keeps drafts and historical source behind save-history permissions` hit its 5000 ms timeout while other verification work was running. Its isolated rerun passed with 1.12 seconds of test execution. No room-service implementation was changed.
- Native Windows execution/path handling, the exact original PC file-access cause and gameplay remain unverified. The reduced-codec review question was resolved by the source-built reduced extractor test above. No second multi-gigabyte game download was needed for this scoped update.

A real game process has not been verified on native Windows. Wine initialization was blocked by the execution environment before startup: `wineserver: socket: Operation not permitted`. This is a test candidate, not evidence of a playable scene, multiplayer, voice or VR.

Decisions and review:

- Work stays in the existing feature checkout and is delivered as a ZIP; no upstream push or merge is performed.
- A private source backup preserves work across session resets; no sharing permissions were changed.
- Archive extraction keeps the current user's ownership, and disk estimates credit a cached game download so retries can reuse it.
- Review fixes were verified by failing regression tests followed by passing runs: actual legacy enrollment with a single game executable, rejection of unpinned loader/runtime code, rejection of added runtime/plugin DLLs, and interrupted connector update recovery.
- Credential-bearing game requests set MaxRedirects to zero. The setter's signature was checked in the pinned game metadata, and the emitted IL is checked; redirect execution still needs a native game test.
- Native Windows bootstrap, game scene loading, native DLL loading and Windows process-tree cleanup require Windows evidence. They remain verification limits, not success claims.
- No deferred code-review minor findings were reported.
