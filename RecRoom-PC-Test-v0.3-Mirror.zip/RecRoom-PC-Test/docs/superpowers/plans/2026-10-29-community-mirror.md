# Community mirror compatibility adjustment

Goal: follow the existing RecFlare 0.0.4 mirror installer for users without Rec Room in their Steam library. Steam itself must remain installed and signed in. The upstream installer writes Steam SDK sample App ID 480 after extracting the same pinned game archive.

Keep the published raw archive fingerprint (including its original steam_appid.txt) for first extraction. Convert only the known original or known compatibility App-ID file to canonical 480 newline, keeping a backup. Pin the expected runtime file separately, so repeated setup does not fail its original-file check. Existing enrolled installations must retain data, manifests and game fingerprints and migrate without downloading the game again. Refuse modified native files, symlinked configuration and unexpected App-ID values.

1. Write regression tests for conversion, repeat setup, backup, tampering and installed-client upgrade; observe failures.
2. Add the profile helper; integrate before first enrollment and after verification of existing native files.
3. Update requirements and provenance. Steam may display Spacewar because 480 is Valve's sample app. This is the community project's profile, not an official Rec Room service.
4. Run focused tests, type/syntax checks and inspect the new ZIP. Preserve the current Windows gameplay verification gate.

No game/client binaries or secrets are changed on the user's computer during this development session. The package prepares that change locally when the user runs it. No credentials are collected and Steam ticket signature validation is unchanged.
