@echo off
setlocal
pushd "%~dp0"
node --use-env-proxy revival\cli.mjs relay-start
popd
pause
