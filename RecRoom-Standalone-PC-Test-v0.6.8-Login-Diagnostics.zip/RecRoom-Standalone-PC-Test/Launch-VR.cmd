@echo off
setlocal
pushd "%~dp0"
node revival\cli.mjs launch --mode vr
popd
pause
