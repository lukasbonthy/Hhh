using System;

namespace RecNetPlugin.Patches;

/** Pure URI handling, also compiled independently by ConnectionTests. */
internal static class NameserverRedirect
{
    internal static string Rewrite(string originalAddress, string serverAddress)
    {
        var original = new Uri(originalAddress, UriKind.Absolute);
        if (!original.Host.Equals("ns.rec.net", StringComparison.OrdinalIgnoreCase))
            return originalAddress;

        if (!Uri.TryCreate(serverAddress, UriKind.Absolute, out var target) ||
            (target.Scheme != Uri.UriSchemeHttp && target.Scheme != Uri.UriSchemeHttps) ||
            !string.IsNullOrEmpty(target.UserInfo) || !string.IsNullOrEmpty(target.Query) ||
            !string.IsNullOrEmpty(target.Fragment) ||
            (target.Scheme == Uri.UriSchemeHttp && !target.IsLoopback))
            throw new ArgumentException("Use an HTTPS server, or a loopback HTTP server, without credentials, query or fragment");

        var builder = new UriBuilder(original)
        {
            Scheme = target.Scheme,
            Host = target.Host,
            Port = target.IsDefaultPort ? -1 : target.Port,
            Path = target.AbsolutePath.TrimEnd('/') + "/" + original.AbsolutePath.TrimStart('/'),
        };
        return builder.Uri.AbsoluteUri;
    }
}
