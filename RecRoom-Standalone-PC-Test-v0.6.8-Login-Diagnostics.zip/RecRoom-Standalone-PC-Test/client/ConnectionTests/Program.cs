using RecNetPlugin.Patches;

var cases = new[] {
    ("https://ns.rec.net/", "http://127.0.0.1:8787", "http://127.0.0.1:8787/"),
    ("https://ns.rec.net/endpoints?v=20230414", "http://127.0.0.1:8787", "http://127.0.0.1:8787/endpoints?v=20230414"),
    ("https://ns.rec.net/", "https://localhost:8443/prefix", "https://localhost:8443/prefix/"),
    ("https://ns.rec.net/a/b?x=1", "https://own.example/base/", "https://own.example/base/a/b?x=1"),
    ("https://ns.rec.net:8443/", "http://localhost", "http://localhost/"),
    ("https://api.other.example/data", "http://127.0.0.1:8787", "https://api.other.example/data"),
    ("https://ns.rec.net.attacker.invalid/", "http://127.0.0.1:8787", "https://ns.rec.net.attacker.invalid/"),
};

var checks = 0;
foreach (var (original, target, expected) in cases) {
    var actual = NameserverRedirect.Rewrite(original, target);
    if (actual != expected) throw new Exception($"Incorrect redirect: expected {expected}, got {actual}");
    if (NameserverRedirect.Rewrite(actual, target) != actual) throw new Exception("A second redirect changed an already redirected URL");
    checks += 2;
}
foreach (var target in new[] { "ftp://localhost:8787", "https://user:pass@own.example", "http://own.example", "https://own.example/?secret=1", "https://own.example/#fragment" }) {
    var rejected = false;
    try { NameserverRedirect.Rewrite("https://ns.rec.net/", target); }
    catch (ArgumentException) { rejected = true; }
    if (!rejected) throw new Exception($"Invalid redirect target was accepted: {target}");
    checks++;
}
Console.WriteLine($"Nameserver redirect: {checks} checks passed");

var credential = new string('a', 80);
foreach (var url in new[] { "http://127.0.0.1:8787/auth/connect/token", "http://127.0.0.1:8787/auth/cachedlogin/forplatformid/0/76561198000000123" })
    if (RecRoom.LocalEndpoint.LocalLogin.ForRequest(url, "http://127.0.0.1:8787", credential) != credential)
        throw new Exception("Missing local authentication credential");
foreach (var url in new[] { "https://auth.rec.net/connect/token", "http://127.0.0.1:8788/auth/connect/token", "http://localhost:8787/auth/connect/token", "http://127.0.0.1:8787/auth/other", "http://user@127.0.0.1:8787/auth/connect/token", "http://127.0.0.1:8787/auth/cachedlogin/forplatformid/0/not-an-id" })
    if (RecRoom.LocalEndpoint.LocalLogin.ForRequest(url, "http://127.0.0.1:8787", credential) is not null)
        throw new Exception("Credential leaked outside its origin/path scope");
foreach (var value in new[] { credential + "\n", credential + "\r\n", new string('a', 1025) })
    if (RecRoom.LocalEndpoint.LocalLogin.ForRequest("http://127.0.0.1:8787/auth/connect/token", "http://127.0.0.1:8787", value) is not null)
        throw new Exception("Invalid header credential accepted");
Console.WriteLine("Standalone credential scope: 11 checks passed");
