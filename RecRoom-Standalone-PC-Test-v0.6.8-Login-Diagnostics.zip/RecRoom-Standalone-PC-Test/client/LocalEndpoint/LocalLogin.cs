using System;
using System.Text.RegularExpressions;
namespace RecRoom.LocalEndpoint;
public static class LocalLogin {
 public static string? ForRequest(string address,string configured,string? credential){
  if(string.IsNullOrEmpty(credential)||credential.Length>1024||!Regex.IsMatch(credential,@"\A[A-Za-z0-9_-]+\z"))return null;
  if(!Uri.TryCreate(configured,UriKind.Absolute,out var target)||!Uri.TryCreate(address,UriKind.Absolute,out var request)||!target.IsLoopback||!request.IsLoopback||(target.Scheme!="http"&&target.Scheme!="https")||target.AbsolutePath!="/"||target.UserInfo.Length!=0||target.Query.Length!=0||target.Fragment.Length!=0||request.UserInfo.Length!=0||request.Fragment.Length!=0||!request.Scheme.Equals(target.Scheme,StringComparison.OrdinalIgnoreCase)||!request.Host.Equals(target.Host,StringComparison.OrdinalIgnoreCase)||request.Port!=target.Port)return null;
  return request.AbsolutePath=="/auth/connect/token"||Regex.IsMatch(request.AbsolutePath,"^/auth/cachedlogin/forplatformid/(0|7)/[0-9]{1,20}$")?credential:null;
 }
 public static string? FromEnvironment(string address,string configured)=>ForRequest(address,configured,Environment.GetEnvironmentVariable("REVIVAL_LOCAL_LOGIN"));
}
