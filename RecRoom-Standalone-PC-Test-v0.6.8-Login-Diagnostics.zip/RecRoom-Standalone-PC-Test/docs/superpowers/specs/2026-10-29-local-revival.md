# Local PC/PCVR revival foundation

The user approved starting the preceding restoration roadmap with “Okay start doing it.” Use the recommended Windows desktop/PCVR, April 2023 RecFlare target. Work continuously in the dedicated checkout; no new public deployment or shared-branch push is requested.

Deliver a locally runnable version of the existing backend, not a replacement mock API. Its discovery URLs must route to this process. Include the existing account, room, storage, economy, images, notification and matchmaking implementations with persistent local D1/R2/KV state. New local configuration must not change existing cloud deployments.

Use an explicitly configured loopback origin; do not derive service URLs from untrusted Host headers. Keep credentials outside source and preserve them across restarts. All upstream schema migrations must run in dependency order, once, with a digest check; changed migrations must fail before mutation. Use real database behavior in verification.

Provide a command-line setup/start/diagnostics flow and Windows entry points. Provide file fingerprinting and a launch plan for a user-supplied exact game installation and existing connection plugin. Reject missing/changed client files and mismatched server builds. Never claim a client is verified because its files merely exist. Do not download or redistribute game binaries or automatically disable system certificate/antivirus settings.

Prepare the self-hosted Luxon relay path using a pinned upstream revision. Build and run it here if supported. A started relay is not proof that Rec Room multiplayer works.

Acceptance: real local HTTP account creation and login, invalid-credential rejection, two distinct accounts assigned to the same public room instance, room/asset persistence, and repeatable setup. This verifies backend contracts only. In-game scene loading, synchronized gameplay, voice, and VR/device behavior require the actual compatible client and remain explicit unverified gates.

Approach: extend RecFlare with an opt-in local facade, reusing its services. DorkNet remains the separate fallback; rewriting the backend or game is out of scope for this foundation. The user's matching game installation is not present in this workspace.
