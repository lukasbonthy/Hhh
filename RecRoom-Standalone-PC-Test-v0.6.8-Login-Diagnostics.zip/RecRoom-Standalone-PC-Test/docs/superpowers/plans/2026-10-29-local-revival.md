# Local Rec Room Revival Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Run the real RecFlare backend locally and supply a version-locked PC/PCVR connection workflow.

**Architecture:** Add a local-only facade next to the existing combined worker, with path-based service discovery and adapters for local secrets and static assets. A Node CLI prepares state and schemas, starts Wrangler, verifies client fingerprints, and produces launch configuration. Keep the original deployments unchanged.

**Tech Stack:** Node 24, pnpm 10, TypeScript, Hono, Wrangler/workerd, D1/R2/KV, Vitest; pinned Luxon C++ relay.

**Spec:** `docs/superpowers/specs/2026-10-29-local-revival.md`

## Global Constraints

- Default client build is `20230414`; PC/PCVR first.
- No proprietary client or room binaries in the deliverable.
- Default listener/public origin: `127.0.0.1:8787` / `http://127.0.0.1:8787`.
- Credentials and local runtime state are gitignored and preserved on repeat setup.
- Backend tests and a running relay do not establish playable Rec Room multiplayer.
- No public deployment, external messages, or shared-branch push.

## Review Focus

- Advertised URLs and nested response URLs must not escape to placeholder hosts or trust an incoming Host header.
- Mixed-owner schema migrations must share one DB, survive reruns, and detect changed history before executing pending SQL.
- Missing/corrupt client files must prevent launch; file enrollment must not be described as independent provenance verification.
- Local passwords, access tokens and signing keys must not appear in diagnostics or packaged output.
- Optional services, relay absence, and missing game files must be reported honestly, with nonzero diagnostic results where appropriate.

---

### Task 1: Local facade and real protocol tests

**Files:** `apps/mono/src/revival.app.ts`, `apps/mono/src/local-routing.ts`, `apps/mono/wrangler.revival.jsonc`, `apps/mono/vitest.revival.config.ts`, `apps/mono/src/test/revival/*.test.ts`, `vitest.config.ts`.

**Interfaces:** Local facade consumes the existing worker implementations and exposes `fetch` plus the notification Durable Object. Routing helpers produce a discovery map from a fixed public origin, strip service prefixes, and rebase only our own service URLs.

- [ ] Write failing integration tests for loopback discovery, forged hosts, unsupported build checks, economy/image service routing, credential rejection, and two-account room assignment using real local bindings and migrations.
- [ ] Run the focused tests and observe missing local behavior.
- [ ] Implement the opt-in local facade and adapters; leave cloud entry points untouched.
- [ ] Run focused tests and existing mono tests; record actual results.
- [ ] Commit the tested deliverable.

### Task 2: Persistent setup and command-line operation

**Files:** `revival/cli.mjs`, `revival/setup.mjs`, `revival/migrations.mjs`, `revival/test/*.test.mjs`, `revival/README.md`, `Start-Server.cmd`.

**Interfaces:** `prepare(root, options)` preserves generated configuration/secrets, stages static assets, and returns paths. `migrate(db, migrations)` uses the D1-compatible binding with per-file hashes. CLI commands `setup`, `start`, and `doctor` use those results.

- [ ] Test repeat preparation, ordered migration application, changed-history rejection, and readable errors against temporary files and real database bindings.
- [ ] Observe the failures; implement the smallest persistent setup and CLI.
- [ ] Exercise first setup, repeat setup, real HTTP registration/login/matchmaking, and restart persistence.
- [ ] Commit the tested deliverable.

### Task 3: PC client preparation and pinned relay

**Files:** `revival/client.mjs`, `revival/test/client.test.mjs`, `revival/relay.mjs`, `revival/upstream-lock.json`, Windows launch scripts, operator documentation.

**Interfaces:** Client enrollment records file SHA-256 fingerprints and an operator-declared build. Verification compares every required file before constructing a shell-free launch plan. Relay scripts consume the pinned upstream and loopback configuration.

- [ ] Write failing tests for missing files, changed files, incompatible build, path/argument injection, and server compatibility checks.
- [ ] Implement enrollment, verification, desktop/VR launch planning and connection settings without claiming independent binary authenticity.
- [ ] Build/run the pinned relay if toolchain permits; record exact blockers otherwise.
- [ ] Run all new tests and the upstream suite, build/type checks, and inspect a clean distribution archive.
- [ ] Commit and obtain one independent whole-branch review; fix important findings with regression tests.

## Handoff

The user already requested execution. Proceed inline without another approval round. Report the actual verified foundation and the missing real-client/device gates, and provide the source package.
