# Standalone desktop package

User requires no Steam application or account. Execute directly, preserving local data.

Use the exact April 2023 client, pinned regular GSE x64 native compatibility library with networking/overlay disabled, and an ordinary local password account. The connector adds private credentials only to the configured loopback authentication endpoints. Cloud ticket verification remains unchanged. Keep original native libraries and refuse unknown modifications.

1. Restore local login adapter and private player profile, then verify account separation, password rejection and URI scope.
2. Build the pinned connector, verify IL, and prepare the download/install/runtime checks.
3. Test backend, installer and actual game startup without Steam where the environment permits. A fresh reviewer checks the whole change.
4. Package a desktop test candidate. Never claim Windows gameplay without observing startup, login and a playable scene. Save a durable source checkpoint because repeated environment resets have discarded recent work.
