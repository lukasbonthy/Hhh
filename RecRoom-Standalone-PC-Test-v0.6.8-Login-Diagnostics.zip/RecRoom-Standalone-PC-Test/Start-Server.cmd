@echo off
setlocal
pushd "%~dp0"
node revival\cli.mjs start
popd
pause
