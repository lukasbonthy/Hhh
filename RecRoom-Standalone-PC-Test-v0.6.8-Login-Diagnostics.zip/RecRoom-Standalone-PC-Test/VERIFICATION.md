# Verification and remaining gates

Date: October 29, 2026. Target: local Windows PC/PCVR workflow for the operator-declared `20230414` client.

## Verified implementation

- The frozen pnpm dependency installation completed.
- Local facade worker tests exercise real D1/R2 bindings: loopback discovery, rejection of forged hosts and inherited-property routes, URL rebasing, separate password accounts, wrong-password rejection, build gating, shared public-room assignment, binary image preservation, and migration rollback/history checks.
- Node tests cover persistent setup, key preservation, critical-file fingerprinting, changed/missing files, connector receipts including Windows UTF-8 BOMs, safe launch arguments, INI configuration preservation, and verified-artifact installation.
- `node revival/smoke.mjs` passed against actual running HTTP processes. It creates two different accounts, assigns both to the same public room instance, checks password rejection, reads a fallback JPEG and an unchanged CDN JSON file, uploads a binary blob, restarts the server, then authenticates the existing account and reads the same blob again. It also checks that diagnostics refuse readiness without a client/relay.
- The local setup applied all **129** upstream schema migrations. Repeat setup skips the same migrations. Setup and server now use the same `storage/v3` directory.
- The standalone C# nameserver helper compiled and passed **19 checks** for schemes, ports, path/query preservation, host matching, and invalid destination rejection.
- The Luxon **v1.5** Linux x64 release matched its pinned SHA-256 digest. Its actual process served the local dashboard and bound UDP **5058, 5055, and 5056** in `relay-smoke.mjs`.
- TypeScript checking of the combined/local backend completed without errors.

The focused test outputs and final review results are recorded in the repository history and the execution summary below.

## Limits

No matching Rec Room game installation or game-generated BepInEx interop assemblies were supplied. Consequently the complete connector DLL was not compiled against the game, no real game client loaded a scene, and no game synchronization, voice, Windows launch, or VR/device behavior was verified.

Two accounts receiving a shared room-instance DTO is a backend contract check. It is not evidence that two game clients can move and interact together. A started relay likewise does not establish game or voice compatibility.

The upstream server and connector documentation disagree on the Steam manifest for their named April 2023 build. Client enrollment is therefore explicitly **operator-declared** and checks local file changes; it is not an authoritative distribution fingerprint.

The available GCC 13 toolchain could not compile the inspected Luxon master revision because it uses a newer C++23 explicit-object feature. This package instead pins a published release and its binary digest. The Windows relay artifact is pinned but was not executed on this Linux host.

This is a loopback development profile. It does not provide a public deployment, email recovery service, standalone Quest support, recovered original accounts, missing original content, or a completed independent server-authoritative game simulation.

## Upstream suite and diagnostics

The initial full upstream run completed with **1826 passed / 1 timeout** out of 1827 tests. The existing rooms test `Studio source revision permissions > keeps drafts and historical source behind save-history permissions` hit its default five-second limit during the loaded run. The same test passed in isolation without code changes. A complete rerun uses an explicit 30-second test budget; the final result is appended before packaging.

The dependency stack emits source-map warnings, an RPC-stub disposal warning, and stream-cancellation diagnostics during some tests. These are reported rather than described as a warning-free run. No outbound email was sent: upstream email tests use local test bindings.

## Decisions made during implementation

- Use the new dedicated clone and feature branch for isolation; no existing user checkout was modified.
- Keep cloud entry points unchanged unless the opt-in local origin is configured.
- Use a verified Luxon release instead of claiming the unsupported source build succeeded.
- Require an explicit client/connector enrollment before launch and keep gameplay verification false until a real client test.
- Preserve existing client configuration and local data; exclude generated secrets, client manifests, runtime databases, build products, and downloaded binaries from the source package.
