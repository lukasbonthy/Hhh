@echo off
setlocal
pushd "%~dp0"
node --version
if errorlevel 1 goto failed
call npx --yes pnpm@10.14.0 install --frozen-lockfile
if errorlevel 1 goto failed
node revival\cli.mjs setup
if errorlevel 1 goto failed
node --use-env-proxy revival\cli.mjs relay-install
if errorlevel 1 goto failed
echo Setup finished. Read START-HERE.md for the matching client requirement.
popd
pause
exit /b 0
:failed
echo Setup stopped. Read the error above. Install Node.js 24 if it is missing.
popd
pause
exit /b 1
