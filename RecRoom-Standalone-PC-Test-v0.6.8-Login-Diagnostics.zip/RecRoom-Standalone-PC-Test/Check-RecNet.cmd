@echo off
setlocal
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0revival\diagnose-recnet.ps1"
echo.
echo The summary is at .revival\logs\recnet-check.txt
pause
