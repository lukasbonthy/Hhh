@echo off
echo This standalone package currently supports desktop mode. Run Play.cmd.
pause
