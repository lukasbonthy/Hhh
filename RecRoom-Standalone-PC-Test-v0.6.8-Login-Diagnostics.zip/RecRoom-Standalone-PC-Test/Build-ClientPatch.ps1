param(
    [Parameter(Mandatory = $true)][string]$GamePath,
    [ValidateSet('20230414')][string]$ClientBuild = '20230414'
)
$ErrorActionPreference = 'Stop'
$game = (Resolve-Path -LiteralPath $GamePath).Path
if (-not (Test-Path -LiteralPath (Join-Path $game 'BepInEx\interop'))) {
    throw 'The matching game must have been launched once under BepInEx 6 to generate its interop assemblies.'
}
$project = Join-Path $PSScriptRoot 'client\RecNetPlugin\RecNetPlugin.csproj'
& dotnet build $project --configuration Release "-p:GamePath=$game" --use-lock-file
if ($LASTEXITCODE -ne 0) { throw 'Connector build failed; no readiness receipt was written.' }
$dll = Join-Path $game 'BepInEx\plugins\RecNetPlugin.dll'
if (-not (Test-Path -LiteralPath $dll)) { throw 'The build did not install RecNetPlugin.dll.' }
$receipt = @{
    profile = 'recroom-local-port-fix-v1'
    clientBuild = $ClientBuild
    dllSha256 = (Get-FileHash -LiteralPath $dll -Algorithm SHA256).Hash.ToLowerInvariant()
    upstreamCommit = '68f42eb6614e4fa788603bc0dd8124527c382e30'
}
$receiptPath = Join-Path $game 'BepInEx\plugins\RecNetPlugin.revival.json'
[System.IO.File]::WriteAllText($receiptPath, ($receipt | ConvertTo-Json), [System.Text.UTF8Encoding]::new($false))
Write-Host 'Connector built. Enroll this installation with the local revival CLI before launching.'
