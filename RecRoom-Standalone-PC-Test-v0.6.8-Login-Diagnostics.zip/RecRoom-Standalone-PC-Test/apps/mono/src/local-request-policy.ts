/**
 * Only known loopback spellings are permitted, even when the local HTTPS
 * development proxy normalizes a WebSocket URL or its protocol internally.
 * This is NOT a global relaxation of the request-origin policy: the exception
 * is limited to the two SignalR notification hub routes.
 */
const LOOPBACK_HOSTS = new Set(['127.0.0.1', 'localhost', '[::1]'])

function isNotificationHubPath(path: string): boolean {
	return path === '/notify/hub/v1' || path === '/notify/hub/v1/negotiate'
}

export function trustedLocalRequestUrl(
	url: URL,
	configuredOrigin: string,
	isWebSocketUpgrade: boolean
): boolean {
	// Every ordinary API request keeps the strict configured HTTPS origin.
	if (url.origin === configuredOrigin) return true

	// A local Wrangler TLS / WebSocket proxy can hand a request to the Worker
	// with an http/ws/wss scheme or a different loopback hostname. The upstream
	// connection still reaches the SAME loopback listener and port. Restrict the
	// compatibility allowance to SignalR, never all application routes.
	if (!isNotificationHubPath(url.pathname)) return false
	const configured = new URL(configuredOrigin)
	if (
		!LOOPBACK_HOSTS.has(configured.hostname) ||
		!LOOPBACK_HOSTS.has(url.hostname) ||
		url.port !== configured.port
	) return false

	// The SignalR negotiate POST is an ordinary HTTP(S) request. Do not allow
	// an unrelated WebSocket scheme just because it uses a known local host.
	if (url.pathname === '/notify/hub/v1/negotiate') {
		return !isWebSocketUpgrade && ['http:', 'https:'].includes(url.protocol)
	}
	// Only genuine hub WebSocket upgrade requests get cross-protocol handling.
	return isWebSocketUpgrade && ['http:', 'https:', 'ws:', 'wss:'].includes(url.protocol)
}
