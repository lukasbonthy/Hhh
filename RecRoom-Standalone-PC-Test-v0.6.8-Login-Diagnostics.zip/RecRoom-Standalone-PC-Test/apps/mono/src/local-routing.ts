import { buildEndpoints } from '../../ns/src/endpoints'

/** The only origin we advertise comes from operator configuration, never request headers. */
export function localOrigin(value: string): string {
	const url = new URL(value)
	if (
		!['127.0.0.1', 'localhost', '[::1]'].includes(url.hostname) ||
		!['http:', 'https:'].includes(url.protocol) ||
		url.username ||
		url.password ||
		url.pathname !== '/' ||
		url.search ||
		url.hash
	)
		throw new Error('Local revival requires a loopback HTTP(S) origin with no path or credentials')
	return url.origin
}

export function localEndpoints(origin: string, domain: string, overrides?: string) {
	return Object.fromEntries(
		Object.entries(buildEndpoints(domain, overrides)).map(([label, address]) => [
			label,
			`${origin}/${new URL(address).hostname.split('.')[0]}`,
		])
	)
}

// This policy has no framework dependencies, so it can be tested directly.
export { trustedLocalRequestUrl } from './local-request-policy'

/** Rebase our own service links, including links inside JSON-encoded config strings. */
export function rebaseLocalValue(value: unknown, domain: string, origin: string): unknown {
	if (typeof value === 'string') {
		const escaped = domain.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
		return value.replace(
			new RegExp(`https?://([a-z0-9-]+)\\.${escaped}(?=[/?#\\s"\\\\]|$)`, 'gi'),
			(_match, service: string) => `${origin}/${service}`
		)
	}
	if (Array.isArray(value)) return value.map((entry) => rebaseLocalValue(entry, domain, origin))
	if (value && typeof value === 'object') {
		return Object.fromEntries(
			Object.entries(value).map(([key, entry]) => [key, rebaseLocalValue(entry, domain, origin)])
		)
	}
	return value
}

export async function rebaseLocalResponse(response: Response, domain: string, origin: string) {
	if (response.webSocket || !response.headers.get('content-type')?.includes('application/json')) {
		return response
	}
	const original = await response.clone().json()
	const value = rebaseLocalValue(original, domain, origin)
	// CDN JSON files may be byte-addressed and include a BOM. Keep the original
	// response, validators and bytes when no service link actually changed.
	if (JSON.stringify(original) === JSON.stringify(value)) return response
	const headers = new Headers(response.headers)
	for (const name of ['content-length', 'content-encoding', 'etag']) headers.delete(name)
	return Response.json(value, { status: response.status, statusText: response.statusText, headers })
}
