import { getAccount } from '@repo/domain'

import auth from '../../auth/src/auth.app'

import type { Env } from './context'

export async function localPasswordLogin(
	request: Request,
	encoded: string | null,
	env: Env,
	ctx: ExecutionContext
): Promise<Response | null> {
	if (encoded === null) return null
	const path = new URL(request.url).pathname
	const picker = /^\/cachedlogin\/forplatformid\/(0|7)\/([0-9]{1,20})$/.exec(path)
	const token = path === '/connect/token' && request.method === 'POST'
	if (!token && !(picker && ['GET', 'POST'].includes(request.method))) return null
	const denied = () =>
		Response.json(
			{ error: 'invalid_grant', error_description: 'local account credentials are invalid' },
			{ status: picker ? 401 : 400 }
		)
	let login: { accountId: string; password: string }
	try {
		if (encoded.length > 1024 || !/^[A-Za-z0-9_-]+$/.test(encoded)) return denied()
		const bytes = Uint8Array.from(atob(encoded.replace(/-/g, '+').replace(/_/g, '/')), (c) =>
			c.charCodeAt(0)
		)
		login = JSON.parse(new TextDecoder('utf-8', { fatal: true, ignoreBOM: false }).decode(bytes))
		if (
			typeof login.accountId !== 'string' ||
			!/^[1-9][0-9]{0,15}$/.test(login.accountId) ||
			!Number.isSafeInteger(Number(login.accountId)) ||
			typeof login.password !== 'string' ||
			!login.password.length ||
			login.password.length > 128
		)
			return denied()
	} catch {
		return denied()
	}
	let body = new URLSearchParams({ ver: '20230414' })
	if (token) {
		if (!request.headers.get('content-type')?.startsWith('application/x-www-form-urlencoded'))
			return denied()
		const text = new TextDecoder().decode(await request.arrayBuffer())
		if (text.length > 65536) return denied()
		body = new URLSearchParams(text)
		if (!['create_account', 'cached_login'].includes(body.get('grant_type') ?? '')) return null
		const selected = body.get('account_id')
		if (selected && selected !== login.accountId) return denied()
	}
	for (const key of ['platform_id', 'platform_auth', 'username']) body.delete(key)
	body.set('grant_type', 'password')
	body.set('account_id', login.accountId)
	body.set('password', login.password)
	body.set('platform', '7')
	const headers = new Headers(request.headers)
	headers.delete('content-length')
	headers.delete('authorization')
	headers.set('content-type', 'application/x-www-form-urlencoded')
	const response = await auth.fetch(
		new Request(new URL('/connect/token', request.url), { method: 'POST', headers, body }),
		env,
		ctx
	)
	if (!picker) return response
	if (!response.ok) return denied()
	const account = await getAccount(env.DB, Number(login.accountId))
	if (!account) return denied()
	// Wire compatibility only; no platform identity is linked or trusted.
	return Response.json([
		{
			platform: Number(picker[1]),
			platformId: picker[2],
			accountId: account.accountId,
			lastLoginTime: account.lastLoginTime ?? account.createdAt,
			requirePassword: false,
		},
	])
}
