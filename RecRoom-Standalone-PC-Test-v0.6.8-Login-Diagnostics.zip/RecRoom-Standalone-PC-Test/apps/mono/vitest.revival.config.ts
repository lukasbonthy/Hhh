import { resolve } from 'node:path'
import { cloudflareTest, readD1Migrations } from '@cloudflare/vitest-pool-workers'
import { defineConfig } from 'vitest/config'

export default defineConfig(async () => {
	const owners = [
		'auth',
		'rooms',
		'api',
		'econ',
		'img',
		'chat',
		'clubs',
		'leaderboard',
		'link',
		'lists',
		'match',
		'roomcomments',
		'studio',
	]
	const migrations = (
		await Promise.all(
			owners.map(async (owner) =>
				(await readD1Migrations(resolve(__dirname, `../${owner}/migrations`))).map((m) => ({
					...m,
					name: `${owner}/${m.name}`,
				}))
			)
		)
	).flat()
	return {
		root: resolve(__dirname, '../..'),
		test: { include: ['revival/worker-tests/**/*.test.ts'], testTimeout: 30_000 },
		plugins: [
			cloudflareTest({
				wrangler: { configPath: `${__dirname}/wrangler.jsonc` },
				miniflare: {
					bindings: {
						ENVIRONMENT: 'VITEST',
						DOMAIN: 'revival.invalid',
						SUBDOMAINS: '{"moderation":"api"}',
						REVIVAL_PUBLIC_ORIGIN: 'http://127.0.0.1:8787',
						TEST_MIGRATIONS: migrations,
						PASSWORD_SIGNUP: true,
						MAX_ACCOUNTS_PER_IP: 0,
						SUPPORTED_GAME_VERSIONS: '20230414',
						ROLLOUT_GAME_VERSIONS: 'off',
					},
				},
			}),
		],
	}
})
