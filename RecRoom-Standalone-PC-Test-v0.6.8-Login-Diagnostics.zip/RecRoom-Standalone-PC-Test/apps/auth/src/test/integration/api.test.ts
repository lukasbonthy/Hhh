import { adminSecretsStore, env } from 'cloudflare:test'
import { exports } from 'cloudflare:workers'
import { beforeAll, describe, expect, test } from 'vitest'

import '../../auth.app'

import {
	AUDIT_LOG_SCHEMA_DDL,
	EMAIL_CODE_SCHEMA_DDL,
	GAME_VERSION,
	getAccount,
	getAccountsByDeviceId,
	getPasswordHash,
	hashPassword,
	PRESENCE_SCHEMA_DDL,
	RATE_LIMIT_SCHEMA_DDL,
	ROOM_SCHEMA_DDL,
	SCHEMA_DDL,
	seedRoomWithSubRooms,
	SUBROOM_SCHEMA_DDL,
	updateAccount,
} from '@repo/domain'
import {
	generateIdentityAssertion,
	generateToken,
	TOKEN_TTL_SECONDS,
	validateIdentityAssertion,
} from '@repo/jwt'

import { SCHEMA_DDL as CUSTOM_AVATAR_ITEM_SCHEMA_DDL } from '../../../../api/src/custom-avatar-items-db'
import {
	banFromReport,
	createReport,
	SCHEMA_DDL as REPORTS_SCHEMA_DDL,
} from '../../../../api/src/reports-db'
import { PlatformType } from '../../openapi'
import {
	countAccountsForPlatformIdentity,
	getLinksForAccount,
	linkPlatformIdentity,
	PLATFORM_BACKFILL_SQL,
	PLATFORM_SCHEMA_DDL,
} from '../../platform-db'
import { resetPasswordUrl } from '../../recovery-email'
import { consumeRefreshToken, issueRefreshToken, REFRESH_SCHEMA_DDL } from '../../refresh-db'
import {
	STUDIO_CLIENT_ID,
	STUDIO_CLIENT_SECRET,
	STUDIO_DEVICE_SCHEMA_DDL,
} from '../../studio-device'

import type { Env } from '../../context'

declare module 'cloudflare:test' {
	interface ProvidedEnv extends Env {}
}

const ORIGIN = 'https://example.com'

// The Orientation room (RoomId 13) new accounts are placed into on signup.
const ORIENTATION_SCENE = 'c79709d8-a31b-48aa-9eb8-cc31ba9505e8'

// Credential login requires the account's password; seed a known one for the
// accounts the login tests authenticate as (42, 77).
const LOGIN_PASSWORD = 'correct-horse'

// Meta (Oculus) logins verify their nonce by calling graph.oculus.com authenticated
// as the app, so the tests seed an app secret and stub that call — see metaLogin.
const META_APP_SECRET = 'test-meta-app-secret'
const META_APP_ID = '1232175103309633'
const META_USER_ID = '27061366730207360'
const META_NONCE = 'xOUoGXJtC2N31BRDtoWJqBNo81o3DwfbQC57i9ApaiBIqkgmyMOgMYIng7c5jL5I'
/** Set in beforeAll; needed to overwrite the secret in the not-configured test. */
let metaSecretId: string

// Apply the accounts schema so create_account can persist (mirrors the migration),
// and seed the Orientation room (owned by the rooms worker) so signup can place
// the new player there.
beforeAll(async () => {
	// Seed the shared JWT signing key into the local Secrets Store so .get() resolves.
	await adminSecretsStore(env.JWT_SECRET).create('test-signing-key')
	// The Meta app secret, likewise — a Meta login is refused outright without one.
	metaSecretId = await adminSecretsStore(env.META_APP_SECRET).create(META_APP_SECRET)
	for (const stmt of SCHEMA_DDL) await env.DB.prepare(stmt).run()
	for (const stmt of REFRESH_SCHEMA_DDL) await env.DB.prepare(stmt).run()
	// The pending email codes (`/account/recoverpassword` issues one as a password_reset).
	for (const stmt of EMAIL_CODE_SCHEMA_DDL) await env.DB.prepare(stmt).run()
	// The counters that cap how many of those go out, per account and per IP.
	for (const stmt of RATE_LIMIT_SCHEMA_DDL) await env.DB.prepare(stmt).run()
	// Platform identity links — one account can hold several (a PC and a headset), and
	// this table is what both the picker and the cached_login grant read.
	for (const stmt of PLATFORM_SCHEMA_DDL) await env.DB.prepare(stmt).run()
	// Presence table (owned by the rooms worker) — signup seeds the Orientation row.
	for (const stmt of PRESENCE_SCHEMA_DDL) await env.DB.prepare(stmt).run()
	// The audit trail a staff sign-in is recorded on. Owned by the `api` worker, whose
	// migrations don't run here, so build it from the mirrored DDL.
	for (const stmt of AUDIT_LOG_SCHEMA_DDL) await env.DB.prepare(stmt).run()

	// Seed the accounts the credential-login tests use, each with LOGIN_PASSWORD set.
	const hash = await hashPassword(LOGIN_PASSWORD)
	for (const id of [42, 77]) {
		await env.DB.prepare('INSERT OR IGNORE INTO account (data) VALUES (?1)')
			.bind(JSON.stringify({ accountId: id, username: `Player${id}`, passwordHash: hash }))
			.run()
	}
	// The rooms worker's schema (room + interaction) — reading a room aggregates its
	// cheer/favorite Stats from `interaction`, so both tables have to be here.
	for (const stmt of ROOM_SCHEMA_DDL) await env.DB.prepare(stmt).run()
	// Subrooms live in their own table; seed the Orientation room and split its subroom into it.
	for (const stmt of SUBROOM_SCHEMA_DDL) await env.DB.prepare(stmt).run()
	await seedRoomWithSubRooms(env.DB, {
		RoomId: 13,
		Name: 'Orientation',
		IsDorm: false,
		SubRooms: [{ SubRoomId: 23, UnitySceneId: ORIENTATION_SCENE, MaxPlayers: 1 }],
	})
	// Report table (owned by the api worker) — a ban is a report row with `banned` set;
	// the token grant reads it for the evasion arms.
	for (const stmt of REPORTS_SCHEMA_DDL) await env.DB.prepare(stmt).run()
	// Custom avatar items (owned by the api worker) — every room read joins the published
	// room badges from this table.
	for (const stmt of CUSTOM_AVATAR_ITEM_SCHEMA_DDL) await env.DB.prepare(stmt).run()
	for (const stmt of STUDIO_DEVICE_SCHEMA_DDL) await env.DB.prepare(stmt).run()
})

/**
 * Ban an account the way a moderator would: file a report against it and convert that
 * report into a ban. `banExpires` null is a permanent ban.
 */
async function banAccount(accountId: number, banExpires: string | null = null): Promise<void> {
	const row = await createReport(env.DB, { reporterPlayerId: 1, reportedPlayerId: accountId })
	await banFromReport(env.DB, row.id, { banExpires })
}

/** Seed an account with LOGIN_PASSWORD set, so it can be logged into. */
async function seedAccount(accountId: number, username: string): Promise<void> {
	await env.DB.prepare('INSERT OR IGNORE INTO account (data) VALUES (?1)')
		.bind(JSON.stringify({ accountId, username, passwordHash: await hashPassword(LOGIN_PASSWORD) }))
		.run()
}

/** Decode a JWT payload (no verification) for asserting claims. */
function decodePayload(token: string): Record<string, unknown> {
	const part = token.split('.')[1].replace(/-/g, '+').replace(/_/g, '/')
	return JSON.parse(
		new TextDecoder().decode(Uint8Array.from(atob(part), (ch) => ch.charCodeAt(0)))
	) as Record<string, unknown>
}

async function accessTokenFor(body: string, ip?: string): Promise<string> {
	return (await postToken(body, ip)).json.access_token as string
}

async function tokenFor(body: string, ip?: string): Promise<Record<string, unknown>> {
	return decodePayload(await accessTokenFor(body, ip))
}

/**
 * POST a form-urlencoded body to /connect/token, returning status + parsed JSON.
 * `ip` sets CF-Connecting-IP (what Cloudflare's edge sets in production); omit it and
 * the request looks IP-less, which is how the other tests dodge the per-IP signup cap.
 */
async function postToken(
	body: string,
	ip?: string
): Promise<{ status: number; json: Record<string, unknown> }> {
	const res = await exports.default.fetch(`${ORIGIN}/connect/token`, {
		method: 'POST',
		headers: {
			'Content-Type': 'application/x-www-form-urlencoded',
			...(ip ? { 'CF-Connecting-IP': ip } : {}),
		},
		body,
	})
	return { status: res.status, json: (await res.json()) as Record<string, unknown> }
}

/**
 * POST a Meta grant to /connect/token with graph.oculus.com stubbed to answer
 * `is_valid`. The worker runs in this isolate, so replacing the global fetch is what
 * stands in for Meta — `verifyMetaNonce` resolves `globalThis.fetch` per call for
 * exactly this reason. Returns the graph requests the worker made alongside the
 * response, so a test can assert WHICH user id the nonce was validated against.
 */
async function metaLogin(
	body: string,
	isValid: boolean
): Promise<{ status: number; json: Record<string, unknown>; graphCalls: URLSearchParams[] }> {
	const graphCalls: URLSearchParams[] = []
	const realFetch = globalThis.fetch
	globalThis.fetch = (async (url: string, init?: { body?: string }) => {
		if (url.startsWith('https://graph.oculus.com/')) {
			graphCalls.push(new URLSearchParams(init?.body ?? ''))
			return Response.json({ is_valid: isValid })
		}
		return realFetch(url, init)
	}) as unknown as typeof fetch
	try {
		return { ...(await postToken(body)), graphCalls }
	} finally {
		globalThis.fetch = realFetch
	}
}

/** GET a JSON route on the worker and parse the body as `T`. */
async function getJson<T>(path: string): Promise<T> {
	const res = await exports.default.fetch(`${ORIGIN}${path}`)
	return (await res.json()) as T
}

/** The picker entries a platform identity yields, as the client sees them. */
function cachedLogins(platform: number, id: string) {
	return getJson<Array<Record<string, unknown> & { accountId: number; platform: number }>>(
		`/cachedlogin/forplatformid/${platform}/${id}`
	)
}

/** The `platform_auth` payload a Meta client posts, as observed from a live login. */
function metaPlatformAuth(): string {
	return JSON.stringify({ Nonce: META_NONCE, AppId: META_APP_ID, Source: 'logged in user' })
}

/** POST a form-urlencoded body to changepassword with an optional bearer token. */
function changePassword(body: string, token?: string): Promise<Response> {
	return exports.default.fetch(`${ORIGIN}/account/me/changepassword`, {
		method: 'POST',
		headers: {
			...(token ? { Authorization: `Bearer ${token}` } : {}),
			'Content-Type': 'application/x-www-form-urlencoded',
		},
		body,
	})
}

describe('auth worker routes', () => {
	test('GET /eac/challenge returns the EAC challenge as text/plain', async () => {
		const res = await exports.default.fetch(`${ORIGIN}/eac/challenge`)
		expect(res.status).toBe(200)
		expect(res.headers.get('content-type')).toContain('text/plain')
		// EAC challenge content (BOM is stripped on read).
		expect(await res.text()).toBe('"AA=="')
	})

	test.each([
		['0 (Steam)', 0],
		['1 (Meta)', 1],
	])(
		'GET /cachedlogin/forplatformid/%s/:id returns [] for an unknown id',
		async (_label, platform) => {
			const res = await exports.default.fetch(
				`${ORIGIN}/cachedlogin/forplatformid/${platform}/abc123`
			)
			expect(res.status).toBe(200)
			expect(await res.json()).toEqual([])
		}
	)

	// The one stubbed identity: `1/1` consults nothing and always answers the canned
	// entry, which is how a sideloaded APK (no Meta SDK, so no real identity) gets off
	// the platform login screen and onto username/password.
	test('GET /cachedlogin/forplatformid/1/1 returns the canned Oculus entry', async () => {
		const res = await exports.default.fetch(`${ORIGIN}/cachedlogin/forplatformid/1/1`)
		expect(res.status).toBe(200)
		expect(await res.json()).toEqual([
			{
				platform: 1,
				platformId: '1',
				accountId: 1,
				lastLoginTime: '2026-07-19T17:13:29.225Z',
				requirePassword: true,
			},
		])
	})

	// Only Steam (0) and Meta (1) can be verified — Steam by its signed platform_auth
	// ticket, Meta by validating its nonce with Meta. Every OTHER platform is rejected
	// on the platform-authenticated grants: we won't bind or authorize an identity we
	// can't prove.
	test.each([2, 3, 4, 5, 6, 7, 8])(
		'create_account rejects unverifiable platform %i',
		async (platform) => {
			const res = await postToken(
				`grant_type=create_account&platform=${platform}&platform_id=whoever`
			)
			expect(res.status).toBe(400)
			expect(res.json.error).toBe('invalid_grant')
			expect(res.json.error_description).toContain('only Steam and Meta')
		}
	)

	test.each([2, 3, 4, 5, 6, 7, 8])(
		'cached_login rejects unverifiable platform %i',
		async (platform) => {
			const res = await postToken(
				`grant_type=cached_login&account_id=42&platform=${platform}&platform_id=whoever`
			)
			expect(res.status).toBe(400)
			expect(res.json.error).toBe('invalid_grant')
			expect(res.json.error_description).toContain('only Steam and Meta')
		}
	)

	test('Steam create_account requires a valid platform_auth ticket', async () => {
		// platform=0 (Steam) with no verifiable ticket must not bind the spoofable
		// platform_id field — it's rejected outright.
		const res = await postToken(
			'grant_type=create_account&platform=0&platform_id=76561197962463211'
		)
		expect(res.status).toBe(400)
		expect(res.json.error).toBe('invalid_grant')
		expect(res.json.error_description).toContain('platform_auth')
	})

	test('Steam cached_login requires a valid platform_auth ticket', async () => {
		const res = await postToken(
			'grant_type=cached_login&account_id=42&platform=0&platform_id=76561197962463211'
		)
		expect(res.status).toBe(400)
		expect(res.json.error).toBe('invalid_grant')
		expect(res.json.error_description).toContain('platform_auth')
	})

	test('Meta create_account requires a platform_auth nonce', async () => {
		// platform=1 with no nonce must not bind the spoofable platform_id field.
		const res = await postToken(`grant_type=create_account&platform=1&platform_id=${META_USER_ID}`)
		expect(res.status).toBe(400)
		expect(res.json.error).toBe('invalid_grant')
		expect(res.json.error_description).toContain('platform_auth')
	})

	test('Meta create_account binds the id Meta validated the nonce against', async () => {
		const res = await metaLogin(
			`grant_type=create_account&platform=1&platform_id=${META_USER_ID}` +
				`&platform_auth=${encodeURIComponent(metaPlatformAuth())}&device_id=meta-device`,
			true
		)
		expect(res.status).toBe(200)

		// The nonce was validated against the posted user id, authenticated as the app.
		expect(res.graphCalls).toHaveLength(1)
		expect(res.graphCalls[0].get('nonce')).toBe(META_NONCE)
		expect(res.graphCalls[0].get('user_id')).toBe(META_USER_ID)
		expect(res.graphCalls[0].get('access_token')).toBe(`OC|${META_APP_ID}|${META_APP_SECRET}`)

		// The account is bound to platform 1 with that id — which is what makes the
		// cached-login picker offer it, and the cached_login grant accept it.
		const payload = decodePayload(res.json.access_token as string)
		const accountId = Number(payload.sub)
		const linked = await cachedLogins(1, META_USER_ID)
		expect(linked).toContainEqual(
			expect.objectContaining({ accountId, platform: 1, platformId: META_USER_ID })
		)
		// Platform ownership is the credential, so the client is not asked for a password.
		expect(linked.every((a) => a.requirePassword === false)).toBe(true)
	})

	test('Meta create_account is rejected when Meta does not vouch for the nonce', async () => {
		const res = await metaLogin(
			`grant_type=create_account&platform=1&platform_id=${META_USER_ID}` +
				`&platform_auth=${encodeURIComponent(metaPlatformAuth())}`,
			false
		)
		expect(res.status).toBe(400)
		expect(res.json.error).toBe('invalid_grant')
		expect(res.json.error_description).toContain('platform_auth')
	})

	test('Meta cached_login logs into the linked account with no password', async () => {
		const userId = '27061366730209999'
		await env.DB.prepare('INSERT OR IGNORE INTO account (data) VALUES (?1)')
			.bind(
				JSON.stringify({
					accountId: 5150,
					username: 'MetaPlayer',
					platform: 1,
					platformId: userId,
				})
			)
			.run()
		await linkPlatformIdentity(env.DB, 5150, 1, userId)
		const res = await metaLogin(
			`grant_type=cached_login&account_id=5150&platform=1&platform_id=${userId}` +
				`&platform_auth=${encodeURIComponent(metaPlatformAuth())}`,
			true
		)
		expect(res.status).toBe(200)
		expect(res.graphCalls[0].get('user_id')).toBe(userId)
		const payload = decodePayload(res.json.access_token as string)
		expect(payload.sub).toBe('5150')
	})

	test('a Meta user id cannot log into an account it is not linked to', async () => {
		// The Meta account seeded above, claimed by a different (but genuinely proven)
		// Meta user. Even with a nonce Meta vouches for, the identity has to be one the
		// account is actually linked to.
		const res = await metaLogin(
			`grant_type=cached_login&account_id=5150&platform=1&platform_id=${META_USER_ID}` +
				`&platform_auth=${encodeURIComponent(metaPlatformAuth())}`,
			true
		)
		expect(res.status).toBe(400)
		expect(res.json.error_description).toContain('no linked account')
	})

	test('a Meta login is refused (500) when META_APP_SECRET is unset', async () => {
		// An operator misconfiguration, not a bad credential: without the secret no nonce
		// can be validated, and the alternative — trusting the posted platform_id — would
		// let anyone log into any Meta-linked account by naming its user id.
		const admin = adminSecretsStore(env.META_APP_SECRET)
		await admin.update('', metaSecretId)
		try {
			const res = await metaLogin(
				`grant_type=create_account&platform=1&platform_id=${META_USER_ID}` +
					`&platform_auth=${encodeURIComponent(metaPlatformAuth())}`,
				true
			)
			expect(res.status).toBe(500)
			expect(res.json.error).toBe('server_error')
			// Nothing was asked of Meta, and nothing was trusted.
			expect(res.graphCalls).toHaveLength(0)
		} finally {
			await admin.update(META_APP_SECRET, metaSecretId)
		}
	})

	test('cachedlogin/forplatformid returns the DTO for a bound (Steam) account', async () => {
		// Seed a Steam-linked account directly (a real create_account needs a live
		// ticket); assert the picker projects the CachedLogin DTO the client expects.
		const steamId = '76561197962463299'
		await env.DB.prepare('INSERT OR IGNORE INTO account (data) VALUES (?1)')
			.bind(
				JSON.stringify({
					accountId: 31380,
					username: 'SteamPlayer',
					platform: 0,
					platformId: steamId,
					lastLoginTime: '2026-07-09T21:20:31.419Z',
				})
			)
			.run()
		await linkPlatformIdentity(env.DB, 31380, 0, steamId)
		const res = await exports.default.fetch(`${ORIGIN}/cachedlogin/forplatformid/0/${steamId}`)
		expect(res.status).toBe(200)
		expect(await res.json()).toEqual([
			{
				platform: 0,
				platformId: steamId,
				accountId: 31380,
				lastLoginTime: '2026-07-09T21:20:31.419Z',
				requirePassword: false,
			},
		])
	})

	// A Discord link is an external identity, not a credential — `www`'s benefits claim
	// writes one so a claimed Discord user can't claim again on a second account. It must
	// stay invisible to BOTH picker routes, for two independent reasons:
	//
	//  - Every entry the picker lists is promised to be redeemable by a `cached_login`
	//    grant, and that grant refuses platform 101 outright (verifyPlatformProof answers
	//    `unsupported`). Listing one offers the client an account it can never log into.
	//  - These routes are PUBLIC and unauthenticated, and a Discord snowflake is readable by
	//    anyone sharing a server with its owner. Answering here would turn the login picker
	//    into a lookup from "Discord user" to "their RecFlare account", for every player who
	//    ever claimed benefits.
	//
	// The bare-id route is checked too, and it is the easier one to miss: it matches on ANY
	// platform, so it would resolve the snowflake even though naming 101 explicitly did not.
	test('never lists a Discord link in either cached-login picker', async () => {
		const discordId = '308994132968210433'
		await env.DB.prepare('INSERT OR IGNORE INTO account (data) VALUES (?1)')
			.bind(JSON.stringify({ accountId: 31399, username: 'DiscordClaimer', hasPlus: true }))
			.run()
		await linkPlatformIdentity(env.DB, 31399, PlatformType.Discord, discordId)

		// Named explicitly…
		const named = await exports.default.fetch(
			`${ORIGIN}/cachedlogin/forplatformid/${PlatformType.Discord}/${discordId}`
		)
		expect(named.status).toBe(200)
		expect(await named.json()).toEqual([])

		// …and via the bare id, which matches across platforms.
		const bare = await exports.default.fetch(`${ORIGIN}/cachedlogin/forplatformid/any/${discordId}`)
		expect(await bare.json()).toEqual([])

		// …and through the bulk friends-resolution route, which takes bare ids only.
		const bulk = await exports.default.fetch(`${ORIGIN}/cachedlogin/forplatformids`, {
			method: 'POST',
			headers: { 'content-type': 'application/x-www-form-urlencoded' },
			body: new URLSearchParams({ id: discordId }).toString(),
		})
		expect(await bulk.json()).toEqual([])

		// The link is still really there — this is a filtered READ, not a failed write.
		await expect(
			countAccountsForPlatformIdentity(env.DB, PlatformType.Discord, discordId)
		).resolves.toBe(1)
	})

	// The `role` column (migration 0010): what the benefits claim read about a member, kept
	// so "why does this account have Plus" is answerable later. Exercised through the helper
	// rather than the claim route, which runs through discord.com.
	test('records the roles a claimed Discord identity held, and refreshes them on a re-claim', async () => {
		const discordId = '308994132968210434'
		const supporter = '1077000000000000001'
		const booster = '1077000000000000002'
		await env.DB.prepare('INSERT OR IGNORE INTO account (data) VALUES (?1)')
			.bind(JSON.stringify({ accountId: 31400, username: 'RoleClaimer', hasPlus: true }))
			.run()

		await linkPlatformIdentity(env.DB, 31400, PlatformType.Discord, discordId, [supporter])
		const first = await getLinksForAccount(env.DB, 31400)
		// Snowflakes come back as STRINGS — parsed as numbers they'd round past 2^53 and stop
		// matching the real role.
		expect(first.map((l) => l.roles)).toEqual([[supporter]])

		// A re-claim is the same row (INSERT OR IGNORE, so `linkedAt` is the first claim's)
		// with a FRESH role list: a membership moves, and this reading is the later one.
		await linkPlatformIdentity(env.DB, 31400, PlatformType.Discord, discordId, [supporter, booster])
		const second = await getLinksForAccount(env.DB, 31400)
		expect(second).toHaveLength(1)
		expect(second[0]?.roles).toEqual([supporter, booster])
		expect(second[0]?.linkedAt).toBe(first[0]?.linkedAt)

		// Losing every role still stores the reading. Empty is a fact about the claim, not an
		// absence of one — and it is what distinguishes this from a Steam link, below.
		await linkPlatformIdentity(env.DB, 31400, PlatformType.Discord, discordId, [])
		expect((await getLinksForAccount(env.DB, 31400))[0]?.roles).toEqual([])
		const stored = await env.DB.prepare(
			'SELECT role FROM platform_account WHERE account_id = 31400'
		).first<{ role: string | null }>()
		expect(stored?.role).toBe('[]')
	})

	// Every login path omits the argument, because Steam and Meta have no such thing. The
	// column stays NULL there rather than becoming `[]`, so the table can still tell "never
	// had roles" from "claimed holding none".
	test('leaves the role column null for a link with no roles to record', async () => {
		const steamId = '76561197962463299'
		await env.DB.prepare('INSERT OR IGNORE INTO account (data) VALUES (?1)')
			.bind(JSON.stringify({ accountId: 31401, username: 'NoRoles' }))
			.run()
		await linkPlatformIdentity(env.DB, 31401, PlatformType.Steam, steamId)

		const row = await env.DB.prepare(
			'SELECT role FROM platform_account WHERE account_id = 31401'
		).first<{ role: string | null }>()
		expect(row?.role).toBeNull()
		// A NULL reads back as no roles rather than throwing — which is also how a row written
		// before 0010 reads.
		expect((await getLinksForAccount(env.DB, 31401))[0]?.roles).toEqual([])
	})

	// The 20250424.01 build POSTs the picker lookup with a platform-attestation form body
	// instead of GETting it. Nothing reads that body yet, so both methods must answer the
	// same list — otherwise the newer client's login screen comes up empty.
	test('POST /cachedlogin/forplatformid answers exactly what the GET answers', async () => {
		const steamId = '76561197962463211'
		await env.DB.prepare('INSERT OR IGNORE INTO account (data) VALUES (?1)')
			.bind(
				JSON.stringify({
					accountId: 31381,
					username: 'SteamPlayer2025',
					platform: 0,
					platformId: steamId,
					lastLoginTime: '2026-08-13T04:21:34.768Z',
				})
			)
			.run()
		await linkPlatformIdentity(env.DB, 31381, 0, steamId)

		// The body as the live client sends it: device id, the platform session ticket, a
		// timestamp. All ignored for now.
		const body = new URLSearchParams({
			deviceId: '69640e6ae1b54ae5b0ca8eeb4a8872ec6cf8fd88',
			platformAuth: JSON.stringify({ Ticket: '140000009C5F501B447424FF', AppId: '471710' }),
			time: '2026-08-13T04:21:34.7684754Z',
		}).toString()
		const posted = await exports.default.fetch(`${ORIGIN}/cachedlogin/forplatformid/0/${steamId}`, {
			method: 'POST',
			headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
			body,
		})
		expect(posted.status).toBe(200)
		const expected = [
			{
				platform: 0,
				platformId: steamId,
				accountId: 31381,
				lastLoginTime: '2026-08-13T04:21:34.768Z',
				requirePassword: false,
			},
		]
		expect(await posted.json()).toEqual(expected)
		expect(await cachedLogins(0, steamId)).toEqual(expected)
	})

	// A POST with no body at all still resolves — the client's body is never consulted.
	test('POST /cachedlogin/forplatformid/1/1 still returns the canned Oculus entry', async () => {
		const res = await exports.default.fetch(`${ORIGIN}/cachedlogin/forplatformid/1/1`, {
			method: 'POST',
		})
		expect(res.status).toBe(200)
		expect(await res.json()).toMatchObject([{ accountId: 1, requirePassword: true }])
	})

	test('one account, a Steam and a Meta identity: both pickers offer it', async () => {
		// The point of the link table. The same account is reachable from the PC and from
		// the headset, and each picker reports the identity IT was asked about — that's
		// what the client posts back on the cached_login grant.
		const steamId = '76561197962463777'
		const metaId = '27061366730207777'
		await env.DB.prepare('INSERT OR IGNORE INTO account (data) VALUES (?1)')
			.bind(
				JSON.stringify({
					accountId: 6200,
					username: 'CrossPlatform',
					platform: 0,
					platformId: steamId,
					lastLoginTime: '2026-08-01T10:00:00.000Z',
				})
			)
			.run()
		await linkPlatformIdentity(env.DB, 6200, 0, steamId)
		await linkPlatformIdentity(env.DB, 6200, 1, metaId)

		const onSteam = await cachedLogins(0, steamId)
		const onMeta = await cachedLogins(1, metaId)

		expect(onSteam).toEqual([
			expect.objectContaining({ accountId: 6200, platform: 0, platformId: steamId }),
		])
		expect(onMeta).toEqual([
			expect.objectContaining({ accountId: 6200, platform: 1, platformId: metaId }),
		])

		// And the grant accepts both, without a password.
		const viaMeta = await metaLogin(
			`grant_type=cached_login&account_id=6200&platform=1&platform_id=${metaId}` +
				`&platform_auth=${encodeURIComponent(metaPlatformAuth())}`,
			true
		)
		expect(viaMeta.status).toBe(200)
		expect(decodePayload(viaMeta.json.access_token as string).sub).toBe('6200')
	})

	test('the picker and the cached_login grant read the same table', async () => {
		// Regression: the picker used to derive links from the account blob (treating a
		// missing `platform` as Steam) while the grant ran its own check, so the client
		// could be handed an account_id that answered "no linked account" forever. Both
		// now read platform_account, which is why an account with a stale blob identity
		// is NOT offered — and, since it isn't offered, never rejected either.
		const steamId = '76561197962463211'
		await env.DB.prepare('INSERT OR IGNORE INTO account (data) VALUES (?1)')
			.bind(JSON.stringify({ accountId: 8, username: 'SteamOnly', platformId: steamId }))
			.run()

		// No link row yet: not offered.
		const before = await cachedLogins(0, steamId)
		expect(before.map((a) => a.accountId)).not.toContain(8)

		// The 0007 backfill is what gives accounts like this one — bound before the link
		// table existed, and carrying no `platform` field at all — their link.
		await env.DB.prepare(PLATFORM_BACKFILL_SQL).run()

		const after = await cachedLogins(0, steamId)
		expect(after.map((a) => a.accountId)).toContain(8)
		// COALESCEd to Steam, which is what an unset platform meant.
		expect(after.find((a) => a.accountId === 8)?.platform).toBe(0)
	})

	test('POST /connect/token issues a bearer token with role/scope claims', async () => {
		const res = await exports.default.fetch(`${ORIGIN}/connect/token`, {
			method: 'POST',
			headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
			body: `account_id=42&platform_id=steam-123&password=${LOGIN_PASSWORD}`,
		})
		expect(res.status).toBe(200)
		const json = (await res.json()) as {
			access_token: string
			token_type: string
			expires_in: number
		}
		expect(json.token_type).toBe('Bearer')
		expect(json.expires_in).toBe(TOKEN_TTL_SECONDS)
		// header.payload.signature
		const parts = json.access_token.split('.')
		expect(parts).toHaveLength(3)

		// The client reads these claims to authorize itself; decode and assert them.
		const payload = JSON.parse(
			new TextDecoder().decode(
				Uint8Array.from(atob(parts[1].replace(/-/g, '+').replace(/_/g, '/')), (ch) =>
					ch.charCodeAt(0)
				)
			)
		) as Record<string, unknown>
		expect(payload.sub).toBe('42') // account_id from the body is honored
		expect(payload.iss).toBe('https://auth.recflare.net')
		expect(payload.aud).toBe('https://auth.recflare.net')
		expect(payload.role).toContain('gameClient')
		// Screen sharing is disabled until staff explicitly grant it.
		expect(payload.role).not.toContain('screenshare')
		// A plain adult account carries nothing beyond those — no elevated roles.
		expect(payload.role).not.toContain('developer')
		expect(payload.role).not.toContain('moderator')
		expect(payload.role).not.toContain('junior')
		// Studio upload access is a whitelist, not a default role.
		expect(payload.role).not.toContain('betastudio')
		// No privileges to carry, so the claim is absent rather than an empty array.
		expect(payload['rn.privilege']).toBeUndefined()
		// Same for Plus: omitted rather than `false`, so a non-subscriber's token is
		// byte-for-byte what it was before `rn.plus` existed.
		expect(payload['rn.plus']).toBeUndefined()
		expect(payload.scope).toContain('rn.api')
	})

	// `rn.ver` is the CLIENT's build, from the `ver` it posts here — presence in `match`
	// reads it back off the token, so this is what a player is reported as running.
	test('POST /connect/token stamps the posted ver into rn.ver', async () => {
		const payload = await tokenFor(`account_id=42&password=${LOGIN_PASSWORD}&ver=20250718.01`)
		expect(payload['rn.ver']).toBe('20250718.01')
	})

	// A grant that names no build — a refresh, or a caller that isn't the game — falls
	// back to the server's GAME_VERSION rather than stamping an empty claim, which would
	// leave presence carrying an empty version.
	test('POST /connect/token falls back to GAME_VERSION with no ver', async () => {
		expect((await tokenFor(`account_id=42&password=${LOGIN_PASSWORD}`))['rn.ver']).toBe(
			GAME_VERSION
		)
		expect((await tokenFor(`account_id=42&password=${LOGIN_PASSWORD}&ver=`))['rn.ver']).toBe(
			GAME_VERSION
		)
	})

	test('POST /connect/token stamps developer/moderator roles into the token', async () => {
		await env.DB.prepare('INSERT OR IGNORE INTO account (data) VALUES (?1)')
			.bind(
				JSON.stringify({
					accountId: 91,
					username: 'StaffPlayer',
					passwordHash: await hashPassword(LOGIN_PASSWORD),
					isDeveloper: true,
					isModerator: true,
				})
			)
			.run()
		const payload = await tokenFor(`account_id=91&password=${LOGIN_PASSWORD}`)
		expect(payload.role).toEqual(expect.arrayContaining(['gameClient', 'developer', 'moderator']))
		// developer is a different grant. It does not set the account's hasStudio flag.
		expect(payload.role).not.toContain('betastudio')
	})

	// RecFlare Studio treats the role claim `betastudio` as permission to upload.
	// It is stamped from the account's hasStudio flag on every mint path — password,
	// refresh, and the Studio device grant — and a refresh after a revoke drops it. A
	// token that kept the role for the rest of the day would leave a removed player
	// uploading.
	test('screen sharing requires a staff grant on login, refresh, and role lookup', async () => {
		await seedAccount(9819, 'ScreenSharePlayer')
		expect((await tokenFor(`account_id=9819&password=${LOGIN_PASSWORD}`)).role).not.toContain(
			'screenshare'
		)
		await updateAccount(env.DB, 9819, { hasScreenshare: true })
		const granted = await tokenFor(`account_id=9819&password=${LOGIN_PASSWORD}`)
		expect(granted.role).toContain('screenshare')
		expect(await (await exports.default.fetch(`${ORIGIN}/role/screenshare/9819`)).json()).toBe(true)
		const session = await postToken(`account_id=9819&password=${LOGIN_PASSWORD}`)
		const sessionBody = session.json as { refresh_token: string }
		await updateAccount(env.DB, 9819, { hasScreenshare: false })
		const refresh = await exports.default.fetch(`${ORIGIN}/connect/token`, {
			method: 'POST',
			headers: { 'content-type': 'application/x-www-form-urlencoded' },
			body: new URLSearchParams({
				grant_type: 'refresh_token',
				refresh_token: sessionBody.refresh_token,
			}),
		})
		expect(refresh.status).toBe(200)
		const refreshed = (await refresh.json()) as { access_token: string }
		const payload = JSON.parse(
			atob(refreshed.access_token.split('.')[1].replace(/-/g, '+').replace(/_/g, '/'))
		)
		expect(payload.role).not.toContain('screenshare')
		expect(await (await exports.default.fetch(`${ORIGIN}/role/screenshare/9819`)).json()).toBe(
			false
		)
	})

	test('POST /connect/token stamps betastudio only while the account has hasStudio', async () => {
		// 9811/9812, not 9601–9605: those ids belong to the staff-login audit tests,
		// which insert with OR IGNORE and then count `staff_login` rows.
		await seedAccount(9811, 'StudioPlayer')
		expect((await tokenFor(`account_id=9811&password=${LOGIN_PASSWORD}`)).role).not.toContain(
			'betastudio'
		)

		await updateAccount(env.DB, 9811, { hasStudio: true })
		expect((await tokenFor(`account_id=9811&password=${LOGIN_PASSWORD}`)).role).toEqual([
			'gameClient',
			'betastudio',
		])

		// developer and moderator stay in front of betastudio, so the claim order is stable.
		await env.DB.prepare('INSERT OR IGNORE INTO account (data) VALUES (?1)')
			.bind(
				JSON.stringify({
					accountId: 9812,
					username: 'StudioStaff',
					passwordHash: await hashPassword(LOGIN_PASSWORD),
					isDeveloper: true,
					isModerator: true,
					hasStudio: true,
				})
			)
			.run()
		expect((await tokenFor(`account_id=9812&password=${LOGIN_PASSWORD}`)).role).toEqual([
			'gameClient',
			'developer',
			'moderator',
			'betastudio',
		])

		const client = `client_id=${STUDIO_CLIENT_ID}&client_secret=${STUDIO_CLIENT_SECRET}`
		const started = await exports.default.fetch(`${ORIGIN}/connect/deviceauthorization`, {
			method: 'POST',
			headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
			body: client,
		})
		expect(started.status).toBe(200)
		const codes = (await started.json()) as { device_code: string; user_code: string }
		const session = await postToken(
			`grant_type=password&username=StudioPlayer&password=${LOGIN_PASSWORD}`
		)
		expect(session.status).toBe(200)
		const approved = await exports.default.fetch(`${ORIGIN}/connect/device/approve`, {
			method: 'POST',
			headers: {
				'Content-Type': 'application/x-www-form-urlencoded',
				Authorization: `Bearer ${session.json.access_token as string}`,
			},
			body: `user_code=${codes.user_code}`,
		})
		expect(approved.status).toBe(200)
		const signedIn = await postToken(
			`${client}&grant_type=${encodeURIComponent('urn:ietf:params:oauth:grant-type:device_code')}&device_code=${codes.device_code}`
		)
		expect(signedIn.status).toBe(200)
		expect(decodePayload(signedIn.json.access_token as string).role).toEqual([
			'gameClient',
			'betastudio',
		])

		// Revoke between issue and refresh. The refresh re-reads the account.
		const login = await postToken(`account_id=9811&password=${LOGIN_PASSWORD}`)
		await updateAccount(env.DB, 9811, { hasStudio: false })
		await updateAccount(env.DB, 9812, { hasStudio: false })
		const refreshed = await postToken(
			`grant_type=refresh_token&refresh_token=${encodeURIComponent(login.json.refresh_token as string)}`
		)
		expect(refreshed.status).toBe(200)
		expect(decodePayload(refreshed.json.access_token as string).role).not.toContain('betastudio')
	})

	// STUDIO_ROLLOUT opens Studio to a Discord ROLE: a holder is stamped `betastudio` exactly
	// as a flagged account is, with no account flag involved, from the same Discord link
	// snapshot the build rollout gate reads. Unset, the flag alone decides.
	test('POST /connect/token stamps betastudio for a Discord role in STUDIO_ROLLOUT', async () => {
		const studioRole = '1077000000000000031'
		const otherRole = '1077000000000000032'
		await seedAccount(9813, 'StudioRoleHolder')
		await linkPlatformIdentity(env.DB, 9813, PlatformType.Discord, '500000000000009813', [
			studioRole,
		])
		await seedAccount(9814, 'StudioRoleOutsider')
		await linkPlatformIdentity(env.DB, 9814, PlatformType.Discord, '500000000000009814', [
			otherRole,
		])
		const login = (id: number) => tokenFor(`account_id=${id}&password=${LOGIN_PASSWORD}`)

		const original = env.STUDIO_ROLLOUT
		try {
			// Unset, or naming no role: the link grants nothing.
			delete env.STUDIO_ROLLOUT
			expect((await login(9813)).role).not.toContain('betastudio')
			env.STUDIO_ROLLOUT = ' , '
			expect((await login(9813)).role).not.toContain('betastudio')

			// Same list grammar as DISCORD_ROLLOUT_ROLE_IDS; any one named role qualifies.
			env.STUDIO_ROLLOUT = ` ${otherRole}x ,\n${studioRole} `
			expect((await login(9813)).role).toEqual(['gameClient', 'betastudio'])
			// A Discord link holding only other roles is not in the rollout.
			expect((await login(9814)).role).not.toContain('betastudio')
			// The account flag never moved: this is the var, not a grant written anywhere.
			expect((await getAccount(env.DB, 9813))?.hasStudio).toBeUndefined()

			// The refresh grant re-resolves it, so ending the rollout drops the claim on the
			// next refresh — the same path a revoked flag takes.
			const session = await postToken(`account_id=9813&password=${LOGIN_PASSWORD}`)
			delete env.STUDIO_ROLLOUT
			const refreshed = await postToken(
				`grant_type=refresh_token&refresh_token=${encodeURIComponent(session.json.refresh_token as string)}`
			)
			expect(refreshed.status).toBe(200)
			expect(decodePayload(refreshed.json.access_token as string).role).not.toContain('betastudio')
		} finally {
			if (original === undefined) delete env.STUDIO_ROLLOUT
			else env.STUDIO_ROLLOUT = original
		}
	})

	// Rec Room Plus rides on the token as `rn.plus`, stamped from `account.hasPlus` — which
	// the website's Discord benefits claim sets. `econ` decides the CampusCard and the
	// subscriber discount from this claim ALONE and never reads the account, so if this
	// stops being stamped, Plus silently stops existing for everyone.
	//
	// It is a CLAIM, not a scope: `scope` is a fixed list the client parses, and this is
	// ours. And it is not a role — the `developer` role does not confer Plus.
	test('POST /connect/token stamps rn.plus for a hasPlus account', async () => {
		await env.DB.prepare('INSERT OR IGNORE INTO account (data) VALUES (?1)')
			.bind(
				JSON.stringify({
					accountId: 93,
					username: 'PlusPlayer',
					passwordHash: await hashPassword(LOGIN_PASSWORD),
					hasPlus: true,
				})
			)
			.run()
		const payload = await tokenFor(`account_id=93&password=${LOGIN_PASSWORD}`)
		expect(payload['rn.plus']).toBe(true)
		expect(payload.scope).not.toContain('rn.plus')
		// Plus is not an elevated role, and does not come with one.
		expect(payload.role).not.toContain('developer')
	})

	// The flag is read at LOGIN, so signing in again is what activates it — the website's
	// claim page and `runx admin grant-plus` both say so, and this is the mechanism behind it.
	//
	// This also pins that `hasPlus` stands ALONE: the flag is set here by raw SQL, exactly as
	// `runx admin grant-plus` sets it, with no Discord app configured, no OAuth exchange and
	// no `platform_account` link anywhere. An operator must be able to grant Plus outright.
	test('rn.plus refreshes on the next login after hasPlus is set, with no Discord link', async () => {
		await env.DB.prepare('INSERT OR IGNORE INTO account (data) VALUES (?1)')
			.bind(
				JSON.stringify({
					accountId: 94,
					username: 'LateClaimer',
					passwordHash: await hashPassword(LOGIN_PASSWORD),
				})
			)
			.run()
		// Before claiming: no Plus.
		expect((await tokenFor(`account_id=94&password=${LOGIN_PASSWORD}`))['rn.plus']).toBeUndefined()

		// The website's claim writes the flag…
		await env.DB.prepare(
			"UPDATE account SET data = json_set(data, '$.hasPlus', json('true')) WHERE account_id = 94"
		).run()

		// …and the NEXT token carries it. The one already in the player's hands does not,
		// which is exactly why they have to sign in again.
		expect((await tokenFor(`account_id=94&password=${LOGIN_PASSWORD}`))['rn.plus']).toBe(true)

		// Nothing linked a Discord identity to this account, and Plus does not care.
		const links = await getLinksForAccount(env.DB, 94)
		expect(links.filter((l) => l.platform === PlatformType.Discord)).toEqual([])
	})

	test('POST /connect/token stamps the junior role for an isJunior account', async () => {
		await env.DB.prepare('INSERT OR IGNORE INTO account (data) VALUES (?1)')
			.bind(
				JSON.stringify({
					accountId: 92,
					username: 'JuniorPlayer',
					passwordHash: await hashPassword(LOGIN_PASSWORD),
					isJunior: true,
				})
			)
			.run()
		const payload = await tokenFor(`account_id=92&password=${LOGIN_PASSWORD}`)
		expect(payload.role).toEqual(expect.arrayContaining(['gameClient', 'junior']))
		expect(payload.role).not.toContain('developer')
		// `rn.privilege` is a claim, not a scope — it sits beside `role`, never in `scope`.
		expect(payload['rn.privilege']).toEqual(['BanVChat', 'BanRmChat'])
		expect(payload.scope).not.toContain('rn.privilege')
	})

	test('POST /connect/token stamps the influencer role for an isInfluencer account', async () => {
		await env.DB.prepare('INSERT OR IGNORE INTO account (data) VALUES (?1)')
			.bind(
				JSON.stringify({
					accountId: 95,
					username: 'InfluencerPlayer',
					passwordHash: await hashPassword(LOGIN_PASSWORD),
					isInfluencer: true,
				})
			)
			.run()
		const payload = await tokenFor(`account_id=95&password=${LOGIN_PASSWORD}`)
		expect(payload.role).toEqual(expect.arrayContaining(['gameClient', 'influencer']))
		expect(payload.role).not.toContain('developer')

		// Off the flag, off the token — no other flag implies it.
		await updateAccount(env.DB, 95, { isInfluencer: false })
		const revoked = await tokenFor(`account_id=95&password=${LOGIN_PASSWORD}`)
		expect(revoked.role).not.toContain('influencer')
	})

	test('POST /connect/token 400s when no account_id is posted (never defaults to 1)', async () => {
		const res = await exports.default.fetch(`${ORIGIN}/connect/token`, { method: 'POST' })
		expect(res.status).toBe(400)
		expect((await res.json()) as { error: string }).toMatchObject({ error: 'invalid_request' })
	})

	test('POST /connect/token 400s on a non-numeric account_id', async () => {
		const res = await exports.default.fetch(`${ORIGIN}/connect/token`, {
			method: 'POST',
			headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
			body: 'account_id=notanumber',
		})
		expect(res.status).toBe(400)
	})

	test('POST /connect/token rejects a credential login with the wrong password', async () => {
		const res = await postToken('account_id=42&password=wrong-password')
		expect(res.status).toBe(400)
		expect(res.json.error).toBe('invalid_grant')
	})

	test('POST /connect/token rejects a credential login with no password', async () => {
		const res = await postToken('account_id=42')
		expect(res.status).toBe(400)
		expect(res.json.error).toBe('invalid_grant')
	})

	test('POST /connect/token refuses login to an account with no password set', async () => {
		// Account 999 exists but never set a password — it has no credential to verify,
		// so login by id alone is refused (this is the closed takeover hole).
		await env.DB.prepare('INSERT OR IGNORE INTO account (data) VALUES (?1)')
			.bind(JSON.stringify({ accountId: 999, username: 'NoPass' }))
			.run()
		const res = await postToken('account_id=999&password=anything')
		expect(res.status).toBe(400)
		expect(res.json.error).toBe('invalid_grant')
	})

	test('POST /connect/token create_account can set a password used for later login', async () => {
		const created = await postToken(
			'grant_type=create_account&platform_id=steam-pw2&password=hunter2'
		)
		expect(created.status).toBe(200)
		const sub = decodePayload(created.json.access_token as string).sub as string

		// The password set at creation authenticates a subsequent credential login.
		const ok = await postToken(`account_id=${sub}&password=hunter2`)
		expect(ok.status).toBe(200)
		// A wrong password for that same account is rejected.
		const bad = await postToken(`account_id=${sub}&password=nope`)
		expect(bad.status).toBe(400)
	})

	test('POST /connect/token logs in by username (RecRoom password grant)', async () => {
		// The RecRoom client posts the username, not the account_id — case-insensitively
		// and with a trailing space, both of which must still resolve account 42.
		const res = await postToken(
			`grant_type=password&username=player42%20&password=${LOGIN_PASSWORD}`
		)
		expect(res.status).toBe(200)
		expect(decodePayload(res.json.access_token as string).sub).toBe('42')
	})

	test('POST /connect/token rejects a username login with the wrong password', async () => {
		const res = await postToken(`grant_type=password&username=Player42&password=wrong`)
		expect(res.status).toBe(400)
		expect(res.json.error).toBe('invalid_grant')
	})

	test('POST /connect/token 400s on an unknown username', async () => {
		const res = await postToken(`grant_type=password&username=NoSuchUser&password=whatever`)
		expect(res.status).toBe(400)
		expect(res.json.error).toBe('invalid_request')
	})

	test('POST /connect/token grant_type=create_account persists a new account', async () => {
		const payload = await tokenFor('grant_type=create_account&platform_id=steam-123')
		// The token's sub is the new account id, allocated above the system accounts.
		const sub = Number.parseInt(payload.sub as string, 10)
		expect(sub).toBeGreaterThanOrEqual(2)
		// The account exists in the DB with an auto-assigned (non-default) username.
		const row = await env.DB.prepare('SELECT data FROM account WHERE account_id = ?1')
			.bind(sub)
			.first<{ data: string }>()
		expect(row).not.toBeNull()
		const account = JSON.parse(row!.data) as { username: string }
		expect(account.username).not.toMatch(/^Player\d+$/)
	})

	test('POST /connect/token create_account stores the login device on the account', async () => {
		const deviceId = '69640e6ae1b54ae5b0ca8eeb4a8872ec6cf8fd88'
		const payload = await tokenFor(
			`grant_type=create_account&platform_id=steam-dev1&device_id=${deviceId}&device_class=2`
		)
		const sub = Number.parseInt(payload.sub as string, 10)
		const row = await env.DB.prepare('SELECT data FROM account WHERE account_id = ?1')
			.bind(sub)
			.first<{ data: string }>()
		const account = JSON.parse(row!.data) as { deviceId: string; deviceClass: number }
		expect(account.deviceId).toBe(deviceId)
		expect(account.deviceClass).toBe(2)

		// Accounts sharing a device can be found later (account linkup).
		const shared = await getAccountsByDeviceId(env.DB, deviceId)
		expect(shared.map((a) => a.accountId)).toContain(sub)
	})

	test('POST /connect/token stores deviceClass as an integer, not a REAL', async () => {
		// D1 binds a JS number as a SQLite REAL, so a naive json_set writes `"deviceClass":2.0`
		// into the blob. JSON.parse tolerates that, but the raw JSON is what other readers
		// (and any strict int parser) see, so assert on the stored TEXT, not the parsed value.
		await postToken(
			`grant_type=password&username=Player77&password=${LOGIN_PASSWORD}&device_id=dev-int&device_class=2`
		)
		const row = await env.DB.prepare('SELECT data FROM account WHERE account_id = ?1')
			.bind(77)
			.first<{ data: string }>()
		expect(row!.data).toContain('"deviceClass":2')
		// Keyed, not a bare '2.0': the row's lastLoginTime has milliseconds, so a login at
		// `…:02.045Z` would match that string on its own.
		expect(row!.data).not.toContain('"deviceClass":2.0')
	})

	// The grant the live client actually logs in with, and the one path whose device
	// recording had no test — `create_account` and the password grant were both pinned,
	// cached_login only happened to work. The body is the shape the 2025 client posts (see
	// the capture the device id below comes from): device_id alongside the platform
	// attestation, on every sign-in.
	//
	// Nothing verifies a device id — the client picks it — so it is recorded and never
	// authorized on. It is stored for ban EVASION to read later: an account logging in from
	// the same install as a banned one. See `getAccountsByDeviceId`.
	test('POST /connect/token cached_login stores the login device on the account', async () => {
		const metaId = '27061366730201234'
		await env.DB.prepare('INSERT OR IGNORE INTO account (data) VALUES (?1)')
			.bind(
				JSON.stringify({
					accountId: 5151,
					username: 'CachedDevicePlayer',
					platform: 1,
					platformId: metaId,
				})
			)
			.run()
		await linkPlatformIdentity(env.DB, 5151, 1, metaId)

		const deviceId = '69640e6ae1b54ae5b0ca8eeb4a8872ec6cf8fd88'
		const res = await metaLogin(
			`grant_type=cached_login&account_id=5151&platform=1&platform_id=${metaId}` +
				`&platform_auth=${encodeURIComponent(metaPlatformAuth())}` +
				`&device_id=${deviceId}&device_class=2&isInitialLogin=true&locale=en`,
			true
		)
		expect(res.status).toBe(200)

		const row = await env.DB.prepare('SELECT data FROM account WHERE account_id = ?1')
			.bind(5151)
			.first<{ data: string }>()
		const account = JSON.parse(row!.data) as { deviceId: string; deviceClass: number }
		expect(account.deviceId).toBe(deviceId)
		expect(account.deviceClass).toBe(2)
		// And findable by it, which is the whole reason it is kept.
		expect((await getAccountsByDeviceId(env.DB, deviceId)).map((a) => a.accountId)).toContain(5151)
	})

	// A refresh is NOT a login: the client redeems a stored token and re-attests nothing,
	// so there is no device to believe and the grant records none. Pinned because the
	// alternative is worse than it looks — trusting a device_id posted alongside a refresh
	// would let a client move an account's recorded device without ever proving anything,
	// which is exactly the signal ban evasion is meant to read.
	test('POST /connect/token refresh_token leaves the recorded device alone', async () => {
		const first = await postToken(
			`grant_type=password&username=Player77&password=${LOGIN_PASSWORD}` +
				'&device_id=dev-77-real&device_class=2'
		)
		expect(first.status).toBe(200)

		const refreshed = await postToken(
			`grant_type=refresh_token&refresh_token=${first.json.refresh_token as string}` +
				'&device_id=dev-77-spoofed&device_class=9'
		)
		expect(refreshed.status).toBe(200)

		const row = await env.DB.prepare('SELECT data FROM account WHERE account_id = ?1')
			.bind(77)
			.first<{ data: string }>()
		const account = JSON.parse(row!.data) as { deviceId: string; deviceClass: number }
		expect(account.deviceId).toBe('dev-77-real')
		expect(account.deviceClass).toBe(2)
	})

	test('POST /connect/token refreshes the stored device on a credential login', async () => {
		// Account 42 was seeded with no device; a later login records the one it came from.
		const res = await postToken(
			`grant_type=password&username=Player42&password=${LOGIN_PASSWORD}&device_id=dev-42-new&device_class=3`
		)
		expect(res.status).toBe(200)
		const row = await env.DB.prepare('SELECT data FROM account WHERE account_id = ?1')
			.bind(42)
			.first<{ data: string }>()
		const account = JSON.parse(row!.data) as { deviceId: string; deviceClass: number }
		expect(account.deviceId).toBe('dev-42-new')
		expect(account.deviceClass).toBe(3)
	})

	test('POST /connect/token create_account records the client IP', async () => {
		const payload = await tokenFor('grant_type=create_account&platform_id=steam-ip1', '203.0.113.7')
		const sub = Number.parseInt(payload.sub as string, 10)
		const row = await env.DB.prepare('SELECT data FROM account WHERE account_id = ?1')
			.bind(sub)
			.first<{ data: string }>()
		const account = JSON.parse(row!.data) as { signupIp: string; lastLoginIp: string }
		expect(account.signupIp).toBe('203.0.113.7')
		expect(account.lastLoginIp).toBe('203.0.113.7')
	})

	test('POST /connect/token caps the accounts created from one IP', async () => {
		const ip = '198.51.100.22'
		for (let i = 0; i < 3; i++) {
			const ok = await postToken(`grant_type=create_account&platform_id=steam-cap${i}`, ip)
			expect(ok.status).toBe(200)
		}
		// The 4th signup from that IP is refused — the cap is 3.
		const capped = await postToken('grant_type=create_account&platform_id=steam-cap3', ip)
		expect(capped.status).toBe(400)
		expect(capped.json.error).toBe('invalid_grant')
		expect(capped.json.error_description).toMatch(/network/)

		// A different IP is unaffected, and the capped IP can still LOG IN to what it has.
		const other = await postToken(
			'grant_type=create_account&platform_id=steam-cap4',
			'198.51.100.23'
		)
		expect(other.status).toBe(200)
	})

	test('POST /connect/token caps the accounts created from one device', async () => {
		// One install, many networks: the VPN-hopping signup the IP cap can't see. Each
		// signup posts a fresh IP so only the device arm can be what refuses it.
		const deviceId = 'dev-capped-install'
		for (let i = 0; i < 3; i++) {
			const ok = await postToken(
				`grant_type=create_account&platform_id=steam-devcap${i}&device_id=${deviceId}&device_class=2`,
				`198.51.100.${40 + i}`
			)
			expect(ok.status).toBe(200)
		}
		// The 4th signup from that device is refused — the cap is 3.
		const capped = await postToken(
			`grant_type=create_account&platform_id=steam-devcap3&device_id=${deviceId}&device_class=2`,
			'198.51.100.43'
		)
		expect(capped.status).toBe(400)
		expect(capped.json.error).toBe('invalid_grant')
		expect(capped.json.error_description).toMatch(/device/)

		// Another device is unaffected, and a signup that posts no device id (the website's)
		// can't be attributed to one, so the arm skips it rather than lumping it in.
		const other = await postToken(
			'grant_type=create_account&platform_id=steam-devcap4&device_id=dev-other-install&device_class=2',
			'198.51.100.44'
		)
		expect(other.status).toBe(200)
		const deviceless = await postToken(
			'grant_type=create_account&platform_id=steam-devcap5',
			'198.51.100.45'
		)
		expect(deviceless.status).toBe(200)

		// The capped device can still LOG IN to what it has — the cap is on signup only.
		const login = await postToken(
			`grant_type=password&username=Player42&password=${LOGIN_PASSWORD}&device_id=${deviceId}&device_class=2`,
			'198.51.100.46'
		)
		expect(login.status).toBe(200)
	})

	test('PASSWORD_SIGNUP=off refuses a no-platform create_account and mints nothing', async () => {
		// The switch the website's signup hangs off. Every other create_account test here
		// runs with it ON (see vitest.config.ts); this one is the closed door.
		const original = env.PASSWORD_SIGNUP
		try {
			env.PASSWORD_SIGNUP = 'off'
			const before = await env.DB.prepare('SELECT COUNT(*) AS n FROM account').first<{
				n: number
			}>()
			const refused = await postToken(
				'grant_type=create_account&password=hunter2&device_id=dev-web&device_class=2',
				'198.51.100.60'
			)
			expect(refused.status).toBe(400)
			expect(refused.json.error).toBe('invalid_grant')
			expect(refused.json.error_description).toBe('password signup is disabled')
			const after = await env.DB.prepare('SELECT COUNT(*) AS n FROM account').first<{
				n: number
			}>()
			expect(after?.n).toBe(before?.n)

			// Logging in is not what the switch gates: an existing password account still gets
			// its token, whatever the switch says.
			const login = await postToken(
				`grant_type=password&username=Player42&password=${LOGIN_PASSWORD}`,
				'198.51.100.60'
			)
			expect(login.status).toBe(200)

			// A platform signup is a different door: it still reaches platform verification
			// (and fails THERE, on the missing ticket) rather than being refused by the switch.
			const steam = await postToken(
				'grant_type=create_account&platform=0&platform_id=76561198000000001',
				'198.51.100.60'
			)
			expect(steam.status).toBe(400)
			expect(steam.json.error_description).not.toBe('password signup is disabled')

			// Unset is off too — the default an operator has to opt out of.
			delete env.PASSWORD_SIGNUP
			const unset = await postToken('grant_type=create_account&password=hunter2', '198.51.100.61')
			expect(unset.status).toBe(400)
			expect(unset.json.error_description).toBe('password signup is disabled')

			// And `on` reopens it.
			env.PASSWORD_SIGNUP = 'on'
			const open = await postToken('grant_type=create_account&password=hunter2', '198.51.100.62')
			expect(open.status).toBe(200)
		} finally {
			env.PASSWORD_SIGNUP = original
		}
	})

	// The rollout gate: build 20260323.14 is for Discord supporters only. A login posting it
	// as `ver` is refused unless the account's Discord link holds a role named in
	// DISCORD_ROLLOUT_ROLE_IDS; every other build, and a grant posting no `ver`, is untouched.
	describe('rollout gate on build 20260323.14', () => {
		const GATED = '20260323.14'
		const REFUSED =
			'this build is limited to Discord supporters; link your Discord on the website first'
		const supporter = '1077000000000000001'
		const booster = '1077000000000000002'
		const outsider = '1077000000000000009'

		async function seedAccount(id: number, username: string) {
			await env.DB.prepare('INSERT OR IGNORE INTO account (data) VALUES (?1)')
				.bind(
					JSON.stringify({
						accountId: id,
						username,
						passwordHash: await hashPassword(LOGIN_PASSWORD),
					})
				)
				.run()
		}

		const login = (username: string, ver?: string) =>
			postToken(
				`grant_type=password&username=${username}&password=${LOGIN_PASSWORD}` +
					(ver === undefined ? '' : `&ver=${ver}`)
			)

		async function withRoleIds<T>(value: string | undefined, run: () => Promise<T>): Promise<T> {
			// `env` is shared by every test in this file, so the override is restored in
			// `finally` rather than leaking a configured gate into the tests around this one.
			const original = env.DISCORD_ROLLOUT_ROLE_IDS
			if (value === undefined) delete env.DISCORD_ROLLOUT_ROLE_IDS
			else env.DISCORD_ROLLOUT_ROLE_IDS = value
			try {
				return await run()
			} finally {
				if (original === undefined) delete env.DISCORD_ROLLOUT_ROLE_IDS
				else env.DISCORD_ROLLOUT_ROLE_IDS = original
			}
		}

		beforeAll(async () => {
			await seedAccount(9301, 'gate_supporter')
			await linkPlatformIdentity(env.DB, 9301, PlatformType.Discord, '500000000000000001', [
				supporter,
			])
			await seedAccount(9302, 'gate_outsider')
			await linkPlatformIdentity(env.DB, 9302, PlatformType.Discord, '500000000000000002', [
				outsider,
			])
			await seedAccount(9303, 'gate_unlinked')
			// A Steam link is not a Discord link — it carries no roles to hold.
			await linkPlatformIdentity(env.DB, 9303, PlatformType.Steam, '76561198000009303')
			// Staff, with no Discord link at all.
			for (const [id, username, flag] of [
				[9304, 'gate_developer', 'isDeveloper'],
				[9305, 'gate_moderator', 'isModerator'],
			] as const) {
				await env.DB.prepare('INSERT OR IGNORE INTO account (data) VALUES (?1)')
					.bind(
						JSON.stringify({
							accountId: id,
							username,
							passwordHash: await hashPassword(LOGIN_PASSWORD),
							[flag]: true,
						})
					)
					.run()
			}
		})

		test('staff are let in with no Discord link, even with the gate closed', async () => {
			for (const roleIds of [undefined, supporter]) {
				await withRoleIds(roleIds, async () => {
					expect((await login('gate_developer', GATED)).status).toBe(200)
					expect((await login('gate_moderator', GATED)).status).toBe(200)
				})
			}
		})

		test('with no roles configured the gate is closed to every non-staff account', async () => {
			await withRoleIds(undefined, async () => {
				const res = await login('gate_supporter', GATED)
				expect(res.status).toBe(400)
				expect(res.json).toEqual({ error: 'invalid_grant', error_description: REFUSED })
			})
			// A value that parses to no ids is the same as unset.
			await withRoleIds(' , ', async () => {
				expect((await login('gate_supporter', GATED)).status).toBe(400)
			})
		})

		test('a configured role lets its holder in, and the token carries the build', async () => {
			await withRoleIds(`${booster},${supporter}`, async () => {
				const res = await login('gate_supporter', GATED)
				expect(res.status).toBe(200)
				const payload = decodePayload(res.json.access_token as string)
				expect(payload.sub).toBe('9301')
				expect(payload['rn.ver']).toBe(GATED)
			})
		})

		test('the list is split on commas and/or whitespace, like DISCORD_BENEFITS_ROLE_IDS', async () => {
			await withRoleIds(` ${booster} ,\n${supporter} `, async () => {
				expect((await login('gate_supporter', GATED)).status).toBe(200)
			})
		})

		test('a Discord link holding only other roles, or no Discord link at all, is refused', async () => {
			await withRoleIds(`${supporter},${booster}`, async () => {
				const other = await login('gate_outsider', GATED)
				expect(other.status).toBe(400)
				expect(other.json.error_description).toBe(REFUSED)

				const unlinked = await login('gate_unlinked', GATED)
				expect(unlinked.status).toBe(400)
				expect(unlinked.json.error_description).toBe(REFUSED)
			})
		})

		test('other builds, and grants posting no ver, are never gated', async () => {
			await withRoleIds(undefined, async () => {
				expect((await login('gate_outsider')).status).toBe(200)
				expect((await login('gate_outsider', GAME_VERSION)).status).toBe(200)
				expect((await login('gate_outsider', '20250718.01')).status).toBe(200)
				expect((await login('gate_unlinked', '20230414')).status).toBe(200)
			})
		})

		test('every point release of the gated build is gated', async () => {
			// The gate is on the BUILD (the bare date): the client's `.NN` is a same-day
			// rebuild, so `.14`, `.2` and the date alone are all the rollout build.
			await withRoleIds(undefined, async () => {
				for (const version of ['20260323', '20260323.2', '20260323.14']) {
					const res = await login('gate_outsider', version)
					expect(res.status, version).toBe(400)
					expect(res.json.error_description, version).toBe(REFUSED)
				}
			})
		})

		test('the credential is checked first, so the gate cannot probe for accounts', async () => {
			await withRoleIds(undefined, async () => {
				const res = await postToken(
					`grant_type=password&username=gate_outsider&password=wrong&ver=${GATED}`
				)
				expect(res.status).toBe(400)
				expect(res.json.error_description).toBe('invalid account_id or password')
			})
		})

		test('create_account on the build is refused before anything is minted', async () => {
			await withRoleIds(`${supporter}`, async () => {
				const before = await env.DB.prepare('SELECT COUNT(*) AS n FROM account').first<{
					n: number
				}>()
				const res = await postToken(
					`grant_type=create_account&platform_id=steam-gated&password=hunter2&ver=${GATED}`
				)
				expect(res.status).toBe(400)
				expect(res.json).toEqual({ error: 'invalid_grant', error_description: REFUSED })
				const after = await env.DB.prepare('SELECT COUNT(*) AS n FROM account').first<{
					n: number
				}>()
				expect(after?.n).toBe(before?.n)
			})
		})

		// The two lists behind the gates are vars (`SUPPORTED_GAME_VERSIONS`,
		// `ROLLOUT_GAME_VERSIONS`), so an operator can end the rollout or drop a build without
		// a deploy of new code. Same env-override discipline as withRoleIds.
		describe('the lists come from vars', () => {
			const UNSUPPORTED = 'this game version is not supported by this server; update your game'

			async function withVars<T>(
				vars: { SUPPORTED_GAME_VERSIONS?: string; ROLLOUT_GAME_VERSIONS?: string },
				run: () => Promise<T>
			): Promise<T> {
				const originals = {
					SUPPORTED_GAME_VERSIONS: env.SUPPORTED_GAME_VERSIONS,
					ROLLOUT_GAME_VERSIONS: env.ROLLOUT_GAME_VERSIONS,
				}
				const apply = (values: typeof originals) => {
					for (const key of ['SUPPORTED_GAME_VERSIONS', 'ROLLOUT_GAME_VERSIONS'] as const) {
						if (values[key] === undefined) delete env[key]
						else env[key] = values[key]
					}
				}
				apply({ ...originals, ...vars })
				try {
					return await run()
				} finally {
					apply(originals)
				}
			}

			test('a build dropped from SUPPORTED_GAME_VERSIONS is refused a token, staff included', async () => {
				await withVars({ SUPPORTED_GAME_VERSIONS: '20230414,20260323' }, async () => {
					await withRoleIds(undefined, async () => {
						// The 2025 build, every point release of it: this is the forced upgrade.
						for (const version of ['20250718', '20250718.01', '20250718.2']) {
							const res = await login('gate_outsider', version)
							expect(res.status, version).toBe(400)
							expect(res.json, version).toEqual({
								error: 'invalid_grant',
								error_description: UNSUPPORTED,
							})
						}
						// Staff get no exception here — the build is not served, full stop.
						expect((await login('gate_developer', '20250718.01')).status).toBe(400)
						// The builds that ARE listed, and a grant posting no `ver`, are untouched;
						// the rollout gate still applies to the one under rollout.
						expect((await login('gate_outsider', GAME_VERSION)).status).toBe(200)
						expect((await login('gate_outsider')).status).toBe(200)
						expect((await login('gate_developer', GATED)).status).toBe(200)
						expect((await login('gate_outsider', GATED)).json.error_description).toBe(REFUSED)
					})
				})
			})

			test('create_account on an unsupported build is refused before anything is minted', async () => {
				await withVars({ SUPPORTED_GAME_VERSIONS: '20230414' }, async () => {
					const before = await env.DB.prepare('SELECT COUNT(*) AS n FROM account').first<{
						n: number
					}>()
					const res = await postToken(
						'grant_type=create_account&platform_id=steam-unsupported&password=hunter2&ver=20250718.01'
					)
					expect(res.status).toBe(400)
					expect(res.json).toEqual({ error: 'invalid_grant', error_description: UNSUPPORTED })
					const after = await env.DB.prepare('SELECT COUNT(*) AS n FROM account').first<{
						n: number
					}>()
					expect(after?.n).toBe(before?.n)
				})
			})

			test('ROLLOUT_GAME_VERSIONS=off ends the rollout: the build opens to everyone', async () => {
				await withVars({ ROLLOUT_GAME_VERSIONS: 'off' }, async () => {
					await withRoleIds(undefined, async () => {
						const res = await login('gate_outsider', GATED)
						expect(res.status).toBe(200)
						expect(decodePayload(res.json.access_token as string)['rn.ver']).toBe(GATED)
						expect((await login('gate_unlinked', GATED)).status).toBe(200)
						// ...and accounts can be created on it, since nothing needs a Discord link.
						const created = await postToken(
							`grant_type=create_account&platform_id=steam-rollout-over&password=hunter2&ver=${GATED}`
						)
						expect(created.status).toBe(200)
					})
				})
			})

			test('ROLLOUT_GAME_VERSIONS names which builds are gated', async () => {
				// Move the gate onto the beta build: it is now supporters-only and the 2026
				// build is open. Both stay served.
				await withVars({ ROLLOUT_GAME_VERSIONS: '20250718' }, async () => {
					await withRoleIds(supporter, async () => {
						const outsider = await login('gate_outsider', '20250718.01')
						expect(outsider.status).toBe(400)
						expect(outsider.json.error_description).toBe(REFUSED)
						expect((await login('gate_supporter', '20250718.01')).status).toBe(200)
						expect((await login('gate_outsider', GATED)).status).toBe(200)
					})
				})
			})

			test('a build under rollout is served even when SUPPORTED_GAME_VERSIONS omits it', async () => {
				await withVars({ SUPPORTED_GAME_VERSIONS: '20230414' }, async () => {
					await withRoleIds(supporter, async () => {
						// Rolling out, so the ROLLOUT gate answers, not the support one.
						expect((await login('gate_supporter', GATED)).status).toBe(200)
						expect((await login('gate_outsider', GATED)).json.error_description).toBe(REFUSED)
					})
				})
				// In neither list, nobody reaches it — a rollout pulled back entirely.
				await withVars(
					{ SUPPORTED_GAME_VERSIONS: '20230414', ROLLOUT_GAME_VERSIONS: 'off' },
					async () => {
						await withRoleIds(supporter, async () => {
							for (const username of ['gate_supporter', 'gate_developer']) {
								const res = await login(username, GATED)
								expect(res.status, username).toBe(400)
								expect(res.json.error_description, username).toBe(UNSUPPORTED)
							}
						})
					}
				)
			})

			test('entries are read as builds, so a copied point release still matches', async () => {
				await withVars({ SUPPORTED_GAME_VERSIONS: ' 20230414, 20250718.01 ' }, async () => {
					expect((await login('gate_outsider', '20250718.2')).status).toBe(200)
					expect((await login('gate_outsider', '20250718')).status).toBe(200)
				})
				// Blank is unset: the default list applies, including the alpha builds.
				await withVars({ SUPPORTED_GAME_VERSIONS: '  ' }, async () => {
					expect((await login('gate_outsider', '20231207')).status).toBe(200)
				})
			})
		})
	})

	test('the signup caps come from vars, and 0 disables an arm', async () => {
		// The cap an operator actually runs is the `MAX_ACCOUNTS_PER_IP` var; the constant in
		// auth.app.ts is only the fallback. `env` is shared by every test in this file, so the
		// override is restored in `finally` rather than leaking a cap of 0 into the tests above.
		const original = env.MAX_ACCOUNTS_PER_IP
		try {
			env.MAX_ACCOUNTS_PER_IP = 1
			const ip = '198.51.100.30'
			const first = await postToken('grant_type=create_account&platform_id=steam-var0', ip)
			expect(first.status).toBe(200)
			const capped = await postToken('grant_type=create_account&platform_id=steam-var1', ip)
			expect(capped.status).toBe(400)
			expect(capped.json.error_description).toMatch(/network/)

			// 0 disables the arm entirely: the IP that was just capped can sign up again.
			env.MAX_ACCOUNTS_PER_IP = 0
			const uncapped = await postToken('grant_type=create_account&platform_id=steam-var2', ip)
			expect(uncapped.status).toBe(200)
		} finally {
			env.MAX_ACCOUNTS_PER_IP = original
		}

		// The device arm reads its own var the same way.
		const originalDevice = env.MAX_ACCOUNTS_PER_DEVICE_ID
		try {
			env.MAX_ACCOUNTS_PER_DEVICE_ID = 1
			const device = '&device_id=dev-var-install&device_class=2'
			const first = await postToken(`grant_type=create_account&platform_id=steam-dvar0${device}`)
			expect(first.status).toBe(200)
			const capped = await postToken(`grant_type=create_account&platform_id=steam-dvar1${device}`)
			expect(capped.status).toBe(400)
			expect(capped.json.error_description).toMatch(/device/)

			env.MAX_ACCOUNTS_PER_DEVICE_ID = 0
			const uncapped = await postToken(`grant_type=create_account&platform_id=steam-dvar2${device}`)
			expect(uncapped.status).toBe(200)
		} finally {
			env.MAX_ACCOUNTS_PER_DEVICE_ID = originalDevice
		}
	})

	test('POST /connect/token does not cap logins, only signups', async () => {
		// Account 42's owner may be over the signup cap; that must never lock them out of
		// an account they already have.
		const res = await postToken(
			`grant_type=password&username=Player42&password=${LOGIN_PASSWORD}`,
			'198.51.100.22'
		)
		expect(res.status).toBe(200)
	})

	test('POST /connect/token create_account seeds the new player into Orientation', async () => {
		const payload = await tokenFor('grant_type=create_account&platform_id=steam-456')
		const sub = payload.sub as string
		// Presence is written to the shared `presence` D1 table (account_id keyed).
		const row = await env.DB.prepare('SELECT data FROM presence WHERE account_id = ?1')
			.bind(Number(sub))
			.first<{ data: string }>()
		expect(row).not.toBeNull()
		const presence = JSON.parse(row!.data) as {
			roomInstance: { roomInstanceId: number; roomId: number; location: string; name: string }
		}
		expect(presence.roomInstance).toMatchObject({
			roomInstanceId: -2,
			roomId: 13,
			location: ORIENTATION_SCENE,
			name: '^Orientation',
		})
	})

	test('POST /connect/token carries the platform int on the token', async () => {
		const payload = await tokenFor(`account_id=42&platform=5&password=${LOGIN_PASSWORD}`)
		expect(payload.platform).toBe(5)
		// `rn.plat` is the same int, not a pinned 0.
		expect(payload['rn.plat']).toBe(5)
	})

	test('POST /connect/token defaults the platform claim when none is posted', async () => {
		const payload = await tokenFor(`account_id=42&password=${LOGIN_PASSWORD}`)
		expect(payload.platform).toBe(0)
		expect(payload['rn.plat']).toBe(0)
	})

	test('POST /connect/token returns a refresh_token that redeems for a new token', async () => {
		const login = await postToken(
			`account_id=42&platform=0&platform_id=steam-123&password=${LOGIN_PASSWORD}`
		)
		expect(login.status).toBe(200)
		const refreshToken = login.json.refresh_token as string
		expect(typeof refreshToken).toBe('string')
		expect(refreshToken.length).toBeGreaterThan(0)

		const refreshed = await postToken(
			`grant_type=refresh_token&refresh_token=${encodeURIComponent(refreshToken)}`
		)
		expect(refreshed.status).toBe(200)
		const payload = decodePayload(refreshed.json.access_token as string)
		expect(payload.sub).toBe('42')
		// The platform identity comes off the account, not the refresh token. Account 42
		// has none bound (the posted `platform_id` above was never Steam-verified, so it
		// was never written), so the refreshed token carries no identity either.
		expect(payload.platform).toBe(0)
		expect(payload.platform_id).toBe('')
		// The refresh token is rotated (single-use), so a new one is returned.
		expect(refreshed.json.refresh_token).not.toBe(refreshToken)
	})

	test('a refreshed token carries the identity bound to the account', async () => {
		// A Steam-bound account: only a verified ticket writes `platformId`, so seed it
		// directly rather than posting an (unverified) platform_id on the login.
		await env.DB.prepare('INSERT OR IGNORE INTO account (data) VALUES (?1)')
			.bind(
				JSON.stringify({
					accountId: 43,
					username: 'Player43',
					passwordHash: await hashPassword(LOGIN_PASSWORD),
					platform: 0,
					platformId: 'steam-123',
				})
			)
			.run()

		const login = await postToken(`account_id=43&password=${LOGIN_PASSWORD}`)
		expect(login.status).toBe(200)
		const refreshed = await postToken(
			`grant_type=refresh_token&refresh_token=${encodeURIComponent(login.json.refresh_token as string)}`
		)
		expect(refreshed.status).toBe(200)
		const payload = decodePayload(refreshed.json.access_token as string)
		expect(payload.sub).toBe('43')
		expect(payload.platform).toBe(0)
		expect(payload.platform_id).toBe('steam-123')
	})

	// A password login is how a player who already has an account signs in on a NEW
	// device. The client posts its platform proof alongside the password, and linking
	// the two is what turns the next launch on that device into a cached login.
	describe('password grant links the platform identity it proves', () => {
		/** Seed an account with LOGIN_PASSWORD set and no platform identity at all. */
		async function seedPasswordAccount(id: number, username: string) {
			await env.DB.prepare('INSERT OR IGNORE INTO account (data) VALUES (?1)')
				.bind(
					JSON.stringify({
						accountId: id,
						username,
						passwordHash: await hashPassword(LOGIN_PASSWORD),
					})
				)
				.run()
		}

		test('a verified Meta login on an existing account links it, and cached login follows', async () => {
			// Exactly the client's flow: an account made elsewhere, signed into on a headset
			// with username + password, with the Meta nonce riding along.
			await seedPasswordAccount(7100, 'djdevin')
			const metaId = '27061366730201234'
			const login = await metaLogin(
				`grant_type=password&username=djdevin&password=${LOGIN_PASSWORD}` +
					`&platform=1&platform_id=${metaId}` +
					`&platform_auth=${encodeURIComponent(metaPlatformAuth())}`,
				true
			)
			expect(login.status).toBe(200)
			expect(decodePayload(login.json.access_token as string).sub).toBe('7100')
			// The nonce was validated against the id being linked — an unproven id is never
			// linked, since a link is a password-free way into the account.
			expect(login.graphCalls[0].get('user_id')).toBe(metaId)

			// The headset now gets a cached login: offered by the picker…
			const offered = await cachedLogins(1, metaId)
			expect(offered.map((a) => a.accountId)).toContain(7100)

			// …and accepted by the grant, with no password.
			const cached = await metaLogin(
				`grant_type=cached_login&account_id=7100&platform=1&platform_id=${metaId}` +
					`&platform_auth=${encodeURIComponent(metaPlatformAuth())}`,
				true
			)
			expect(cached.status).toBe(200)
		})

		test('the first identity linked becomes the account primary; later ones just link', async () => {
			await seedPasswordAccount(7101, 'multiplatform')
			const metaId = '27061366730205678'
			await metaLogin(
				`grant_type=password&username=multiplatform&password=${LOGIN_PASSWORD}` +
					`&platform=1&platform_id=${metaId}` +
					`&platform_auth=${encodeURIComponent(metaPlatformAuth())}`,
				true
			)
			// The blob's primary identity was empty, so the first link fills it in — this is
			// what the account DTO and the refresh grant's claims report.
			const account = (await env.DB.prepare(
				'SELECT data FROM account WHERE account_id = 7101'
			).first<{ data: string }>())!
			expect(JSON.parse(account.data)).toMatchObject({ platform: 1, platformId: metaId })

			// A second identity on another platform links without disturbing the primary.
			await linkPlatformIdentity(env.DB, 7101, 0, '76561197962465678')
			const links = await getLinksForAccount(env.DB, 7101)
			expect(links.map((l) => [l.platform, l.platformId])).toEqual([
				[1, metaId],
				[0, '76561197962465678'],
			])
		})

		test('an unverified platform_auth logs in but links nothing', async () => {
			// The password already proved who this is, so the login stands — but a link is a
			// password-free way in, and this identity was never proven, so none is written.
			await seedPasswordAccount(7102, 'unproven')
			const metaId = '27061366730209876'
			const login = await metaLogin(
				`grant_type=password&username=unproven&password=${LOGIN_PASSWORD}` +
					`&platform=1&platform_id=${metaId}` +
					`&platform_auth=${encodeURIComponent(metaPlatformAuth())}`,
				false // Meta rejects the nonce
			)
			expect(login.status).toBe(200)
			expect(await getLinksForAccount(env.DB, 7102)).toEqual([])
		})

		test('a login with no platform_auth links nothing and asks Meta nothing', async () => {
			await seedPasswordAccount(7103, 'noproof')
			const login = await metaLogin(
				`grant_type=password&username=noproof&password=${LOGIN_PASSWORD}` +
					`&platform=1&platform_id=27061366730204321`,
				true
			)
			expect(login.status).toBe(200)
			expect(login.graphCalls).toHaveLength(0)
			expect(await getLinksForAccount(env.DB, 7103)).toEqual([])
		})

		test('a sideloaded APK (platform id 1) logs in but is never linked', async () => {
			// The sideload placeholder identifies nobody — every sideloaded headset reports
			// `1`, so a link on it would be a password-free way into this account from any of
			// them. The password login still stands; Meta is never even asked, since there is
			// nothing there to validate.
			await seedPasswordAccount(7105, 'sideloader')
			const login = await metaLogin(
				`grant_type=password&username=sideloader&password=${LOGIN_PASSWORD}` +
					`&platform=1&platform_id=1` +
					`&platform_auth=${encodeURIComponent(metaPlatformAuth())}`,
				true // even with Meta answering yes to everything
			)
			expect(login.status).toBe(200)
			expect(login.graphCalls).toHaveLength(0)
			expect(await getLinksForAccount(env.DB, 7105)).toEqual([])
			// And so the picker never offers this account off the placeholder — only the
			// canned stub entry is there.
			expect((await cachedLogins(1, '1')).map((a) => a.accountId)).toEqual([1])
		})

		test('linking obeys the per-identity account cap, without failing the login', async () => {
			// Otherwise the signup cap would be trivially bypassable: create accounts with a
			// password, then link the capped identity into all of them.
			const metaId = '27061366730203333'
			for (let i = 0; i < 3; i++) await linkPlatformIdentity(env.DB, 8000 + i, 1, metaId)

			await seedPasswordAccount(8100, 'overcap')
			const login = await metaLogin(
				`grant_type=password&username=overcap&password=${LOGIN_PASSWORD}` +
					`&platform=1&platform_id=${metaId}` +
					`&platform_auth=${encodeURIComponent(metaPlatformAuth())}`,
				true
			)
			// The password was valid, so the player is logged in — they just don't get a
			// cached login on this account.
			expect(login.status).toBe(200)
			expect(await getLinksForAccount(env.DB, 8100)).toEqual([])
		})

		test('re-logging in on the same device does not duplicate the link', async () => {
			await seedPasswordAccount(7104, 'repeatlogin')
			const metaId = '27061366730207654'
			const body =
				`grant_type=password&username=repeatlogin&password=${LOGIN_PASSWORD}` +
				`&platform=1&platform_id=${metaId}` +
				`&platform_auth=${encodeURIComponent(metaPlatformAuth())}`
			await metaLogin(body, true)
			await metaLogin(body, true)
			expect(await getLinksForAccount(env.DB, 7104)).toHaveLength(1)
		})
	})

	test('POST /connect/token refresh_token is single-use (rejected on reuse)', async () => {
		const login = await postToken(`account_id=77&platform=0&password=${LOGIN_PASSWORD}`)
		const refreshToken = login.json.refresh_token as string

		const first = await postToken(
			`grant_type=refresh_token&refresh_token=${encodeURIComponent(refreshToken)}`
		)
		expect(first.status).toBe(200)
		// Redeeming the same token again fails — it was consumed (rotated) above.
		const reuse = await postToken(
			`grant_type=refresh_token&refresh_token=${encodeURIComponent(refreshToken)}`
		)
		expect(reuse.status).toBe(400)
		expect(reuse.json.error).toBe('invalid_grant')
	})

	/**
	 * A D1 that throws the storage-side `internal error` on its first `n` reads and then
	 * behaves. Only what `consumeRefreshToken` touches is wrapped — prepare/bind/first.
	 */
	const flakyDb = (failures: number): D1Database => {
		let remaining = failures
		const wrap = (stmt: D1PreparedStatement): D1PreparedStatement =>
			({
				bind: (...values: unknown[]) => wrap(stmt.bind(...values)),
				first: async <T>() => {
					if (remaining > 0) {
						remaining--
						throw new Error('D1_ERROR: internal error; reference = testref0000')
					}
					return stmt.first<T>()
				},
			}) as unknown as D1PreparedStatement
		return { prepare: (sql: string) => wrap(env.DB.prepare(sql)) } as unknown as D1Database
	}

	test('consumeRefreshToken rides out a transient D1 error rather than logging the player out', async () => {
		const token = await issueRefreshToken(env.DB, 77)
		// Two hiccups, then the real thing — the redemption still succeeds, so the player
		// keeps their session instead of being bounced to the login screen by a 500.
		expect(await consumeRefreshToken(flakyDb(2), token)).toBe(77)
		// And it was genuinely consumed: the retry didn't leave the row behind.
		expect(await consumeRefreshToken(env.DB, token)).toBeNull()
	})

	test('consumeRefreshToken rethrows once the retries are spent, never a silent null', async () => {
		const token = await issueRefreshToken(env.DB, 77)
		// A real D1 outage has to surface as a 500. Answering null would tell the player
		// their token was bad and make them log in again over something that isn't theirs.
		await expect(consumeRefreshToken(flakyDb(99), token)).rejects.toThrow('internal error')
		// The token survived, so a later attempt still works.
		expect(await consumeRefreshToken(env.DB, token)).toBe(77)
	})

	test('POST /connect/token 400s on an unknown refresh_token', async () => {
		const res = await postToken('grant_type=refresh_token&refresh_token=NOPE-1')
		expect(res.status).toBe(400)
		expect(res.json.error).toBe('invalid_grant')
	})

	test('POST /cachedlogin/forplatformids returns []', async () => {
		const res = await exports.default.fetch(`${ORIGIN}/cachedlogin/forplatformids`, {
			method: 'POST',
			headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
			body: 'id=76561197971551621&id=76561197976728738',
		})
		expect(res.status).toBe(200)
		expect(await res.json()).toEqual([])
	})

	test('POST /account/me/changepassword 401s without a token', async () => {
		const res = await changePassword('oldPassword=&newPassword=secret123')
		expect(res.status).toBe(401)
	})

	test('POST /account/me/changepassword 400s without a new password', async () => {
		const token = await accessTokenFor('grant_type=create_account&platform_id=steam-pw0')
		const res = await changePassword('oldPassword=&newPassword=', token)
		expect(res.status).toBe(400)
	})

	test('POST /account/me/changepassword sets then rotates the password', async () => {
		const token = await accessTokenFor('grant_type=create_account&platform_id=steam-pw1')

		// First set — oldPassword is empty (as the client sends it).
		const set = await changePassword('oldPassword=&newPassword=first-password', token)
		expect(set.status).toBe(200)
		expect(await set.json()).toEqual({ success: true })

		// A wrong old password is now rejected.
		const wrong = await changePassword('oldPassword=nope&newPassword=second-password', token)
		expect(wrong.status).toBe(400)

		// The correct old password rotates it.
		const rotate = await changePassword(
			'oldPassword=first-password&newPassword=second-password',
			token
		)
		expect(rotate.status).toBe(200)
		expect(await rotate.json()).toEqual({ success: true })
	})

	/** POST a form-urlencoded body to one of the unauthenticated recovery routes. */
	const postForm = (path: string, body: string) =>
		exports.default.fetch(`${ORIGIN}${path}`, {
			method: 'POST',
			headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
			body,
		})
	const recover = (body: string) => postForm('/account/recoverpassword', body)
	const reset = (body: string) => postForm('/account/resetpassword', body)
	const SENT = { Success: true, Error: null, error_id: null }

	/** The pending recovery row for an account, or null. */
	const pendingReset = (accountId: number) =>
		env.DB.prepare(
			"SELECT code_hash AS codeHash, created_at AS createdAt, expires_at AS expiresAt FROM email_code WHERE account_id = ?1 AND purpose = 'password_reset'"
		)
			.bind(accountId)
			.first<{ codeHash: string | null; createdAt: number; expiresAt: number }>()

	/**
	 * Only the code's hash is stored and the email goes to the local binding's log, so a test
	 * that needs to KNOW the code puts a known one in: same hash function as the route.
	 */
	const plantCode = async (accountId: number, code: string) => {
		await env.DB.prepare(
			"UPDATE email_code SET code_hash = ?2 WHERE account_id = ?1 AND purpose = 'password_reset'"
		)
			.bind(accountId, await hashPassword(code))
			.run()
	}

	/** A fresh account with an email address on it, for the recovery tests. */
	const accountWithEmail = async (tag: string, email: string) => {
		const claims = await tokenFor(`grant_type=create_account&platform_id=steam-${tag}`)
		const accountId = Number(claims.sub)
		await updateAccount(env.DB, accountId, { email })
		return accountId
	}

	test('POST /account/recoverpassword issues a code and emails it', async () => {
		const id = await accountWithEmail('recover1', 'recover1@example.com')
		const before = Math.floor(Date.now() / 1000)
		const res = await recover('email=recover1%40example.com')
		expect(res.status).toBe(200)
		expect(await res.json()).toEqual(SENT)

		const row = await pendingReset(id)
		expect(row).not.toBeNull()
		expect(row!.codeHash).toMatch(/^[^:]+:[^:]+$/)
		expect(row!.createdAt).toBeGreaterThanOrEqual(before)
		expect(row!.expiresAt - row!.createdAt).toBe(30 * 60)
	})

	test('POST /account/recoverpassword finds the account case-insensitively', async () => {
		const id = await accountWithEmail('recover2', 'Recover2@Example.com')
		const res = await recover('email=RECOVER2%40example.com')
		expect(await res.json()).toEqual(SENT)
		expect(await pendingReset(id)).not.toBeNull()
	})

	test('POST /account/recoverpassword answers an unknown address exactly like a sent one', async () => {
		const res = await recover('email=nobody-here%40example.com')
		expect(res.status).toBe(200)
		expect(await res.json()).toEqual(SENT)
		const rows = await env.DB.prepare('SELECT COUNT(*) AS n FROM email_code').first<{
			n: number
		}>()
		// Nothing was issued for it — the account doesn't exist — but the caller can't tell.
		expect(rows!.n).toBeGreaterThanOrEqual(0)
	})

	test('POST /account/recoverpassword refuses a missing or malformed address, in the client envelope', async () => {
		for (const [body, error] of [
			['', 'Enter the email address on your account.'],
			['email=', 'Enter the email address on your account.'],
			['email=not-an-address', "That doesn't look like an email address."],
		]) {
			const res = await recover(body!)
			expect(res.status).toBe(200)
			expect(await res.json()).toEqual({ Success: false, Error: error, error_id: null })
		}
	})

	test('POST /account/recoverpassword does not resend within the cooldown', async () => {
		const id = await accountWithEmail('recover3', 'recover3@example.com')
		expect(await (await recover('email=recover3%40example.com')).json()).toEqual(SENT)
		const first = await pendingReset(id)
		// Same answer, but the pending code is untouched: no second email went out.
		expect(await (await recover('email=recover3%40example.com')).json()).toEqual(SENT)
		expect(await pendingReset(id)).toEqual(first)
	})

	test('POST /account/recoverpassword replaces the pending code once the cooldown has passed', async () => {
		const id = await accountWithEmail('recover4', 'recover4@example.com')
		await recover('email=recover4%40example.com')
		const first = await pendingReset(id)
		await env.DB.prepare(
			"UPDATE email_code SET created_at = created_at - 600 WHERE account_id = ?1 AND purpose = 'password_reset'"
		)
			.bind(id)
			.run()
		await recover('email=recover4%40example.com')
		const second = await pendingReset(id)
		expect(second!.codeHash).not.toBe(first!.codeHash)
		expect(second!.createdAt).toBeGreaterThan(first!.createdAt - 600)
	})

	test('POST /account/recoverpassword sends an account at most five codes a day', async () => {
		const id = await accountWithEmail('recover5', 'recover5@example.com')
		/** Lift the cooldown, so only the daily cap is in play. */
		const lift = () =>
			env.DB.prepare(
				"UPDATE email_code SET created_at = created_at - 600 WHERE account_id = ?1 AND purpose = 'password_reset'"
			)
				.bind(id)
				.run()
		const hashes: string[] = []
		for (let i = 0; i < 5; i++) {
			expect(await (await recover('email=recover5%40example.com')).json()).toEqual(SENT)
			hashes.push((await pendingReset(id))!.codeHash!)
			await lift()
		}
		expect(new Set(hashes).size).toBe(5)
		// The sixth is answered the same and changes nothing: no email went out.
		expect(await (await recover('email=recover5%40example.com')).json()).toEqual(SENT)
		expect((await pendingReset(id))!.codeHash).toBe(hashes[4])
	})

	test('POST /account/recoverpassword takes at most ten requests an hour from one IP', async () => {
		const id = await accountWithEmail('recover6', 'recover6@example.com')
		const fromIp = (body: string) =>
			exports.default.fetch(`${ORIGIN}/account/recoverpassword`, {
				method: 'POST',
				headers: {
					'Content-Type': 'application/x-www-form-urlencoded',
					'CF-Connecting-IP': '203.0.113.9',
				},
				body,
			})
		// Ten requests for addresses on no account spend the hour's allowance just the same.
		for (let i = 0; i < 10; i++) {
			expect(await (await fromIp(`email=nobody${i}%40example.com`)).json()).toEqual(SENT)
		}
		// The eleventh, for a real account, is answered the same and issues nothing.
		expect(await (await fromIp('email=recover6%40example.com')).json()).toEqual(SENT)
		expect(await pendingReset(id)).toBeNull()
		// Another IP is unaffected.
		const other = await exports.default.fetch(`${ORIGIN}/account/recoverpassword`, {
			method: 'POST',
			headers: {
				'Content-Type': 'application/x-www-form-urlencoded',
				'CF-Connecting-IP': '203.0.113.10',
			},
			body: 'email=recover6%40example.com',
		})
		expect(await other.json()).toEqual(SENT)
		expect(await pendingReset(id)).not.toBeNull()
	})

	test('POST /account/resetpassword sets the password with the emailed code, once', async () => {
		const id = await accountWithEmail('reset1', 'reset1@example.com')
		await recover('email=reset1%40example.com')
		await plantCode(id, '123456')
		// A refresh token from an old session, which the reset signs out.
		const refresh = await issueRefreshToken(env.DB, id)

		const res = await reset('email=reset1%40example.com&code=123456&newPassword=brand-new')
		expect(res.status).toBe(200)
		expect(await res.json()).toEqual({ success: true })
		expect(await pendingReset(id)).toBeNull()
		expect(await consumeRefreshToken(env.DB, refresh)).toBeNull()

		// The new password signs in.
		const login = await exports.default.fetch(`${ORIGIN}/connect/token`, {
			method: 'POST',
			headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
			body: `grant_type=password&account_id=${id}&password=brand-new`,
		})
		expect(login.status).toBe(200)

		// The code was spent: the same one again is refused.
		const again = await reset('email=reset1%40example.com&code=123456&newPassword=another')
		expect(again.status).toBe(400)
	})

	test('POST /account/resetpassword voids the recovery on a wrong code', async () => {
		const id = await accountWithEmail('reset2', 'reset2@example.com')
		await recover('email=reset2%40example.com')
		await plantCode(id, '123456')

		const wrong = await reset('email=reset2%40example.com&code=654321&newPassword=brand-new')
		expect(wrong.status).toBe(400)
		expect(await wrong.json()).toEqual({
			success: false,
			error: 'That code is wrong or has expired. Request a new recovery email and try again.',
		})
		// Burned, not deleted: the row stays for the resend cooldown, with no code to guess.
		expect((await pendingReset(id))!.codeHash).toBeNull()

		// The RIGHT code no longer works either — a new email has to be requested.
		const right = await reset('email=reset2%40example.com&code=123456&newPassword=brand-new')
		expect(right.status).toBe(400)
		expect(await getPasswordHash(env.DB, id)).toBeNull()
	})

	test('POST /account/resetpassword refuses a lapsed code', async () => {
		const id = await accountWithEmail('reset3', 'reset3@example.com')
		await recover('email=reset3%40example.com')
		await plantCode(id, '123456')
		await env.DB.prepare(
			"UPDATE email_code SET expires_at = expires_at - 3600 WHERE account_id = ?1 AND purpose = 'password_reset'"
		)
			.bind(id)
			.run()
		const res = await reset('email=reset3%40example.com&code=123456&newPassword=brand-new')
		expect(res.status).toBe(400)
		expect(await pendingReset(id)).toBeNull()
	})

	test('POST /account/resetpassword refuses the same way for no recovery and an unknown address', async () => {
		const sameError = {
			success: false,
			error: 'That code is wrong or has expired. Request a new recovery email and try again.',
		}
		await accountWithEmail('reset4', 'reset4@example.com')
		const none = await reset('email=reset4%40example.com&code=123456&newPassword=brand-new')
		expect(none.status).toBe(400)
		expect(await none.json()).toEqual(sameError)
		const unknown = await reset('email=nobody%40example.com&code=123456&newPassword=brand-new')
		expect(unknown.status).toBe(400)
		expect(await unknown.json()).toEqual(sameError)
	})

	test('POST /account/resetpassword refuses a missing field', async () => {
		for (const body of [
			'code=123456&newPassword=x',
			'email=a%40b.com&newPassword=x',
			'email=a%40b.com&code=123456',
		]) {
			const res = await reset(body)
			expect(res.status).toBe(400)
			expect(((await res.json()) as { success: boolean }).success).toBe(false)
		}
	})

	test('the reset link carries the address and the code for the website', () => {
		expect(resetPasswordUrl('https://www.rec.example.com', 'a+b@example.com', '012345')).toBe(
			'https://www.rec.example.com/reset-password?email=a%2Bb%40example.com&code=012345'
		)
	})

	test('GET /privileges/me/restrictions is an empty array for an unrestricted caller', async () => {
		const token = await accessTokenFor('grant_type=create_account&platform_id=steam-restrict1')
		const res = await exports.default.fetch(`${ORIGIN}/privileges/me/restrictions`, {
			headers: { Authorization: `Bearer ${token}` },
		})
		expect(res.status).toBe(200)
		// [] is the normal unrestricted answer — not null, not a 404: the client refills its
		// list from this and acts on a record being present.
		expect(await res.text()).toBe('[]')
	})

	test('GET /privileges/me/restrictions 401s without a token', async () => {
		const res = await exports.default.fetch(`${ORIGIN}/privileges/me/restrictions`)
		expect(res.status).toBe(401)
		expect(await res.text()).toBe('')
	})

	test('GET /role/screenshare/:id matches the token feature gate for existing accounts', async () => {
		for (const id of [42, 77]) {
			const res = await exports.default.fetch(`${ORIGIN}/role/screenshare/${id}`)
			expect(res.status).toBe(200)
			expect(await res.json()).toBe(false)
		}
	})

	test('GET /role/screenshare/:id does not grant a role to unknown accounts', async () => {
		for (const id of ['999999', 'nonsense']) {
			const res = await exports.default.fetch(`${ORIGIN}/role/screenshare/${id}`)
			expect(res.status).toBe(404)
			expect(await res.text()).toBe('')
		}
	})

	test('GET /role/developer/:id returns a bare false for an un-flagged account', async () => {
		const res = await exports.default.fetch(`${ORIGIN}/role/developer/42`)
		expect(res.status).toBe(200)
		expect(await res.json()).toBe(false)
	})

	test('GET /role/developer/:id returns a bare true when the account is flagged', async () => {
		await env.DB.prepare('INSERT OR IGNORE INTO account (data) VALUES (?1)')
			.bind(JSON.stringify({ accountId: 4242, username: 'DevPlayer', isDeveloper: true }))
			.run()
		const res = await exports.default.fetch(`${ORIGIN}/role/developer/4242`)
		expect(res.status).toBe(200)
		expect(await res.json()).toBe(true)
	})

	test('GET /role/developer/:id 404s for an unknown player', async () => {
		const res = await exports.default.fetch(`${ORIGIN}/role/developer/99999`)
		expect(res.status).toBe(404)
	})

	test('GET /role/moderator/:id reflects the isModerator flag as a bare boolean', async () => {
		await env.DB.prepare('INSERT OR IGNORE INTO account (data) VALUES (?1)')
			.bind(JSON.stringify({ accountId: 4343, username: 'ModPlayer', isModerator: true }))
			.run()
		const granted = await exports.default.fetch(`${ORIGIN}/role/moderator/4343`)
		expect(await granted.json()).toBe(true)
		// An account without the flag (42) is not a moderator.
		const plain = await exports.default.fetch(`${ORIGIN}/role/moderator/42`)
		expect(await plain.json()).toBe(false)
		// Unknown player → 404.
		expect((await exports.default.fetch(`${ORIGIN}/role/moderator/99999`)).status).toBe(404)
	})

	// `/role/{role}?id=` is a BULK FILTER — which of these players hold the role, as an array
	// of ints — not the single lookup's boolean. Different question, different shape.
	test('GET /role/developer?id= answers which of the players are developers', async () => {
		await env.DB.prepare('INSERT OR IGNORE INTO account (data) VALUES (?1)')
			.bind(JSON.stringify({ accountId: 4242, username: 'DevPlayer', isDeveloper: true }))
			.run()
		await env.DB.prepare('INSERT OR IGNORE INTO account (data) VALUES (?1)')
			.bind(JSON.stringify({ accountId: 4244, username: 'DevPlayer2', isDeveloper: true }))
			.run()

		// INTS, not strings, and not a boolean.
		const one = await exports.default.fetch(`${ORIGIN}/role/developer?id=4242`)
		expect(one.status).toBe(200)
		expect(await one.json()).toEqual([4242])

		// The subset that holds the role: 42 exists without the flag and 99999 not at all, and
		// neither is an error — a filter answers "none of them", never 404.
		const many = await exports.default.fetch(
			`${ORIGIN}/role/developer?id=42&id=4242&id=99999&id=4244`
		)
		expect(many.status).toBe(200)
		expect(await many.json()).toEqual([4242, 4244])

		// Ordered as asked, so a caller can read the answer against its own list.
		const reversed = await exports.default.fetch(`${ORIGIN}/role/developer?id=4244&id=4242`)
		expect(await reversed.json()).toEqual([4244, 4242])

		// A repeated id yields at most one entry.
		const repeated = await exports.default.fetch(`${ORIGIN}/role/developer?id=4242&id=4242`)
		expect(await repeated.json()).toEqual([4242])
	})

	test('GET /role/developer?id= answers [] rather than erroring', async () => {
		// No ids, only unknown ids, only un-flagged ids, and a non-numeric id all answer an empty
		// array with a 200 — nothing about this question is a 400 or a 404.
		for (const query of ['', '?id=99999', '?id=42', '?id=nonsense', '?id=']) {
			const res = await exports.default.fetch(`${ORIGIN}/role/developer${query}`)
			expect(res.status, query).toBe(200)
			expect(await res.json(), query).toEqual([])
		}
	})

	// The repeated parameter is the whole point: reading only the first would silently answer
	// about one player out of the set.
	test('GET /role/developer?id= reads every repeated id, not just the first', async () => {
		await env.DB.prepare('INSERT OR IGNORE INTO account (data) VALUES (?1)')
			.bind(JSON.stringify({ accountId: 4242, username: 'DevPlayer', isDeveloper: true }))
			.run()
		const res = await exports.default.fetch(`${ORIGIN}/role/developer?id=42&id=4242`)
		expect(await res.json()).toEqual([4242])
	})

	test('GET /role/moderator?id= filters on the moderator flag alone', async () => {
		await env.DB.prepare('INSERT OR IGNORE INTO account (data) VALUES (?1)')
			.bind(JSON.stringify({ accountId: 4343, username: 'ModPlayer', isModerator: true }))
			.run()
		await env.DB.prepare('INSERT OR IGNORE INTO account (data) VALUES (?1)')
			.bind(JSON.stringify({ accountId: 4242, username: 'DevPlayer', isDeveloper: true }))
			.run()
		// The two roles are independent flags: a developer is not implicitly a moderator.
		const res = await exports.default.fetch(`${ORIGIN}/role/moderator?id=4242&id=4343&id=42`)
		expect(await res.json()).toEqual([4343])
	})

	// The single lookup keeps its own shape — the bulk form must not have changed it.
	test('GET /role/developer/:id is still a bare boolean, not an array', async () => {
		await env.DB.prepare('INSERT OR IGNORE INTO account (data) VALUES (?1)')
			.bind(JSON.stringify({ accountId: 4242, username: 'DevPlayer', isDeveloper: true }))
			.run()
		expect(await (await exports.default.fetch(`${ORIGIN}/role/developer/4242`)).json()).toBe(true)
		expect(await (await exports.default.fetch(`${ORIGIN}/role/developer/42`)).json()).toBe(false)
		expect((await exports.default.fetch(`${ORIGIN}/role/developer/99999`)).status).toBe(404)
	})

	test('unknown path returns 404', async () => {
		const res = await exports.default.fetch(`${ORIGIN}/nope`)
		expect(res.status).toBe(404)
	})

	test('Studio device login is approved on the website and polled on auth', async () => {
		const client = `client_id=${STUDIO_CLIENT_ID}&client_secret=${STUDIO_CLIENT_SECRET}`
		const bad = await exports.default.fetch(`${ORIGIN}/connect/deviceauthorization`, {
			method: 'POST',
			headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
			body: 'client_id=recroom.studio&client_secret=nope',
		})
		expect(bad.status).toBe(400)

		const started = await exports.default.fetch(`${ORIGIN}/connect/deviceauthorization`, {
			method: 'POST',
			headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
			body: client,
		})
		expect(started.status).toBe(200)
		const codes = (await started.json()) as {
			device_code: string
			user_code: string
			verification_uri: string
			verification_uri_complete: string
			expires_in: number
			interval: number
		}
		// The editor opens this in a browser. It is the website, not the auth API.
		expect(codes.verification_uri).toBe('https://www.rec.example.com/device')
		expect(codes.verification_uri_complete).toBe(
			`https://www.rec.example.com/device?user_code=${codes.user_code}`
		)
		expect(codes.expires_in).toBeGreaterThan(0)
		expect(codes.interval).toBeGreaterThan(0)

		const pending = await postToken(
			`${client}&grant_type=${encodeURIComponent('urn:ietf:params:oauth:grant-type:device_code')}&device_code=${codes.device_code}`
		)
		expect(pending.status).toBe(400)
		expect(pending.json.error).toBe('authorization_pending')

		const session = await postToken(
			`grant_type=password&username=Player42&password=${LOGIN_PASSWORD}`
		)
		expect(session.status).toBe(200)
		const approved = await exports.default.fetch(`${ORIGIN}/connect/device/approve`, {
			method: 'POST',
			headers: {
				'Content-Type': 'application/x-www-form-urlencoded',
				Authorization: `Bearer ${session.json.access_token as string}`,
			},
			body: `user_code=${codes.user_code}`,
		})
		expect(approved.status).toBe(200)

		const signedIn = await postToken(
			`${client}&grant_type=${encodeURIComponent('urn:ietf:params:oauth:grant-type:device_code')}&device_code=${codes.device_code}`
		)
		expect(signedIn.status).toBe(200)
		expect(typeof signedIn.json.access_token).toBe('string')
		expect(signedIn.json.expires_in).toBe(TOKEN_TTL_SECONDS)
		// Studio treats expires_in as seconds, same as the game client.
		const devicePayload = decodePayload(signedIn.json.access_token as string)
		expect(devicePayload.sub).toBe('42')
		// Player42 has no hasStudio flag, so a Studio login is still Limited.
		expect(devicePayload.role).not.toContain('betastudio')

		const again = await postToken(
			`${client}&grant_type=${encodeURIComponent('urn:ietf:params:oauth:grant-type:device_code')}&device_code=${codes.device_code}`
		)
		expect(again.status).toBe(400)
		expect(again.json.error).toBe('invalid_grant')
	})

	test('GET /openapi.json documents every route', async () => {
		const res = await exports.default.fetch(`${ORIGIN}/openapi.json`)
		expect(res.status).toBe(200)
		const spec = (await res.json()) as {
			openapi: string
			paths: Record<string, Record<string, { summary?: string }>>
		}
		expect(spec.openapi).toMatch(/^3\.1/)

		// The spec route hides itself.
		expect(spec.paths['/openapi.json']).toBeUndefined()

		// Every route the worker serves is described. This is the drift guard: adding a
		// route without a describeRoute() block fails here rather than silently shipping
		// an incomplete spec. Hono's `:param` syntax becomes OpenAPI's `{param}`.
		const documented = new Set(
			Object.entries(spec.paths).flatMap(([path, ops]) =>
				Object.keys(ops).map((method) => `${method.toUpperCase()} ${path}`)
			)
		)
		expect([...documented].sort()).toEqual([
			'GET /cachedlogin/forplatformid/{platform}/{id}',
			'GET /eac/challenge',
			'GET /oculus/nonce',
			'GET /privileges/me/restrictions',
			'GET /role/developer',
			'GET /role/developer/{id}',
			'GET /role/moderator',
			'GET /role/moderator/{id}',
			'GET /role/screenshare/{id}',
			'POST /account/me/changepassword',
			'POST /account/recoverpassword',
			'POST /account/resetpassword',
			'POST /cachedlogin/forplatformid/{platform}/{id}',
			'POST /cachedlogin/forplatformids',
			'POST /connect/device/approve',
			'POST /connect/device/deny',
			'POST /connect/deviceauthorization',
			'POST /connect/token',
		])

		// Every operation carries a summary — a path present but undescribed is not
		// documentation.
		for (const ops of Object.values(spec.paths)) {
			for (const op of Object.values(ops)) expect(op.summary).toBeTruthy()
		}
	})
})

// The website is a browser origin calling these endpoints directly — the same ones the
// game calls — instead of proxying them through `www`. That only works if the responses
// carry CORS headers: without them the browser discards a perfectly good token response
// and sign-in fails with nothing in any server log to explain it.
describe('CORS', () => {
	test('answers the preflight the browser sends before a token grant', async () => {
		const res = await exports.default.fetch(
			new Request(`${ORIGIN}/connect/token`, {
				method: 'OPTIONS',
				headers: {
					origin: 'https://www.example.com',
					'access-control-request-method': 'POST',
					'access-control-request-headers': 'content-type',
				},
			}),
			env
		)
		expect(res.status).toBe(204)
		expect(res.headers.get('access-control-allow-origin')).toBe('*')
		expect(res.headers.get('access-control-allow-headers')?.toLowerCase()).toContain('content-type')
	})

	// The header has to be on the REAL response too, not just the preflight — and on a
	// refusal as much as a success, or a rejected sign-in reaches the page as an opaque
	// network error rather than "that password is incorrect".
	test('allows the origin on the response itself, refusals included', async () => {
		const res = await exports.default.fetch(
			new Request(`${ORIGIN}/connect/token`, {
				method: 'POST',
				headers: {
					origin: 'https://www.example.com',
					'content-type': 'application/x-www-form-urlencoded',
				},
				body: new URLSearchParams({ grant_type: 'password', username: 'nobody' }).toString(),
			}),
			env
		)
		expect(res.status).toBe(400)
		expect(res.headers.get('access-control-allow-origin')).toBe('*')
	})

	// The bearer header is what the SPA authenticates with, so it must be allowed by name
	// — a preflight that omits it makes every signed-in call fail.
	test('allows the Authorization header the SPA signs its calls with', async () => {
		const res = await exports.default.fetch(
			new Request(`${ORIGIN}/account/me/changepassword`, {
				method: 'OPTIONS',
				headers: {
					origin: 'https://www.example.com',
					'access-control-request-method': 'POST',
					'access-control-request-headers': 'authorization',
				},
			}),
			env
		)
		expect(res.status).toBe(204)
		expect(res.headers.get('access-control-allow-headers')?.toLowerCase()).toContain(
			'authorization'
		)
	})
})

// A banned account is still issued a token: the game client needs one to reach the api
// worker's moderationBlockDetails, which is where the player is shown WHY they are
// blocked. The ban is a `report` row with `banned` set (the api worker owns that table)
// and is enforced by matchmaking, which refuses every matchmake for a banned player — so
// the token gets them to the block screen and no further.
describe('banned accounts', () => {
	test('POST /connect/token issues a token to a banned account', async () => {
		await seedAccount(6101, 'BannedPlayer')
		await banAccount(6101)

		const res = await postToken(`account_id=6101&password=${LOGIN_PASSWORD}`)
		expect(res.status).toBe(200)
		expect(decodePayload(res.json.access_token as string).sub).toBe('6101')
	})

	test('POST /connect/token issues a token to a banned account logging in by username', async () => {
		await seedAccount(6102, 'BannedByName')
		await banAccount(6102)

		const res = await postToken(
			`grant_type=password&username=BannedByName&password=${LOGIN_PASSWORD}`
		)
		expect(res.status).toBe(200)
		expect(decodePayload(res.json.access_token as string).sub).toBe('6102')
	})

	// A client that was already signed in when the ban landed refreshes as normal — its
	// next matchmake is what refuses it, and moderationBlockDetails says why.
	test('POST /connect/token refreshes a banned account’s session', async () => {
		await seedAccount(6103, 'BannedLater')
		const login = await postToken(`account_id=6103&password=${LOGIN_PASSWORD}`)
		expect(login.status).toBe(200)
		const refreshToken = login.json.refresh_token as string

		await banAccount(6103)
		const refreshed = await postToken(
			`grant_type=refresh_token&refresh_token=${encodeURIComponent(refreshToken)}`
		)
		expect(refreshed.status).toBe(200)
		expect(decodePayload(refreshed.json.access_token as string).sub).toBe('6103')
	})

	// A ban does not loosen the credential check: a wrong password on a banned account is
	// the ordinary bad-credential refusal.
	test('a wrong password on a banned account is still a credential refusal', async () => {
		await seedAccount(6104, 'BannedWrongPw')
		await banAccount(6104)

		const res = await postToken('account_id=6104&password=not-the-password')
		expect(res.status).toBe(400)
		expect(res.json.error_description).toBe('invalid account_id or password')
	})

	test('a ban that has not expired yet still issues a token', async () => {
		await seedAccount(6106, 'StillServing')
		await banAccount(6106, new Date(Date.now() + 3_600_000).toISOString())

		const res = await postToken(`account_id=6106&password=${LOGIN_PASSWORD}`)
		expect(res.status).toBe(200)
		expect(decodePayload(res.json.access_token as string).sub).toBe('6106')
	})

	// A report is not a ban until a moderator converts it.
	test('an unbanned report does not refuse the login', async () => {
		await seedAccount(6107, 'MerelyReported')
		await createReport(env.DB, { reporterPlayerId: 1, reportedPlayerId: 6107 })

		const res = await postToken(`account_id=6107&password=${LOGIN_PASSWORD}`)
		expect(res.status).toBe(200)
	})

	// The ban is the ACCOUNT's: nothing here stops the player signing up again, which is
	// the signup caps' job, not this check's.
	test('a banned player can still create a new account', async () => {
		await seedAccount(6108, 'BannedButNew')
		await banAccount(6108)

		const created = await postToken('grant_type=create_account&platform_id=steam-after-ban')
		expect(created.status).toBe(200)
	})
})

// The ban follows the player past the account it was written on. SIGNING IN is not where
// that is enforced: a linked account gets its token like any other, and `match` holds it to
// its own dorm — refusing the token only ever left the client stuck on a failed login. What
// IS refused here is a SIGNUP carrying either link, before it mints anything: making a new
// account to evade with is a different act from signing into one. See the api worker's
// bans-db.ts for the arms and the BAN_EVASION_MATCH knob.
describe('ban evasion at the token endpoint', () => {
	/** Seed a loginable account carrying the IPs it signed up / last logged in from. */
	const account = async (id: number, name: string, ips: Record<string, string> = {}) => {
		await env.DB.prepare('INSERT OR IGNORE INTO account (data) VALUES (?1)')
			.bind(
				JSON.stringify({
					accountId: id,
					username: name,
					passwordHash: await hashPassword(LOGIN_PASSWORD),
					...ips,
				})
			)
			.run()
	}

	const login = (id: number, ip?: string) =>
		postToken(`account_id=${id}&password=${LOGIN_PASSWORD}`, ip)

	test('an account sharing a banned account’s platform identity still signs in', async () => {
		await account(6301, 'EvaderOne')
		await linkPlatformIdentity(env.DB, 6301, 0, 'steam-tokenevader')
		await banAccount(6301)
		await account(6302, 'EvaderTwo')
		await linkPlatformIdentity(env.DB, 6302, 0, 'steam-tokenevader')

		// A token, like anyone else: the client has to load in before it can be told anything,
		// and `match` is what keeps this account out of every room but its dorm.
		const res = await login(6302)
		expect(res.status).toBe(200)
		expect(decodePayload(res.json.access_token as string).sub).toBe('6302')
	})

	test('an account sharing a banned account’s IP still signs in', async () => {
		await account(6303, 'SameHouseBanned', { signupIp: '203.0.113.30' })
		await banAccount(6303)
		await account(6304, 'SameHouseClean', { signupIp: '203.0.113.30' })

		expect((await login(6304)).status).toBe(200)
	})

	// The address the request arrives from counts, so a SIGNUP from the banned network is
	// caught on the first attempt rather than the second.
	test('the request’s own IP is matched at signup even when the account has none stored', async () => {
		await account(6305, 'BannedAtHome', { signupIp: '203.0.113.31' })
		await banAccount(6305)
		await account(6306, 'CleanElsewhere')

		expect((await postToken('grant_type=create_account', '203.0.113.31')).status).toBe(400)
		// Signing in from that same network is not refused — only minting a new account is.
		expect((await login(6306, '203.0.113.31')).status).toBe(200)
		expect((await login(6306, '198.51.100.31')).status).toBe(200)
	})

	test('an unrelated account signs in normally', async () => {
		await account(6307, 'Unrelated', { signupIp: '198.51.100.7' })
		await banAccount(6307 + 1000) // a ban on somebody else entirely
		expect((await login(6307)).status).toBe(200)
	})

	// The point of checking before minting: a refused signup must leave nothing behind,
	// or the evader keeps the account (and burns a slot off the signup caps) anyway.
	test('create_account from a banned IP is refused and creates no account', async () => {
		await account(6310, 'BannedSignupSource', { signupIp: '203.0.113.40' })
		await banAccount(6310)

		const before = await env.DB.prepare('SELECT COUNT(*) AS n FROM account').first<{ n: number }>()
		const res = await postToken('grant_type=create_account', '203.0.113.40')
		expect(res.status).toBe(400)
		expect(res.json.error_description).toBe('this device or network is blocked')
		const after = await env.DB.prepare('SELECT COUNT(*) AS n FROM account').first<{ n: number }>()
		expect(after?.n).toBe(before?.n)
	})

	test('create_account from an unrelated IP still works', async () => {
		const res = await postToken('grant_type=create_account', '198.51.100.99')
		expect(res.status).toBe(200)
	})

	// The knob an operator reaches for when the IP arm locks out real players. It governs the
	// linked arms wherever they are applied — at signup here, and at every matchmake in `match`.
	test('BAN_EVASION_MATCH=platform drops the IP arm but keeps the platform one', async () => {
		const original = env.BAN_EVASION_MATCH
		await account(6320, 'KnobBanned', { signupIp: '203.0.113.50' })
		await linkPlatformIdentity(env.DB, 6320, 0, 'steam-knobevader')
		await banAccount(6320)
		await account(6321, 'KnobHousemate', { signupIp: '203.0.113.50' })
		await account(6322, 'KnobEvader')
		await linkPlatformIdentity(env.DB, 6322, 0, 'steam-knobevader')

		try {
			env.BAN_EVASION_MATCH = 'platform'
			// Signup from the banned IP is open again, since that arm is off...
			expect((await postToken('grant_type=create_account', '203.0.113.50')).status).toBe(200)
			// ...while the platform arm still refuses one from the banned headset.
			expect(
				(await postToken('grant_type=create_account&platform=0&platform_id=steam-knobevader'))
					.status
			).toBe(400)

			// Signing in is not what the knob gates: every one of these gets a token whatever it
			// says — the housemate, the evader, and the banned account itself.
			for (const arms of ['platform', 'off']) {
				env.BAN_EVASION_MATCH = arms
				for (const id of [6320, 6321, 6322]) {
					expect((await login(id)).status, `${arms}/${id}`).toBe(200)
				}
			}
		} finally {
			env.BAN_EVASION_MATCH = original
		}
	})
})

// A staff sign-in is recorded on the `audit_log` table — the same table `notify` files
// every `/internal/*` call on. What those accounts then do is attributed to them; this is
// the row that says the session it came from began, and from what device, build and IP.
describe('staff login audit', () => {
	interface AuditRow {
		player_id: number
		action: string
		data: string | null
		date: string
	}

	const staffLogins = async (accountId: number): Promise<AuditRow[]> => {
		const { results } = await env.DB.prepare(
			`SELECT player_id, action, data, date FROM audit_log
			 WHERE player_id = ?1 AND action = 'staff_login' ORDER BY audit_log_id`
		)
			.bind(accountId)
			.all<AuditRow>()
		return results
	}

	/** Seed an account with the given flags and a known password. */
	const seedAccount = async (accountId: number, data: Record<string, unknown>) =>
		env.DB.prepare('INSERT OR IGNORE INTO account (data) VALUES (?1)')
			.bind(
				JSON.stringify({
					accountId,
					username: `Staff${accountId}`,
					passwordHash: await hashPassword(LOGIN_PASSWORD),
					...data,
				})
			)
			.run()

	test('a login by an isModerator account is recorded, with the context of the sign-in', async () => {
		await seedAccount(9601, { username: 'ModPlayer', isModerator: true })
		const res = await postToken(
			`grant_type=password&account_id=9601&password=${LOGIN_PASSWORD}` +
				'&device_id=dev-mod&device_class=2&ver=20230414',
			'203.0.113.9'
		)
		expect(res.status).toBe(200)

		const rows = await staffLogins(9601)
		expect(rows).toHaveLength(1)
		expect(Number.isNaN(Date.parse(rows[0].date))).toBe(false)
		const data = JSON.parse(rows[0].data!) as Record<string, unknown>
		expect(data).toMatchObject({
			ip: '203.0.113.9',
			roles: ['moderator'],
			grantType: 'password',
			username: 'ModPlayer',
			deviceId: 'dev-mod',
			deviceClass: 2,
			version: '20230414',
		})
		// The IP LEADS the payload: it is the first thing anyone asks of a staff sign-in, and
		// the reader of a raw row should not have to hunt for it.
		expect(Object.keys(data)[0]).toBe('ip')
	})

	// Both flags on one account record both — the row says which powers the session carries,
	// not merely that it carries some.
	test('an account holding both flags records both roles', async () => {
		await seedAccount(9602, { isDeveloper: true, isModerator: true })
		expect((await postToken(`account_id=9602&password=${LOGIN_PASSWORD}`)).status).toBe(200)

		const rows = await staffLogins(9602)
		expect(rows).toHaveLength(1)
		expect((JSON.parse(rows[0].data!) as { roles: string[] }).roles).toEqual([
			'developer',
			'moderator',
		])
	})

	// The flags are the whole trigger. An ordinary player signing in is not an audit event,
	// and recording every login would bury the ones that are.
	test('an ordinary login records nothing', async () => {
		await seedAccount(9603, {})
		expect((await postToken(`account_id=9603&password=${LOGIN_PASSWORD}`)).status).toBe(200)
		expect(await staffLogins(9603)).toHaveLength(0)
	})

	// A refresh renews the SAME session every TOKEN_TTL_SECONDS. Recording those would bury
	// the actual sign-ins under hourly repeats saying nothing new about who came in or from
	// where — so the login is recorded once, and the refreshes after it are not.
	test('a refresh_token grant is not a login and is not recorded', async () => {
		await seedAccount(9604, { isDeveloper: true })
		const first = await postToken(`account_id=9604&password=${LOGIN_PASSWORD}`)
		expect(first.status).toBe(200)
		expect(await staffLogins(9604)).toHaveLength(1)

		const refreshed = await postToken(
			`grant_type=refresh_token&refresh_token=${first.json.refresh_token as string}`
		)
		expect(refreshed.status).toBe(200)
		expect(await staffLogins(9604)).toHaveLength(1)
	})

	// The flag is read at LOGIN, exactly as `rn.plus` and the token's `role` claim are, so
	// granting the role starts the trail at their next sign-in rather than retroactively.
	test('an account granted the role starts being recorded on its next login', async () => {
		await seedAccount(9605, {})
		expect((await postToken(`account_id=9605&password=${LOGIN_PASSWORD}`)).status).toBe(200)
		expect(await staffLogins(9605)).toHaveLength(0)

		await env.DB.prepare(
			`UPDATE account SET data = json_set(data, '$.isModerator', json('true')) WHERE account_id = ?1`
		)
			.bind(9605)
			.run()

		expect((await postToken(`account_id=9605&password=${LOGIN_PASSWORD}`)).status).toBe(200)
		expect(await staffLogins(9605)).toHaveLength(1)
	})
})

// The website's "Sign in with Discord". `www` proves the Discord user (it holds the client
// secret) and posts an identity ASSERTION signed with the shared JWT_SECRET; this grant
// resolves it through the link table like a cached_login, or makes the account when there
// is none. Everything here mints the assertion the way www does, with the test key.
describe('identity_assertion grant', () => {
	const SIGNING_KEY = 'test-signing-key'
	const assertionFor = (platformId: string, platform = PlatformType.Discord) =>
		generateIdentityAssertion({ platform, platformId }, SIGNING_KEY)
	const redeem = async (assertion: string, ip?: string) =>
		postToken(`grant_type=identity_assertion&assertion=${encodeURIComponent(assertion)}`, ip)

	test('an assertion round-trips, and nothing else passes as one', async () => {
		const assertion = await assertionFor('700000000000000001')
		await expect(validateIdentityAssertion(assertion, SIGNING_KEY)).resolves.toEqual({
			platform: PlatformType.Discord,
			platformId: '700000000000000001',
		})
		// A different key, and an access token signed with the RIGHT key: both refused. The
		// second is the one that matters — the same secret signs sessions, so the audience is
		// what keeps a stolen token from being replayed as proof of a platform identity.
		await expect(validateIdentityAssertion(assertion, 'another-key')).resolves.toBeNull()
		const session = await generateToken('42', '', 4, SIGNING_KEY)
		await expect(validateIdentityAssertion(session, SIGNING_KEY)).resolves.toBeNull()
		// And the other direction: an assertion carries no `sub`, so it is no session.
		const res = await exports.default.fetch(`${ORIGIN}/connect/device/approve`, {
			method: 'POST',
			headers: {
				'Content-Type': 'application/x-www-form-urlencoded',
				Authorization: `Bearer ${assertion}`,
			},
			body: 'user_code=ABCDEFGH',
		})
		expect(res.status).toBe(401)
	})

	test('signs into the one account the identity is linked to', async () => {
		await seedAccount(9400, 'DiscordLinked')
		// Linked the way the benefits claim links: with roles recorded.
		await linkPlatformIdentity(env.DB, 9400, PlatformType.Discord, '700000000000009400', [])
		const res = await redeem(await assertionFor('700000000000009400'))
		expect(res.status).toBe(200)
		expect(decodePayload(res.json.access_token as string).sub).toBe('9400')
		expect(res.json).not.toHaveProperty('created')
		expect(typeof res.json.refresh_token).toBe('string')
	})

	test('refuses a missing, forged or replayed-session assertion', async () => {
		expect((await postToken('grant_type=identity_assertion')).status).toBe(400)
		const forged = await generateIdentityAssertion(
			{ platform: PlatformType.Discord, platformId: '700000000000009400' },
			'not-the-key'
		)
		const res = await redeem(forged)
		expect(res.status).toBe(400)
		expect(res.json.error_description).toBe('invalid or expired identity assertion')
		// An access token for the linked account, presented as the assertion.
		const session = await generateToken('9400', '', 4, SIGNING_KEY)
		expect((await redeem(session)).status).toBe(400)
	})

	test('creates and links an account when the identity opens none, once', async () => {
		const discordId = '700000000000009401'
		const first = await redeem(await assertionFor(discordId))
		expect(first.status).toBe(200)
		expect(first.json.created).toBe(true)
		const accountId = Number(decodePayload(first.json.access_token as string).sub)
		expect(accountId).toBeGreaterThan(0)

		// Linked on the Discord platform, and ONLY there: the blob carries no platform
		// identity (the snowflake stays off the DTO and the token), like a password account.
		const links = await getLinksForAccount(env.DB, accountId)
		expect(links.map((l) => [l.platform, l.platformId])).toEqual([
			[PlatformType.Discord, discordId],
		])
		const row = await env.DB.prepare('SELECT data FROM account WHERE account_id = ?1')
			.bind(accountId)
			.first<{ data: string }>()
		const blob = JSON.parse(row!.data) as Record<string, unknown>
		expect(blob.platformId).toBeUndefined()
		expect(blob.passwordHash).toBeUndefined()
		// Placed in Orientation like any signup.
		const presence = await env.DB.prepare('SELECT 1 AS ok FROM presence WHERE account_id = ?1')
			.bind(accountId)
			.first()
		expect(presence).not.toBeNull()

		// The same Discord again is a sign-IN to that account, not a second account.
		const again = await redeem(await assertionFor(discordId))
		expect(again.status).toBe(200)
		expect(again.json).not.toHaveProperty('created')
		expect(decodePayload(again.json.access_token as string).sub).toBe(String(accountId))
		await expect(
			countAccountsForPlatformIdentity(env.DB, PlatformType.Discord, discordId)
		).resolves.toBe(1)
	})

	// The stretch of the feature: a Discord-made account has no password, and a password is
	// what signs it into the game (a sideloaded Quest has no Meta nonce to offer). The
	// website's password form posts with an EMPTY old password the first time.
	test('a Discord-made account can set a password and then sign in with it', async () => {
		const created = await redeem(await assertionFor('700000000000009402'))
		const accountId = decodePayload(created.json.access_token as string).sub as string
		expect((await postToken(`account_id=${accountId}&password=hunter22`)).status).toBe(400)

		const set = await changePassword(
			'oldPassword=&newPassword=hunter22',
			created.json.access_token as string
		)
		expect(set.status).toBe(200)
		const login = await postToken(`grant_type=password&account_id=${accountId}&password=hunter22`)
		expect(login.status).toBe(200)
		expect(decodePayload(login.json.access_token as string).sub).toBe(accountId)
	})

	test('refuses an identity that opens several accounts rather than guessing', async () => {
		await seedAccount(9403, 'TwoLinksA')
		await seedAccount(9404, 'TwoLinksB')
		await linkPlatformIdentity(env.DB, 9403, PlatformType.Discord, '700000000000009403', [])
		await linkPlatformIdentity(env.DB, 9404, PlatformType.Discord, '700000000000009403', [])
		const res = await redeem(await assertionFor('700000000000009403'))
		expect(res.status).toBe(400)
		expect(res.json.error_description).toBe('platform identity is linked to more than one account')
	})

	// The signup caps reach this path as they reach create_account — www forwards the
	// browser's real address over the service binding, so the per-IP cap counts browsers.
	test('the per-IP signup cap applies to accounts made this way', async () => {
		const ip = '198.51.100.77'
		for (let i = 0; i < 3; i++) {
			const res = await redeem(await assertionFor(`70000000000000950${i}`), ip)
			expect(res.status).toBe(200)
			expect(res.json.created).toBe(true)
		}
		const fourth = await redeem(await assertionFor('700000000000009509'), ip)
		expect(fourth.status).toBe(400)
		expect(fourth.json.error_description).toBe('too many accounts created from this network')
		// Signing IN from that network is untouched: the cap is on creation.
		const existing = await redeem(await assertionFor('700000000000009500'), ip)
		expect(existing.status).toBe(200)
	})
})
