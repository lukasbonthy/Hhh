import { adminSecretsStore, env } from 'cloudflare:test'
import { exports } from 'cloudflare:workers'
import { beforeAll, describe, expect, test } from 'vitest'

import '../../accounts.app'

import {
	EMAIL_CODE_SCHEMA_DDL,
	hashPassword,
	RATE_LIMIT_SCHEMA_DDL,
	SCHEMA_DDL,
} from '@repo/domain'

import { WHITELISTED_EMOJIS } from '../../whitelisted-emojis'

import type { Env } from '../../context'

declare module 'cloudflare:test' {
	interface ProvidedEnv extends Env {}
}

const ORIGIN = 'https://example.com'

// Apply the accounts schema + seed the system (uid 0) and Coach (uid 1) accounts
// into the test D1 (mirrors apps/auth/migrations/0001_accounts.sql).
beforeAll(async () => {
	// Seed the shared JWT signing key into the local Secrets Store so .get() resolves.
	await adminSecretsStore(env.JWT_SECRET).create('test-signing-key')
	for (const stmt of SCHEMA_DDL) await env.DB.prepare(stmt).run()
	// The codes an email change is confirmed with (owned by `auth`'s migrations).
	for (const stmt of EMAIL_CODE_SCHEMA_DDL) await env.DB.prepare(stmt).run()
	// The counters that cap how many of those go out per account and day.
	for (const stmt of RATE_LIMIT_SCHEMA_DDL) await env.DB.prepare(stmt).run()
	const insert = env.DB.prepare('INSERT OR IGNORE INTO account (data) VALUES (?1)')
	await env.DB.batch([
		insert.bind(JSON.stringify({ accountId: 0, username: 'RecRoom', displayName: 'Rec Room' })),
		insert.bind(JSON.stringify({ accountId: 1, username: 'Coach', displayName: 'Coach' })),
	])
})

// Mint a token the way the `auth` worker does, signing with the shared test key seeded into the JWT_SECRET store, so the
// accounts worker's validation accepts it. Kept inline to avoid a cross-package
// import.
const TEST_SECRET = 'test-signing-key'

function b64url(input: ArrayBuffer | string): string {
	const bytes = typeof input === 'string' ? new TextEncoder().encode(input) : new Uint8Array(input)
	let binary = ''
	for (const byte of bytes) binary += String.fromCharCode(byte)
	return btoa(binary).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '')
}

async function bearer(
	sub = '42',
	claims: Record<string, unknown> = {}
): Promise<Record<string, string>> {
	const now = Math.floor(Date.now() / 1000)
	const signingInput = `${b64url(JSON.stringify({ alg: 'HS256', typ: 'JWT' }))}.${b64url(
		JSON.stringify({ sub, exp: now + 3600, ...claims })
	)}`
	const key = await crypto.subtle.importKey(
		'raw',
		new TextEncoder().encode(TEST_SECRET),
		{ name: 'HMAC', hash: 'SHA-256' },
		false,
		['sign']
	)
	const sig = await crypto.subtle.sign('HMAC', key, new TextEncoder().encode(signingInput))
	return { Authorization: `Bearer ${signingInput}.${b64url(sig)}` }
}

/** The `rn.plus` claim `auth` stamps for a Rec Room Plus account. */
const PLUS = { 'rn.plus': true }

const form = (fields: Record<string, string>): RequestInit => ({
	method: 'PUT',
	headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
	body: new URLSearchParams(fields).toString(),
})

describe('public endpoints', () => {
	test('GET / returns a health response', async () => {
		const res = await exports.default.fetch(`${ORIGIN}/`)
		expect(res.status).toBe(200)
		expect(await res.json()).toEqual({ service: 'accounts', status: 'ok' })
	})

	test('GET /account/:id returns a default account', async () => {
		const res = await exports.default.fetch(`${ORIGIN}/account/123`)
		expect(res.status).toBe(200)
		expect(await res.json()).toMatchObject({
			accountId: 123,
			username: 'Player123',
			displayName: 'Player123',
			profileImage: 'DefaultProfileImage.jpg',
		})
	})

	test('GET /account/:id rejects a non-numeric id', async () => {
		const res = await exports.default.fetch(`${ORIGIN}/account/abc`)
		expect(res.status).toBe(400)
	})

	test('GET /account/bulk resolves stored accounts and synthesizes the rest', async () => {
		const res = await exports.default.fetch(`${ORIGIN}/account/bulk?id=1&id=2,3`)
		expect(res.status).toBe(200)
		const accounts = (await res.json()) as Array<{ accountId: number; username: string }>
		// Every requested id is present and in order.
		expect(accounts.map((a) => a.accountId)).toEqual([1, 2, 3])
		// id 1 is the seeded Coach account; 2 and 3 fall back to synthesized defaults.
		expect(accounts[0].username).toBe('Coach')
		expect(accounts[1].username).toBe('Player2')
	})

	test('POST /account/bulk reads the ids from a form body', async () => {
		// The 2023 client asks for its friends list as a POST — the ids are in a
		// form-urlencoded body, not the query string. GET-only left it a 404.
		const res = await exports.default.fetch(`${ORIGIN}/account/bulk`, {
			method: 'POST',
			headers: { 'content-type': 'application/x-www-form-urlencoded' },
			body: 'id=1&id=2&id=3',
		})
		expect(res.status).toBe(200)
		const accounts = (await res.json()) as Array<{ accountId: number; username: string }>
		expect(accounts.map((a) => a.accountId)).toEqual([1, 2, 3])
		expect(accounts[0].username).toBe('Coach')
	})

	test('POST /account/bulk answers more ids than D1 will bind at once', async () => {
		// D1 caps a statement at 100 bound parameters; a real friends list runs past that,
		// and an unchunked `IN (…)` 500s. Requesting a stored id in the LAST chunk proves
		// the later statements ran, not just the first.
		const ids = [...Array.from({ length: 250 }, (_, i) => 1000 + i), 1]
		const res = await exports.default.fetch(`${ORIGIN}/account/bulk`, {
			method: 'POST',
			headers: { 'content-type': 'application/x-www-form-urlencoded' },
			body: ids.map((id) => `id=${id}`).join('&'),
		})
		expect(res.status).toBe(200)
		const accounts = (await res.json()) as Array<{ accountId: number; username: string }>
		expect(accounts.map((a) => a.accountId)).toEqual(ids)
		expect(accounts.at(-1)?.username).toBe('Coach')
	})

	test('POST /account/bulk returns one entry per id, deduped', async () => {
		const res = await exports.default.fetch(`${ORIGIN}/account/bulk`, {
			method: 'POST',
			headers: { 'content-type': 'application/x-www-form-urlencoded' },
			// Negative ids are real in the client's list and synthesize like any other.
			body: 'id=1&id=-1&id=1',
		})
		const accounts = (await res.json()) as Array<{ accountId: number; username: string }>
		expect(accounts.map((a) => a.accountId)).toEqual([1, -1])
		expect(accounts[1].username).toBe('Player-1')
	})

	test('GET /account/search prefix-matches usernames, returns public DTOs', async () => {
		const res = await exports.default.fetch(`${ORIGIN}/account/search?name=coa`)
		expect(res.status).toBe(200)
		const accounts = (await res.json()) as Array<{ accountId: number; username: string }>
		// "Coach" (seeded uid 1) matches the "coa" prefix, case-insensitively.
		expect(accounts.some((a) => a.accountId === 1 && a.username === 'Coach')).toBe(true)
		// A non-matching prefix yields nothing.
		const none = await exports.default.fetch(`${ORIGIN}/account/search?name=zzzznope`)
		expect(await none.json()).toEqual([])
		// An empty query yields nothing (no full-table dump).
		const empty = await exports.default.fetch(`${ORIGIN}/account/search?name=`)
		expect(await empty.json()).toEqual([])
	})

	test('GET /account/username/:name is an exact, case-insensitive lookup', async () => {
		const res = await exports.default.fetch(`${ORIGIN}/account/username/coach`)
		expect(res.status).toBe(200)
		const account = (await res.json()) as { accountId: number; username: string }
		expect(account).toMatchObject({ accountId: 1, username: 'Coach' })
		// A leading `@` is tolerated — staff fields take names in that form.
		const at = await exports.default.fetch(
			`${ORIGIN}/account/username/${encodeURIComponent('@Coach')}`
		)
		expect(((await at.json()) as { accountId: number }).accountId).toBe(1)
		// A prefix is NOT a match: that's what `/account/search` is for.
		const prefix = await exports.default.fetch(`${ORIGIN}/account/username/coa`)
		expect(prefix.status).toBe(404)
		const missing = await exports.default.fetch(`${ORIGIN}/account/username/zzzznope`)
		expect(missing.status).toBe(404)
		expect(await missing.json()).toEqual({ error: "There's no player called @zzzznope." })
	})

	test('GET /account/:id/bio returns an empty bio', async () => {
		const res = await exports.default.fetch(`${ORIGIN}/account/7/bio`)
		expect(await res.json()).toEqual({ accountId: 7, bio: '' })
	})

	test('POST /account/create persists a new account with a random username', async () => {
		const res = await exports.default.fetch(`${ORIGIN}/account/create`, { method: 'POST' })
		expect(res.status).toBe(200)
		const body = (await res.json()) as {
			success: boolean
			value: { accountId: number; username: string; displayName: string }
		}
		expect(body.success).toBe(true)
		// Id is allocated above the seeded system accounts (0, 1).
		expect(body.value.accountId).toBeGreaterThanOrEqual(2)
		// Username is auto-assigned (not the synthesized "Player<id>" fallback) and
		// the display name mirrors it.
		expect(body.value.username).not.toMatch(/^Player\d+$/)
		expect(body.value.username.length).toBeGreaterThan(0)
		expect(body.value.displayName).toBe(body.value.username)
		// It's retrievable afterwards.
		const lookup = await exports.default.fetch(`${ORIGIN}/account/${body.value.accountId}`)
		const found = (await lookup.json()) as { username: string }
		expect(found.username).toBe(body.value.username)
	})
})

describe('auth-gated endpoints', () => {
	test('GET /account/me 401s without a token', async () => {
		const res = await exports.default.fetch(`${ORIGIN}/account/me`)
		expect(res.status).toBe(401)
	})

	test('GET /account/me 401s with a garbage token', async () => {
		const res = await exports.default.fetch(`${ORIGIN}/account/me`, {
			headers: { Authorization: 'Bearer not-a-real-token' },
		})
		expect(res.status).toBe(401)
	})

	test('GET /account/me rejects a signed token with a non-canonical account subject', async () => {
		for (const sub of ['42junk', '42.5', '042', '-42', '9007199254740992']) {
			const res = await exports.default.fetch(`${ORIGIN}/account/me`, {
				headers: await bearer(sub),
			})
			expect(res.status, sub).toBe(401)
		}
	})

	test('GET /account/me returns the self account with a valid token', async () => {
		const res = await exports.default.fetch(`${ORIGIN}/account/me`, { headers: await bearer() })
		expect(res.status).toBe(200)
		const body = (await res.json()) as Record<string, unknown>
		// Account JSON is camelCase (the client's AccountDTO), not the PascalCase we
		// store internally.
		expect(body).toMatchObject({
			accountId: 42,
			username: 'Player42',
			personalPronouns: 0,
			identityFlags: 0,
			availableUsernameChanges: 3,
			// An unset email is "", not null — the client reads it as a string, and the
			// hub frame this DTO also rides drops null values outright.
			email: '',
			// Unset on a fresh account, but the key has to be present — the client reads
			// both off the account DTO.
			bannerImage: '',
			displayEmoji: '',
		})
		// juniorState + parentAccountId must be omitted when null, not emitted as
		// null, or the client's enum parser throws on `juniorState`. `phone` isn't
		// part of the shape.
		expect('juniorState' in body).toBe(false)
		expect('parentAccountId' in body).toBe(false)
		expect('phone' in body).toBe(false)
	})

	test('GET /parentalcontrol/me returns the flags', async () => {
		const res = await exports.default.fetch(`${ORIGIN}/parentalcontrol/me`, {
			headers: await bearer(),
		})
		expect(await res.json()).toEqual({ accountId: 42, disallowInAppPurchases: true })
	})

	test('GET /accountprivacysettings/:id echoes the id with the privacy flags', async () => {
		// A bare {} fails the client's deserializer, so the fields have to be there.
		const res = await exports.default.fetch(`${ORIGIN}/accountprivacysettings/145`)
		expect(res.status).toBe(200)
		expect(await res.json()).toEqual({ accountId: 145, isRecentHistoryVisible: true })
	})

	test('PUT /account/me/displayname 401s without a token', async () => {
		const res = await exports.default.fetch(`${ORIGIN}/account/me/displayname`, {
			...form({ displayName: 'Bob' }),
		})
		expect(res.status).toBe(401)
	})

	test('PUT /account/me/displayname persists the display name', async () => {
		const headers = {
			...(await bearer('895')),
			'Content-Type': 'application/x-www-form-urlencoded',
		}
		const res = await exports.default.fetch(`${ORIGIN}/account/me/displayname`, {
			...form({ displayName: 'laskdjfasdlfkj' }),
			headers,
		})
		expect(res.status).toBe(200)
		expect(await res.json()).toEqual({ success: true })

		const me = await exports.default.fetch(`${ORIGIN}/account/me`, { headers: await bearer('895') })
		expect(((await me.json()) as { displayName: string }).displayName).toBe('laskdjfasdlfkj')
	})

	test('PUT /account/me/displayname 400s on a name with a swear in it', async () => {
		const headers = {
			...(await bearer('895')),
			'Content-Type': 'application/x-www-form-urlencoded',
		}
		// These names carry no spaces, so the filter has to find the swear at the seam the
		// player typed instead of one.
		for (const displayName of ['fuck', 'ShitLord', 'Fucker123']) {
			const res = await exports.default.fetch(`${ORIGIN}/account/me/displayname`, {
				...form({ displayName }),
				headers,
			})
			expect(res.status).toBe(400)
		}

		// And the words that merely contain one still get through — refusing these is worse
		// than missing a swear, because the player can't see why.
		for (const displayName of ['Scunthorpe', 'ClassicCar', 'Cumberland']) {
			const res = await exports.default.fetch(`${ORIGIN}/account/me/displayname`, {
				...form({ displayName }),
				headers,
			})
			expect(res.status).toBe(200)
		}
	})

	test('PUT /account/me/username 401s without a token', async () => {
		const res = await exports.default.fetch(`${ORIGIN}/account/me/username`, {
			...form({ username: 'whoever' }),
		})
		expect(res.status).toBe(401)
	})

	test('PUT /account/me/username returns a Success:false envelope for a taken name', async () => {
		// "Coach" is the seeded account 1.
		const res = await exports.default.fetch(`${ORIGIN}/account/me/username`, {
			...form({ username: 'Coach' }),
			headers: { ...(await bearer('893')), 'Content-Type': 'application/x-www-form-urlencoded' },
		})
		// Business errors are HTTP 200 with the { success, error, value } envelope.
		expect(res.status).toBe(200)
		const body = (await res.json()) as { success: boolean; error: string; value: string }
		expect(body.success).toBe(false)
		expect(body.error).toMatch(/already taken/i)
		expect(body.value).toBe('')
	})

	test('PUT /account/me/username refuses a swear without spending a change', async () => {
		const headers = {
			...(await bearer('894')),
			'Content-Type': 'application/x-www-form-urlencoded',
		}
		const res = await exports.default.fetch(`${ORIGIN}/account/me/username`, {
			...form({ username: 'ShitLord' }),
			headers,
		})
		expect(res.status).toBe(200)
		const body = (await res.json()) as { success: boolean; error: string; value: string }
		expect(body.success).toBe(false)
		// Vague on purpose — the message must not print the swear back at the player.
		expect(body.error).toMatch(/can't contain that word/i)
		expect(body.value).toBe('')

		// The schema runs before the handler, so a refused name costs none of the account's
		// rationed changes.
		const me = (await (
			await exports.default.fetch(`${ORIGIN}/account/me`, { headers: await bearer('894') })
		).json()) as { username: string; availableUsernameChanges: number }
		expect(me.availableUsernameChanges).toBe(3)
	})

	test('PUT /account/me/username allows three changes, decrements the counter, then blocks', async () => {
		const headers = {
			...(await bearer('892')),
			'Content-Type': 'application/x-www-form-urlencoded',
		}
		// First change succeeds — value is the updated account.
		const ok = await exports.default.fetch(`${ORIGIN}/account/me/username`, {
			...form({ username: 'coachx' }),
			headers,
		})
		expect(ok.status).toBe(200)
		const okBody = (await ok.json()) as {
			success: boolean
			error: string
			value: { accountId: number; username: string }
		}
		expect(okBody.success).toBe(true)
		expect(okBody.error).toBe('')
		expect(okBody.value).toMatchObject({ accountId: 892, username: 'coachx' })

		// /account/me reflects the new name and the decremented counter.
		const me = (await (
			await exports.default.fetch(`${ORIGIN}/account/me`, { headers: await bearer('892') })
		).json()) as { username: string; availableUsernameChanges: number }
		expect(me.username).toBe('coachx')
		expect(me.availableUsernameChanges).toBe(2)

		// The second and third changes consume the rest of the account's allowance.
		for (const username of ['coachy', 'coachz']) {
			const changed = await exports.default.fetch(`${ORIGIN}/account/me/username`, {
				...form({ username }),
				headers,
			})
			expect(changed.status).toBe(200)
			expect(((await changed.json()) as { success: boolean }).success).toBe(true)
		}

		const exhausted = (await (
			await exports.default.fetch(`${ORIGIN}/account/me`, { headers: await bearer('892') })
		).json()) as { username: string; availableUsernameChanges: number }
		expect(exhausted.username).toBe('coachz')
		expect(exhausted.availableUsernameChanges).toBe(0)

		// A fourth change is blocked — no changes remaining (still HTTP 200).
		const blocked = await exports.default.fetch(`${ORIGIN}/account/me/username`, {
			...form({ username: 'coachq' }),
			headers,
		})
		expect(blocked.status).toBe(200)
		const blockedBody = (await blocked.json()) as { success: boolean; error: string }
		expect(blockedBody.success).toBe(false)
		expect(blockedBody.error).toMatch(/no username changes/i)
	})

	test('PUT /account/me/profileimage 401s without a token', async () => {
		const res = await exports.default.fetch(`${ORIGIN}/account/me/profileimage`, {
			...form({ imageName: 'abc.jpg' }),
		})
		expect(res.status).toBe(401)
	})

	test('PUT /account/me/profileimage 400s without an imageName', async () => {
		const res = await exports.default.fetch(`${ORIGIN}/account/me/profileimage`, {
			...form({}),
			headers: { ...(await bearer('777')), 'Content-Type': 'application/x-www-form-urlencoded' },
		})
		expect(res.status).toBe(400)
	})

	test('PUT /account/me/profileimage persists the avatar on the account', async () => {
		const res = await exports.default.fetch(`${ORIGIN}/account/me/profileimage`, {
			...form({ imageName: 'deadbeef.jpg' }),
			headers: { ...(await bearer('777')), 'Content-Type': 'application/x-www-form-urlencoded' },
		})
		expect(res.status).toBe(200)
		expect(await res.json()).toEqual({ success: true })

		// The stored value is returned by the self account (no hardcoded override).
		const me = await exports.default.fetch(`${ORIGIN}/account/me`, { headers: await bearer('777') })
		expect(((await me.json()) as { profileImage: string }).profileImage).toBe('deadbeef.jpg')
	})

	test('PUT /account/me/bannerimage persists the banner and pushes the profile update', async () => {
		type Sent = { playerId: number; notificationType: string | number; data: unknown }
		const hub = () => env.RECFLARE_NOTIFICATIONS_HUB.getByName('global')
		await hub().fetch('http://do/', { method: 'DELETE' })

		const key = 'sharecamera/2026-08-18/75c295fd-8f1b-402e-961d-5c277fd56690.jpg'
		const res = await exports.default.fetch(`${ORIGIN}/account/me/bannerimage`, {
			...form({ imageName: key }),
			headers: { ...(await bearer('778')), 'Content-Type': 'application/x-www-form-urlencoded' },
		})
		expect(res.status).toBe(200)
		expect(await res.json()).toEqual({ success: true })

		// Stored on the account, and served back by both the self and public reads.
		const me = await exports.default.fetch(`${ORIGIN}/account/me`, { headers: await bearer('778') })
		expect(((await me.json()) as { bannerImage: string }).bannerImage).toBe(key)
		const pub = await exports.default.fetch(`${ORIGIN}/account/778`)
		expect(((await pub.json()) as { bannerImage: string }).bannerImage).toBe(key)

		// And the profile-update notification fired, carrying the new banner — so anyone
		// looking at the profile redraws it without refetching.
		const sent = (await (await hub().fetch('http://do/all')).json()) as Sent[]
		expect(sent.length).toBeGreaterThan(0)
		expect(sent.every((n) => n.playerId === 778)).toBe(true)
		expect(sent.map((n) => (n.data as { bannerImage?: string }).bannerImage)).toContain(key)
	})

	test('PUT /account/me/emoji persists the emoji and pushes the profile update', async () => {
		type Sent = { playerId: number; notificationType: string | number; data: unknown }
		const hub = () => env.RECFLARE_NOTIFICATIONS_HUB.getByName('global')
		await hub().fetch('http://do/', { method: 'DELETE' })

		// Exactly the body the client sends: one urlencoded field (`%F0%9F%A4%AA`).
		const res = await exports.default.fetch(`${ORIGIN}/account/me/emoji`, {
			method: 'PUT',
			headers: {
				...(await bearer('779', PLUS)),
				'Content-Type': 'application/x-www-form-urlencoded',
			},
			body: 'displayEmoji=%F0%9F%A4%AA',
		})
		expect(res.status).toBe(200)
		expect(await res.json()).toEqual({ success: true })

		// Served back by both the self and public reads — displayEmoji is in the public DTO.
		const me = await exports.default.fetch(`${ORIGIN}/account/me`, { headers: await bearer('779') })
		expect(((await me.json()) as { displayEmoji: string }).displayEmoji).toBe('\u{1F92A}')
		const pub = await exports.default.fetch(`${ORIGIN}/account/779`)
		expect(((await pub.json()) as { displayEmoji: string }).displayEmoji).toBe('\u{1F92A}')

		// And it rides the profile-update notification, so it redraws beside the name.
		const sent = (await (await hub().fetch('http://do/all')).json()) as Sent[]
		expect(sent.length).toBeGreaterThan(0)
		expect(sent.map((n) => (n.data as { displayEmoji?: string }).displayEmoji)).toContain(
			'\u{1F92A}'
		)
	})

	// The pick is stored in the whitelist's CANONICAL form. A client that posts the emoji
	// without its U+FE0F variation selector means the same pick, but storing what arrived
	// would leave a string the picker list no longer matches, so the current pick would
	// stop highlighting.
	test('PUT /account/me/emoji canonicalizes a pick sent without its variation selector', async () => {
		const res = await exports.default.fetch(`${ORIGIN}/account/me/emoji`, {
			...form({ displayEmoji: '\u{2764}' }),
			headers: {
				...(await bearer('780', PLUS)),
				'Content-Type': 'application/x-www-form-urlencoded',
			},
		})
		expect(res.status).toBe(200)

		const me = await exports.default.fetch(`${ORIGIN}/account/me`, { headers: await bearer('780') })
		const stored = ((await me.json()) as { displayEmoji: string }).displayEmoji
		expect(stored).toBe('\u{2764}\u{FE0F}')
		expect(WHITELISTED_EMOJIS).toContain(stored)
	})

	// An empty value clears the pick rather than 400ing — that's how the picker's "none"
	// gets back to no emoji at all.
	test('PUT /account/me/emoji clears the pick on an empty value', async () => {
		const set = await exports.default.fetch(`${ORIGIN}/account/me/emoji`, {
			...form({ displayEmoji: '\u{1F389}' }),
			headers: {
				...(await bearer('781', PLUS)),
				'Content-Type': 'application/x-www-form-urlencoded',
			},
		})
		expect(set.status).toBe(200)

		const cleared = await exports.default.fetch(`${ORIGIN}/account/me/emoji`, {
			...form({ displayEmoji: '' }),
			headers: {
				...(await bearer('781', PLUS)),
				'Content-Type': 'application/x-www-form-urlencoded',
			},
		})
		expect(cleared.status).toBe(200)

		const me = await exports.default.fetch(`${ORIGIN}/account/me`, { headers: await bearer('781') })
		expect(((await me.json()) as { displayEmoji: string }).displayEmoji).toBe('')
	})

	// displayEmoji renders beside the display name, so an unchecked field would be a
	// free-text label on every profile. Off-list values are refused, not stored.
	test('PUT /account/me/emoji 401s without a token, 400s on an off-list value', async () => {
		const anon = await exports.default.fetch(`${ORIGIN}/account/me/emoji`, {
			...form({ displayEmoji: '\u{1F92A}' }),
		})
		expect(anon.status).toBe(401)

		for (const displayEmoji of ['not an emoji', '\u{1F92A}\u{1F92A}', '\u{1F595}\u{1F3FB}']) {
			const res = await exports.default.fetch(`${ORIGIN}/account/me/emoji`, {
				...form({ displayEmoji }),
				headers: {
					...(await bearer('782', PLUS)),
					'Content-Type': 'application/x-www-form-urlencoded',
				},
			})
			expect(res.status).toBe(400)
		}

		// Nothing was stored by the refusals.
		const me = await exports.default.fetch(`${ORIGIN}/account/me`, { headers: await bearer('782') })
		expect(((await me.json()) as { displayEmoji: string }).displayEmoji).toBe('')
	})

	// Setting an emoji is a Rec Room Plus perk; clearing one is not, so a player whose Plus
	// lapsed can still take an old pick down.
	test('PUT /account/me/emoji 403s a set without Rec Room Plus but allows a clear', async () => {
		const headers = {
			...(await bearer('783')),
			'Content-Type': 'application/x-www-form-urlencoded',
		}
		const set = await exports.default.fetch(`${ORIGIN}/account/me/emoji`, {
			...form({ displayEmoji: '\u{1F92A}' }),
			headers,
		})
		expect(set.status).toBe(403)

		const notPlus = await exports.default.fetch(`${ORIGIN}/account/me/emoji`, {
			...form({ displayEmoji: '\u{1F92A}' }),
			headers: {
				...(await bearer('783', { 'rn.plus': 'true' })),
				'Content-Type': 'application/x-www-form-urlencoded',
			},
		})
		expect(notPlus.status).toBe(403)

		const me = await exports.default.fetch(`${ORIGIN}/account/me`, { headers: await bearer('783') })
		expect(((await me.json()) as { displayEmoji: string }).displayEmoji).toBe('')

		const clear = await exports.default.fetch(`${ORIGIN}/account/me/emoji`, {
			...form({ displayEmoji: '' }),
			headers,
		})
		expect(clear.status).toBe(200)
	})

	test('PUT /account/me/bannerimage 401s without a token, 400s without an imageName', async () => {
		const anon = await exports.default.fetch(`${ORIGIN}/account/me/bannerimage`, {
			...form({ imageName: 'x.jpg' }),
		})
		expect(anon.status).toBe(401)

		const empty = await exports.default.fetch(`${ORIGIN}/account/me/bannerimage`, {
			...form({}),
			headers: { ...(await bearer('778')), 'Content-Type': 'application/x-www-form-urlencoded' },
		})
		expect(empty.status).toBe(400)
	})

	test('PUT /account/me/identityflags 401s without a token', async () => {
		const res = await exports.default.fetch(`${ORIGIN}/account/me/identityflags`, {
			...form({ identityFlags: '384' }),
		})
		expect(res.status).toBe(401)
	})

	test('PUT /account/me/identityflags 400s on a non-numeric value', async () => {
		const res = await exports.default.fetch(`${ORIGIN}/account/me/identityflags`, {
			...form({ identityFlags: 'nope' }),
			headers: { ...(await bearer('889')), 'Content-Type': 'application/x-www-form-urlencoded' },
		})
		expect(res.status).toBe(400)
	})

	test('PUT /account/me/identityflags persists the flags, surfaced by /account/me', async () => {
		const res = await exports.default.fetch(`${ORIGIN}/account/me/identityflags`, {
			...form({ identityFlags: '384' }),
			headers: { ...(await bearer('889')), 'Content-Type': 'application/x-www-form-urlencoded' },
		})
		expect(res.status).toBe(200)
		expect(await res.json()).toEqual({ success: true })

		const me = await exports.default.fetch(`${ORIGIN}/account/me`, { headers: await bearer('889') })
		expect(((await me.json()) as { identityFlags: number }).identityFlags).toBe(384)
	})

	test('POST /account/me/phone 401s without a token', async () => {
		const res = await exports.default.fetch(`${ORIGIN}/account/me/phone`, {
			method: 'POST',
			headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
			body: 'phone=%2B14444444444',
		})
		expect(res.status).toBe(401)
	})

	test('POST /account/me/phone 400s on empty, persists a real number', async () => {
		const headers = {
			...(await bearer('891')),
			'Content-Type': 'application/x-www-form-urlencoded',
		}
		// Empty phone → 400.
		const empty = await exports.default.fetch(`${ORIGIN}/account/me/phone`, {
			method: 'POST',
			headers,
			body: 'phone=',
		})
		expect(empty.status).toBe(400)

		// Set it → success.
		const res = await exports.default.fetch(`${ORIGIN}/account/me/phone`, {
			method: 'POST',
			headers,
			body: 'phone=%2B14444444444',
		})
		expect(res.status).toBe(200)
		expect(await res.json()).toEqual({ success: true })
	})

	test('PUT /account/me/personalpronouns persists the value, surfaced by /account/me', async () => {
		const res = await exports.default.fetch(`${ORIGIN}/account/me/personalpronouns`, {
			...form({ pronounFlags: '2' }),
			headers: { ...(await bearer('894')), 'Content-Type': 'application/x-www-form-urlencoded' },
		})
		expect(res.status).toBe(200)
		expect(await res.json()).toEqual({ success: true })

		const me = await exports.default.fetch(`${ORIGIN}/account/me`, { headers: await bearer('894') })
		expect(((await me.json()) as { personalPronouns: number }).personalPronouns).toBe(2)
	})

	test('PUT /account/me/bio 401s without a token', async () => {
		const res = await exports.default.fetch(`${ORIGIN}/account/me/bio`, { ...form({ bio: 'x' }) })
		expect(res.status).toBe(401)
	})

	test('PUT /account/me/bio persists the bio, read back via GET /account/:id/bio', async () => {
		const res = await exports.default.fetch(`${ORIGIN}/account/me/bio`, {
			...form({ bio: 'Devin!' }),
			headers: { ...(await bearer('890')), 'Content-Type': 'application/x-www-form-urlencoded' },
		})
		expect(res.status).toBe(200)
		expect(await res.json()).toEqual({ success: true })

		const bio = await exports.default.fetch(`${ORIGIN}/account/890/bio`)
		expect(await bio.json()).toEqual({ accountId: 890, bio: 'Devin!' })
	})

	test('POST /account/me/email 401s without a token', async () => {
		const res = await exports.default.fetch(`${ORIGIN}/account/me/email`, {
			...form({ email: 'a@b.com' }),
			method: 'POST',
		})
		expect(res.status).toBe(401)
	})

	test('POST /account/me/email 400s on a malformed email', async () => {
		const res = await exports.default.fetch(`${ORIGIN}/account/me/email`, {
			...form({ email: 'notanemail' }),
			method: 'POST',
			headers: { ...(await bearer('888')), 'Content-Type': 'application/x-www-form-urlencoded' },
		})
		expect(res.status).toBe(400)
	})

	/** POST an address for an account, as the website and the game do. */
	const postEmail = async (id: string, email: string) =>
		exports.default.fetch(`${ORIGIN}/account/me/email`, {
			...form({ email }),
			method: 'POST',
			headers: { ...(await bearer(id)), 'Content-Type': 'application/x-www-form-urlencoded' },
		})
	/** POST a code to confirm the account's staged change. */
	const confirmEmail = async (id: string, code: string) =>
		exports.default.fetch(`${ORIGIN}/account/me/email/confirm`, {
			...form({ code }),
			method: 'POST',
			headers: { ...(await bearer(id)), 'Content-Type': 'application/x-www-form-urlencoded' },
		})
	const pendingEmail = async (id: string) =>
		(await (
			await exports.default.fetch(`${ORIGIN}/account/me/email/pending`, {
				headers: await bearer(id),
			})
		).json()) as { pending: string | null; sentTo: string | null }
	const emailOf = async (id: string) =>
		(
			(await (
				await exports.default.fetch(`${ORIGIN}/account/me`, { headers: await bearer(id) })
			).json()) as { email: string }
		).email
	type Purpose = 'email_change' | 'email_verify'
	/** The staged step's row. Only the code's hash is stored; `plantCode` puts a known one in. */
	const stagedRow = (id: string, purpose: Purpose) =>
		env.DB.prepare(
			'SELECT code_hash AS codeHash, payload, created_at AS createdAt FROM email_code WHERE account_id = ?1 AND purpose = ?2'
		)
			.bind(Number(id), purpose)
			.first<{ codeHash: string | null; payload: string; createdAt: number }>()
	const plantCode = async (id: string, purpose: Purpose, code: string) => {
		await env.DB.prepare(
			'UPDATE email_code SET code_hash = ?2 WHERE account_id = ?1 AND purpose = ?3'
		)
			.bind(Number(id), await hashPassword(code), purpose)
			.run()
	}
	/** Set an address the way a player does, through every step the account needs. */
	const setEmail = async (id: string, email: string) => {
		const staged = await postEmail(id, email)
		if (staged.status !== 200) return staged
		if ((await pendingEmail(id)).sentTo !== email) {
			await plantCode(id, 'email_change', '100000')
			const approved = await confirmEmail(id, '100000')
			if (approved.status !== 200) return approved
		}
		await plantCode(id, 'email_verify', '100001')
		return confirmEmail(id, '100001')
	}

	test('POST /account/me/email on an account with no address: one code, to the new address', async () => {
		const res = await postEmail('888', 'ners@recroom.com')
		expect(res.status).toBe(200)
		expect(await res.json()).toEqual({ success: true })

		// Staged, not applied: the self account still has no email, and the pending read says
		// where the code went — the NEW address, since there is nobody else to ask.
		expect(await emailOf('888')).toBe('')
		expect(await pendingEmail('888')).toEqual({
			pending: 'ners@recroom.com',
			sentTo: 'ners@recroom.com',
		})
		const row = await stagedRow('888', 'email_verify')
		expect(row?.payload).toBe('ners@recroom.com')
		expect(row?.codeHash).toMatch(/^[^:]+:[^:]+$/)
		expect(await stagedRow('888', 'email_change')).toBeNull()

		await plantCode('888', 'email_verify', '123456')
		const ok = await confirmEmail('888', '123456')
		expect(ok.status).toBe(200)
		expect(await ok.json()).toEqual({ success: true, applied: true, pending: null, sentTo: null })
		expect(await emailOf('888')).toBe('ners@recroom.com')
		expect(await pendingEmail('888')).toEqual({ pending: null, sentTo: null })

		// Spent: the same code again is refused.
		expect((await confirmEmail('888', '123456')).status).toBe(400)
	})

	test('with no address on file, a mistyped address can be replaced at once; the same one waits', async () => {
		await postEmail('892', 'typo@exmaple.com')
		const first = await stagedRow('892', 'email_verify')

		// A DIFFERENT address right away: a fresh code, to it.
		expect((await postEmail('892', 'right@example.com')).status).toBe(200)
		const second = await stagedRow('892', 'email_verify')
		expect(second?.payload).toBe('right@example.com')
		expect(second?.codeHash).not.toBe(first?.codeHash)
		expect((await pendingEmail('892')).sentTo).toBe('right@example.com')

		// The SAME address again within the cooldown is a repeat, and refused.
		const repeat = await postEmail('892', 'right@example.com')
		expect(repeat.status).toBe(400)
		expect(((await repeat.json()) as { error: string }).error).toMatch(/less than two minutes/)
		expect(await stagedRow('892', 'email_verify')).toEqual(second)
	})

	test('with an address on file, the current address approves and then the new one confirms', async () => {
		expect((await setEmail('889', 'first@example.com')).status).toBe(200)
		expect(await emailOf('889')).toBe('first@example.com')

		// Step 1: the code goes to the address being given up, not the new one.
		expect((await postEmail('889', 'second@example.com')).status).toBe(200)
		expect(await pendingEmail('889')).toEqual({
			pending: 'second@example.com',
			sentTo: 'first@example.com',
		})
		expect(await stagedRow('889', 'email_verify')).toBeNull()
		expect(await emailOf('889')).toBe('first@example.com')

		// Approving it applies nothing yet: step 2's code goes to the new address.
		await plantCode('889', 'email_change', '111111')
		const approved = await confirmEmail('889', '111111')
		expect(approved.status).toBe(200)
		expect(await approved.json()).toEqual({
			success: true,
			applied: false,
			pending: 'second@example.com',
			sentTo: 'second@example.com',
		})
		expect(await stagedRow('889', 'email_change')).toBeNull()
		expect(await pendingEmail('889')).toEqual({
			pending: 'second@example.com',
			sentTo: 'second@example.com',
		})
		expect(await emailOf('889')).toBe('first@example.com')

		// Step 2 lands it.
		await plantCode('889', 'email_verify', '222222')
		const done = await confirmEmail('889', '222222')
		expect(await done.json()).toEqual({ success: true, applied: true, pending: null, sentTo: null })
		expect(await emailOf('889')).toBe('second@example.com')
	})

	test('a wrong code at either step voids the change; a new attempt starts again at step 1', async () => {
		expect((await setEmail('893', 'keep@example.com')).status).toBe(200)

		// Wrong at step 1: burned, and the right code no longer works.
		await postEmail('893', 'next@example.com')
		await plantCode('893', 'email_change', '333333')
		const wrong = await confirmEmail('893', '999999')
		expect(wrong.status).toBe(400)
		expect(await wrong.json()).toEqual({
			success: false,
			error: 'That code is wrong or has expired. Save the address again to be sent a new one.',
		})
		expect((await stagedRow('893', 'email_change'))?.codeHash).toBeNull()
		expect(await pendingEmail('893')).toEqual({ pending: null, sentTo: null })
		expect((await confirmEmail('893', '333333')).status).toBe(400)

		// Past the cooldown, try again: step 1 again, then wrong at step 2.
		await env.DB.prepare(
			"UPDATE email_code SET created_at = created_at - 600 WHERE account_id = 893 AND purpose = 'email_change'"
		).run()
		expect((await postEmail('893', 'next@example.com')).status).toBe(200)
		await plantCode('893', 'email_change', '444444')
		expect((await confirmEmail('893', '444444')).status).toBe(200)
		await plantCode('893', 'email_verify', '555555')
		expect((await confirmEmail('893', '000000')).status).toBe(400)
		expect((await stagedRow('893', 'email_verify'))?.codeHash).toBeNull()
		expect((await confirmEmail('893', '555555')).status).toBe(400)
		expect(await emailOf('893')).toBe('keep@example.com')

		// A fresh attempt (cooldown passed) starts at step 1 again, whatever the address: the
		// current address has approved nothing yet.
		await env.DB.prepare(
			"UPDATE email_code SET created_at = created_at - 600 WHERE account_id = 893 AND purpose = 'email_change'"
		).run()
		expect((await postEmail('893', 'other@example.com')).status).toBe(200)
		expect((await pendingEmail('893')).sentTo).toBe('keep@example.com')
		expect(await stagedRow('893', 'email_verify')).toBeNull()
	})

	test('with an address on file, a second attempt within the cooldown is refused whatever the address, and re-saving the same address applies at once', async () => {
		expect((await setEmail('890', 'cool@example.com')).status).toBe(200)
		await postEmail('890', 'cooler@example.com')
		const first = await stagedRow('890', 'email_change')
		// A different new address is still the current inbox being written to: refused.
		const again = await postEmail('890', 'coolest@example.com')
		expect(again.status).toBe(400)
		expect(((await again.json()) as { error: string }).error).toMatch(/less than two minutes/)
		expect(await stagedRow('890', 'email_change')).toEqual(first)

		// Re-saving the current address in another case: no code, applied directly.
		expect((await postEmail('890', 'COOL@example.com')).status).toBe(200)
		expect(await emailOf('890')).toBe('COOL@example.com')
	})

	test('POST /account/me/email sends an account at most five codes a day, typos included', async () => {
		// With no address on file every different address gets a code at once — until the
		// day's five are spent, when the sixth is refused with a reason, not silently.
		for (let i = 0; i < 5; i++) {
			expect((await postEmail('894', `try${i}@example.com`)).status).toBe(200)
		}
		const sixth = await postEmail('894', 'try5@example.com')
		expect(sixth.status).toBe(400)
		expect(((await sixth.json()) as { error: string }).error).toMatch(/today/)
		// The fifth is still the one staged, and still works.
		expect((await pendingEmail('894')).pending).toBe('try4@example.com')
		await plantCode('894', 'email_verify', '123456')
		expect((await confirmEmail('894', '123456')).status).toBe(200)
		expect(await emailOf('894')).toBe('try4@example.com')
	})

	test('POST /account/me/email/confirm refuses an empty code and a code with nothing staged', async () => {
		const empty = await confirmEmail('891', '')
		expect(empty.status).toBe(400)
		const none = await confirmEmail('891', '123456')
		expect(none.status).toBe(400)
		expect(await none.json()).toEqual({
			success: false,
			error: 'That code is wrong or has expired. Save the address again to be sent a new one.',
		})
	})

	test('the email routes 401 without a token', async () => {
		const pending = await exports.default.fetch(`${ORIGIN}/account/me/email/pending`)
		expect(pending.status).toBe(401)
		// A well-formed body, so the refusal is for the missing token and not the form.
		const confirm = await exports.default.fetch(`${ORIGIN}/account/me/email/confirm`, {
			...form({ code: '123456' }),
			method: 'POST',
		})
		expect(confirm.status).toBe(401)
	})

	test('POST /account/me/email refuses an address another account holds, case-insensitively', async () => {
		expect((await setEmail('886', 'shared@example.com')).status).toBe(200)

		// Another account, same address in different case: refused with a sentence the
		// website shows — a 400 like the malformed-address refusal, but with a body.
		const taken = await postEmail('887', 'Shared@Example.com')
		expect(taken.status).toBe(400)
		expect(await taken.json()).toEqual({
			success: false,
			error: 'That email address is already on another account.',
		})
		expect(await emailOf('887')).toBe('')

		// The holder may save it again (a no-op), and may change case — no code either way.
		expect((await postEmail('886', 'shared@example.com')).status).toBe(200)
		expect((await postEmail('886', 'SHARED@example.com')).status).toBe(200)
		expect(await emailOf('886')).toBe('SHARED@example.com')

		// A change that was staged while the address was free is refused as it lands, if
		// another account took the address meanwhile.
		expect((await postEmail('887', 'contested@example.com')).status).toBe(200)
		expect((await setEmail('886', 'contested@example.com')).status).toBe(200)
		await plantCode('887', 'email_verify', '100002')
		const late = await confirmEmail('887', '100002')
		expect(late.status).toBe(400)
		expect(((await late.json()) as { error: string }).error).toMatch(/already on another account/)

		// Once the holder moves on, the address is free.
		expect((await setEmail('886', 'moved@example.com')).status).toBe(200)
		expect((await setEmail('887', 'shared@example.com')).status).toBe(200)
	})

	test('GET /openapi.json documents every route', async () => {
		const res = await exports.default.fetch(`${ORIGIN}/openapi.json`)
		expect(res.status).toBe(200)
		const spec = (await res.json()) as {
			openapi: string
			paths: Record<string, Record<string, { summary?: string }>>
		}
		expect(spec.openapi).toMatch(/^3\.1/)

		// The spec route hides itself.
		expect(spec.paths['/openapi.json']).toBeUndefined()

		// Every route the worker serves is described. This is the drift guard: adding a
		// route without a describeRoute() block fails here rather than silently shipping
		// an incomplete spec. Hono's `:param` syntax becomes OpenAPI's `{param}`.
		const documented = new Set(
			Object.entries(spec.paths).flatMap(([path, ops]) =>
				Object.keys(ops).map((method) => `${method.toUpperCase()} ${path}`)
			)
		)
		expect([...documented].sort()).toEqual([
			'GET /',
			'GET /account/bulk',
			'GET /account/me',
			'GET /account/me/email/pending',
			'GET /account/search',
			'GET /account/username/{name}',
			'GET /account/{id}',
			'GET /account/{id}/bio',
			'GET /accountprivacysettings/{id}',
			'GET /emojiConfig/whitelistedEmojis',
			'GET /parentalcontrol/me',
			'POST /account/bulk',
			'POST /account/create',
			'POST /account/me/email',
			'POST /account/me/email/confirm',
			'POST /account/me/phone',
			'PUT /account/me/bannerimage',
			'PUT /account/me/bio',
			'PUT /account/me/displayname',
			'PUT /account/me/emoji',
			'PUT /account/me/identityflags',
			'PUT /account/me/personalpronouns',
			'PUT /account/me/profileimage',
			'PUT /account/me/username',
		])

		// Every operation carries a summary — a path present but undescribed is not
		// documentation.
		for (const ops of Object.values(spec.paths)) {
			for (const op of Object.values(ops)) expect(op.summary).toBeTruthy()
		}
	})

	// hono-openapi registers a validated form body under `multipart/form-data` only, and
	// its `media` option can't say otherwise (a precedence bug — see `withCleanSpec`). The
	// real callers post `application/x-www-form-urlencoded`, so a spec that named only
	// multipart would tell an integrator to send the one thing nothing here sends.
	test('GET /openapi.json documents both form content types on validated routes', async () => {
		const res = await exports.default.fetch(`${ORIGIN}/openapi.json`)
		const spec = (await res.json()) as {
			paths: Record<string, Record<string, { requestBody?: { content: Record<string, unknown> } }>>
		}

		for (const [path, method] of [
			['/account/me/email', 'post'],
			['/account/me/username', 'put'],
			['/account/me/displayname', 'put'],
			['/account/me/bio', 'put'],
			['/account/me/phone', 'post'],
		] as const) {
			const content = spec.paths[path]?.[method]?.requestBody?.content ?? {}
			expect(Object.keys(content).sort(), path).toEqual([
				'application/x-www-form-urlencoded',
				'multipart/form-data',
			])
		}
	})
})

// The names a player chooses are charset- and length-capped by the rules in @repo/domain:
// a username is alphanumeric (`nameRejection`), a display name takes the wider charset
// the client's own box does (`displayNameRejection`). The limits come
// from the client's own input boxes rather than a round number, so anything stored is
// something the game can render and re-edit.
//
// Server-generated names go around this deliberately — the seeded "Rec Room" account
// above has a space in its display name, and dorms are called `@<username>'s Dorm`. The
// check belongs at the request handler, not in the db helpers.
describe('name, email and bio validation', () => {
	const authed = async (sub: string) => ({
		...(await bearer(sub)),
		'Content-Type': 'application/x-www-form-urlencoded',
	})

	test('PUT /account/me/username refuses anything but letters and digits, max 50', async () => {
		const headers = await authed('8801')
		for (const username of ['has space', 'under_score', 'punct!', 'café', 'a'.repeat(51)]) {
			const res = await exports.default.fetch(`${ORIGIN}/account/me/username`, {
				...form({ username }),
				headers,
			})
			// Refused by the SCHEMA (see openapi.ts `UsernameRequest`) before the handler
			// runs — but still the envelope at HTTP 200, like every other refusal here,
			// because the hook puts it there.
			expect(res.status, username).toBe(200)
			const body = (await res.json()) as { success: boolean; error: string; value: string }
			expect(body.success, username).toBe(false)
			expect(body.error).toMatch(/letters and numbers|at most 50 characters/)
			expect(body.value).toBe('')
		}

		// A rationed change must NOT be spent by a refusal: an account starts with three,
		// and burning it on a typo would leave the player stuck with a name they never had.
		const me = (await (
			await exports.default.fetch(`${ORIGIN}/account/me`, { headers: await bearer('8801') })
		).json()) as { availableUsernameChanges: number }
		expect(me.availableUsernameChanges).toBe(3)

		// 50 is the client's own cap, so a name that long has to be accepted.
		const ok = await exports.default.fetch(`${ORIGIN}/account/me/username`, {
			...form({ username: 'a'.repeat(50) }),
			headers,
		})
		expect(((await ok.json()) as { success: boolean }).success).toBe(true)
	})

	test('PUT /account/me/displayname holds a name to the client charset, max 15', async () => {
		const headers = await authed('8802')
		const put = (displayName: string) =>
			exports.default.fetch(`${ORIGIN}/account/me/displayname`, {
				...form({ displayName }),
				headers,
			})

		// The Rec Room build's own rule: ^[\p{Latin}0-9 .,'!?_&()#@:+-]+$
		for (const displayName of ['has space', 'punct!', 'café', "O'Neil_Jr.", '(a)&b#1@c:+-,?']) {
			expect((await put(displayName)).status, displayName).toBe(200)
		}

		for (const displayName of [
			'semi;colon',
			'star*',
			'sla/sh',
			'Привет',
			'名前',
			'smile😀',
			'a'.repeat(16),
		]) {
			// An empty 400, matching what this route already answers for an empty name —
			// it acks with a bare `{ success: true }` and has never sent the client a body
			// on failure.
			expect((await put(displayName)).status, displayName).toBe(400)
		}

		// Trimmed before it is checked, so a name of nothing but spaces is an empty one.
		expect((await put('   ')).status).toBe(400)

		// A swear set off by the punctuation the charset now allows is still a swear.
		for (const displayName of ['shit lord', 'Shit_Lord', 'fuck.you', 'fuck!']) {
			expect((await put(displayName)).status, displayName).toBe(400)
		}

		// 15 is the client's box, so it must fit.
		expect((await put('a'.repeat(15))).status).toBe(200)
	})

	// Syntax comes from the `isemail` package rather than a pattern written here — this is
	// a contact address nothing is ever sent to in order to prove it, so a hand-rolled
	// regex only buys more edge cases to get wrong. It enforces the RFC's own
	// 254-character maximum, which is why there's no separate length check.
	test('POST /account/me/email requires a syntactically valid address', async () => {
		const headers = await authed('8803')
		const bad = [
			'nope', // no @ at all — what this route used to be the only check for
			'@example.com', // nothing to deliver to
			'someone@', // no domain
			'someone@example.', // empty last label
			'two words@example.com', // whitespace
			`${'a'.repeat(250)}@example.com`, // past the RFC's 254
		]
		for (const email of bad) {
			const res = await exports.default.fetch(`${ORIGIN}/account/me/email`, {
				...form({ email }),
				method: 'POST',
				headers,
			})
			expect(res.status, email).toBe(400)
		}

		// `someone@localhost` is in the ACCEPTED list on purpose: it's valid per the RFC,
		// and an undeliverable address costs nothing here. One account per address: a second
		// save on the same account within two minutes is refused for the cooldown, not the syntax.
		for (const [i, email] of [
			'someone@example.com',
			'first.last+tag@mail.example.co.uk',
			'someone@localhost',
		].entries()) {
			const res = await exports.default.fetch(`${ORIGIN}/account/me/email`, {
				...form({ email }),
				method: 'POST',
				headers: await authed(`881${i}`),
			})
			expect(res.status, email).toBe(200)
		}
	})

	test('PUT /account/me/bio caps the stored text at 255 characters', async () => {
		const headers = await authed('8804')

		const ok = await exports.default.fetch(`${ORIGIN}/account/me/bio`, {
			...form({ bio: 'b'.repeat(255) }),
			headers,
		})
		expect(ok.status).toBe(200)

		// Refused rather than truncated — storing half a sentence reads as data loss.
		const tooLong = await exports.default.fetch(`${ORIGIN}/account/me/bio`, {
			...form({ bio: 'b'.repeat(256) }),
			headers,
		})
		expect(tooLong.status).toBe(400)

		// The refusal changed nothing: the 255-character bio is still what's stored.
		const me = await exports.default.fetch(`${ORIGIN}/account/8804/bio`)
		expect(((await me.json()) as { bio: string }).bio).toBe('b'.repeat(255))
	})
})

// Phone is deliberately NOT held to the name rule above: the client sends E.164
// (`+15552223333`), so a letters-and-digits check would reject every real number by
// eating the leading `+`. Pinned here because this route sits between two that DID just
// get stricter, and the obvious next "cleanup" is to make it match them.
test('POST /account/me/phone stores an E.164 number exactly as the client sends it', async () => {
	const res = await exports.default.fetch(`${ORIGIN}/account/me/phone`, {
		...form({ phone: '+15552223333' }),
		method: 'POST',
		headers: { ...(await bearer('8805')), 'Content-Type': 'application/x-www-form-urlencoded' },
	})
	expect(res.status).toBe(200)
	expect(await res.json()).toEqual({ success: true })

	// Read from the row: phone is stored but not surfaced by any DTO, so there's no
	// endpoint to check it through.
	const row = await env.DB.prepare(
		"SELECT json_extract(data, '$.phone') AS phone FROM account WHERE json_extract(data, '$.accountId') = 8805"
	).first<{ phone: string }>()
	// Verbatim — no normalising, no stripping of the +.
	expect(row?.phone).toBe('+15552223333')
})

// The emoji picker. Served as a BARE array — the client parses the response body itself
// as the list, so wrapping it in `{ value: [...] }` or the success envelope every
// mutation here uses would leave the picker empty.
test('GET /emojiConfig/whitelistedEmojis serves the list as a bare array', async () => {
	const res = await exports.default.fetch(`${ORIGIN}/emojiConfig/whitelistedEmojis`)
	expect(res.status).toBe(200)
	const body = (await res.json()) as string[]
	expect(Array.isArray(body)).toBe(true)
	expect(body).toEqual(WHITELISTED_EMOJIS)
	// Order is the picker's order, and the first entry anchors it.
	expect(body[0]).toBe('😀')
	// Every entry is a non-empty string and appears once — a duplicate draws twice in
	// the grid, and the list is compared against `displayEmoji` as an exact string.
	expect(body.every((e) => typeof e === 'string' && e.length > 0)).toBe(true)
	expect(new Set(body).size).toBe(body.length)
})

// Not auth-gated: the client asks for the picker before it has a token in hand.
test('GET /emojiConfig/whitelistedEmojis needs no bearer token', async () => {
	const res = await exports.default.fetch(`${ORIGIN}/emojiConfig/whitelistedEmojis`)
	expect(res.status).toBe(200)
})
