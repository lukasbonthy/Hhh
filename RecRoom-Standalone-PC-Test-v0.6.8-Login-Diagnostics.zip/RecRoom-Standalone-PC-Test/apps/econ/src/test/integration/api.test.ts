import {
	adminSecretsStore,
	createExecutionContext,
	createScheduledController,
	env,
	waitOnExecutionContext,
} from 'cloudflare:test'
import { exports } from 'cloudflare:workers'
import { beforeAll, describe, expect, test } from 'vitest'

import {
	getAccount,
	getOwnedInventionIds,
	getPendingGifts,
	getProgression,
	INVENTORY_INVENTION_SCHEMA_DDL,
	OUTFIT_SCHEMA_DDL,
	PRESENCE_SCHEMA_DDL,
	PROGRESSION_SCHEMA_DDL,
	RECEIVED_GIFT_SCHEMA_DDL,
	ROOM_SCHEMA_DDL,
	setPresence,
	updateAccount,
} from '@repo/domain'
import { PlatformType } from '@repo/domain/src/enums'

// The `invention` table belongs to the `api` worker; buyInvention reads it, so its DDL
// is built here too (see the same cross-worker import in econ.app.ts).
import {
	createCustomAvatarItem,
	SCHEMA_DDL as CUSTOM_AVATAR_ITEM_SCHEMA_DDL,
	importCustomAvatarItem,
} from '../../../../api/src/custom-avatar-items-db'
import { SCHEMA_DDL as INVENTION_SCHEMA_DDL } from '../../../../api/src/inventions-db'
// The Discord link table (owned by `auth`, kept current by `www`) is what the weekly
// supporter gift reads its roles from.
import { linkPlatformIdentity, PLATFORM_SCHEMA_DDL } from '../../../../auth/src/platform-db'
// The notification-type ids the hub carries, from the worker that owns them — asserting
// against the enum rather than a copied number is what keeps these frames honest.
import { NotificationType } from '../../../../notify/src/notification-types'
// The catalog's two migrations and the captures the loader reads, imported so the tests at the
// bottom can check the schema they build against `CATALOG_SCHEMA_DDL`. `?raw` because they are
// SQL, not modules: they are never executed here, only read.
import catalogStructureSql from '../../../migrations/0015_catalog.sql?raw'
import catalogIdSql from '../../../migrations/0016_catalog_id.sql?raw'
import catalogListingSql from '../../../migrations/0028_catalog_listing.sql?raw'
import skinsJson from '../../../static/db/skins.json'
// The 2025 store DUMP, the source `runx storefront build` and `runx catalog load` both read.
import storeDump from '../../../static/db/Watch_EnumValue_3.json'
import questRewards from '../../../static/quest-rewards.json'
// Both general-store files, read as FILES: which one the route serves depends on the caller's
// build, and these assertions are about each file's CONTENTS.
import sf32025 from '../../../static/storefronts/sf3-2025.json'
import sf3 from '../../../static/storefronts/sf3.json'
import { SCHEMA_DDL } from '../../avatar-db'
import {
	BALANCE_SCHEMA_DDL,
	CurrencyType,
	DEFAULT_STARTING_TOKENS,
	getBalance,
	PLUS_MEMBERS_SQL,
	plusReloadSql,
	spendCurrency,
} from '../../balance-db'
import {
	baseAsset,
	buildCatalogLoad,
	CATALOG_INSERT_COLUMNS,
	CATALOG_SCHEMA_DDL,
	CatalogKind,
	countCatalog,
	getAvatarItem,
	getAvatarItemsByTag,
	getCatalogItem,
	getCatalogItemById,
	getCatalogItems,
	getSkin,
	getSkinsForPrefab,
	searchCatalog,
	toCatalogSkin,
} from '../../catalog-db'
import {
	collapseRepeatedListings,
	GOLD_SKIN_PRICE,
	isGoldSkin,
	UNLISTED_SKIN_ID_BASE,
	UNLISTED_SKIN_RARITY,
	unlistedSkinListing,
} from '../../catalog-load'
import { CHALLENGE_GIFT_SCHEMA_DDL, CHALLENGE_STATUS_SCHEMA_DDL } from '../../challenge-db'
// The live weekly rotation, generated the same way the worker generates it, so the challenge
// tests exercise whatever this week actually holds instead of ids from a rotation that has
// since rolled over.
import { buildRotation, rotationIndex, withWeeklyGift } from '../../challenge-rotation'
import { CONSUMABLE_SCHEMA_DDL, grantConsumable } from '../../consumables-db'
import {
	DISCORD_ROLE_GIFT_MESSAGE,
	grantDiscordRoleGift,
	grantDiscordRoleGifts,
	parseRoleTokens,
} from '../../discord-role-gift'
import { scheduled } from '../../econ.app'
import { EQUIPMENT_SCHEMA_DDL, grantEquipment } from '../../equipment-db'
import {
	grantCustomAvatarItem,
	INVENTORY_CUSTOM_SCHEMA_DDL,
	ownedCustomAvatarItemIds,
} from '../../inventory-custom-db'
import { INVENTORY_SCHEMA_DDL } from '../../inventory-db'
import { REWARD_STATUS_SCHEMA_DDL } from '../../reward-db'
import {
	ROOM_CONSUMABLE_SCHEMA_DDL,
	ROOM_INVENTORY_SCHEMA_DDL,
	upsertRoomConsumable,
} from '../../room-consumable-db'
import {
	createPurchaseOffer,
	createRoomCurrency,
	ROOM_BALANCE_SCHEMA_DDL,
	ROOM_CURRENCY_SCHEMA_DDL,
} from '../../room-currency-db'
import { createRoomKey, ROOM_KEY_SCHEMA_DDL } from '../../room-key-db'
import { WISHLIST_SCHEMA_DDL } from '../../wishlist-db'

import type { CatalogLoadRow, CatalogRow, CatalogValue, StoreListing } from '../../catalog-db'
import type { Env } from '../../context'

/**
 * The store dump's listings with the verbatim repeats collapsed — what `runx storefront build`
 * writes out as sf3-2025.json, sale stripped. The file test below holds the two to each other.
 */
const dumpListings = collapseRepeatedListings(storeDump.StoreItems as StoreListing[]).listings

/** The served store's listings, which is what `runx catalog load` reads. */
const storeListings = sf32025.StoreItems as StoreListing[]

/**
 * An avatar item ONLY the 2025 store sells, priced in tokens: an id sf3-2025 lists and sf3
 * does not. The build gate is only observable through such an item — the two files number their
 * stores differently, so nearly any 2025 listing qualifies; the first tokens-priced avatar item
 * is as good as any.
 */
const sf3Ids = new Set(sf3.StoreItems.map((i) => i.PurchasableItemId))
const NEWER_ONLY = (() => {
	const item = storeListings.find(
		(i) =>
			!sf3Ids.has(i.PurchasableItemId) &&
			i.GiftDrop.AvatarItemDesc !== '' &&
			i.Prices.some((p) => p.CurrencyType === 2)
	)
	if (item === undefined)
		throw new Error('sf3-2025 sells no tokens-priced avatar item sf3 does not')
	return {
		id: item.PurchasableItemId,
		price: item.Prices.find((p) => p.CurrencyType === 2)!.Price,
		name: item.GiftDrop.FriendlyName,
	}
})()

/**
 * The avatar items the suite-wide catalog holds — a slice of the real load, seeded below so the
 * catalogue reads (`lockeditems/bulk`) have something in store order to answer from. A slice
 * rather than the whole load: the table is rebuilt per test file, and fifty rows say what three
 * thousand would.
 */
const SEEDED_AVATAR_ITEMS = buildCatalogLoad(storeListings)
	.rows.filter((r) => r.values[CATALOG_INSERT_COLUMNS.indexOf('kind')] === CatalogKind.AvatarItem)
	.slice(0, 50)

/**
 * Items the generated `sf3.json` sells, resolved FROM the file rather than hardcoded.
 *
 * sf3 used to be a capture with its own ids (73 = "Bowtie (White)" at 450); it is now generated
 * from the item catalog, so those ids are gone and the prices come from the rarity table. Looking
 * them up here means a regenerate — or a repriced tier — cannot leave these tests asserting
 * against items the store no longer sells.
 *
 * `atPrice` picks an AVATAR item at a given tier; the carried equipment/consumables/boxes keep
 * their captured ids and are still referenced by number where a test is about one of those.
 */
const sf3AvatarAtPrice = (price: number) => {
	const item = sf3.StoreItems.find(
		(i) => (i.GiftDrop.AvatarItemDesc ?? '') !== '' && i.Prices[0]?.Price === price
	)
	if (item === undefined) throw new Error(`sf3 sells no avatar item at ${price}`)
	return { id: item.PurchasableItemId, price, name: item.GiftDrop.FriendlyName }
}
/** A mid-priced item — the general "buy something" fixture. */
const SF3_ITEM = sf3AvatarAtPrice(600)
/** The cheapest tier, for the line-level price-mismatch assertions. */
const SF3_CHEAP = sf3AvatarAtPrice(150)

declare module 'cloudflare:test' {
	interface ProvidedEnv extends Env {}
}

const ORIGIN = 'https://example.com'

/** This week's rotation — the same one the worker builds for these requests. */
const weekly = buildRotation(new Date())

/** The first challenge of the live rotation — the progress tests report against it. */
const CURRENT_CHALLENGE = weekly.Challenges[0]

// Build the accounts table and seed the test player (the default token's sub, 42)
// so avatar reads/writes have a row to attach to.
beforeAll(async () => {
	// Seed the shared JWT signing key into the local Secrets Store so .get() resolves.
	await adminSecretsStore(env.JWT_SECRET).create('test-signing-key')
	for (const stmt of SCHEMA_DDL) await env.DB.prepare(stmt).run()
	for (const stmt of BALANCE_SCHEMA_DDL) await env.DB.prepare(stmt).run()
	for (const stmt of OUTFIT_SCHEMA_DDL) await env.DB.prepare(stmt).run()
	for (const stmt of CHALLENGE_STATUS_SCHEMA_DDL) await env.DB.prepare(stmt).run()
	for (const stmt of CHALLENGE_GIFT_SCHEMA_DDL) await env.DB.prepare(stmt).run()
	for (const stmt of PROGRESSION_SCHEMA_DDL) await env.DB.prepare(stmt).run()
	for (const stmt of REWARD_STATUS_SCHEMA_DDL) await env.DB.prepare(stmt).run()
	for (const stmt of INVENTORY_SCHEMA_DDL) await env.DB.prepare(stmt).run()
	for (const stmt of CONSUMABLE_SCHEMA_DDL) await env.DB.prepare(stmt).run()
	for (const stmt of EQUIPMENT_SCHEMA_DDL) await env.DB.prepare(stmt).run()
	for (const stmt of RECEIVED_GIFT_SCHEMA_DDL) await env.DB.prepare(stmt).run()
	for (const stmt of INVENTORY_INVENTION_SCHEMA_DDL) await env.DB.prepare(stmt).run()
	for (const stmt of INVENTION_SCHEMA_DDL) await env.DB.prepare(stmt).run()
	for (const stmt of CUSTOM_AVATAR_ITEM_SCHEMA_DDL) await env.DB.prepare(stmt).run()
	for (const stmt of INVENTORY_CUSTOM_SCHEMA_DDL) await env.DB.prepare(stmt).run()
	for (const stmt of CATALOG_SCHEMA_DDL) await env.DB.prepare(stmt).run()
	for (const stmt of ROOM_CURRENCY_SCHEMA_DDL) await env.DB.prepare(stmt).run()
	for (const stmt of ROOM_BALANCE_SCHEMA_DDL) await env.DB.prepare(stmt).run()
	for (const stmt of ROOM_CONSUMABLE_SCHEMA_DDL) await env.DB.prepare(stmt).run()
	for (const stmt of ROOM_INVENTORY_SCHEMA_DDL) await env.DB.prepare(stmt).run()
	for (const stmt of ROOM_KEY_SCHEMA_DDL) await env.DB.prepare(stmt).run()
	for (const stmt of WISHLIST_SCHEMA_DDL) await env.DB.prepare(stmt).run()
	// The platform link table (owned by `auth`) — the Discord supporter gift reads the roles
	// `www` records on each Discord link.
	for (const stmt of PLATFORM_SCHEMA_DDL) await env.DB.prepare(stmt).run()
	// Presence (owned by the `match` worker) — a new room currency is pushed to everyone
	// standing in the room, which is read from here.
	for (const stmt of PRESENCE_SCHEMA_DDL) await env.DB.prepare(stmt).run()
	// The rooms table (owned by the `rooms` worker) — creating a room currency reads the room
	// blob to apply its creator/co-owner check (the blob alone: `canManageRoomById` skips the
	// hydration that would drag in subrooms/tags/stats). Room 2511 is account 1's, with 2 as
	// co-owner.
	for (const stmt of ROOM_SCHEMA_DDL) await env.DB.prepare(stmt).run()
	await env.DB.prepare('INSERT OR IGNORE INTO room (data) VALUES (?1)')
		.bind(
			JSON.stringify({
				RoomId: 2511,
				Name: 'CurrencyRoom',
				CreatorAccountId: 1,
				Roles: [
					{ AccountId: 1, Role: 255, LastChangedByAccountId: null, InvitedRole: 0 },
					{ AccountId: 2, Role: 30, LastChangedByAccountId: null, InvitedRole: 0 },
				],
			})
		)
		.run()
	// A few equipment skins, which is where the WEEKLY CHALLENGE gift pool comes from now that
	// skins are awarded rather than sold and no storefront lists one. Without these the pool is
	// empty and the week has nothing to be themed on.
	// Skipping the two the `catalog` block seeds by hand further down — `item_key` is the primary
	// key, so a second insert of either would fail rather than merge.
	const catalogBlockSeeds = new Set([
		'19ef59c7-f74b-4c63-935a-1d4b1abd8518',
		'bfrFOdnHzEaIwHqem2dXkg',
	])
	for (const [i, skin] of skinsJson
		.filter((sk) => !catalogBlockSeeds.has(sk.ModificationGuid))
		.slice(0, 8)
		.entries()) {
		await env.DB.prepare(
			`INSERT OR IGNORE INTO catalog
				(item_key, catalog_id, kind, friendly_name, tooltip, rarity, platform_mask, prefab_name)
			 VALUES (?1, ?2, 'skin', ?3, '', ?4, -1, ?5)`
		)
			.bind(skin.ModificationGuid, 70_001 + i, skin.FriendlyName, skin.Rarity, skin.PrefabName)
			.run()
	}
	// A slice of the real avatar-item load, in load order, for the catalogue reads. One batch:
	// these are the loader's own rows, so a row it builds that the table refuses fails here.
	await env.DB.batch(
		SEEDED_AVATAR_ITEMS.map((row) =>
			env.DB.prepare(
				`INSERT OR IGNORE INTO catalog (${CATALOG_INSERT_COLUMNS.join(', ')})
				 VALUES (${CATALOG_INSERT_COLUMNS.map((_, i) => `?${i + 1}`).join(', ')})`
			).bind(...row.values.map((v) => v ?? null))
		)
	)
	await env.DB.prepare('INSERT OR IGNORE INTO account (data) VALUES (?1)')
		.bind(JSON.stringify({ accountId: 42, username: 'Tester', displayName: 'Tester' }))
		.run()
	for (const invention of SEEDED_INVENTIONS) {
		await env.DB.prepare('INSERT INTO invention (data) VALUES (?1)')
			.bind(JSON.stringify(invention))
			.run()
	}
})

/**
 * Inventions the buyInvention tests buy (or fail to buy). Only the fields that path
 * reads are meaningful — id, creator, published flag and price — but the record is
 * shaped like a real stored `RRInvention` so the response envelope is realistic.
 */
function invention(
	inventionId: number,
	overrides: { CreatorPlayerId?: number; IsPublished?: boolean; Price?: number } = {}
) {
	return {
		InventionId: inventionId,
		ReplicationId: `replication-${inventionId}`,
		CreatorPlayerId: 999,
		Name: `Invention ${inventionId}`,
		Description: 'A test invention',
		ImageName: '',
		CurrentVersionNumber: 1,
		CurrentVersion: {
			InventionId: inventionId,
			ReplicationId: `version-${inventionId}`,
			VersionNumber: 1,
			BlobName: `invention-${inventionId}.inv`,
			BlobHash: null,
			InstantiationCost: 0,
			LightsCost: 0,
			ChipsCost: 0,
			CloudVariablesCost: 0,
			AICost: 0,
		},
		Accessibility: 0,
		IsPublished: true,
		IsFeatured: false,
		ModifiedAt: '2026-01-01T00:00:00.000Z',
		CreatedAt: '2026-01-01T00:00:00.000Z',
		FirstPublishedAt: '2026-01-01T00:00:00.000Z',
		CreationRoomId: 0,
		NumPlayersHaveUsedInRoom: 0,
		NumDownloads: 0,
		CheerCount: 0,
		CreatorPermission: 100,
		GeneralPermission: 20,
		IsAGInvention: false,
		IsCertifiedInvention: false,
		Price: 0,
		AllowTrial: true,
		HideFromPlayer: false,
		ReferencedInventions: [],
		...overrides,
	}
}

const SEEDED_INVENTIONS = [
	invention(8), // free, published, someone else's — the sellable one
	invention(9, { Price: 250 }), // priced: buying it pays creator 999 250 tokens
	invention(10, { IsPublished: false }), // a draft, not on sale even at 0
	invention(11, { CreatorPlayerId: 60 }), // account 60's own invention
]

/**
 * A real outfit as the client posts it to /api/avatar/v3/saved/set — kept verbatim
 * (including the JSON-in-a-string OutfitSelectionsV2/FaceFeatures fields) so the
 * round-trip is tested against the actual payload shape, not a tidied-up version.
 */
const SAVED_OUTFIT = {
	Slot: 4,
	PreviewImageName: 'outfit/2026-07-14/38e84678-1ccf-4cfd-bf3f-5b21eec88b0f.jpg',
	OutfitSelections:
		'5cd08cfb-c729-4c30-96d9-6a99bb934d91,,1;77d3c585-4928-4471-a425-89036efe7299,,0;40528de7-38a3-4a7c-8f93-6d3bfa5573f2,51ef8d39-2b94-4f9e-9620-07b6b0a913a5,0b2395e1-ebcc-47e9-aaf1-faf9e9cec4cd,,0;d0a9262f-5504-46a7-bb10-7507503db58e,95e4cc30-cb68-473d-a395-feadf5b51512,0440f08f-ef1d-49d8-942b-523056e8bb45,,1',
	OutfitSelectionsV2:
		'{"selections":[{"PrefabGuid":"5cd08cfb-c729-4c30-96d9-6a99bb934d91","CombinationGuid":"","BodyPart":1,"UgcOutfitData":{"BaseAvatarItemColor":{"r":0.0,"g":0.0,"b":0.0,"a":0.0},"CustomAvatarItemId":""}}]}',
	FaceFeatures:
		'{"ver":6,"eyeId":"pY0dY6IxOEaNv8uNL8qUgQ","eyeScl":-0.007145103067159653,"useHelmetHair":1,"hideEars":false}',
	SkinColor: 'Xac-W_R330KfOz-pQla9qg',
	HairColor: 'UAT0OaWEkUG-mWDIyiX1Kg',
	CustomAvatarItems: [],
}

// Mint a token the way the `auth` worker does, signing with the shared test key seeded into the JWT_SECRET store.
const TEST_SECRET = 'test-signing-key'

function b64url(input: ArrayBuffer | string): string {
	const bytes = typeof input === 'string' ? new TextEncoder().encode(input) : new Uint8Array(input)
	let binary = ''
	for (const byte of bytes) binary += String.fromCharCode(byte)
	return btoa(binary).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '')
}

/**
 * A bearer token carrying `rn.plus`. Listing anything for a TOKEN price (a room key, a
 * token-priced room consumable, a room currency's purchase offer) is a Rec Room Plus perk,
 * so the room-economy tests stock their shops as a subscriber.
 */
const plusBearer = (sub: string) => bearer(sub, undefined, undefined, true)

/**
 * A bearer token for `sub`. `roles` becomes the `role` claim the auth worker stamps from an
 * account's flags — pass `['gameClient', 'developer']` for an elevated account; the default
 * is no claim at all, which reads as no roles.
 */
async function bearer(
	sub = '42',
	roles?: string[],
	/** The client build to stamp as `rn.ver` — omitted, like a token minted before the claim. */
	version?: string,
	/**
	 * Stamp `rn.plus`, as auth does for an account with `hasPlus`. This is the ONLY thing
	 * that makes a caller a Rec Room Plus subscriber — the `developer` role does not — so
	 * every subscriber-priced test passes it.
	 */
	plus = false
): Promise<Record<string, string>> {
	const now = Math.floor(Date.now() / 1000)
	const claims: Record<string, unknown> = { sub, exp: now + 3600 }
	if (roles !== undefined) claims.role = roles
	if (version !== undefined) claims['rn.ver'] = version
	// Omitted when false, exactly as generateToken omits it — so these tokens match the
	// shape of a real non-subscriber's.
	if (plus) claims['rn.plus'] = true
	const signingInput = `${b64url(JSON.stringify({ alg: 'HS256', typ: 'JWT' }))}.${b64url(
		JSON.stringify(claims)
	)}`
	const key = await crypto.subtle.importKey(
		'raw',
		new TextEncoder().encode(TEST_SECRET),
		{ name: 'HMAC', hash: 'SHA-256' },
		false,
		['sign']
	)
	const sig = await crypto.subtle.sign('HMAC', key, new TextEncoder().encode(signingInput))
	return { Authorization: `Bearer ${signingInput}.${b64url(sig)}` }
}

describe('econ endpoints', () => {
	test('GET /api/avatar/v1/defaultunlocked returns the default avatar items', async () => {
		const res = await exports.default.fetch(`${ORIGIN}/api/avatar/v1/defaultunlocked`)
		expect(res.status).toBe(200)
		const body = (await res.json()) as unknown[]
		expect(Array.isArray(body)).toBe(true)
		expect(body.length).toBeGreaterThan(0)
		expect(body[0]).toHaveProperty('AvatarItemDesc')
	})

	test('GET /api/avatar/v1/defaultbaseavataritems returns the base items (no auth)', async () => {
		const res = await exports.default.fetch(`${ORIGIN}/api/avatar/v1/defaultbaseavataritems`)
		expect(res.status).toBe(200)
		const body = (await res.json()) as Array<Record<string, unknown>>
		expect(body.map((i) => i.AvatarItemId)).toEqual([2184, 2918])
		// The client keys these off IsBaseAvatarItem, and the trailing comma in the desc
		// is part of the item descriptor — both are served verbatim.
		expect(body.every((i) => i.IsBaseAvatarItem === true)).toBe(true)
		expect(body[0]?.AvatarItemDesc).toBe('c5d70cb4-71dd-4fe4-b719-34fe2073c611,')
	})

	test('GET /api/avatar/v4/items 401s without a token', async () => {
		const res = await exports.default.fetch(`${ORIGIN}/api/avatar/v4/items`)
		expect(res.status).toBe(401)
	})

	test('GET /api/avatar/v4/items serves the catalog in the camelCase v4 shape', async () => {
		const res = await exports.default.fetch(`${ORIGIN}/api/avatar/v4/items`, {
			headers: await bearer(),
		})
		expect(res.status).toBe(200)
		const body = (await res.json()) as Array<Record<string, unknown>>
		expect(body.length).toBeGreaterThan(0)
		// Every key of the DTO is present on every item, and nothing PascalCase leaks
		// through from the stored/bundled records.
		for (const item of body) {
			expect(Object.keys(item).sort()).toEqual([
				'avatarItemDesc',
				'avatarItemId',
				'avatarItemType',
				'friendlyName',
				'isBaseAvatarItem',
				'rarity',
				'tagList',
				'tooltip',
			])
		}
		expect(typeof body[0]?.avatarItemDesc).toBe('string')
		expect(typeof body[0]?.friendlyName).toBe('string')
		// The catalog carries no ids, tags or base flag — those default rather than
		// being invented.
		expect(body[0]?.avatarItemId).toBe(0)
		expect(body[0]?.tagList).toBe('')
		expect(body[0]?.isBaseAvatarItem).toBe(false)
	})

	test('GET /api/avatar/v2 401s without a token', async () => {
		const res = await exports.default.fetch(`${ORIGIN}/api/avatar/v2`)
		expect(res.status).toBe(401)
	})

	test('GET /api/avatar/v2 returns a populated default avatar when none is saved', async () => {
		// Account 7 has no saved avatar → falls back to the default outfit.
		const res = await exports.default.fetch(`${ORIGIN}/api/avatar/v2`, {
			headers: await bearer('7'),
		})
		expect(res.status).toBe(200)
		const body = (await res.json()) as { OutfitSelections: string; FaceFeatures: string }
		// Must be non-empty — the client's outfit parser NREs on an empty string.
		expect(body.OutfitSelections.length).toBeGreaterThan(0)
		expect(body.OutfitSelections).toContain(';')
		expect(body.FaceFeatures).toContain('eyeId')
	})

	test('POST /api/avatar/v2/set 401s without a token', async () => {
		const res = await exports.default.fetch(`${ORIGIN}/api/avatar/v2/set`, {
			method: 'POST',
			headers: { 'Content-Type': 'application/json' },
			body: JSON.stringify({ OutfitSelections: 'a,,0' }),
		})
		expect(res.status).toBe(401)
	})

	test('POST /api/avatar/v2/set saves the avatar, and GET reads it back', async () => {
		const headers = { ...(await bearer()), 'Content-Type': 'application/json' }
		const avatar = {
			OutfitSelections:
				'1fd69ef8-0b74-4962-af5a-67f0bf0358f2,,0;d0a9262f-5504-46a7-bb10-7507503db58e,,1',
			OutfitSelectionsV2: '{"selections":[]}',
			FaceFeatures: '{"eyeId":"AjGMoJhEcEehacRZjUMuDg"}',
			SkinColor: '3529b670-a66d-448e-9573-1905eae5b9bf',
			HairColor: '0e_jaaObREWTf1AorAZ95g',
			CustomAvatarItems: [],
		}

		// Save echoes the payload back.
		const setRes = await exports.default.fetch(`${ORIGIN}/api/avatar/v2/set`, {
			method: 'POST',
			headers,
			body: JSON.stringify(avatar),
		})
		expect(setRes.status).toBe(200)
		expect(await setRes.json()).toEqual(avatar)

		// And it persists — GET now returns the saved avatar, not the default.
		const getRes = await exports.default.fetch(`${ORIGIN}/api/avatar/v2`, {
			headers: await bearer(),
		})
		expect(await getRes.json()).toEqual(avatar)
	})

	test('GET /api/avatar/v2/:id 400s on a non-numeric id', async () => {
		const res = await exports.default.fetch(`${ORIGIN}/api/avatar/v2/notanumber`)
		expect(res.status).toBe(400)
	})

	test('GET /api/avatar/v2/:id returns the default projection when none is saved (no auth)', async () => {
		// Account 8 has no saved avatar → falls back to the default outfit. No token needed.
		const res = await exports.default.fetch(`${ORIGIN}/api/avatar/v2/8`)
		expect(res.status).toBe(200)
		const body = (await res.json()) as Record<string, unknown>
		// Projected to exactly the render subset — no OutfitSelectionsV2/CustomAvatarItems.
		expect(Object.keys(body).sort()).toEqual([
			'FaceFeatures',
			'HairColor',
			'OutfitSelections',
			'SkinColor',
		])
		expect((body.OutfitSelections as string).length).toBeGreaterThan(0)
	})

	test('GET /api/avatar/v2/:id returns another player’s saved avatar, projected', async () => {
		// Seed account 314 with a full avatar blob (superset of the projection).
		await env.DB.prepare('INSERT OR IGNORE INTO account (data) VALUES (?1)')
			.bind(JSON.stringify({ accountId: 314, username: 'Pi', displayName: 'Pi' }))
			.run()
		await env.DB.prepare('UPDATE account SET avatar = ?2 WHERE account_id = ?1')
			.bind(
				314,
				JSON.stringify({
					OutfitSelections: 'guid,,0;guid2,,1',
					OutfitSelectionsV2: '{"selections":[]}',
					FaceFeatures: '{"eyeId":"abc"}',
					SkinColor: 'skin-guid',
					HairColor: 'hair-guid',
					CustomAvatarItems: [],
				})
			)
			.run()

		const res = await exports.default.fetch(`${ORIGIN}/api/avatar/v2/314`)
		expect(res.status).toBe(200)
		// Only the four projected fields, carrying the saved values.
		expect(await res.json()).toEqual({
			OutfitSelections: 'guid,,0;guid2,,1',
			FaceFeatures: '{"eyeId":"abc"}',
			SkinColor: 'skin-guid',
			HairColor: 'hair-guid',
		})
	})

	test('GET /api/avatar/v2/gifts is not shadowed by the :id route', async () => {
		const res = await exports.default.fetch(`${ORIGIN}/api/avatar/v2/gifts`, {
			headers: await bearer(),
		})
		expect(res.status).toBe(200)
		expect(await res.json()).toEqual([])
	})

	test('POST /api/avatar/v2/set 404s when the caller has no account row', async () => {
		const res = await exports.default.fetch(`${ORIGIN}/api/avatar/v2/set`, {
			method: 'POST',
			headers: { ...(await bearer('99999')), 'Content-Type': 'application/json' },
			body: JSON.stringify({ OutfitSelections: 'a,,0' }),
		})
		expect(res.status).toBe(404)
	})

	test('room badges grant once from a live circuit and appear on another player’s badge tab', async () => {
		const seed = await createCustomAvatarItem(env.DB, {
			customAvatarItemId: crypto.randomUUID(),
			creatorAccountId: 801,
			name: 'Room badge',
			description: '',
			price: 0,
			baseAvatarItemId: 1,
			baseAvatarItemColor: '#fff',
			accessibility: 1,
			designFilename: 'badge.png',
			thumbnailImageFilename: 'badge.png',
		})
		const badge = await importCustomAvatarItem(env.DB, {
			...seed,
			OutfitType: 1000,
			CustomBadgeMetadata: { RoomId: 989891 },
			CurrentSaves: [
				{
					CustomAvatarItemSaveId: 1,
					CustomAvatarItemId: seed.CustomAvatarItemId,
					UnityAssetId: crypto.randomUUID(),
					BodyType: 0,
					OutfitType: 1000,
					QAState: 0,
					CreatedAt: seed.CreatedAt,
					ModifiedAt: seed.ModifiedAt,
					Description: null,
					ThumbnailFileName: 'badge.png',
					AdditionalConfiguration: '{}',
					UnityAsset: 'badge.png',
					UnityAssetHash: '',
					UnityAsset2: null,
					UnityAsset2Hash: null,
				},
			],
		})
		const presence = async (accountId: number, roomInstanceId = 891) =>
			setPresence(env.DB, {
				accountId,
				roomInstance: { roomId: 989891, roomInstanceId },
				statusVisibility: 0,
				deviceClass: 0,
				vrMovementMode: 0,
				platform: 0,
				appVersion: '20260323.14',
			})
		await presence(802)
		await presence(803)
		const grant = async (overrides = {}, authenticated = true): Promise<Response> =>
			exports.default.fetch(`${ORIGIN}/circuitsRoomRewards/grantRoomBadge`, {
				method: 'POST',
				headers: {
					...(authenticated ? await bearer('802') : {}),
					'Content-Type': 'application/json',
				},
				body: JSON.stringify({
					TargetAccountId: 803,
					BadgeCustomAvatarItemId: badge.CustomAvatarItemId.toUpperCase(),
					RoomInstanceId: 891,
					GrantMessage: 'Well done!',
					...overrides,
				}),
			})
		const list = async (query = '', authenticated = true): Promise<Response> =>
			exports.default.fetch(`${ORIGIN}/econ/customAvatarItems/v1/ownedby/803${query}`, {
				headers: authenticated ? await bearer('802') : {},
			})
		expect((await grant({}, false)).status).toBe(401)
		expect((await list('', false)).status).toBe(401)
		expect(await (await list('?outfitType=1000')).json()).toEqual({ Results: [], TotalResults: 0 })
		expect(await (await grant({ RoomInstanceId: 892 })).json()).toMatchObject({ ResponseCode: 2 })
		await presence(803, 892)
		expect(await (await grant()).json()).toMatchObject({ ResponseCode: 2 })
		await presence(803)
		expect(
			await (await grant({ BadgeCustomAvatarItemId: crypto.randomUUID() })).json()
		).toMatchObject({ ResponseCode: 2 })
		const grants = await Promise.all([grant(), grant()])
		expect(
			(await Promise.all(grants.map((r) => r.json() as Promise<{ ResponseCode: number }>)))
				.map((r) => r.ResponseCode)
				.sort((a, b) => a - b)
		).toEqual([0, 1])
		expect(await (await grant()).json()).toEqual({ ResponseCode: 1, ErrorMessage: null })
		const gifts = await getPendingGifts(env.DB, 803)
		expect(gifts).toHaveLength(1)
		expect(gifts[0]!).toMatchObject({
			CustomAvatarItemId: badge.CustomAvatarItemId,
			Message: 'Well done!',
		})
		await grantCustomAvatarItem(env.DB, 803, seed.CustomAvatarItemId)
		const shirt = await createCustomAvatarItem(env.DB, {
			customAvatarItemId: crypto.randomUUID(),
			creatorAccountId: 801,
			name: 'Shirt',
			description: '',
			price: 0,
			baseAvatarItemId: 1,
			baseAvatarItemColor: '#fff',
			accessibility: 1,
			designFilename: 'shirt.png',
			thumbnailImageFilename: 'shirt.png',
		})
		await grantCustomAvatarItem(env.DB, 803, shirt.CustomAvatarItemId)
		const draft = await importCustomAvatarItem(env.DB, {
			...badge,
			CustomAvatarItemId: crypto.randomUUID(),
			Accessibility: 0,
		})
		await grantCustomAvatarItem(env.DB, 803, draft.CustomAvatarItemId)
		expect(
			await (await grant({ BadgeCustomAvatarItemId: draft.CustomAvatarItemId })).json()
		).toMatchObject({ ResponseCode: 2 })
		expect(await (await list('?outfitType=1000&skip=0&take=1000')).json()).toEqual({
			Results: [{ ...badge, PurchaseInfo: null }],
			TotalResults: 1,
		})
		expect(await (await list('?outfitType=1000&skip=1&take=1')).json()).toEqual({
			Results: [],
			TotalResults: 1,
		})
		expect(await (await list('?outfitType=1000&unityAssetTarget=2')).json()).toMatchObject({
			Results: [{ CurrentSaves: [{ UnityAsset: 'badge.png' }] }],
			TotalResults: 1,
		})
	})

	test('GET /econ/customAvatarItems/v1/owned 401s without a token, lists what the caller bought', async () => {
		const anon = await exports.default.fetch(`${ORIGIN}/econ/customAvatarItems/v1/owned`)
		expect(anon.status).toBe(401)
		// Nothing bought yet: the paginated envelope, empty.
		const res = await exports.default.fetch(`${ORIGIN}/econ/customAvatarItems/v1/owned`, {
			headers: await bearer('610'),
		})
		expect(res.status).toBe(200)
		expect(await res.json()).toEqual({ Results: [], TotalResults: 0 })

		// Two bought items and two the caller made (one still a draft): the owned list is what
		// was BOUGHT plus what they CREATED, each as the whole record out of
		// `custom_avatar_item`, oldest first by when it became theirs — a purchase's time for
		// a bought item, the item's creation for a made one.
		const make = (name: string, creator: number, accessibility = 1, createdAt?: Date) =>
			createCustomAvatarItem(
				env.DB,
				{
					customAvatarItemId: crypto.randomUUID(),
					creatorAccountId: creator,
					name,
					description: '',
					price: 100,
					baseAvatarItemId: 1,
					baseAvatarItemColor: '#fff',
					accessibility,
					designFilename: 'design_x.bin',
					thumbnailImageFilename: 'thumb_x.png',
				},
				createdAt
			)
		const first = await make('Bought First', 205)
		const second = await make('Bought Second', 206)
		const made = await make('Made Myself', 610, 1, new Date('2026-08-03T00:00:00Z'))
		const draft = await make('Made Myself, Unpublished', 610, 0, new Date('2026-08-04T00:00:00Z'))
		await grantCustomAvatarItem(
			env.DB,
			610,
			second.CustomAvatarItemId,
			new Date('2026-08-02T00:00:00Z')
		)
		await grantCustomAvatarItem(
			env.DB,
			610,
			first.CustomAvatarItemId,
			new Date('2026-08-01T00:00:00Z')
		)
		// Someone else's purchase of the same item is theirs, not the caller's.
		await grantCustomAvatarItem(env.DB, 611, first.CustomAvatarItemId)

		const owned = await exports.default.fetch(`${ORIGIN}/econ/customAvatarItems/v1/owned`, {
			headers: await bearer('610'),
		})
		expect(owned.status).toBe(200)
		expect(await owned.json()).toEqual({
			Results: [
				{ ...first, PurchaseInfo: null },
				{ ...second, PurchaseInfo: null },
				{ ...made, PurchaseInfo: null },
				{ ...draft, PurchaseInfo: null },
			],
			TotalResults: 4,
		})

		// A first-party item is rendered from its saves' assetbundles. A caller asking for the
		// Quest target (`unityAssetTarget=2`, Android/Oculus) is pointed at the `quest/` builds;
		// target 0 (PC) gets the names as stored.
		const save = {
			CustomAvatarItemSaveId: 1,
			CustomAvatarItemId: '83fe651f-15b3-46a7-8afc-adec32c35568',
			UnityAssetId: crypto.randomUUID(),
			BodyType: 2,
			OutfitType: 100,
			QAState: 0,
			CreatedAt: '2024-09-26T21:32:48.523Z',
			ModifiedAt: '2024-09-26T21:32:48.523Z',
			Description: null,
			ThumbnailFileName: 'avatar/f2y1ndzuvm5ke2hjmn4cwfwfl.png',
			AdditionalConfiguration: '{}',
			UnityAsset: '3rdxsypmi0bdkxzrt1qmz1dpa.assetbundle',
			UnityAssetHash: 'hash-a',
			UnityAsset2: null,
			UnityAsset2Hash: null,
		}
		const wings = await importCustomAvatarItem(env.DB, {
			...first,
			CustomAvatarItemId: save.CustomAvatarItemId,
			RankedEntityId: save.CustomAvatarItemId,
			CreatorAccountId: 1,
			Name: 'Skeletal Wings',
			BaseAvatarItemId: null,
			BaseAvatarItemColor: null,
			DesignFilename: null,
			ThumbnailImageFilename: null,
			OutfitType: 100,
			CurrentSaves: [save],
		})
		await grantCustomAvatarItem(env.DB, 612, wings.CustomAvatarItemId)
		const ownedAssets = async (query: string) => {
			const res = await exports.default.fetch(`${ORIGIN}/econ/customAvatarItems/v1/owned${query}`, {
				headers: await bearer('612'),
			})
			const { Results } = (await res.json()) as {
				Results: Array<{ CurrentSaves: Array<{ UnityAsset: string; UnityAsset2: string | null }> }>
			}
			return Results[0].CurrentSaves.map((s) => [s.UnityAsset, s.UnityAsset2])
		}
		expect(await ownedAssets('?skip=0&take=1000&unityAssetTarget=0')).toEqual([
			[save.UnityAsset, null],
		])
		expect(await ownedAssets('?skip=0&take=1000&unityAssetTarget=2&unityAssetVersion=3')).toEqual([
			[`quest/${save.UnityAsset}`, null],
		])
	})

	test('GET /api/objectives/v1/myprogress returns the default progress (no auth)', async () => {
		const res = await exports.default.fetch(`${ORIGIN}/api/objectives/v1/myprogress`)
		expect(res.status).toBe(200)
		const body = (await res.json()) as { Objectives: unknown[]; ObjectiveGroups: unknown[] }
		expect(Array.isArray(body.Objectives)).toBe(true)
		expect(Array.isArray(body.ObjectiveGroups)).toBe(true)
	})

	test('objectives/v1/cleargroup returns [] for GET and POST (no auth)', async () => {
		for (const method of ['GET', 'POST'] as const) {
			const res = await exports.default.fetch(`${ORIGIN}/api/objectives/v1/cleargroup`, { method })
			expect(res.status).toBe(200)
			expect(await res.json()).toEqual([])
		}
	})

	test('POST /api/objectives/v1/updateobjective echoes the group, never completed', async () => {
		const res = await exports.default.fetch(`${ORIGIN}/api/objectives/v1/updateobjective`, {
			method: 'POST',
			headers: { 'content-type': 'application/json' },
			body: JSON.stringify({
				Index: 2,
				Group: 3,
				Progress: 1,
				VisualProgress: 0,
				IsCompleted: true,
				HasClaimedReward: false,
			}),
		})
		expect(res.status).toBe(200)
		const body = (await res.json()) as { group: number; isCompleted: boolean; clearedAt: string }
		expect(body.group).toBe(3)
		expect(body.isCompleted).toBe(false)
		expect(Number.isNaN(Date.parse(body.clearedAt))).toBe(false)
	})

	test('POST /api/objectives/v1/updateobjective tolerates a non-JSON body', async () => {
		const res = await exports.default.fetch(`${ORIGIN}/api/objectives/v1/updateobjective`, {
			method: 'POST',
			body: 'not json',
		})
		expect(res.status).toBe(200)
		const body = (await res.json()) as { group: number; isCompleted: boolean }
		expect(body.group).toBe(0)
		expect(body.isCompleted).toBe(false)
	})

	test('GET /api/checklist/v1|v2/current 401s without a token, serves the NUX list with one', async () => {
		const expected = [
			{ Order: 0, Objective: 38, Count: 1, CreditAmount: 25 },
			{ Order: 1, Objective: 32, Count: 1, CreditAmount: 25 },
			{ Order: 2, Objective: 2, Count: 1, CreditAmount: 25 },
			{ Order: 3, Objective: 30, Count: 1, CreditAmount: 25 },
			{ Order: 4, Objective: 6, Count: 1, CreditAmount: 25 },
		]
		// Both version paths are live and serve the same list.
		for (const path of ['/api/checklist/v1/current', '/api/checklist/v2/current']) {
			const anon = await exports.default.fetch(`${ORIGIN}${path}`)
			expect(anon.status).toBe(401)
			const res = await exports.default.fetch(`${ORIGIN}${path}`, { headers: await bearer() })
			expect(res.status).toBe(200)
			expect(await res.json()).toEqual(expected)
		}
	})

	test('POST /api/checklist/v1|v2/complete 401s without a token, grants nothing with one', async () => {
		for (const path of ['/api/checklist/v1/complete', '/api/checklist/v2/complete']) {
			const anon = await exports.default.fetch(`${ORIGIN}${path}`, {
				method: 'POST',
				headers: { 'Content-Type': 'application/json' },
				body: JSON.stringify({ ItemIndex: 1 }),
			})
			expect(anon.status).toBe(401)

			const res = await exports.default.fetch(`${ORIGIN}${path}`, {
				method: 'POST',
				headers: { ...(await bearer('33')), 'Content-Type': 'application/json' },
				body: JSON.stringify({ ItemIndex: 1 }),
			})
			expect(res.status).toBe(200)
			expect(await res.json()).toEqual({
				BalanceUpdates: [{ UpdateResponse: 303, Data: [] }],
				Balance: 0,
				CurrencyType: 2,
				BalanceType: -2,
			})
		}

		// Stubbed, so completing rows does not move the balance — re-posting cannot farm
		// tokens, and the checklist still lists every row.
		const bal = await exports.default.fetch(`${ORIGIN}/api/storefronts/v4/balance/2`, {
			headers: await bearer('33'),
		})
		expect(await bal.json()).toEqual([{ CurrencyType: 2, Platform: -2, Balance: 10000 }])
	})

	test('GET /api/itemWishlists/v1/wishlist/me 401s without a token, returns [] with one', async () => {
		const anon = await exports.default.fetch(`${ORIGIN}/api/itemWishlists/v1/wishlist/me`)
		expect(anon.status).toBe(401)
		const res = await exports.default.fetch(`${ORIGIN}/api/itemWishlists/v1/wishlist/me`, {
			headers: await bearer(),
		})
		expect(res.status).toBe(200)
		expect(await res.json()).toEqual([])
	})

	test('GET /api/itemWishlists/v1/wishlist/:accountId 401s without a token, returns []', async () => {
		const anon = await exports.default.fetch(`${ORIGIN}/api/itemWishlists/v1/wishlist/207`)
		expect(anon.status).toBe(401)

		const res = await exports.default.fetch(`${ORIGIN}/api/itemWishlists/v1/wishlist/207`, {
			headers: await bearer(),
		})
		expect(res.status).toBe(200)
		expect(await res.json()).toEqual([])

		// `me` is still its own route, not read as an account id.
		const mine = await exports.default.fetch(`${ORIGIN}/api/itemWishlists/v1/wishlist/me`, {
			headers: await bearer(),
		})
		expect(mine.status).toBe(200)
	})

	describe('item wishlist', () => {
		const WISHLIST = `${ORIGIN}/api/itemWishlists/v1`
		const GUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/
		// The form body exactly as the client posts it: both fields, the unused one empty.
		const post = async (path: string, sub: string, body: string) =>
			exports.default.fetch(`${WISHLIST}${path}`, {
				method: 'POST',
				headers: { ...(await bearer(sub)), 'Content-Type': 'application/x-www-form-urlencoded' },
				body,
			})
		const list = async (who: string, sub: string) =>
			(
				await exports.default.fetch(`${WISHLIST}/wishlist/${who}`, { headers: await bearer(sub) })
			).json()

		test('the writes 401 without a token', async () => {
			for (const path of ['/wishlist/add', '/wishlist/remove', '/isonwishlist/bulk']) {
				const res = await exports.default.fetch(`${WISHLIST}${path}`, {
					method: 'POST',
					headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
					body: 'purchasableItemId=1534&customAvatarItemId=',
				})
				expect(res.status, path).toBe(401)
			}
		})

		test('add stores an entry, serves it enveloped, and the list reads it back newest first', async () => {
			const first = await post('/wishlist/add', '601', 'purchasableItemId=1534&customAvatarItemId=')
			expect(first.status).toBe(200)
			const env1 = (await first.json()) as {
				Value: Record<string, unknown>
				Success: boolean
				Error: null
				error_id: null
			}
			// The envelope, `Value` first; the entry is the client's five keys in its order, with
			// a GUID id and a NULL custom id for a storefront item.
			expect(Object.keys(env1)).toEqual(['Value', 'Success', 'Error', 'error_id'])
			expect(env1.Success).toBe(true)
			expect(env1.Error).toBeNull()
			expect(env1.error_id).toBeNull()
			expect(Object.keys(env1.Value)).toEqual([
				'WishlistItemId',
				'AccountId',
				'PurchasableItemId',
				'CustomAvatarItemId',
				'CreatedAt',
			])
			expect(env1.Value.WishlistItemId).toMatch(GUID_RE)
			expect(env1.Value.AccountId).toBe(601)
			expect(env1.Value.PurchasableItemId).toBe(1534)
			expect(env1.Value.CustomAvatarItemId).toBeNull()
			expect(typeof env1.Value.CreatedAt).toBe('string')

			// Wait so the second wish sorts after the first by its timestamp.
			await new Promise((r) => setTimeout(r, 5))
			// A custom avatar item is the mirror image: `PurchasableItemId` 0 (the client's field
			// is a plain int), the GUID beside it — lowercased, however the client spelled it.
			const second = await post(
				'/wishlist/add',
				'601',
				'purchasableItemId=&customAvatarItemId=C3ED9841-1B4A-40A6-B266-5DBCFD7F2865'
			)
			const env2 = (await second.json()) as { Value: Record<string, unknown> }
			expect(env2.Value.PurchasableItemId).toBe(0)
			expect(env2.Value.CustomAvatarItemId).toBe('c3ed9841-1b4a-40a6-b266-5dbcfd7f2865')

			// Newest first — the order the reference served. The keyless `?True`/`?False` the
			// client appends is ignored, so both spellings serve the same list.
			const mine = (await list('me?True', '601')) as Array<Record<string, unknown>>
			expect(mine.map((e) => e.WishlistItemId)).toEqual([
				env2.Value.WishlistItemId,
				env1.Value.WishlistItemId,
			])
			expect(await list('me?False', '601')).toEqual(mine)
			expect(await list('me', '601')).toEqual(mine)
			// Readable by another signed-in player under the account id.
			expect(await list('601?False', '602')).toEqual(mine)
			// And nobody else's list picked it up.
			expect(await list('me', '602')).toEqual([])
		})

		test('re-adding an item answers the existing entry rather than a twin', async () => {
			const first = (await (
				await post('/wishlist/add', '603', 'purchasableItemId=2137&customAvatarItemId=')
			).json()) as { Value: { WishlistItemId: string } }
			const again = (await (
				await post('/wishlist/add', '603', 'purchasableItemId=2137&customAvatarItemId=')
			).json()) as { Success: boolean; Value: { WishlistItemId: string } }
			expect(again.Success).toBe(true)
			expect(again.Value.WishlistItemId).toBe(first.Value.WishlistItemId)
			expect(((await list('me', '603')) as unknown[]).length).toBe(1)
		})

		test('remove answers the removed entry; removing an unlisted item is still a success', async () => {
			const added = (await (
				await post('/wishlist/add', '604', 'purchasableItemId=1274&customAvatarItemId=')
			).json()) as { Value: { WishlistItemId: string } }

			const removed = await post(
				'/wishlist/remove',
				'604',
				'purchasableItemId=1274&customAvatarItemId='
			)
			expect(removed.status).toBe(200)
			expect(await removed.json()).toEqual({
				Value: expect.objectContaining({
					WishlistItemId: added.Value.WishlistItemId,
					AccountId: 604,
					PurchasableItemId: 1274,
				}),
				Success: true,
				Error: null,
				error_id: null,
			})
			expect(await list('me', '604')).toEqual([])

			// Already gone: the list is as asked, so this is not an error — a null `Value`.
			const again = await post(
				'/wishlist/remove',
				'604',
				'purchasableItemId=1274&customAvatarItemId='
			)
			expect(await again.json()).toEqual({
				Value: null,
				Success: true,
				Error: null,
				error_id: null,
			})
		})

		test('remove only touches the caller’s own list', async () => {
			await post('/wishlist/add', '605', 'purchasableItemId=1274&customAvatarItemId=')
			const other = await post(
				'/wishlist/remove',
				'606',
				'purchasableItemId=1274&customAvatarItemId='
			)
			expect(((await other.json()) as { Value: unknown }).Value).toBeNull()
			expect(((await list('me', '605')) as unknown[]).length).toBe(1)
		})

		test('a body naming no item is a refusal in the envelope, with a readable Error', async () => {
			for (const body of [
				'',
				'purchasableItemId=&customAvatarItemId=',
				'purchasableItemId=abc',
				'customAvatarItemId=not-a-guid',
				'purchasableItemId=0',
			]) {
				for (const path of ['/wishlist/add', '/wishlist/remove']) {
					const res = await post(path, '607', body)
					expect(res.status, `${path} ${body}`).toBe(200)
					expect(await res.json(), `${path} ${body}`).toEqual({
						Value: null,
						Success: false,
						Error: 'No item was specified.',
						error_id: null,
					})
				}
			}
			expect(await list('me', '607')).toEqual([])
		})

		test('POST /isonwishlist/bulk answers one boolean per accountId, in order', async () => {
			await post('/wishlist/add', '608', 'purchasableItemId=3001&customAvatarItemId=')
			await post('/wishlist/add', '610', 'purchasableItemId=3001&customAvatarItemId=')
			await post(
				'/wishlist/add',
				'609',
				'purchasableItemId=&customAvatarItemId=8f0c1e4a-2b77-4b16-9a3e-5dbcfd7f2865'
			)

			// `accountIds` repeated once per id, as the client's list parameter encodes; the
			// unknown account 611 reads false rather than shortening the array.
			const res = await post(
				'/isonwishlist/bulk',
				'608',
				'accountIds=608&accountIds=609&accountIds=610&accountIds=611&purchasableItemId=3001&customAvatarItemId='
			)
			expect(res.status).toBe(200)
			expect(await res.json()).toEqual([true, false, true, false])

			// A comma-separated single value, and a custom item, matched case-insensitively.
			const custom = await post(
				'/isonwishlist/bulk',
				'608',
				'accountIds=609,608&purchasableItemId=&customAvatarItemId=8F0C1E4A-2B77-4B16-9A3E-5DBCFD7F2865'
			)
			expect(await custom.json()).toEqual([true, false])

			// No item named: false for everyone, still one per id.
			const none = await post('/isonwishlist/bulk', '608', 'accountIds=608&accountIds=610')
			expect(await none.json()).toEqual([false, false])
			// No ids: an empty array.
			const empty = await post('/isonwishlist/bulk', '608', 'purchasableItemId=3001')
			expect(await empty.json()).toEqual([])
		})
	})

	test('GET /api/avatar/v3/saved 401s without a token, returns [] with one', async () => {
		const anon = await exports.default.fetch(`${ORIGIN}/api/avatar/v3/saved`)
		expect(anon.status).toBe(401)
		// Account 21 has saved nothing.
		const res = await exports.default.fetch(`${ORIGIN}/api/avatar/v3/saved`, {
			headers: await bearer('21'),
		})
		expect(res.status).toBe(200)
		expect(await res.json()).toEqual([])
	})

	test('POST /api/avatar/v3/saved/set saves an outfit, read back by /saved', async () => {
		const anon = await exports.default.fetch(`${ORIGIN}/api/avatar/v3/saved/set`, {
			method: 'POST',
			body: JSON.stringify(SAVED_OUTFIT),
		})
		expect(anon.status).toBe(401)

		const res = await exports.default.fetch(`${ORIGIN}/api/avatar/v3/saved/set`, {
			method: 'POST',
			headers: { ...(await bearer('22')), 'Content-Type': 'application/json' },
			body: JSON.stringify(SAVED_OUTFIT),
		})
		expect(res.status).toBe(200)
		expect(await res.json()).toEqual(SAVED_OUTFIT)

		// Round-trips verbatim — including the JSON-in-a-string fields the client parses
		// back itself (OutfitSelectionsV2, FaceFeatures).
		const saved = await exports.default.fetch(`${ORIGIN}/api/avatar/v3/saved`, {
			headers: await bearer('22'),
		})
		expect(await saved.json()).toEqual([SAVED_OUTFIT])
	})

	test('POST /api/avatar/v3/saved/set overwrites the same slot, and keeps others', async () => {
		const headers = await bearer('23')
		const post = (outfit: unknown) =>
			exports.default.fetch(`${ORIGIN}/api/avatar/v3/saved/set`, {
				method: 'POST',
				headers: { ...headers, 'Content-Type': 'application/json' },
				body: JSON.stringify(outfit),
			})

		await post({ ...SAVED_OUTFIT, Slot: 4, SkinColor: 'first' })
		await post({ ...SAVED_OUTFIT, Slot: 7, SkinColor: 'other-slot' })
		// Re-saving slot 4 replaces it rather than adding a second row for it.
		await post({ ...SAVED_OUTFIT, Slot: 4, SkinColor: 'second' })

		const res = await exports.default.fetch(`${ORIGIN}/api/avatar/v3/saved`, { headers })
		const outfits = (await res.json()) as Array<{ Slot: number; SkinColor: string }>
		expect(outfits.map((o) => [o.Slot, o.SkinColor])).toEqual([
			[4, 'second'],
			[7, 'other-slot'],
		])
	})

	test('POST /api/avatar/v3/saved/set 400s without an integer Slot', async () => {
		const { Slot: _Slot, ...noSlot } = SAVED_OUTFIT
		const res = await exports.default.fetch(`${ORIGIN}/api/avatar/v3/saved/set`, {
			method: 'POST',
			headers: { ...(await bearer('24')), 'Content-Type': 'application/json' },
			body: JSON.stringify(noSlot),
		})
		expect(res.status).toBe(400)
	})

	test('POST /api/avatar/v4/saved/set stores like v3 but acks with { Success, Slot }', async () => {
		const anon = await exports.default.fetch(`${ORIGIN}/api/avatar/v4/saved/set`, {
			method: 'POST',
			body: JSON.stringify(SAVED_OUTFIT),
		})
		expect(anon.status).toBe(401)

		const res = await exports.default.fetch(`${ORIGIN}/api/avatar/v4/saved/set`, {
			method: 'POST',
			headers: { ...(await bearer('25')), 'Content-Type': 'application/json' },
			body: JSON.stringify(SAVED_OUTFIT),
		})
		expect(res.status).toBe(200)
		// v4 answers a lean ack, not the echoed outfit.
		expect(await res.json()).toEqual({ Success: true, Slot: SAVED_OUTFIT.Slot })

		// Shares the v3 outfit table, so the v3 read serves the outfit back verbatim.
		const saved = await exports.default.fetch(`${ORIGIN}/api/avatar/v3/saved`, {
			headers: await bearer('25'),
		})
		expect(await saved.json()).toEqual([SAVED_OUTFIT])
	})

	test('POST /api/avatar/v4/saved/set 400s without an integer Slot', async () => {
		const { Slot: _Slot, ...noSlot } = SAVED_OUTFIT
		const res = await exports.default.fetch(`${ORIGIN}/api/avatar/v4/saved/set`, {
			method: 'POST',
			headers: { ...(await bearer('26')), 'Content-Type': 'application/json' },
			body: JSON.stringify(noSlot),
		})
		expect(res.status).toBe(400)
	})

	test('GET /api/avatar/v2/gifts 401s without a token, returns [] with one', async () => {
		const anon = await exports.default.fetch(`${ORIGIN}/api/avatar/v2/gifts`)
		expect(anon.status).toBe(401)
		const res = await exports.default.fetch(`${ORIGIN}/api/avatar/v2/gifts`, {
			headers: await bearer(),
		})
		expect(res.status).toBe(200)
		expect(await res.json()).toEqual([])
	})

	test('GET /api/equipment/v2/getUnlocked 401s without a token, returns [] when none owned', async () => {
		const anon = await exports.default.fetch(`${ORIGIN}/api/equipment/v2/getUnlocked`)
		expect(anon.status).toBe(401)
		// Account 30 has bought no equipment → empty list.
		const res = await exports.default.fetch(`${ORIGIN}/api/equipment/v2/getUnlocked`, {
			headers: await bearer('30'),
		})
		expect(res.status).toBe(200)
		expect(await res.json()).toEqual([])
	})

	test('GET /api/roomconsumables/v1/roomConsumable/room/:id returns [] for a room with no shop', async () => {
		const res = await exports.default.fetch(
			`${ORIGIN}/api/roomconsumables/v1/roomConsumable/room/1`
		)
		expect(res.status).toBe(200)
		expect(await res.json()).toEqual([])
	})

	test('GET /api/roomcurrencies/v1/currencies returns [] for a room with none', async () => {
		const res = await exports.default.fetch(`${ORIGIN}/api/roomcurrencies/v1/currencies?roomId=1`)
		expect(res.status).toBe(200)
		expect(await res.json()).toEqual([])

		// An unknown room and a missing roomId read the same way — the client takes any of
		// them as "this room has no currency of its own".
		for (const query of ['?roomId=99999', '', '?roomId=nope']) {
			const other = await exports.default.fetch(
				`${ORIGIN}/api/roomcurrencies/v1/currencies${query}`
			)
			expect(other.status).toBe(200)
			expect(await other.json()).toEqual([])
		}
	})

	// Room 2511 is seeded as account 1's, with account 2 as co-owner.
	describe('room consumables', () => {
		type Consumable = {
			RoomConsumableId: string
			RoomId: number
			Name: string
			Description: string
			ImageName: string | null
			Price: number
			PurchaseCurrencyId: string | null
			ModifiedAt: string
			MaximumCountPerPurchase: number
		}

		const save = async (payload: unknown, headers?: Record<string, string>) =>
			exports.default.fetch(`${ORIGIN}/api/roomconsumables/v1/roomConsumable`, {
				method: 'PUT',
				headers: { 'Content-Type': 'application/json', ...headers },
				body: JSON.stringify(payload),
			})
		const envOf = async (res: Response) =>
			(await res.json()) as {
				Value: Consumable | null
				Success: boolean
				Error: string | null
				error_id: null
			}
		const shopOf = async (roomId: number) =>
			(await (
				await exports.default.fetch(
					`${ORIGIN}/api/roomconsumables/v1/roomConsumable/room/${roomId}`
				)
			).json()) as Consumable[]

		const body = {
			RoomConsumableId: null,
			RoomId: 2511,
			Name: 'test',
			Description: 'test444444',
			ImageName: null,
			PriceAndCurrency: { Price: 50, CurrencyId: 'b9f41a7c-32f1-4456-b84f-fdb94b240955' },
		}

		test('PUT roomConsumable stocks the shop, gated to the room', async () => {
			// No token → 401; a valid token with no standing in the room → 403.
			expect((await save(body)).status).toBe(401)
			expect((await save(body, await bearer('999'))).status).toBe(403)

			// An unusable body is the failure envelope, and stocks nothing.
			const badBodies: unknown[] = [
				{ ...body, RoomId: 'nope' },
				{ ...body, Name: '   ' },
				{ ...body, RoomConsumableId: 'a3f1e8d2-0000-4000-8000-000000000000' },
				'not an object',
			]
			for (const bad of badBodies) {
				const res = await save(bad, await plusBearer('1'))
				expect(res.status).toBe(200)
				expect(await envOf(res)).toEqual({
					Value: null,
					Success: false,
					Error: 'Failed to save consumable',
					error_id: null,
				})
			}
			expect(await shopOf(2511)).toEqual([])

			// The owner stocks it. `PriceAndCurrency` collapses to the flat pair the read serves.
			const res = await save(body, await plusBearer('1'))
			expect(res.status).toBe(200)
			const env = await envOf(res)
			expect(env).toMatchObject({ Success: true, Error: null, error_id: null })
			const created = env.Value!
			expect(created).toMatchObject({
				RoomId: 2511,
				Name: 'test',
				Description: 'test444444',
				ImageName: null,
				Price: 50,
				PurchaseCurrencyId: 'b9f41a7c-32f1-4456-b84f-fdb94b240955',
				// The client doesn't send this, so it falls back rather than landing as NaN.
				MaximumCountPerPurchase: 0,
			})
			expect(created.RoomConsumableId).toMatch(/^[0-9a-f-]{36}$/)
			expect(Date.parse(created.ModifiedAt)).not.toBeNaN()
			// The client's own model, member for member and in its order.
			expect(Object.keys(created)).toEqual([
				'RoomConsumableId',
				'RoomId',
				'Name',
				'Description',
				'ImageName',
				'Price',
				'PurchaseCurrencyId',
				'ModifiedAt',
				'MaximumCountPerPurchase',
			])

			// The list serves it back, and it belongs to this room alone.
			expect(await shopOf(2511)).toEqual([created])
			expect(await shopOf(1)).toEqual([])
		})

		test('PUT roomConsumable replaces when the body names a listing', async () => {
			const created = (await envOf(await save({ ...body, Name: 'Before' }, await plusBearer('1'))))
				.Value!

			// Naming the listing REPLACES it rather than adding a second, and a co-owner may.
			const edited = (
				await envOf(
					await save(
						{
							RoomConsumableId: created.RoomConsumableId,
							// Deliberately another room: an edit must not move a listing, and the
							// permission check must not follow the body.
							RoomId: 1,
							Name: 'After',
							Description: 'edited',
							ImageName: 'potion.png',
							PriceAndCurrency: { Price: 25, CurrencyId: null },
							MaximumCountPerPurchase: 10,
						},
						await plusBearer('2')
					)
				)
			).Value!

			expect(edited).toMatchObject({
				RoomConsumableId: created.RoomConsumableId,
				// Still room 2511 — the body's RoomId is ignored on a replace.
				RoomId: 2511,
				Name: 'After',
				Description: 'edited',
				ImageName: 'potion.png',
				Price: 25,
				PurchaseCurrencyId: null,
				MaximumCountPerPurchase: 10,
			})
			const shop = await shopOf(2511)
			expect(shop.filter((it) => it.RoomConsumableId === created.RoomConsumableId)).toEqual([
				edited,
			])

			// A replace is a REPLACE, not a merge: a field left out is cleared, since the client
			// sends the whole form back.
			const cleared = (
				await envOf(
					await save(
						{ RoomConsumableId: created.RoomConsumableId, Name: 'Bare' },
						await plusBearer('1')
					)
				)
			).Value!
			expect(cleared).toMatchObject({
				Name: 'Bare',
				Description: '',
				ImageName: null,
				Price: 0,
				PurchaseCurrencyId: null,
				MaximumCountPerPurchase: 0,
			})
		})

		test('PUT roomConsumable masks a name players will see, and a room can stock several', async () => {
			const masked = (
				await envOf(await save({ ...body, Name: 'shit potion' }, await plusBearer('1')))
			).Value!
			expect(masked.Name).toBe('**** potion')

			await save({ ...body, Name: 'Second' }, await plusBearer('1'))
			const shop = await shopOf(2511)
			expect(shop.length).toBeGreaterThanOrEqual(2)
			// Each listing has its own id — two things in a shop are not one thing.
			expect(new Set(shop.map((it) => it.RoomConsumableId)).size).toBe(shop.length)
		})

		test('POST roomConsumable/awardBulk gives them to the CALLER, reporting each entry', async () => {
			type AwardResult = {
				ConsumableId: string
				Success: boolean
				Error: string | null
				Response: {
					PlayerId: number
					ConsumableId: string
					Quantity: number
					AwardedAt: string
				} | null
			}
			const potion = (await envOf(await save({ ...body, Name: 'Potion' }, await plusBearer('1'))))
				.Value!
			const elixir = (await envOf(await save({ ...body, Name: 'Elixir' }, await plusBearer('1'))))
				.Value!

			const awardBulk = async (payload: unknown, headers?: Record<string, string>) =>
				exports.default.fetch(`${ORIGIN}/api/roomconsumables/v1/roomConsumable/awardBulk`, {
					method: 'POST',
					headers: { 'Content-Type': 'application/json', ...headers },
					body: JSON.stringify(payload),
				})
			const resultsOf = async (res: Response) => (await res.json()) as AwardResult[]
			const ownedBy = async (playerId: number, consumableId: string) =>
				(
					await env.DB.prepare(
						'SELECT quantity FROM room_inventory WHERE player_id = ?1 AND consumable_id = ?2'
					)
						.bind(playerId, consumableId)
						.first<{ quantity: number }>()
				)?.quantity ?? 0

			const request = (id: string, Quantity: number) => ({
				Requests: {
					[id]: {
						Quantity,
						ConcurrencyCodes: {
							CurrentConcurrencyCode: null,
							NewConcurrencyCode: '8792f49a-703d-4906-8320-dc9c5f616e21',
						},
					},
				},
			})

			// No token → 401. Nothing else is answered at the call level.
			expect((await awardBulk(request(potion.RoomConsumableId, 1))).status).toBe(401)

			// The award goes to whoever is ASKING — account 42 here, not the room's owner.
			const res = await awardBulk(request(potion.RoomConsumableId, 1), await bearer('42'))
			expect(res.status).toBe(200)
			const results = await resultsOf(res)
			expect(results).toHaveLength(1)
			expect(results[0]).toMatchObject({
				ConsumableId: potion.RoomConsumableId,
				Success: true,
				Error: null,
				Response: {
					PlayerId: 42,
					ConsumableId: potion.RoomConsumableId,
					Quantity: 1,
				},
			})
			expect(Date.parse(results[0].Response!.AwardedAt)).not.toBeNaN()
			expect(await ownedBy(42, potion.RoomConsumableId)).toBe(1)
			// Nobody else got one.
			expect(await ownedBy(1, potion.RoomConsumableId)).toBe(0)

			// Awards accumulate, and `Quantity` on the result is the RESULTING total.
			expect(
				(
					await resultsOf(await awardBulk(request(potion.RoomConsumableId, 4), await bearer('42')))
				)[0].Response
			).toMatchObject({ Quantity: 5 })

			// Negative takes them away, and the count floors at zero.
			expect(
				(
					await resultsOf(await awardBulk(request(potion.RoomConsumableId, -2), await bearer('42')))
				)[0].Response
			).toMatchObject({ Quantity: 3 })
			expect(
				(
					await resultsOf(
						await awardBulk(request(potion.RoomConsumableId, -99), await bearer('42'))
					)
				)[0].Response
			).toMatchObject({ Quantity: 0 })

			// Several keys in one call: each entry stands alone, in the order the keys appeared,
			// so an id naming no listing leaves the rest to land.
			const mixed = await awardBulk(
				{
					Requests: {
						[elixir.RoomConsumableId]: { Quantity: 2 },
						'a3f1e8d2-0000-4000-8000-000000000000': { Quantity: 9 },
						[potion.RoomConsumableId]: { Quantity: 'lots' },
					},
				},
				await bearer('42')
			)
			const mixedResults = await resultsOf(mixed)
			expect(mixedResults.map((r) => r.ConsumableId)).toEqual([
				elixir.RoomConsumableId,
				'a3f1e8d2-0000-4000-8000-000000000000',
				potion.RoomConsumableId,
			])
			expect(mixedResults.map((r) => r.Success)).toEqual([true, false, false])
			expect(mixedResults.map((r) => r.Error)).toEqual([
				null,
				'No such consumable',
				'Invalid quantity',
			])
			expect(await ownedBy(42, elixir.RoomConsumableId)).toBe(2)
			// The bad entries wrote nothing.
			expect(await ownedBy(42, 'a3f1e8d2-0000-4000-8000-000000000000')).toBe(0)
			expect(await ownedBy(42, potion.RoomConsumableId)).toBe(0)

			// A body with no `Requests` map has no entries to report on.
			for (const bad of [{}, { Requests: null }, { Requests: [] }, 'nope']) {
				const res = await awardBulk(bad, await bearer('42'))
				expect(res.status).toBe(200)
				expect(await resultsOf(res)).toEqual([])
			}
		})

		test('PUT roomconsumable/:id/purchase/tokens|currency sells for tokens (paying the owner) or room currency (paying nobody)', async () => {
			const coin = 'b9f41a7c-32f1-4456-b84f-fdb94b240955'
			// Room 2511 is account 1's, with 2 as co-owner. One listing in tokens (max 3 a
			// purchase), one in the room's coin.
			const tokenItem = (
				await envOf(
					await save(
						{
							...body,
							Name: 'Token potion',
							PriceAndCurrency: { Price: 5, CurrencyId: null },
							MaximumCountPerPurchase: 3,
						},
						await plusBearer('1')
					)
				)
			).Value!
			const coinItem = (
				await envOf(await save({ ...body, Name: 'Coin potion' }, await plusBearer('1')))
			).Value!
			expect(tokenItem).toMatchObject({ Price: 5, PurchaseCurrencyId: null })
			expect(coinItem).toMatchObject({ Price: 50, PurchaseCurrencyId: coin })

			const purchase = async (
				sub: string | null,
				consumableId: string,
				price: number,
				currencyId: string | null,
				quantity = 1,
				gift: number | null = null
			) =>
				exports.default.fetch(
					// As the client does: a token price to `/tokens`, a room currency to `/currency`.
					`${ORIGIN}/api/roomconsumables/v1/roomconsumable/${consumableId}/purchase/` +
						(currencyId === null ? 'tokens' : 'currency'),
					{
						method: 'PUT',
						headers: {
							'Content-Type': 'application/json',
							...(sub === null ? {} : await plusBearer(sub)),
						},
						body: JSON.stringify({
							ConcurrencyCodes: {
								CurrentConcurrencyCode: null,
								NewConcurrencyCode: '1ea4a2dd-b643-406d-99b7-bd1b936e678b',
							},
							ExpectedPriceAndCurrency: { Price: price, CurrencyId: currencyId },
							Quantity: quantity,
							GiftRecipientAccountId: gift,
						}),
					}
				)
			type InventoryItem = {
				RoomConsumableId: string
				AccountId: number
				Count: number
				ConcurrencyCode: string | null
				ModifiedAt: string
				Consumable: Consumable & { IsGiftable: boolean; Visibility: number }
			}
			type Purchase = {
				BalanceUpdateResult: number
				CurrencyBalanceResponse: {
					AccountId: number
					CurrencyId: string | null
					Balance: number
					ModifiedAt: string
				}
				OperationResult: {
					Status: number
					InventoryItem: InventoryItem | null
				}
			}
			const result = async (res: Response) => {
				expect(res.status).toBe(200)
				return (await res.json()) as Purchase
			}
			// A refusal: the same shape, nothing given, the buyer's balance as it stands.
			const refused = (
				code: number,
				buyer: number,
				currencyId: string | null,
				balance: number
			) => ({
				BalanceUpdateResult: code,
				CurrencyBalanceResponse: {
					AccountId: buyer,
					CurrencyId: currencyId,
					Balance: balance,
					ModifiedAt: expect.any(String),
				},
				OperationResult: { Status: 1, InventoryItem: null },
			})
			const setTokens = (accountId: number, amount: number) =>
				env.DB.prepare(
					'INSERT OR REPLACE INTO balance (account_id, currency_type, amount) VALUES (?1, 2, ?2)'
				)
					.bind(accountId, amount)
					.run()
			const tokens = async (accountId: number) =>
				(
					await env.DB.prepare(
						'SELECT amount FROM balance WHERE account_id = ?1 AND currency_type = 2'
					)
						.bind(accountId)
						.first<{ amount: number }>()
				)?.amount
			const setCoins = (playerId: number, amount: number) =>
				env.DB.prepare(
					'INSERT OR REPLACE INTO room_balance (currency_id, player_id, amount) VALUES (?1, ?2, ?3)'
				)
					.bind(coin, playerId, amount)
					.run()
			const coins = async (playerId: number) =>
				(
					await env.DB.prepare(
						'SELECT amount FROM room_balance WHERE currency_id = ?1 AND player_id = ?2'
					)
						.bind(coin, playerId)
						.first<{ amount: number }>()
				)?.amount ?? 0
			const owned = async (playerId: number, consumableId: string) =>
				(
					await env.DB.prepare(
						'SELECT quantity FROM room_inventory WHERE player_id = ?1 AND consumable_id = ?2'
					)
						.bind(playerId, consumableId)
						.first<{ quantity: number }>()
				)?.quantity ?? 0
			const drainFrames = async () =>
				(
					env.RECFLARE_NOTIFICATIONS_HUB.getByName('global') as unknown as {
						drainFrames(): Promise<Array<{ accountId: number; payload: Record<string, unknown> }>>
					}
				).drainFrames()

			await setTokens(1, 1000)
			await setTokens(2, 40)
			await setTokens(7701, 100)
			await setTokens(7702, 4)
			await setCoins(7701, 120)
			await drainFrames()

			expect((await purchase(null, tokenItem.RoomConsumableId, 5, null)).status).toBe(401)
			// Only the two purchase paths exist.
			const other = await exports.default.fetch(
				`${ORIGIN}/api/roomconsumables/v1/roomconsumable/${tokenItem.RoomConsumableId}/purchase/gems`,
				{ method: 'PUT', headers: await bearer('7701'), body: '{}' }
			)
			expect(other.status).toBe(404)

			// Refusals charge and give nothing, and say why in `BalanceUpdateResult`.
			const refusals: Array<[Promise<Response>, ReturnType<typeof refused>]> = [
				[purchase('7701', 'nope', 5, null), refused(4, 7701, null, 100)],
				[purchase('7701', tokenItem.RoomConsumableId, 5, null, 0), refused(7, 7701, null, 100)],
				[purchase('7701', tokenItem.RoomConsumableId, 5, null, 4), refused(7, 7701, null, 100)],
				[purchase('7701', tokenItem.RoomConsumableId, 5, null, 1, -3), refused(8, 7701, null, 100)],
				[purchase('7701', tokenItem.RoomConsumableId, 0, null), refused(6, 7701, null, 100)],
				[purchase('7701', tokenItem.RoomConsumableId, 5, coin), refused(6, 7701, null, 100)],
				[purchase('7701', coinItem.RoomConsumableId, 50, null), refused(6, 7701, coin, 120)],
				[purchase('7702', tokenItem.RoomConsumableId, 5, null), refused(2, 7702, null, 4)],
				[purchase('7701', coinItem.RoomConsumableId, 50, coin, 3), refused(2, 7701, coin, 120)],
			]
			for (const [res, expected] of refusals) {
				expect(await result(await res)).toEqual(expected)
			}
			expect([await tokens(1), await tokens(7701), await tokens(7702)]).toEqual([1000, 100, 4])
			expect(await coins(7701)).toBe(120)
			expect(await owned(7701, tokenItem.RoomConsumableId)).toBe(0)
			expect(await drainFrames()).toEqual([])

			// Tokens: 3 × 5 leaves the buyer and reaches the room's owner.
			const sold = await result(await purchase('7701', tokenItem.RoomConsumableId, 5, null, 3))
			expect(sold).toEqual({
				BalanceUpdateResult: 0,
				CurrencyBalanceResponse: {
					AccountId: 7701,
					CurrencyId: null,
					Balance: 85,
					ModifiedAt: expect.any(String),
				},
				OperationResult: {
					Status: 0,
					InventoryItem: {
						RoomConsumableId: tokenItem.RoomConsumableId,
						AccountId: 7701,
						Count: 3,
						ConcurrencyCode: '1ea4a2dd-b643-406d-99b7-bd1b936e678b',
						ModifiedAt: expect.any(String),
						// The listing plus two fields, with no picture as '' — not the catalogue's.
						Consumable: { ...tokenItem, ImageName: '', IsGiftable: false, Visibility: 0 },
					},
				},
			})
			// Member order as the client was observed receiving it.
			expect(Object.keys(sold)).toEqual([
				'BalanceUpdateResult',
				'CurrencyBalanceResponse',
				'OperationResult',
			])
			expect(Object.keys(sold.OperationResult.InventoryItem!)).toEqual([
				'RoomConsumableId',
				'AccountId',
				'Count',
				'ConcurrencyCode',
				'ModifiedAt',
				'Consumable',
			])
			expect([await tokens(1), await tokens(7701)]).toEqual([1015, 85])
			const frames = await drainFrames()
			expect(frames.find((f) => f.accountId === 1)?.payload).toMatchObject({
				Balance: 1015,
				Platform: -2,
			})
			expect(frames.find((f) => f.accountId === 7701)?.payload).toMatchObject({
				Delta: -15,
				Balance: 85,
				Platform: -2,
			})

			// Room currency: 2 × 50 leaves the buyer's coin and pays nobody.
			const bought = await result(await purchase('7701', coinItem.RoomConsumableId, 50, coin, 2))
			expect(bought.CurrencyBalanceResponse).toMatchObject({
				AccountId: 7701,
				CurrencyId: coin,
				Balance: 20,
			})
			expect(bought.OperationResult.InventoryItem).toMatchObject({ AccountId: 7701, Count: 2 })
			expect(await coins(7701)).toBe(20)
			expect(await coins(1)).toBe(0)
			expect(await tokens(1)).toBe(1015)
			expect(await drainFrames()).toEqual([])

			// A gift: the buyer pays, the owner is paid, the recipient owns it.
			const gift = await result(
				await purchase('7701', tokenItem.RoomConsumableId, 5, null, 1, 7702)
			)
			// The balance is the BUYER's; the item is the RECIPIENT's.
			expect(gift.CurrencyBalanceResponse).toMatchObject({ AccountId: 7701, Balance: 80 })
			expect(gift.OperationResult.InventoryItem).toMatchObject({ AccountId: 7702, Count: 1 })
			expect(await owned(7702, tokenItem.RoomConsumableId)).toBe(1)
			expect(await owned(7701, tokenItem.RoomConsumableId)).toBe(3)
			expect([await tokens(1), await tokens(7701), await tokens(7702)]).toEqual([1020, 80, 4])
			await drainFrames()

			// A co-owner gets it free at the 0 the client asks them, in either currency.
			const free = await result(await purchase('2', tokenItem.RoomConsumableId, 0, null, 2))
			expect(free.BalanceUpdateResult).toBe(0)
			expect(free.OperationResult.InventoryItem).toMatchObject({ AccountId: 2, Count: 2 })
			const freeCoin = await result(await purchase('2', coinItem.RoomConsumableId, 0, coin))
			expect(freeCoin.OperationResult.Status).toBe(0)
			expect([await tokens(1), await tokens(2), await coins(2)]).toEqual([1020, 40, 0])
			expect(await drainFrames()).toEqual([])

			// `/me` lists what the caller holds of the room, in the shop's order — the same item
			// the purchase answered with, the stored concurrency code included.
			const mine = async (sub: string | null, roomId: number | string = 2511) => {
				const res = await exports.default.fetch(
					`${ORIGIN}/api/roomconsumables/v1/roomConsumable/room/${roomId}/me`,
					sub === null ? undefined : { headers: await plusBearer(sub) }
				)
				return {
					status: res.status,
					items: (await res.json().catch(() => null)) as InventoryItem[],
				}
			}
			expect((await mine(null)).status).toBe(401)
			const own = await mine('7701')
			expect(own.status).toBe(200)
			expect(own.items).toEqual([
				{
					RoomConsumableId: tokenItem.RoomConsumableId,
					AccountId: 7701,
					Count: 3,
					ConcurrencyCode: '1ea4a2dd-b643-406d-99b7-bd1b936e678b',
					ModifiedAt: expect.any(String),
					Consumable: { ...tokenItem, ImageName: '', IsGiftable: false, Visibility: 0 },
				},
				expect.objectContaining({ RoomConsumableId: coinItem.RoomConsumableId, Count: 2 }),
			])
			expect((await mine('7702')).items).toEqual([
				expect.objectContaining({ RoomConsumableId: tokenItem.RoomConsumableId, Count: 1 }),
			])
			// Another room, an unknown one, and a nonsense id are all empty.
			expect((await mine('7701', 99999)).items).toEqual([])
			expect((await mine('7701', 'nope')).items).toEqual([])
			// Spent down to zero is absent, not a zero row.
			await env.DB.prepare('UPDATE room_inventory SET quantity = 0 WHERE player_id = 7702').run()
			expect((await mine('7702')).items).toEqual([])

			await env.DB.prepare('DELETE FROM room_inventory').run()
			await env.DB.prepare('DELETE FROM room_balance WHERE currency_id = ?1').bind(coin).run()
		})

		test('PUT roomConsumable/:id/consume uses up one the caller holds', async () => {
			const potion = (
				await envOf(await save({ ...body, Name: 'Drinkable potion' }, await plusBearer('1')))
			).Value!
			await env.DB.prepare(
				'INSERT INTO room_inventory (player_id, consumable_id, quantity) VALUES (7801, ?1, 2)'
			)
				.bind(potion.RoomConsumableId)
				.run()

			const consume = async (sub: string | null, consumableId: string, code: string) =>
				exports.default.fetch(
					`${ORIGIN}/api/roomconsumables/v1/roomConsumable/${consumableId}/consume`,
					{
						method: 'PUT',
						headers: {
							'Content-Type': 'application/json',
							...(sub === null ? {} : await plusBearer(sub)),
						},
						body: JSON.stringify({
							CurrentConcurrencyCode: '872adb91-b163-4f2c-aa8f-4f5d828078cb',
							NewConcurrencyCode: code,
						}),
					}
				)
			const held = async () =>
				(
					await env.DB.prepare(
						'SELECT quantity FROM room_inventory WHERE player_id = 7801 AND consumable_id = ?1'
					)
						.bind(potion.RoomConsumableId)
						.first<{ quantity: number }>()
				)?.quantity

			expect((await consume(null, potion.RoomConsumableId, 'a')).status).toBe(401)

			const res = await consume('7801', potion.RoomConsumableId, 'code-1')
			expect(res.status).toBe(200)
			expect(await res.json()).toEqual({
				Status: 0,
				InventoryItem: {
					RoomConsumableId: potion.RoomConsumableId,
					AccountId: 7801,
					Count: 1,
					ConcurrencyCode: 'code-1',
					ModifiedAt: expect.any(String),
					Consumable: { ...potion, ImageName: '', IsGiftable: false, Visibility: 0 },
				},
			})

			// The last one answers Count 0; after that there is nothing to use.
			const last = (await (await consume('7801', potion.RoomConsumableId, 'code-2')).json()) as {
				Status: number
				InventoryItem: { Count: number; ConcurrencyCode: string } | null
			}
			expect(last).toMatchObject({
				Status: 0,
				InventoryItem: { Count: 0, ConcurrencyCode: 'code-2' },
			})
			const refusal = { Status: 1, InventoryItem: null }
			expect(await (await consume('7801', potion.RoomConsumableId, 'code-3')).json()).toEqual(
				refusal
			)
			expect(await held()).toBe(0)
			// Someone who never had one, and an unknown consumable, are refused too.
			expect(await (await consume('7802', potion.RoomConsumableId, 'x')).json()).toEqual(refusal)
			expect(await (await consume('7801', 'nope', 'x')).json()).toEqual(refusal)

			await env.DB.prepare('DELETE FROM room_inventory').run()
		})

		test('GET roomConsumable/room/:id is public and empty for an unknown room', async () => {
			expect(await shopOf(99999)).toEqual([])
			const res = await exports.default.fetch(
				`${ORIGIN}/api/roomconsumables/v1/roomConsumable/room/nope`
			)
			expect(res.status).toBe(200)
			expect(await res.json()).toEqual([])
		})
	})

	// Room 2511 is seeded as account 1's, with account 2 as co-owner.
	describe('room currencies', () => {
		type RoomCurrency = {
			CurrencyId: string
			RoomId: number
			Name: string
			Description: string
			CurrencyType: number
			Limit: number
			Shape: number
			Color: number
			ImageName: string | null
			CreatedAt: string
			ModifiedAt: string
		}

		const create = async (fields: Record<string, string>, headers?: Record<string, string>) =>
			exports.default.fetch(`${ORIGIN}/api/roomcurrencies/v1/createCurrency`, {
				method: 'POST',
				headers: { 'Content-Type': 'application/x-www-form-urlencoded', ...headers },
				body: new URLSearchParams(fields),
			})

		/** Everything the stub hub was pushed since the last call (see vitest.config). */
		const drainFrames = async (): Promise<
			Array<{
				accountId: number
				notificationType: string | number
				payload: Record<string, unknown>
			}>
		> =>
			(
				env.RECFLARE_NOTIFICATIONS_HUB.getByName('global') as unknown as {
					drainFrames(): Promise<
						Array<{
							accountId: number
							notificationType: string | number
							payload: Record<string, unknown>
						}>
					>
				}
			).drainFrames()

		/** The `{ Value, Success, Error, error_id }` envelope the create endpoint answers in. */
		const envOf = async (res: Response) =>
			(await res.json()) as {
				Value: RoomCurrency | null
				Success: boolean
				Error: string | null
				error_id: null
			}

		const currenciesOf = async (roomId: number) =>
			(await (
				await exports.default.fetch(`${ORIGIN}/api/roomcurrencies/v1/currencies?roomId=${roomId}`)
			).json()) as RoomCurrency[]

		const body = {
			RoomId: '2511',
			Name: 'Devintokens',
			Description: 'this is my currency',
			Limit: '100',
			Shape: '0',
			Color: '19',
		}

		test('POST createCurrency is gated to the room’s creator or a co-owner', async () => {
			// Only the auth gates answer with a status of their own: no token → 401, a valid
			// token with no standing in the room → 403.
			expect((await create(body)).status).toBe(401)
			expect((await create(body, await bearer('999'))).status).toBe(403)

			// Everything else is a 200 carrying the failure envelope — an unknown room, an
			// unusable RoomId, an empty Name. None of them writes anything.
			for (const bad of [
				{ ...body, RoomId: '99999' },
				{ ...body, RoomId: 'nope' },
				{ ...body, Name: '  ' },
			]) {
				const res = await create(bad, await plusBearer('1'))
				expect(res.status).toBe(200)
				expect(await envOf(res)).toEqual({
					Value: null,
					Success: false,
					Error: 'Failed to create currency',
					error_id: null,
				})
			}
			expect(await currenciesOf(2511)).toEqual([])
		})

		test('POST createCurrency mints the currency and the list reads it back', async () => {
			const res = await create(body, await plusBearer('1'))
			expect(res.status).toBe(200)

			// Enveloped: the client unwraps it and hands its callers `Value` alone.
			const env = await envOf(res)
			expect(env).toMatchObject({ Success: true, Error: null, error_id: null })
			const created = env.Value!
			// The client's own model, member for member and in its order.
			expect(Object.keys(created)).toEqual([
				'CurrencyId',
				'RoomId',
				'Name',
				'Description',
				'CurrencyType',
				'Limit',
				'Shape',
				'Color',
				'ImageName',
				'CreatedAt',
				'ModifiedAt',
			])
			expect(created).toMatchObject({
				RoomId: 2511,
				Name: 'Devintokens',
				Description: 'this is my currency',
				// A room currency is told apart by its id, not its type — the type is always 300.
				CurrencyType: 300,
				Limit: 100,
				Shape: 0,
				Color: 19,
				// Null until custom coin art can be uploaded — null, not empty string.
				ImageName: null,
			})
			// A GUID of its own, and timestamps that start equal.
			expect(created.CurrencyId).toMatch(/^[0-9a-f-]{36}$/)
			expect(created.ModifiedAt).toBe(created.CreatedAt)
			expect(Date.parse(created.CreatedAt)).not.toBeNaN()

			// The list serves it back, and it belongs to this room alone.
			expect(await currenciesOf(2511)).toEqual([created])
			expect(await currenciesOf(1)).toEqual([])

			// A co-owner may mint one too, and a room can hold several — oldest first.
			const second = await create({ ...body, Name: 'Coowner coins', Limit: '5' }, await bearer('2'))
			expect(second.status).toBe(200)
			const list = await currenciesOf(2511)
			expect(list.map((c) => c.Name)).toEqual(['Devintokens', 'Coowner coins'])
			// Each carries its own id — two currencies in one room are not one currency.
			expect(new Set(list.map((c) => c.CurrencyId)).size).toBe(2)
			expect(list[1]).toMatchObject({ Limit: 5, CurrencyType: 300 })
		})

		test('POST updateCurrency edits it, gated by the room that minted it', async () => {
			const made = (await envOf(await create({ ...body, Name: 'Before' }, await plusBearer('1'))))
				.Value!

			const update = async (fields: Record<string, string>, headers?: Record<string, string>) =>
				exports.default.fetch(`${ORIGIN}/api/roomcurrencies/v1/updateCurrency`, {
					method: 'POST',
					headers: { 'Content-Type': 'application/x-www-form-urlencoded', ...headers },
					body: new URLSearchParams(fields),
				})

			// No token → 401. A valid token belonging to nobody in the room → 403: the room
			// comes off the CURRENCY, so the caller can't point the gate somewhere friendlier.
			expect((await update({ CurrencyId: made.CurrencyId, Name: 'X' })).status).toBe(401)
			expect(
				(await update({ CurrencyId: made.CurrencyId, Name: 'X' }, await bearer('999'))).status
			).toBe(403)

			// An unknown currency, a missing id and a blank name are the failure envelope — a
			// name sent but empty is a bad edit, not "leave it alone".
			const badEdits: Array<Record<string, string>> = [
				{ CurrencyId: 'a3f1e8d2-0000-4000-8000-000000000000', Name: 'X' },
				{ Name: 'X' },
				{ CurrencyId: made.CurrencyId, Name: '   ' },
			]
			for (const bad of badEdits) {
				const res = await update(bad, await plusBearer('1'))
				expect(res.status).toBe(200)
				expect(await envOf(res)).toEqual({
					Value: null,
					Success: false,
					Error: 'Failed to update currency',
					error_id: null,
				})
			}
			// None of that touched it.
			expect((await currenciesOf(2511)).find((cur) => cur.CurrencyId === made.CurrencyId)).toEqual(
				made
			)

			// The owner edits every mutable field.
			const res = await update(
				{
					CurrencyId: made.CurrencyId,
					Name: 'After',
					Description: 'edited',
					Limit: '330',
					Shape: '9',
					Color: '5',
				},
				await plusBearer('1')
			)
			expect(res.status).toBe(200)
			const updated = (await envOf(res)).Value!
			expect(updated).toMatchObject({
				CurrencyId: made.CurrencyId,
				Name: 'After',
				Description: 'edited',
				Limit: 330,
				Shape: 9,
				Color: 5,
				// What an edit may never change.
				RoomId: 2511,
				CurrencyType: 300,
				CreatedAt: made.CreatedAt,
			})
			// `ModifiedAt` moves; `CreatedAt` doesn't. That is what the client carries both for.
			expect(Date.parse(updated.ModifiedAt)).toBeGreaterThanOrEqual(Date.parse(made.CreatedAt))
			// Persisted, and still one row rather than a second currency.
			const listed = (await currenciesOf(2511)).filter((cur) => cur.CurrencyId === made.CurrencyId)
			expect(listed).toEqual([updated])

			// A co-owner may edit too, and a field left out is left ALONE rather than reset.
			const partial = await update({ CurrencyId: made.CurrencyId, Limit: '7' }, await bearer('2'))
			expect(partial.status).toBe(200)
			expect((await envOf(partial)).Value).toMatchObject({
				Limit: 7,
				Name: 'After',
				Description: 'edited',
				Shape: 9,
				Color: 5,
			})

			// And a name is masked on the way in, like it is on create.
			const masked = await update(
				{ CurrencyId: made.CurrencyId, Name: 'shit bucks' },
				await plusBearer('1')
			)
			expect((await envOf(masked)).Value?.Name).toBe('**** bucks')
		})

		test('POST updateCurrency pushes RoomCurrencyModified to the room and the editor', async () => {
			const made = (await envOf(await create({ ...body, Name: 'Watched' }, await plusBearer('1'))))
				.Value!

			const now = Math.floor(Date.now() / 1000)
			await env.DB.prepare('INSERT OR REPLACE INTO presence (data) VALUES (?1)')
				.bind(
					JSON.stringify({
						accountId: 320,
						roomInstance: { roomInstanceId: 1002511, roomId: 2511, subRoomId: 2511 },
						expiresAt: now + 900,
					})
				)
				.run()
			await drainFrames()

			const res = await exports.default.fetch(`${ORIGIN}/api/roomcurrencies/v1/updateCurrency`, {
				method: 'POST',
				headers: {
					'Content-Type': 'application/x-www-form-urlencoded',
					...(await plusBearer('1')),
				},
				body: new URLSearchParams({ CurrencyId: made.CurrencyId, Name: 'Renamed' }),
			})
			expect(res.status).toBe(200)

			// An edit reaches the room, not just the editor — otherwise everyone else keeps
			// spending the currency under its old name and cap.
			const frames = await drainFrames()
			expect(frames.map((f) => f.accountId).sort((a, b) => a - b)).toEqual([1, 320])
			expect(
				frames.every((f) => f.notificationType === NotificationType.RoomCurrencyModified)
			).toBe(true)
			expect(frames[0].payload).toMatchObject({
				CurrencyId: made.CurrencyId,
				Name: 'Renamed',
				RoomId: 2511,
				CurrencyType: 300,
			})

			await env.DB.prepare('DELETE FROM presence WHERE account_id = 320').run()
		})

		test('POST awardCurrency/bulk credits players, reporting each entry on its own', async () => {
			const coin = (
				await envOf(await create({ ...body, Name: 'Payable', Limit: '10' }, await plusBearer('1')))
			).Value!

			type AwardResult = {
				AccountId: number
				CurrencyId: string
				Success: boolean
				Error: string | null
				Response: {
					AccountId: number
					CurrencyId: string
					Balance: number
					AmountAwarded: number
					AwardedAt: string
				} | null
			}
			const award = async (awards: unknown, headers?: Record<string, string>) =>
				exports.default.fetch(`${ORIGIN}/api/roomcurrencies/v1/awardCurrency/bulk`, {
					method: 'POST',
					headers: { 'Content-Type': 'application/json', ...headers },
					body: JSON.stringify(awards),
				})
			const resultsOf = async (res: Response) => (await res.json()) as AwardResult[]

			const one = [
				{
					CurrencyId: coin.CurrencyId,
					RecipientId: 205,
					Amount: 1,
					TransactionId: '6f523936-7aa8-4660-b02e-cfd388902402',
				},
			]

			// Only the token is answered at the call level.
			expect((await award(one)).status).toBe(401)

			// A caller with no standing in the minting room is refused PER ENTRY, not with a
			// 403 over the whole call — and nothing is awarded.
			const outsider = await award(one, await bearer('999'))
			expect(outsider.status).toBe(200)
			expect(await resultsOf(outsider)).toEqual([
				{
					AccountId: 205,
					CurrencyId: coin.CurrencyId,
					Success: false,
					Error: 'Not permitted',
					Response: null,
				},
			])

			// The owner awards: the result names the entry and carries what the award did.
			const res = await award(one, await plusBearer('1'))
			expect(res.status).toBe(200)
			const results = await resultsOf(res)
			expect(results).toHaveLength(1)
			expect(results[0]).toMatchObject({
				AccountId: 205,
				CurrencyId: coin.CurrencyId,
				Success: true,
				Error: null,
				Response: {
					AccountId: 205,
					CurrencyId: coin.CurrencyId,
					Balance: 1,
					AmountAwarded: 1,
				},
			})
			expect(Date.parse(results[0].Response!.AwardedAt)).not.toBeNaN()
			expect(Object.keys(results[0])).toEqual([
				'AccountId',
				'CurrencyId',
				'Success',
				'Error',
				'Response',
			])
			expect(Object.keys(results[0].Response!)).toEqual([
				'AccountId',
				'CurrencyId',
				'Balance',
				'AmountAwarded',
				'AwardedAt',
			])

			// Awards accumulate, and a co-owner may award too.
			const more = await award(
				[{ CurrencyId: coin.CurrencyId, RecipientId: 205, Amount: 4 }],
				await bearer('2')
			)
			expect((await resultsOf(more))[0].Response).toMatchObject({ Balance: 5, AmountAwarded: 4 })

			// A mixed batch: the good entries land and the bad ones are reported in place, in
			// the order sent, so nothing is lost and nothing is silently skipped.
			const mixed = await award(
				[
					{ CurrencyId: coin.CurrencyId, RecipientId: 206, Amount: 2 },
					{ CurrencyId: 'a3f1e8d2-0000-4000-8000-000000000000', RecipientId: 206, Amount: 5 },
					{ CurrencyId: coin.CurrencyId, RecipientId: 'nope', Amount: 1 },
					{ CurrencyId: coin.CurrencyId, RecipientId: 205, Amount: 1 },
				],
				await plusBearer('1')
			)
			const mixedResults = await resultsOf(mixed)
			expect(mixedResults.map((r) => r.Success)).toEqual([true, false, false, true])
			expect(mixedResults.map((r) => r.Error)).toEqual([
				null,
				'No such currency',
				'Invalid award',
				null,
			])
			expect(mixedResults[0].Response).toMatchObject({ Balance: 2, AmountAwarded: 2 })
			// The two entries for 205 in this batch and the one before it ran in order.
			expect(mixedResults[3].Response).toMatchObject({ Balance: 6, AmountAwarded: 1 })

			// A body that is not a list of awards has no entries to report on.
			for (const bad of [{ CurrencyId: coin.CurrencyId }, 'nope', null]) {
				const res = await award(bad, await plusBearer('1'))
				expect(res.status).toBe(200)
				expect(await resultsOf(res)).toEqual([])
			}
			expect(await resultsOf(await award([], await plusBearer('1')))).toEqual([])

			// getBalance reads back what the awards left, for any player the query names.
			const balance = async (query: string, headers?: Record<string, string>) =>
				exports.default.fetch(`${ORIGIN}/api/roomcurrencies/v1/getBalance?${query}`, { headers })
			expect((await balance(`currencyId=${coin.CurrencyId}&accountId=205`)).status).toBe(401)
			const read = await balance(`currencyId=${coin.CurrencyId}&accountId=205`, await bearer('999'))
			expect(read.status).toBe(200)
			const body205 = (await read.json()) as Record<string, unknown>
			expect(Object.keys(body205)).toEqual(['AccountId', 'CurrencyId', 'Balance', 'ModifiedAt'])
			expect(body205).toMatchObject({ AccountId: 205, CurrencyId: coin.CurrencyId, Balance: 6 })
			expect(Date.parse(body205.ModifiedAt as string)).not.toBeNaN()
			// Never paid, and an unknown currency, are both a balance of 0.
			for (const query of [
				`currencyId=${coin.CurrencyId}&accountId=207`,
				'currencyId=a3f1e8d2-0000-4000-8000-000000000000&accountId=205',
			]) {
				expect(await (await balance(query, await plusBearer('1'))).json()).toMatchObject({
					Balance: 0,
				})
			}
			for (const query of [
				`currencyId=${coin.CurrencyId}`,
				'accountId=205',
				`currencyId=${coin.CurrencyId}&accountId=x`,
			]) {
				expect((await balance(query, await plusBearer('1'))).status).toBe(400)
			}
		})

		test('POST awardCurrency/bulk floors at zero and ignores the Limit', async () => {
			// `Limit` is the most the room may award PER DAY — a faucet rate, not a ceiling on
			// holdings — and nothing tracks a day's awards yet, so it must not bound a balance.
			// It once did, which left every player of a Limit-3 currency stuck at 3 coins.
			const capped = (
				await envOf(await create({ ...body, Name: 'Limited', Limit: '3' }, await plusBearer('1')))
			).Value!
			const award = async (currencyId: string, recipientId: number, amount: number) =>
				(
					(await (
						await exports.default.fetch(`${ORIGIN}/api/roomcurrencies/v1/awardCurrency/bulk`, {
							method: 'POST',
							headers: {
								'Content-Type': 'application/json',
								...(await plusBearer('1')),
							},
							body: JSON.stringify([
								{ CurrencyId: currencyId, RecipientId: recipientId, Amount: amount },
							]),
						})
					).json()) as Array<{ Response: { Balance: number; AmountAwarded: number } }>
				)[0].Response
			const landed = async (currencyId: string, recipientId: number, amount: number) => {
				const { Balance, AmountAwarded } = await award(currencyId, recipientId, amount)
				return { Balance, AmountAwarded }
			}

			// Straight past the `Limit` of 3, and on past it again.
			expect(await landed(capped.CurrencyId, 210, 3)).toEqual({ Balance: 3, AmountAwarded: 3 })
			expect(await landed(capped.CurrencyId, 210, 5)).toEqual({ Balance: 8, AmountAwarded: 5 })
			expect(await landed(capped.CurrencyId, 210, 999)).toEqual({
				Balance: 1007,
				AmountAwarded: 999,
			})

			// Negative deducts, and floors at zero — a player cannot owe a room currency, and
			// `AmountAwarded` reports the part that had somewhere to come from.
			expect(await landed(capped.CurrencyId, 211, 10)).toEqual({ Balance: 10, AmountAwarded: 10 })
			expect(await landed(capped.CurrencyId, 211, -3)).toEqual({ Balance: 7, AmountAwarded: -3 })
			expect(await landed(capped.CurrencyId, 211, -99)).toEqual({ Balance: 0, AmountAwarded: -7 })

			// A `Limit` of 0 is no different from any other — it bounds nothing either way.
			const unlimited = (
				await envOf(await create({ RoomId: '2511', Name: 'Unlimited' }, await plusBearer('1')))
			).Value!
			expect(await landed(unlimited.CurrencyId, 212, 50_000)).toEqual({
				Balance: 50_000,
				AmountAwarded: 50_000,
			})
		})

		test('GET getPurchaseOffersBatch groups each currency’s shop', async () => {
			type Offer = {
				CurrencyPurchaseOfferId: string
				CurrencyId: string
				Order: number
				Name: string
				CurrencyAmount: number
				Price: number
				ModifiedAt: string
			}
			type Group = { CurrencyId: string; PurchaseOffers: Offer[] }
			const groupsFor = async (query: string) =>
				(await (
					await exports.default.fetch(
						`${ORIGIN}/api/roomcurrencies/v1/getPurchaseOffersBatch${query}`
					)
				).json()) as Group[]

			const shopped = (
				await envOf(await create({ ...body, Name: 'Shopped' }, await plusBearer('1')))
			).Value!
			const alsoShopped = (
				await envOf(await create({ ...body, Name: 'AlsoShopped' }, await plusBearer('1')))
			).Value!
			const unshopped = (
				await envOf(await create({ ...body, Name: 'Unshopped' }, await plusBearer('1')))
			).Value!

			// Seeded directly, deliberately out of `Order`, to prove the read sorts them.
			const setOffers = (currencyId: string, offers: unknown[]) =>
				env.DB.prepare('UPDATE room_currency SET purchase_offers = ?2 WHERE currency_id = ?1')
					.bind(currencyId, JSON.stringify(offers))
					.run()

			await setOffers(shopped.CurrencyId, [
				{
					CurrencyPurchaseOfferId: 'ffffffff-0000-4000-8000-000000000002',
					Order: 2,
					Name: 'Handful',
					CurrencyAmount: 5,
					Price: 500,
					ModifiedAt: '2026-09-14T12:00:00Z',
				},
				{
					CurrencyPurchaseOfferId: 'ffffffff-0000-4000-8000-000000000001',
					Order: 1,
					Name: 'Pile',
					CurrencyAmount: 50,
					Price: 4000,
					ModifiedAt: '2026-09-14T12:00:00Z',
				},
			])
			await setOffers(alsoShopped.CurrencyId, [
				{
					CurrencyPurchaseOfferId: 'ffffffff-0000-4000-8000-000000000003',
					Order: 1,
					Name: 'Single',
					CurrencyAmount: 1,
					Price: 100,
					ModifiedAt: '2026-09-14T12:00:00Z',
				},
			])

			// One currency: one group, its shop in `Order` rather than stored order, and
			// `CurrencyId` on every offer projected in from the row that owns it.
			const one = await groupsFor(`?ids=${shopped.CurrencyId}`)
			expect(one).toHaveLength(1)
			expect(Object.keys(one[0])).toEqual(['CurrencyId', 'PurchaseOffers'])
			expect(one[0].CurrencyId).toBe(shopped.CurrencyId)
			expect(one[0].PurchaseOffers.map((o) => o.Name)).toEqual(['Pile', 'Handful'])
			expect(one[0].PurchaseOffers[0]).toEqual({
				CurrencyPurchaseOfferId: 'ffffffff-0000-4000-8000-000000000001',
				CurrencyId: shopped.CurrencyId,
				Order: 1,
				Name: 'Pile',
				CurrencyAmount: 50,
				Price: 4000,
				ModifiedAt: '2026-09-14T12:00:00Z',
			})
			// The client's own model, member for member and in its order.
			expect(Object.keys(one[0].PurchaseOffers[0])).toEqual([
				'CurrencyPurchaseOfferId',
				'CurrencyId',
				'Order',
				'Name',
				'CurrencyAmount',
				'Price',
				'ModifiedAt',
			])

			// Several: a group each, in the order the ids were given. Both spellings of `ids`
			// reach the same answer, and a repeated id is one group.
			for (const query of [
				`?ids=${shopped.CurrencyId},${alsoShopped.CurrencyId}`,
				`?ids=${shopped.CurrencyId}&ids=${alsoShopped.CurrencyId}`,
				`?ids=${shopped.CurrencyId},${alsoShopped.CurrencyId},${shopped.CurrencyId}`,
			]) {
				const groups = await groupsFor(query)
				expect(groups.map((g) => g.CurrencyId)).toEqual([
					shopped.CurrencyId,
					alsoShopped.CurrencyId,
				])
				expect(groups.flatMap((g) => g.PurchaseOffers.map((o) => o.Name))).toEqual([
					'Pile',
					'Handful',
					'Single',
				])
			}
			// Reversing the ids reverses the groups.
			expect(
				(await groupsFor(`?ids=${alsoShopped.CurrencyId},${shopped.CurrencyId}`)).map(
					(g) => g.CurrencyId
				)
			).toEqual([alsoShopped.CurrencyId, shopped.CurrencyId])

			// A currency with no shop still gets a GROUP, with an empty list — "sells nothing"
			// and "you didn't ask about it" are different answers.
			expect(await groupsFor(`?ids=${unshopped.CurrencyId}`)).toEqual([
				{ CurrencyId: unshopped.CurrencyId, PurchaseOffers: [] },
			])

			// An id naming no currency at all is omitted, and doesn't fail the batch it was
			// sent in. No ids is an empty list.
			expect(await groupsFor('?ids=a3f1e8d2-0000-4000-8000-000000000000')).toEqual([])
			expect(await groupsFor('')).toEqual([])
			expect(await groupsFor('?ids=')).toEqual([])
			expect(
				(
					await groupsFor(`?ids=a3f1e8d2-0000-4000-8000-000000000000,${alsoShopped.CurrencyId}`)
				).map((g) => g.CurrencyId)
			).toEqual([alsoShopped.CurrencyId])

			// A column that doesn't parse shows an empty shop rather than failing the call.
			await env.DB.prepare('UPDATE room_currency SET purchase_offers = ?2 WHERE currency_id = ?1')
				.bind(unshopped.CurrencyId, 'not json')
				.run()
			expect(await groupsFor(`?ids=${unshopped.CurrencyId}`)).toEqual([
				{ CurrencyId: unshopped.CurrencyId, PurchaseOffers: [] },
			])
		})

		test('POST deletePurchaseOffer takes one offer out of its shop, gated to the room', async () => {
			type Offer = {
				CurrencyPurchaseOfferId: string
				CurrencyId: string
				Order: number
				Name: string
				CurrencyAmount: number
				Price: number
				ModifiedAt: string
			}
			type Envelope = {
				Value: Offer | null
				Success: boolean
				Error: string | null
				error_id: null
			}
			const post = async (path: string, fields: Record<string, string>, sub: string | null) =>
				exports.default.fetch(`${ORIGIN}${path}`, {
					method: 'POST',
					headers: {
						'Content-Type': 'application/x-www-form-urlencoded',
						...(sub === null ? {} : await plusBearer(sub)),
					},
					body: new URLSearchParams(fields),
				})
			const addOffer = async (currencyId: string, name: string, order: number) =>
				(
					(await (
						await post(
							'/api/roomcurrencies/v1/createPurchaseOffer',
							{
								CurrencyId: currencyId,
								Name: name,
								Amount: '5',
								Price: '50',
								Order: String(order),
							},
							'1'
						)
					).json()) as Envelope
				).Value!
			const remove = (offerId: string, sub: string | null) =>
				post('/api/roomcurrencies/v1/deletePurchaseOffer', { PurchaseOfferId: offerId }, sub)
			const shopOf = async (currencyId: string) =>
				(
					(await (
						await exports.default.fetch(
							`${ORIGIN}/api/roomcurrencies/v1/getPurchaseOffersBatch?ids=${currencyId}`
						)
					).json()) as Array<{ PurchaseOffers: Offer[] }>
				)[0].PurchaseOffers.map((o) => o.Name)
			const refused = {
				Value: null,
				Success: false,
				Error: 'Failed to delete purchase offer',
				error_id: null,
			}

			// Two shops in room 2511, so the delete has to find the right one from the id alone.
			const shopped = (
				await envOf(await create({ ...body, Name: 'Shopped' }, await plusBearer('1')))
			).Value!
			const other = (await envOf(await create({ ...body, Name: 'Other' }, await plusBearer('1'))))
				.Value!
			const first = await addOffer(shopped.CurrencyId, 'First', 0)
			const second = await addOffer(shopped.CurrencyId, 'Second', 1)
			const third = await addOffer(shopped.CurrencyId, 'Third', 2)
			const elsewhere = await addOffer(other.CurrencyId, 'Elsewhere', 0)

			// No token → 401; a valid token with no standing in the room → 403, and the offer
			// stays. An id no shop lists, or none at all, is a refusal in the envelope.
			expect((await remove(second.CurrencyPurchaseOfferId, null)).status).toBe(401)
			expect((await remove(second.CurrencyPurchaseOfferId, '999')).status).toBe(403)
			expect(await shopOf(shopped.CurrencyId)).toEqual(['First', 'Second', 'Third'])
			for (const id of [crypto.randomUUID(), '']) {
				const res = await remove(id, '1')
				expect(res.status).toBe(200)
				expect(await res.json()).toEqual(refused)
			}

			// The co-owner removes the middle one: the answer is the offer as it stood, the
			// shop keeps its neighbours in order, and the other currency's shop is untouched.
			const res = await remove(second.CurrencyPurchaseOfferId, '2')
			expect(res.status).toBe(200)
			expect(await res.json()).toEqual({
				Value: second,
				Success: true,
				Error: null,
				error_id: null,
			})
			expect(await shopOf(shopped.CurrencyId)).toEqual(['First', 'Third'])
			expect(await shopOf(other.CurrencyId)).toEqual(['Elsewhere'])
			// What is left is still what the create wrote, not a re-encoding of it.
			expect(
				(await (
					await exports.default.fetch(
						`${ORIGIN}/api/roomcurrencies/v1/getPurchaseOffersBatch?ids=${shopped.CurrencyId}`
					)
				).json()) as Array<{ PurchaseOffers: Offer[] }>
			).toEqual([{ CurrencyId: shopped.CurrencyId, PurchaseOffers: [first, third] }])

			// Gone means gone: a second delete is the unknown-id refusal. The id matches in any
			// letter case, like the purchase's lookup.
			expect(await (await remove(second.CurrencyPurchaseOfferId, '1')).json()).toEqual(refused)
			expect(
				(
					(await (
						await remove(third.CurrencyPurchaseOfferId.toUpperCase(), '1')
					).json()) as Envelope
				).Value?.Name
			).toBe('Third')
			// Emptying a shop leaves it an empty shop, still listed.
			await remove(first.CurrencyPurchaseOfferId, '1')
			expect(await shopOf(shopped.CurrencyId)).toEqual([])
			expect(await shopOf(other.CurrencyId)).toEqual(['Elsewhere'])
			expect(elsewhere.Name).toBe('Elsewhere')
		})

		test('POST createCurrency pushes RoomCurrencyCreated to the room and the creator', async () => {
			// Two players standing in 2511, one somewhere else, and one whose presence lapsed.
			const now = Math.floor(Date.now() / 1000)
			const putInRoom = async (accountId: number, roomId: number, expired = false) =>
				env.DB.prepare('INSERT OR REPLACE INTO presence (data) VALUES (?1)')
					.bind(
						JSON.stringify({
							accountId,
							roomInstance: { roomInstanceId: 1000000 + roomId, roomId, subRoomId: roomId },
							expiresAt: expired ? now - 1 : now + 900,
						})
					)
					.run()
			await putInRoom(310, 2511)
			await putInRoom(311, 2511)
			await putInRoom(312, 1)
			await putInRoom(313, 2511, true)
			await drainFrames()

			// Account 1 owns the room but is NOT standing in it — the settings UI opens from
			// anywhere, so the creator is added to the audience separately.
			const res = await create({ ...body, Name: 'Broadcast bucks' }, await plusBearer('1'))
			expect(res.status).toBe(200)
			const created = (await envOf(res)).Value!

			const frames = await drainFrames()
			expect(frames.map((f) => f.accountId).sort((a, b) => a - b)).toEqual([1, 310, 311])
			expect(frames.every((f) => f.notificationType === NotificationType.RoomCurrencyCreated)).toBe(
				true
			)
			// The frame IS the create response — same object, same member order, so the two
			// cannot drift apart.
			expect(Object.keys(frames[0].payload)).toEqual(Object.keys(created))
			expect(frames[0].payload).toEqual({
				CurrencyId: created.CurrencyId,
				RoomId: 2511,
				Name: 'Broadcast bucks',
				Description: 'this is my currency',
				CurrencyType: 300,
				Limit: 100,
				ImageName: null,
				CreatedAt: created.CreatedAt,
				ModifiedAt: created.ModifiedAt,
				Shape: 0,
				Color: 19,
			})

			for (const id of [310, 311, 312, 313]) {
				await env.DB.prepare('DELETE FROM presence WHERE account_id = ?1').bind(id).run()
			}
		})

		test('POST createCurrency masks a name players will see, and defaults the rest', async () => {
			const res = await create({ RoomId: '2511', Name: 'shit bucks' }, await plusBearer('1'))
			expect(res.status).toBe(200)
			const created = (await envOf(res)).Value!
			// Masked per character like every other player-typed string (see the gift message
			// above) — a currency's name is shown to everyone who walks into the room.
			expect(created.Name).toBe('**** bucks')
			// Everything the body left out falls back rather than landing as NaN.
			expect(created).toMatchObject({ Description: '', Limit: 0, Shape: 0, Color: 0 })
		})

		test('POST createCurrency keeps a negative Color and a large Limit', async () => {
			// `Color` is signed — the client sends -1 for "no colour chosen" — and `Limit` is a
			// long. Neither may be clamped or dropped on the way through.
			const res = await create(
				{ RoomId: '2511', Name: 'Uncoloured', Limit: '1000000', Color: '-1' },
				await plusBearer('1')
			)
			expect(res.status).toBe(200)
			expect((await envOf(res)).Value).toMatchObject({ Limit: 1000000, Color: -1 })
		})

		test('POST roomCurrencies/v2/purchase sells an offer’s currency for tokens, paying the owner', async () => {
			const form = async (path: string, fields: Record<string, string>, sub: string | null) =>
				exports.default.fetch(`${ORIGIN}${path}`, {
					method: 'POST',
					headers: {
						'Content-Type': 'application/x-www-form-urlencoded',
						...(sub === null ? {} : await plusBearer(sub)),
					},
					body: new URLSearchParams(fields),
				})
			const purchase = async (sub: string | null, offerId: string, amount: number, price: number) =>
				form(
					'/api/roomCurrencies/v2/purchase',
					{
						PurchaseOfferId: offerId,
						RequestedAmount: String(amount),
						RequestedPrice: String(price),
					},
					sub
				)
			const addOffer = async (currencyId: string, amount: number, price: number) =>
				(
					(await (
						await form(
							'/api/roomcurrencies/v1/createPurchaseOffer',
							{
								CurrencyId: currencyId,
								Name: 'pack',
								Amount: String(amount),
								Price: String(price),
							},
							'1'
						)
					).json()) as { Value: { CurrencyPurchaseOfferId: string } }
				).Value.CurrencyPurchaseOfferId
			const setTokens = (accountId: number, amount: number) =>
				env.DB.prepare(
					'INSERT OR REPLACE INTO balance (account_id, currency_type, amount) VALUES (?1, 2, ?2)'
				)
					.bind(accountId, amount)
					.run()
			const tokens = async (accountId: number) =>
				(
					await env.DB.prepare(
						'SELECT amount FROM balance WHERE account_id = ?1 AND currency_type = 2'
					)
						.bind(accountId)
						.first<{ amount: number }>()
				)?.amount
			const held = async (currencyId: string, playerId: number) =>
				(
					await env.DB.prepare(
						'SELECT amount FROM room_balance WHERE currency_id = ?1 AND player_id = ?2'
					)
						.bind(currencyId, playerId)
						.first<{ amount: number }>()
				)?.amount ?? 0
			const refused = (error: string) => ({
				Value: null,
				Success: false,
				Error: error,
				error_id: null,
			})

			// Two currencies in room 2511 (account 1's), so the offer has to pick the right one.
			const other = (await envOf(await create({ ...body, Name: 'Other' }, await plusBearer('1'))))
				.Value!
			const sold = (await envOf(await create({ ...body, Name: 'Sold' }, await plusBearer('1'))))
				.Value!
			await addOffer(other.CurrencyId, 444, 1)
			const offerId = await addOffer(sold.CurrencyId, 444, 555)
			const freeOfferId = await addOffer(sold.CurrencyId, 5, 0)
			await setTokens(1, 1000)
			await setTokens(7401, 600)
			await setTokens(7402, 100)
			await drainFrames()

			expect((await purchase(null, offerId, 444, 555)).status).toBe(401)

			// Refusals: an unknown offer, numbers that are not the offer's, too few tokens.
			const cases: Array<[Response, string]> = [
				[await purchase('7401', crypto.randomUUID(), 444, 555), 'No such purchase offer'],
				[await purchase('7401', '', 444, 555), 'No such purchase offer'],
				[await purchase('7401', offerId, 445, 555), 'Requested amount does not match'],
				[await purchase('7401', offerId, 444, 554), 'Requested price does not match'],
				[await purchase('7401', offerId, 444, 0), 'Requested price does not match'],
				[await purchase('7402', offerId, 444, 555), 'Not enough tokens'],
			]
			for (const [res, error] of cases) {
				expect(res.status).toBe(200)
				expect(await res.json()).toEqual(refused(error))
			}
			expect([await tokens(1), await tokens(7401), await tokens(7402)]).toEqual([1000, 600, 100])
			expect(await held(sold.CurrencyId, 7401)).toBe(0)
			expect(await drainFrames()).toEqual([])

			// The sale, exactly as the client posts it: 555 tokens for 444 of the offer's currency.
			const res = await purchase('7401', offerId, 444, 555)
			expect(res.status).toBe(200)
			expect(await res.json()).toEqual({
				Value: {
					CurrencyBalanceResponse: {
						AccountId: 7401,
						CurrencyId: sold.CurrencyId,
						Balance: 444,
						ModifiedAt: expect.any(String),
					},
					TokenBalanceResponse: { Balance: 45, CurrencyType: 2, Platform: -2 },
				},
				Success: true,
				Error: null,
				error_id: null,
			})
			expect([await tokens(1), await tokens(7401)]).toEqual([1555, 45])
			expect(await held(sold.CurrencyId, 7401)).toBe(444)
			expect(await held(other.CurrencyId, 7401)).toBe(0)
			// Both hear their RESULTING token total, in the account-wide bucket.
			const frames = await drainFrames()
			expect(frames.find((f) => f.accountId === 1)?.payload).toEqual({
				Balance: 1555,
				CurrencyType: 2,
				Platform: -2,
			})
			expect(frames.find((f) => f.accountId === 7401)?.payload).toMatchObject({
				Delta: -555,
				Balance: 45,
				Platform: -2,
			})

			// A second purchase needs the tokens again; the holding is left where it was.
			expect(await (await purchase('7401', offerId, 444, 555)).json()).toEqual(
				refused('Not enough tokens')
			)
			expect(await held(sold.CurrencyId, 7401)).toBe(444)

			// A free offer, and the owner buying from their own shop, move no tokens.
			const gratis = (await (await purchase('7402', freeOfferId, 5, 0)).json()) as {
				Value: {
					CurrencyBalanceResponse: { Balance: number }
					TokenBalanceResponse: { Balance: number }
				}
			}
			expect(gratis.Value.CurrencyBalanceResponse.Balance).toBe(5)
			expect(gratis.Value.TokenBalanceResponse.Balance).toBe(100)
			const own = (await (await purchase('1', offerId, 444, 555)).json()) as typeof gratis
			expect(own.Value.CurrencyBalanceResponse.Balance).toBe(444)
			expect(own.Value.TokenBalanceResponse.Balance).toBe(1555)
			expect([await tokens(1), await tokens(7402)]).toEqual([1555, 100])
			expect(await drainFrames()).toEqual([])

			// A co-owner (account 2 on room 2511) takes from the shop for free too. The client
			// shows them the offer at no cost and posts `RequestedPrice=0` — which a stranger
			// is refused for above — so their price is not checked: 0 and the real one both go
			// through, nobody is charged, the owner is not paid, and no frame is sent.
			await setTokens(2, 50)
			const coOwner = (await (await purchase('2', offerId, 444, 0)).json()) as typeof gratis
			expect(coOwner.Value.CurrencyBalanceResponse.Balance).toBe(444)
			expect(coOwner.Value.TokenBalanceResponse.Balance).toBe(50)
			const coOwnerAgain = (await (await purchase('2', offerId, 444, 555)).json()) as typeof gratis
			expect(coOwnerAgain.Value.CurrencyBalanceResponse.Balance).toBe(888)
			expect(coOwnerAgain.Value.TokenBalanceResponse.Balance).toBe(50)
			// The amount still has to be the offer's, manager or not.
			expect(await (await purchase('2', offerId, 1, 0)).json()).toEqual(
				refused('Requested amount does not match')
			)
			expect([await tokens(1), await tokens(2)]).toEqual([1555, 50])
			expect(await drainFrames()).toEqual([])

			await env.DB.prepare('DELETE FROM room_balance WHERE currency_id IN (?1, ?2)')
				.bind(sold.CurrencyId, other.CurrencyId)
				.run()
			await env.DB.prepare('DELETE FROM room_currency WHERE currency_id IN (?1, ?2)')
				.bind(sold.CurrencyId, other.CurrencyId)
				.run()
		})
	})

	// Room 2511 is seeded as account 1's, with account 2 as co-owner.
	describe('room keys', () => {
		type RoomKey = {
			RoomKeyId: number
			ReplicationId: string
			RoomId: number
			Name: string
			Description: string
			Price: number
			PurchaseCurrencyId: string | null
			CreatedAt: string
			ImageName: string | null
			Type: number
		}

		const create = async (fields: Record<string, string>, headers?: Record<string, string>) =>
			exports.default.fetch(`${ORIGIN}/api/roomkeys/v1/create`, {
				method: 'POST',
				headers: { 'Content-Type': 'application/x-www-form-urlencoded', ...headers },
				body: new URLSearchParams(fields),
			})

		const drainFrames = async (): Promise<
			Array<{
				accountId: number
				notificationType: string | number
				payload: Record<string, unknown>
			}>
		> =>
			(
				env.RECFLARE_NOTIFICATIONS_HUB.getByName('global') as unknown as {
					drainFrames(): Promise<
						Array<{
							accountId: number
							notificationType: string | number
							payload: Record<string, unknown>
						}>
					>
				}
			).drainFrames()

		// The create's reply, as the live client reads it — NOT the `{ Value, Success, Error,
		// error_id }` envelope the currency and consumable writes answer in.
		const envOf = async (res: Response) =>
			(await res.json()) as {
				Status: number
				RoomKey: RoomKey | null
			}
		const keyOf = async (res: Response) => (await envOf(res)).RoomKey!

		const keysOf = async (roomId: number) =>
			(await (
				await exports.default.fetch(`${ORIGIN}/api/roomkeys/v1/room?roomId=${roomId}`)
			).json()) as RoomKey[]

		// The body exactly as the client posts it.
		const body = {
			Type: 'Key',
			RoomId: '2511',
			Name: 'my key',
			Description: 'testsdfsdfsdf',
			Price: '50',
		}

		test('GET /api/roomkeys/v1/room is public and empty for a room with none', async () => {
			expect(await keysOf(2511)).toEqual([])
			expect(await keysOf(99999)).toEqual([])
			const res = await exports.default.fetch(`${ORIGIN}/api/roomkeys/v1/room`)
			expect(res.status).toBe(200)
			expect(await res.json()).toEqual([])
		})

		test('POST create is gated to the room’s creator or a co-owner', async () => {
			expect((await create(body)).status).toBe(401)
			expect((await create(body, await bearer('999'))).status).toBe(403)

			for (const bad of [
				{ ...body, RoomId: '99999' },
				{ ...body, RoomId: 'nope' },
				{ ...body, Name: '  ' },
			]) {
				const res = await create(bad, await plusBearer('1'))
				expect(res.status).toBe(200)
				expect(await envOf(res)).toEqual({ Status: 1, RoomKey: null })
			}
			expect(await keysOf(2511)).toEqual([])
		})

		test('POST create lists the key and the room read serves it back', async () => {
			const res = await create(body, await plusBearer('1'))
			expect(res.status).toBe(200)
			const envelope = await envOf(res)
			expect(Object.keys(envelope)).toEqual(['Status', 'RoomKey'])
			expect(envelope.Status).toBe(0)
			const created = envelope.RoomKey!
			// The key as the live client reads it, member for member and in its order.
			expect(Object.keys(created)).toEqual([
				'RoomKeyId',
				'ReplicationId',
				'RoomId',
				'Name',
				'Description',
				'Price',
				'PurchaseCurrencyId',
				'CreatedAt',
				'ImageName',
				'Type',
			])
			expect(created).toMatchObject({
				RoomId: 2511,
				Name: 'my key',
				Description: 'testsdfsdfsdf',
				Price: 50,
				PurchaseCurrencyId: null,
				// Null, not '', until a key carries art.
				ImageName: null,
				// The posted enum NAME (`Key`) comes back as its ordinal.
				Type: 0,
			})
			// A NUMERIC id, with a GUID beside it.
			expect(Number.isInteger(created.RoomKeyId)).toBe(true)
			expect(created.ReplicationId).toMatch(/^[0-9a-f-]{36}$/)
			expect(new Date(created.CreatedAt).toISOString()).toBe(created.CreatedAt)

			// The body's Type is stored as the name it arrived as.
			const row = await env.DB.prepare('SELECT key_type FROM room_key WHERE room_key_id = ?1')
				.bind(created.RoomKeyId)
				.first<{ key_type: string }>()
			expect(row?.key_type).toBe('Key')

			expect(await keysOf(2511)).toEqual([created])

			// A co-owner may list one too, and the list is oldest first.
			const second = await keyOf(await create({ ...body, Name: 'second' }, await plusBearer('2')))
			expect(second.RoomKeyId).toBeGreaterThan(created.RoomKeyId)
			expect((await keysOf(2511)).map((k) => k.Name)).toEqual(['my key', 'second'])
		})

		test('POST create pushes LocalRoomKeyCreated to the room and the creator', async () => {
			const now = Math.floor(Date.now() / 1000)
			const putInRoom = async (accountId: number, roomId: number) =>
				env.DB.prepare('INSERT OR REPLACE INTO presence (data) VALUES (?1)')
					.bind(
						JSON.stringify({
							accountId,
							roomInstance: { roomInstanceId: 1000000 + roomId, roomId, subRoomId: roomId },
							expiresAt: now + 900,
						})
					)
					.run()
			await putInRoom(320, 2511)
			await putInRoom(321, 1)
			await drainFrames()

			const created = await keyOf(await create({ ...body, Name: 'pushed' }, await plusBearer('1')))
			const frames = await drainFrames()
			expect(frames.map((f) => f.accountId).sort((a, b) => a - b)).toEqual([1, 320])
			expect(frames.every((f) => f.notificationType === NotificationType.LocalRoomKeyCreated)).toBe(
				true
			)
			// The frame IS the create response.
			expect(frames[0].payload).toEqual(created)

			for (const id of [320, 321]) {
				await env.DB.prepare('DELETE FROM presence WHERE account_id = ?1').bind(id).run()
			}
		})

		test('POST create masks a name players will see, and defaults the rest', async () => {
			const res = await create({ RoomId: '2511', Name: 'shit key' }, await plusBearer('1'))
			const created = await keyOf(res)
			expect(created.Name).toBe('**** key')
			expect(created).toMatchObject({ Description: '', Price: 0, Type: 0 })
			const row = await env.DB.prepare('SELECT key_type FROM room_key WHERE room_key_id = ?1')
				.bind(created.RoomKeyId)
				.first<{ key_type: string }>()
			expect(row?.key_type).toBe('Key')
			// A negative price is floored at nothing.
			const free = await keyOf(await create({ ...body, Price: '-5' }, await plusBearer('1')))
			expect(free.Price).toBe(0)
		})

		test('POST awardbulk records the CALLER as holding each key, reporting each entry', async () => {
			const award = async (payload: unknown, headers?: Record<string, string>) =>
				exports.default.fetch(`${ORIGIN}/api/roomkeys/v1/awardbulk`, {
					method: 'POST',
					headers: { 'Content-Type': 'application/json', ...headers },
					body: JSON.stringify(payload),
				})
			const held = async () =>
				(
					await env.DB.prepare(
						'SELECT room_key_id, account_id, awarded_at FROM room_key_player ORDER BY room_key_id'
					).all<{ room_key_id: number; account_id: number; awarded_at: string }>()
				).results

			const key = await keyOf(await create({ ...body, Name: 'awarded' }, await plusBearer('1')))
			const id = key.RoomKeyId

			// Auth-gated.
			expect((await award([{ RoomKeyId: id, AccountId: 42 }])).status).toBe(401)
			expect(await held()).toEqual([])

			// The body exactly as the client posts it. The token's player gets the key —
			// the body's `AccountId` is ignored, even when it names someone else.
			const res = await award(
				[
					{ RoomKeyId: id, AccountId: 205 },
					{ RoomKeyId: 999999, AccountId: 205 },
					{ AccountId: 205 },
				],
				await bearer('42')
			)
			expect(res.status).toBe(200)
			// An array of envelopes, one per entry — `error_id` lowercase beside the rest.
			const awarded = {
				Value: { RoomKeyId: id, AccountId: 42 },
				Success: true,
				Error: null,
				error_id: null,
			}
			expect(await res.json()).toEqual([
				awarded,
				{ Value: null, Success: false, Error: 'No such room key', error_id: null },
				{ Value: null, Success: false, Error: 'Invalid room key', error_id: null },
			])
			const rows = await held()
			expect(rows).toEqual([{ room_key_id: id, account_id: 42, awarded_at: expect.any(String) }])

			// Held once: a repeat award succeeds and leaves the row as it was.
			const again = await award([{ RoomKeyId: id, AccountId: 42 }], await bearer('42'))
			expect(await again.json()).toEqual([awarded])
			expect(await held()).toEqual(rows)

			// Another player holds their own copy; a body that is no list has no entries.
			await award([{ RoomKeyId: id }], await bearer('43'))
			expect((await held()).map((r) => r.account_id).sort()).toEqual([42, 43])
			expect(await (await award({ RoomKeyId: id }, await bearer('42'))).json()).toEqual([])

			await env.DB.prepare('DELETE FROM room_key_player').run()
			await env.DB.prepare('DELETE FROM room_key').run()
		})

		test('POST owns/bulk answers each (player, key) pair, reading the body’s AccountId', async () => {
			const post = async (path: string, payload: unknown, headers?: Record<string, string>) =>
				exports.default.fetch(`${ORIGIN}/api/roomkeys/v1/${path}`, {
					method: 'POST',
					headers: { 'Content-Type': 'application/json', ...headers },
					body: JSON.stringify(payload),
				})

			const key = await keyOf(await create({ ...body, Name: 'held' }, await plusBearer('1')))
			const id = key.RoomKeyId
			await post('awardbulk', [{ RoomKeyId: id, AccountId: 42 }], await bearer('42'))

			// Auth-gated.
			expect((await post('owns/bulk', [{ AccountId: 42, RoomKeyId: id }])).status).toBe(401)

			// Asked by 43 about 42 and others: the body's player is the one checked. A bare
			// array back, in the order posted; the malformed entry is skipped.
			const res = await post(
				'owns/bulk',
				[
					{ AccountId: 42, RoomKeyId: id },
					{ AccountId: 43, RoomKeyId: id },
					{ AccountId: 42, RoomKeyId: 999999 },
					{ AccountId: 42 },
				],
				await bearer('43')
			)
			expect(res.status).toBe(200)
			expect(await res.json()).toEqual([
				{ AccountId: 42, RoomKeyId: id, DoesPlayerOwnRoomKey: true },
				{ AccountId: 43, RoomKeyId: id, DoesPlayerOwnRoomKey: false },
				{ AccountId: 42, RoomKeyId: 999999, DoesPlayerOwnRoomKey: false },
			])

			// Nothing to ask is nothing to answer.
			expect(await (await post('owns/bulk', [], await bearer('43'))).json()).toEqual([])
			expect(await (await post('owns/bulk', {}, await bearer('43'))).json()).toEqual([])

			await env.DB.prepare('DELETE FROM room_key_player').run()
			await env.DB.prepare('DELETE FROM room_key').run()
		})

		test('POST create refuses the eleventh key in a room', async () => {
			// MaxKeysPerRoom is 10 (apps/api/static/api-config-v2.json). Fill up to it…
			while ((await keysOf(2511)).length < 10) {
				const res = await create({ ...body, Name: 'filler' }, await plusBearer('1'))
				expect((await envOf(res)).Status).toBe(0)
			}
			// …and the next is refused, leaving the room at ten.
			const res = await create({ ...body, Name: 'one too many' }, await plusBearer('1'))
			expect(res.status).toBe(200)
			expect(await envOf(res)).toEqual({ Status: 1, RoomKey: null })
			expect((await keysOf(2511)).length).toBe(10)
			await env.DB.prepare('DELETE FROM room_key').run()
		})

		test('POST create refuses a token price over 1000', async () => {
			const atCap = await create({ ...body, Price: '1000' }, await plusBearer('1'))
			expect((await envOf(atCap)).Status).toBe(0)
			const over = await create({ ...body, Price: '1001' }, await plusBearer('1'))
			expect(await envOf(over)).toEqual({ Status: 1, RoomKey: null })
			await env.DB.prepare('DELETE FROM room_key').run()
		})

		test('PUT updateAll edits one key, capping the price by its currency', async () => {
			const update = async (fields: Record<string, string>, headers?: Record<string, string>) =>
				exports.default.fetch(`${ORIGIN}/api/roomkeys/v1/updateAll`, {
					method: 'PUT',
					headers: { 'Content-Type': 'application/x-www-form-urlencoded', ...headers },
					body: new URLSearchParams(fields),
				})
			const mint = async (roomId: string, as: string) =>
				(
					(await (
						await exports.default.fetch(`${ORIGIN}/api/roomcurrencies/v1/createCurrency`, {
							method: 'POST',
							headers: {
								'Content-Type': 'application/x-www-form-urlencoded',
								...(await bearer(as)),
							},
							body: new URLSearchParams({ RoomId: roomId, Name: 'coin' }),
						})
					).json()) as { Value: { CurrencyId: string } }
				).Value.CurrencyId

			const key = await keyOf(await create(body, await plusBearer('1')))
			const other = await keyOf(await create({ ...body, Name: 'other' }, await plusBearer('1')))
			const id = String(key.RoomKeyId)
			// The body exactly as the client puts it.
			const edit = {
				RoomKeyId: id,
				Name: 'key1',
				Description: 'testssdfsdfsdf',
				Price: '1000',
				PurchaseCurrencyId: '',
			}
			const refused = { Status: 1, RoomKey: null }

			expect((await update(edit)).status).toBe(401)
			expect((await update(edit, await bearer('42'))).status).toBe(403)

			// In tokens: 1000 passes, 1001 does not. A co-owner may edit.
			const res = await update(edit, await plusBearer('2'))
			expect(res.status).toBe(200)
			expect(await envOf(res)).toEqual({
				Status: 0,
				RoomKey: { ...key, Name: 'key1', Description: 'testssdfsdfsdf', Price: 1000 },
			})
			expect(await envOf(await update({ ...edit, Price: '1001' }, await plusBearer('1')))).toEqual(
				refused
			)

			// In the room's own currency the cap is a billion.
			const currencyId = await mint('2511', '1')
			const rich = { ...edit, Price: '1000000000', PurchaseCurrencyId: currencyId }
			expect((await envOf(await update(rich, await plusBearer('1')))).RoomKey).toMatchObject({
				Price: 1000000000,
				PurchaseCurrencyId: currencyId,
			})
			expect(
				await envOf(await update({ ...rich, Price: '1000000001' }, await plusBearer('1')))
			).toEqual(refused)
			// Back to tokens with the big price still on it: the token cap applies again.
			expect(
				await envOf(await update({ RoomKeyId: id, PurchaseCurrencyId: '' }, await plusBearer('1')))
			).toEqual(refused)

			// Refusals: no such key, a blank name, an unknown currency.
			for (const bad of [
				{ ...edit, RoomKeyId: '999999' },
				{ ...edit, Name: '  ' },
				{ ...edit, PurchaseCurrencyId: '46eddc63-e6d4-42cc-bf04-5d879e33ac17' },
			]) {
				expect(await envOf(await update(bad, await plusBearer('1')))).toEqual(refused)
			}

			// Only the named key moved, and the refused edits left it as the last good one.
			expect(await keysOf(2511)).toEqual([
				{
					...key,
					Name: 'key1',
					Description: 'testssdfsdfsdf',
					Price: 1000000000,
					PurchaseCurrencyId: currencyId,
				},
				other,
			])

			await env.DB.prepare('DELETE FROM room_key').run()
			await env.DB.prepare('DELETE FROM room_currency WHERE currency_id = ?1')
				.bind(currencyId)
				.run()
		})

		test('PUT updateAll: a BLANK PurchaseCurrencyId or ImageName clears it; an absent one is left alone', async () => {
			const update = async (fields: Record<string, string>) =>
				envOf(
					await exports.default.fetch(`${ORIGIN}/api/roomkeys/v1/updateAll`, {
						method: 'PUT',
						headers: {
							'Content-Type': 'application/x-www-form-urlencoded',
							...(await plusBearer('1')),
						},
						body: new URLSearchParams(fields),
					})
				)
			const stored = async (roomKeyId: number) =>
				env.DB.prepare(
					'SELECT purchase_currency_id, image_name FROM room_key WHERE room_key_id = ?1'
				)
					.bind(roomKeyId)
					.first<{ purchase_currency_id: string | null; image_name: string }>()

			const currencyId = (
				(await (
					await exports.default.fetch(`${ORIGIN}/api/roomcurrencies/v1/createCurrency`, {
						method: 'POST',
						headers: {
							'Content-Type': 'application/x-www-form-urlencoded',
							...(await plusBearer('1')),
						},
						body: new URLSearchParams({ RoomId: '2511', Name: 'coin' }),
					})
				).json()) as { Value: { CurrencyId: string } }
			).Value.CurrencyId

			const key = await keyOf(await create(body, await plusBearer('1')))
			const id = String(key.RoomKeyId)
			expect(key).toMatchObject({ PurchaseCurrencyId: null, ImageName: null })

			// Put the key on the room's currency and give it art.
			const set = await update({
				RoomKeyId: id,
				PurchaseCurrencyId: currencyId,
				ImageName: 'key.png',
			})
			expect(set.RoomKey).toMatchObject({ PurchaseCurrencyId: currencyId, ImageName: 'key.png' })
			expect(await stored(key.RoomKeyId)).toEqual({
				purchase_currency_id: currencyId,
				image_name: 'key.png',
			})

			// An edit that mentions neither leaves both alone.
			const renamed = await update({ RoomKeyId: id, Name: 'renamed' })
			expect(renamed.RoomKey).toMatchObject({
				Name: 'renamed',
				PurchaseCurrencyId: currencyId,
				ImageName: 'key.png',
			})

			// Blank clears the currency — NULL in the row, null on the wire — and nothing else.
			const noCurrency = await update({ RoomKeyId: id, PurchaseCurrencyId: '' })
			expect(noCurrency.RoomKey).toMatchObject({ PurchaseCurrencyId: null, ImageName: 'key.png' })
			expect(await stored(key.RoomKeyId)).toEqual({
				purchase_currency_id: null,
				image_name: 'key.png',
			})

			// Blank clears the art: '' in the row, served as null. The list read agrees.
			const noArt = await update({ RoomKeyId: id, ImageName: '' })
			expect(noArt.RoomKey).toMatchObject({ PurchaseCurrencyId: null, ImageName: null })
			expect(await stored(key.RoomKeyId)).toEqual({ purchase_currency_id: null, image_name: '' })
			expect(await keysOf(2511)).toEqual([noArt.RoomKey])

			await env.DB.prepare('DELETE FROM room_key').run()
			await env.DB.prepare('DELETE FROM room_currency WHERE currency_id = ?1')
				.bind(currencyId)
				.run()
		})

		test('GET buyRoomKey moves the key’s price from the buyer to the room’s owner', async () => {
			const buy = async (sub: string | null, roomKeyId: number | string, price?: number) =>
				exports.default.fetch(
					`${ORIGIN}/api/storefronts/v1/buyRoomKey?RoomKeyId=${roomKeyId}` +
						(price === undefined ? '' : `&RequestedPrice=${price}`),
					sub === null ? undefined : { headers: await plusBearer(sub) }
				)
			const setTokens = (accountId: number, amount: number) =>
				env.DB.prepare(
					'INSERT OR REPLACE INTO balance (account_id, currency_type, amount) VALUES (?1, 2, ?2)'
				)
					.bind(accountId, amount)
					.run()
			const tokens = async (accountId: number) =>
				(
					await env.DB.prepare(
						'SELECT amount FROM balance WHERE account_id = ?1 AND currency_type = 2'
					)
						.bind(accountId)
						.first<{ amount: number }>()
				)?.amount
			const holders = async (roomKeyId: number) =>
				(
					await env.DB.prepare(
						'SELECT account_id FROM room_key_player WHERE room_key_id = ?1 ORDER BY account_id'
					)
						.bind(roomKeyId)
						.all<{ account_id: number }>()
				).results.map((r) => r.account_id)
			// A refusal: the same shape, nothing sold, the balance as it stood.
			const refused = (code: number, data: RoomKey | null, balance: number) => ({
				RoomKeyResponse: { Status: 1, RoomKey: null },
				BalanceUpdateResponse: {
					BalanceUpdates: [{ UpdateResponse: code, Data: data }],
					Balance: balance,
					CurrencyType: 2,
					Platform: -2,
				},
			})

			// Room 2511 is account 1's. A 300-token key, and a free one.
			const key = await keyOf(await create({ ...body, Price: '300' }, await plusBearer('1')))
			const free = await keyOf(
				await create({ ...body, Name: 'free', Price: '0' }, await plusBearer('1'))
			)
			await setTokens(1, 1000)
			await setTokens(7301, 500)
			await setTokens(7302, 100)
			await drainFrames()

			expect((await buy(null, key.RoomKeyId, 300)).status).toBe(401)

			// The price must match — `RequestedPrice=0`, or none, does not buy a priced key.
			for (const wrong of [0, 299, undefined]) {
				const res = await buy('7301', key.RoomKeyId, wrong)
				expect(res.status).toBe(200)
				expect(await res.json()).toEqual(refused(6, key, 500))
			}
			// No such key; not enough tokens.
			expect(await (await buy('7301', 999999, 300)).json()).toEqual(refused(4, null, 500))
			expect(await (await buy('7301', 'abc', 300)).json()).toEqual(refused(4, null, 500))
			expect(await (await buy('7302', key.RoomKeyId, 300)).json()).toEqual(refused(2, key, 100))
			expect(await holders(key.RoomKeyId)).toEqual([])
			expect([await tokens(1), await tokens(7301), await tokens(7302)]).toEqual([1000, 500, 100])
			expect(await drainFrames()).toEqual([])

			// The sale: 300 leaves the buyer, reaches the owner, and the buyer holds the key.
			const sold = await buy('7301', key.RoomKeyId, 300)
			expect(sold.status).toBe(200)
			const soldBody = (await sold.json()) as {
				BalanceUpdateResponse: Record<string, unknown>
			}
			expect(soldBody).toEqual({
				RoomKeyResponse: { Status: 0, RoomKey: key },
				BalanceUpdateResponse: {
					BalanceUpdates: [{ UpdateResponse: 0, Data: key }],
					Balance: 200,
					CurrencyType: 2,
					Platform: -2,
				},
			})
			// Derived-first key order, as the client's formatter runs it.
			expect(Object.keys(soldBody.BalanceUpdateResponse)).toEqual([
				'BalanceUpdates',
				'Balance',
				'CurrencyType',
				'Platform',
			])
			expect(await holders(key.RoomKeyId)).toEqual([7301])
			expect([await tokens(1), await tokens(7301)]).toEqual([1300, 200])
			// Both hear their RESULTING total, in the account-wide bucket.
			const frames = await drainFrames()
			expect(frames.find((f) => f.accountId === 1)?.payload).toEqual({
				Balance: 1300,
				CurrencyType: 2,
				Platform: -2,
			})
			expect(frames.find((f) => f.accountId === 7301)?.payload).toMatchObject({
				Delta: -300,
				Balance: 200,
				Platform: -2,
			})

			// Held once: buying it again is refused and charges nothing.
			expect(await (await buy('7301', key.RoomKeyId, 300)).json()).toEqual(refused(3, key, 200))
			expect([await tokens(1), await tokens(7301)]).toEqual([1300, 200])

			// A free key moves nothing; nor does a room manager buying their own room's key —
			// the owner at the stored price, or a co-owner at the 0 the client asks them.
			const gratis = (await (await buy('7302', free.RoomKeyId)).json()) as {
				RoomKeyResponse: { Status: number }
				BalanceUpdateResponse: { Balance: number }
			}
			expect(gratis.RoomKeyResponse.Status).toBe(0)
			expect(gratis.BalanceUpdateResponse.Balance).toBe(100)
			const own = (await (await buy('1', key.RoomKeyId, 300)).json()) as typeof gratis
			expect(own.RoomKeyResponse.Status).toBe(0)
			expect(own.BalanceUpdateResponse.Balance).toBe(1300)
			await setTokens(2, 50)
			const coOwner = (await (await buy('2', key.RoomKeyId, 0)).json()) as typeof gratis
			expect(coOwner.RoomKeyResponse.Status).toBe(0)
			expect(coOwner.BalanceUpdateResponse.Balance).toBe(50)
			expect(await holders(key.RoomKeyId)).toEqual([1, 2, 7301])
			expect([await tokens(1), await tokens(2)]).toEqual([1300, 50])
			expect(await drainFrames()).toEqual([])

			// A key priced in a room currency is not sold for tokens.
			await env.DB.prepare(
				"UPDATE room_key SET purchase_currency_id = 'c0ffee' WHERE room_key_id = ?1"
			)
				.bind(free.RoomKeyId)
				.run()
			const inCurrency = { ...free, PurchaseCurrencyId: 'c0ffee' }
			expect(await (await buy('7301', free.RoomKeyId, 0)).json()).toEqual(
				refused(4, inCurrency, 200)
			)

			await env.DB.prepare('DELETE FROM room_key_player').run()
			await env.DB.prepare('DELETE FROM room_key').run()
		})

		test('POST PurchaseRoomKeyWithCurrency subtracts the key’s price in its room currency and pays nobody', async () => {
			const form = async (
				path: string,
				fields: Record<string, string>,
				sub: string | null,
				method = 'POST'
			) =>
				exports.default.fetch(`${ORIGIN}${path}`, {
					method,
					headers: {
						'Content-Type': 'application/x-www-form-urlencoded',
						...(sub === null ? {} : await plusBearer(sub)),
					},
					body: new URLSearchParams(fields),
				})
			const purchase = async (
				sub: string | null,
				roomKeyId: number,
				price: number,
				currency: string
			) =>
				form(
					'/api/storefronts/v1/PurchaseRoomKeyWithCurrency',
					{
						RoomKeyId: String(roomKeyId),
						RequestedPrice: String(price),
						RequestedPurchaseCurrencyId: currency,
					},
					sub
				)
			const mint = async (name: string) =>
				(
					(await (
						await form('/api/roomcurrencies/v1/createCurrency', { RoomId: '2511', Name: name }, '1')
					).json()) as { Value: { CurrencyId: string } }
				).Value.CurrencyId
			const give = (currencyId: string, playerId: number, amount: number) =>
				env.DB.prepare(
					'INSERT OR REPLACE INTO room_balance (currency_id, player_id, amount) VALUES (?1, ?2, ?3)'
				)
					.bind(currencyId, playerId, amount)
					.run()
			const held = async (currencyId: string, playerId: number) =>
				(
					await env.DB.prepare(
						'SELECT amount FROM room_balance WHERE currency_id = ?1 AND player_id = ?2'
					)
						.bind(currencyId, playerId)
						.first<{ amount: number }>()
				)?.amount ?? 0
			const holders = async (roomKeyId: number) =>
				(
					await env.DB.prepare(
						'SELECT account_id FROM room_key_player WHERE room_key_id = ?1 ORDER BY account_id'
					)
						.bind(roomKeyId)
						.all<{ account_id: number }>()
				).results.map((r) => r.account_id)
			const tokens = async (accountId: number) =>
				(
					await env.DB.prepare(
						'SELECT amount FROM balance WHERE account_id = ?1 AND currency_type = 2'
					)
						.bind(accountId)
						.first<{ amount: number }>()
				)?.amount
			// A refusal: the same shape, nothing sold, the holding as it stands.
			const refused = (accountId: number, currencyId: string, balance: number) => ({
				Balance: {
					AccountId: accountId,
					CurrencyId: currencyId,
					Balance: balance,
					ModifiedAt: expect.any(String),
				},
				RoomKeyResponse: { Status: 1, RoomKey: null },
			})

			// A key priced at 1000 of the room's own currency; a second currency; a token key.
			const coin = await mint('coin')
			const other = await mint('other')
			const made = await keyOf(await create(body, await plusBearer('1')))
			const key = (
				await envOf(
					await form(
						'/api/roomkeys/v1/updateAll',
						{ RoomKeyId: String(made.RoomKeyId), Price: '1000', PurchaseCurrencyId: coin },
						'1',
						'PUT'
					)
				)
			).RoomKey!
			expect(key).toMatchObject({ Price: 1000, PurchaseCurrencyId: coin })
			const tokenKey = await keyOf(
				await create({ ...body, Name: 'token key' }, await plusBearer('1'))
			)
			await give(coin, 7501, 1500)
			await give(other, 7501, 5000)
			await give(coin, 7502, 999)
			const ownerTokens = await tokens(1)
			await drainFrames()

			expect((await purchase(null, key.RoomKeyId, 1000, coin)).status).toBe(401)

			// Refusals: no such key, the wrong price, a currency that is not the key's, a key
			// priced in tokens, and a buyer one coin short — who is NOT sold it for what they have.
			const cases: Array<[Response, ReturnType<typeof refused>]> = [
				[await purchase('7501', 999999, 1000, coin), refused(7501, coin, 1500)],
				[await purchase('7501', key.RoomKeyId, 999, coin), refused(7501, coin, 1500)],
				[await purchase('7501', key.RoomKeyId, 1000, other), refused(7501, coin, 1500)],
				[await purchase('7501', tokenKey.RoomKeyId, 50, coin), refused(7501, coin, 1500)],
				[await purchase('7502', key.RoomKeyId, 1000, coin), refused(7502, coin, 999)],
			]
			for (const [res, expected] of cases) {
				expect(res.status).toBe(200)
				expect(await res.json()).toEqual(expected)
			}
			expect(await holders(key.RoomKeyId)).toEqual([])
			expect(await holders(tokenKey.RoomKeyId)).toEqual([])
			expect([await held(coin, 7501), await held(other, 7501), await held(coin, 7502)]).toEqual([
				1500, 5000, 999,
			])

			// The sale, exactly as the client posts it. `Balance` is an OBJECT holding the
			// resulting total, and it comes first.
			const res = await purchase('7501', key.RoomKeyId, 1000, coin)
			expect(res.status).toBe(200)
			const sold = (await res.json()) as Record<string, unknown>
			expect(sold).toEqual({
				Balance: {
					AccountId: 7501,
					CurrencyId: coin,
					Balance: 500,
					ModifiedAt: expect.any(String),
				},
				RoomKeyResponse: { Status: 0, RoomKey: key },
			})
			expect(Object.keys(sold)).toEqual(['Balance', 'RoomKeyResponse'])
			expect(await holders(key.RoomKeyId)).toEqual([7501])
			expect([await held(coin, 7501), await held(other, 7501)]).toEqual([500, 5000])

			// Nobody is paid: the owner holds none of the coin, their tokens did not move, and
			// no balance frame went out.
			expect(await held(coin, 1)).toBe(0)
			expect(await tokens(1)).toBe(ownerTokens)
			expect(await drainFrames()).toEqual([])

			// Held once: buying it again is refused and subtracts nothing.
			expect(await (await purchase('7501', key.RoomKeyId, 1000, coin)).json()).toEqual(
				refused(7501, coin, 500)
			)
			expect(await held(coin, 7501)).toBe(500)

			// A non-manager cannot buy it for 0; the room's managers can — the co-owner at the 0
			// the client asks them, the owner at the stored price — and nothing is subtracted.
			expect(await (await purchase('7502', key.RoomKeyId, 0, coin)).json()).toEqual(
				refused(7502, coin, 999)
			)
			await give(coin, 2, 10)
			const coOwner = (await (await purchase('2', key.RoomKeyId, 0, coin)).json()) as {
				Balance: { Balance: number }
				RoomKeyResponse: { Status: number }
			}
			expect(coOwner.RoomKeyResponse.Status).toBe(0)
			expect(coOwner.Balance.Balance).toBe(10)
			const own = (await (await purchase('1', key.RoomKeyId, 1000, coin)).json()) as typeof coOwner
			expect(own.RoomKeyResponse.Status).toBe(0)
			expect(own.Balance.Balance).toBe(0)
			expect(await holders(key.RoomKeyId)).toEqual([1, 2, 7501])
			expect([await held(coin, 1), await held(coin, 2)]).toEqual([0, 10])

			await env.DB.prepare('DELETE FROM room_key_player').run()
			await env.DB.prepare('DELETE FROM room_key').run()
			await env.DB.prepare('DELETE FROM room_balance WHERE currency_id IN (?1, ?2)')
				.bind(coin, other)
				.run()
			await env.DB.prepare('DELETE FROM room_currency WHERE currency_id IN (?1, ?2)')
				.bind(coin, other)
				.run()
		})
	})

	// Selling for TOKENS is a Rec Room Plus perk: a room manager without `rn.plus` may not put
	// a non-zero token price on a room key, a room consumable or a currency purchase offer.
	// A room-currency price, or a free listing, is open to every manager. Room 2511 is
	// account 1's.
	test('a token price on a room key, consumable or currency offer needs Rec Room Plus', async () => {
		const send = async (
			method: string,
			path: string,
			body: BodyInit,
			type: string,
			plus: boolean
		) =>
			exports.default.fetch(`${ORIGIN}${path}`, {
				method,
				headers: {
					'Content-Type': type,
					...(await (plus ? plusBearer('1') : bearer('1'))),
				},
				body,
			})
		const formSend = (method: string, path: string, fields: Record<string, string>, plus = false) =>
			send(method, path, new URLSearchParams(fields), 'application/x-www-form-urlencoded', plus)
		const jsonSend = (path: string, payload: unknown, plus = false) =>
			send('PUT', path, JSON.stringify(payload), 'application/json', plus)

		const coin = (
			(await (
				await formSend('POST', '/api/roomcurrencies/v1/createCurrency', {
					RoomId: '2511',
					Name: 'plus coin',
				})
			).json()) as { Value: { CurrencyId: string } }
		).Value.CurrencyId

		// Room keys: a create is always priced in tokens.
		const keyPath = '/api/roomkeys/v1/create'
		const key = { RoomId: '2511', Name: 'gate key', Price: '50' }
		expect((await formSend('POST', keyPath, key)).status).toBe(403)
		expect((await formSend('POST', keyPath, { ...key, Price: '0' })).status).toBe(200)
		const free = (
			(await (await formSend('POST', keyPath, { ...key, Price: '0' })).json()) as {
				RoomKey: { RoomKeyId: number }
			}
		).RoomKey
		const update = (fields: Record<string, string>) =>
			formSend('PUT', '/api/roomkeys/v1/updateAll', {
				RoomKeyId: String(free.RoomKeyId),
				...fields,
			})
		// An edit to a token price is refused; onto the room's currency it is not.
		expect((await update({ Price: '50' })).status).toBe(403)
		expect((await update({ Price: '50', PurchaseCurrencyId: coin })).status).toBe(200)
		// Taking it back off the currency at that price would make it a token key.
		expect((await update({ PurchaseCurrencyId: '' })).status).toBe(403)
		expect((await formSend('POST', keyPath, key, true)).status).toBe(200)
		// A key CREATED on the room's currency needs no Plus, and is stored on it.
		const onCoin = await formSend('POST', keyPath, {
			...key,
			Type: 'Key',
			Description: 'coin key',
			Price: '10',
			PurchaseCurrencyId: coin,
		})
		expect(onCoin.status).toBe(200)
		expect(
			((await onCoin.json()) as { RoomKey: { Price: number; PurchaseCurrencyId: string } }).RoomKey
		).toMatchObject({ Price: 10, PurchaseCurrencyId: coin })
		// A room currency lifts the token cap, and a currency of another room is refused.
		expect(
			(
				(await (
					await formSend('POST', keyPath, { ...key, Price: '5000', PurchaseCurrencyId: coin })
				).json()) as { Status: number }
			).Status
		).toBe(0)
		expect(
			await (
				await formSend('POST', keyPath, { ...key, PurchaseCurrencyId: crypto.randomUUID() })
			).json()
		).toEqual({ Status: 1, RoomKey: null })
		await env.DB.prepare('DELETE FROM room_key WHERE room_id = 2511').run()

		// Room consumables: CurrencyId null is a token price.
		const consumablePath = '/api/roomconsumables/v1/roomConsumable'
		const listing = (price: number, currencyId: string | null) => ({
			RoomConsumableId: null,
			RoomId: 2511,
			Name: 'gate snack',
			Description: '',
			PriceAndCurrency: { Price: price, CurrencyId: currencyId },
		})
		expect((await jsonSend(consumablePath, listing(50, null))).status).toBe(403)
		expect((await jsonSend(consumablePath, listing(50, coin))).status).toBe(200)
		expect((await jsonSend(consumablePath, listing(0, null))).status).toBe(200)
		expect((await jsonSend(consumablePath, listing(50, null), true)).status).toBe(200)

		// Currency purchase offers are always paid in tokens.
		const offerPath = '/api/roomcurrencies/v1/createPurchaseOffer'
		const offer = { CurrencyId: coin, Name: 'pack', Amount: '5', Price: '50' }
		expect((await formSend('POST', offerPath, offer)).status).toBe(403)
		expect((await formSend('POST', offerPath, { ...offer, Price: '0' })).status).toBe(200)
		expect((await formSend('POST', offerPath, offer, true)).status).toBe(200)

		await env.DB.prepare('DELETE FROM room_key WHERE room_id = 2511').run()
		await env.DB.prepare('DELETE FROM room_consumable WHERE room_id = 2511').run()
		await env.DB.prepare('DELETE FROM room_currency WHERE currency_id = ?1').bind(coin).run()
	})

	test('GET /api/roomcurrencies/v1/getAllBalances returns []', async () => {
		const res = await exports.default.fetch(
			`${ORIGIN}/api/roomcurrencies/v1/getAllBalances?roomId=1`
		)
		expect(res.status).toBe(200)
		expect(await res.json()).toEqual([])
	})

	// The room-economy stubs. One table-driven test: they're the same empty-list answer,
	// and what's worth pinning is that every path the client asks for on room entry is
	// registered — an unregistered one 404s and stalls the room load.
	test('the room-economy endpoints all return []', async () => {
		for (const path of [
			'/econ/roomInventory/room/92',
			'/econ/roomInventory/room/92/player',
			'/econ/roomInventoryItemTags/room/92',
			'/econ/roomOffer/room/92',
			'/econ/roomOffer/room/92/purchaseCounts',
			'/econ/roomGiftDropShops/room/92',
		]) {
			const res = await exports.default.fetch(`${ORIGIN}${path}`)
			expect(res.status, path).toBe(200)
			expect(await res.json(), path).toEqual([])
		}
	})

	test('GET /api/ugcPurchasables/v1/items/room/:roomId lists keys, consumables and currency packs as one shop', async () => {
		const shop = async (roomId: number) =>
			(await (
				await exports.default.fetch(`${ORIGIN}/api/ugcPurchasables/v1/items/room/${roomId}`)
			).json()) as Array<Record<string, unknown>>

		// A room that sells nothing is `[]`, never `{}` — the client's decoder throws on that.
		expect(await shop(93)).toEqual([])

		const key = await createRoomKey(env.DB, {
			RoomId: 93,
			Type: 'Key',
			Name: 'VIP Key',
			Description: '',
			Price: 250,
			PurchaseCurrencyId: null,
		})
		const consumable = await upsertRoomConsumable(env.DB, null, {
			RoomId: 93,
			Name: 'Potion',
			Description: 'Drink me',
			ImageName: 'potion.png',
			Price: 5,
			PurchaseCurrencyId: 'c0ffee00-0000-4000-8000-000000000093',
			MaximumCountPerPurchase: 10,
		})
		const currency = await createRoomCurrency(env.DB, {
			RoomId: 93,
			Name: 'Gems',
			Description: 'Shiny',
			Limit: 100,
			Shape: 0,
			Color: 0,
		})
		// The client names an offer by a GUID — not a label anyone should see.
		const offer = await createPurchaseOffer(env.DB, currency.CurrencyId, {
			Name: '5a1c3e4f-0000-4000-8000-000000000093',
			CurrencyAmount: 100,
			Price: 400,
			Order: 0,
		})

		// The client's 10-key `UgcPurchasableItem`, `ItemType` saying which table a line is
		// from and `ItemId` a bare GUID: a key is named by its ReplicationId, not its number.
		expect(await shop(93)).toEqual([
			{
				ItemType: 0,
				ItemId: key.ReplicationId,
				Name: 'VIP Key',
				Description: '',
				ImageName: null,
				RoomId: 93,
				Price: 250,
				PurchaseCurrencyId: null,
				CreatedAt: key.CreatedAt,
				ModifiedAt: key.CreatedAt,
			},
			{
				ItemType: 1,
				ItemId: consumable.RoomConsumableId,
				Name: 'Potion',
				Description: 'Drink me',
				ImageName: 'potion.png',
				RoomId: 93,
				Price: 5,
				PurchaseCurrencyId: 'c0ffee00-0000-4000-8000-000000000093',
				CreatedAt: consumable.ModifiedAt,
				ModifiedAt: consumable.ModifiedAt,
			},
			{
				ItemType: 3,
				ItemId: offer.CurrencyPurchaseOfferId,
				// So a pack is labelled by what it is, and wears the currency's description.
				Name: '100 Gems',
				Description: 'Shiny',
				ImageName: null,
				RoomId: 93,
				Price: 400,
				// A currency pack is bought with tokens.
				PurchaseCurrencyId: null,
				CreatedAt: offer.ModifiedAt,
				ModifiedAt: offer.ModifiedAt,
			},
		])
		// Another room's shop is untouched.
		expect(await shop(92)).toEqual([])
	})

	test('2026 room-offer purchase counts use the captured result envelope', async () => {
		const res = await exports.default.fetch(`${ORIGIN}/econ/roomOffer/room/92/purchaseCounts`, {
			headers: await bearer('42', undefined, '20260323.14'),
		})
		expect(res.status).toBe(200)
		expect(await res.json()).toEqual({ Value: [], Success: true, Error: null, error_id: null })
	})

	test('POST /api/ugcPurchasables/v1/items/bulk resolves custom avatar items, echoing RoomId', async () => {
		const item = await createCustomAvatarItem(env.DB, {
			customAvatarItemId: crypto.randomUUID(),
			creatorAccountId: 205,
			name: 'Neon Visor',
			description: '',
			price: 250,
			baseAvatarItemId: 1,
			baseAvatarItemColor: '#fff',
			accessibility: 0,
			designFilename: 'design_x.bin',
			thumbnailImageFilename: 'thumb_x.png',
		})
		const res = await exports.default.fetch(`${ORIGIN}/api/ugcPurchasables/v1/items/bulk`, {
			method: 'POST',
			headers: { ...(await bearer()), 'content-type': 'application/json' },
			body: JSON.stringify({
				RoomId: 92,
				Ids: [
					{ itemType: 3, itemId: item.CustomAvatarItemId },
					{ itemType: 3, itemId: 'does-not-exist' },
					{ itemType: 1, itemId: item.CustomAvatarItemId },
				],
			}),
		})
		expect(res.status).toBe(200)
		expect(await res.json()).toEqual([
			{
				ItemType: 3,
				ItemId: item.CustomAvatarItemId,
				Name: 'Neon Visor',
				Description: '',
				ImageName: 'thumb_x.png',
				RoomId: 92,
				Price: 250,
				PurchaseCurrencyId: null,
				CreatedAt: item.CreatedAt,
				ModifiedAt: item.ModifiedAt,
			},
		])
	})

	test('POST /api/ugcPurchasables/v1/items/bulk 400s without Ids and 401s without a token', async () => {
		const bad = await exports.default.fetch(`${ORIGIN}/api/ugcPurchasables/v1/items/bulk`, {
			method: 'POST',
			headers: { ...(await bearer()), 'content-type': 'application/json' },
			body: JSON.stringify({ RoomId: 92 }),
		})
		expect(bad.status).toBe(400)
		const anon = await exports.default.fetch(`${ORIGIN}/api/ugcPurchasables/v1/items/bulk`, {
			method: 'POST',
			headers: { 'content-type': 'application/json' },
			body: JSON.stringify({ RoomId: 92, Ids: [] }),
		})
		expect(anon.status).toBe(401)
	})

	test('bulkpurchase buys a merged-store catalog item from storefront 3', async () => {
		// The exact request the client sends, verbatim: a 2025 store id under storefront 3, which
		// is what sf3-2025 lists it as. It resolves because `loadStorefront` picks the file by the
		// caller's build, so what the store page offered is what the purchase is checked against.
		const res = await exports.default.fetch(`${ORIGIN}/api/items/bulkpurchase`, {
			method: 'POST',
			headers: {
				...((await bearer('4801', undefined, '20250718.01')) as Record<string, string>),
				'Content-Type': 'application/json',
			},
			body: JSON.stringify({
				PurchaseItemRequests: [
					{
						ItemPurchaseMethodId: { Type: 0, NumberId: NEWER_ONLY.id, Guid: null },
						RequestedPrice: NEWER_ONLY.price,
						Gift: null,
						CouponConsumablePlayerMappingId: null,
						DuplicateItemCount: 1,
					},
				],
				StorefrontType: 3,
				CurrencyType: 2,
				BypassGiftPackages: false,
				AllowPartialSuccess: true,
				ShoppingBagId: null,
			}),
		})
		expect(res.status).toBe(200)
		const body = (await res.json()) as {
			Success: boolean
			Error: string
			Value: { Balance: number } | null
		}
		// It used to answer `{ Success: false, Error: "Item not found" }` — storefront 3 resolved
		// to the 2023 sf3, which does not list this id.
		expect(body.Error).not.toBe('Item not found')
		expect(body.Success).toBe(true)

		// The price the client posts is the one the file lists — the dump's list price, its
		// captured sale stripped. A second pricing anywhere would 409 every purchase as "Price
		// has changed".
		const item = storeListings.find((i) => i.PurchasableItemId === NEWER_ONLY.id)
		expect(item?.Prices.find((p) => p.CurrencyType === 2)?.Price).toBe(NEWER_ONLY.price)

		// The SAME request from an old build still fails: its storefront 3 is the 2023 store,
		// which does not list this id.
		const legacy = await exports.default.fetch(`${ORIGIN}/api/items/bulkpurchase`, {
			method: 'POST',
			headers: {
				...((await bearer('4802', undefined, '20230414')) as Record<string, string>),
				'Content-Type': 'application/json',
			},
			body: JSON.stringify({
				PurchaseItemRequests: [
					{
						ItemPurchaseMethodId: { Type: 0, NumberId: NEWER_ONLY.id, Guid: null },
						RequestedPrice: NEWER_ONLY.price,
						DuplicateItemCount: 1,
					},
				],
				StorefrontType: 3,
				CurrencyType: 2,
				AllowPartialSuccess: true,
			}),
		})
		expect(((await legacy.json()) as { Success: boolean }).Success).toBe(false)
	})

	test('bulkpurchase resolves numbered lines against the storefront file alone', async () => {
		// Rows the `catalog` table holds that the store does NOT list — an avatar item, a skin and
		// a developer-tier item — none of which may be bought: the file is the whole catalog, and
		// the ids the discovery rows hand out are the store's own, so a numbered line resolves
		// there or nowhere.
		const AVATAR_ID = 20_001
		const SKIN_ID = 20_002
		const DEV_ID = 20_003
		await env.DB.prepare(
			`INSERT INTO catalog (item_key, catalog_id, kind, friendly_name, tooltip, rarity, platform_mask, avatar_item_type)
			 VALUES ('bulk-buy-desc,,,', ?1, 'avatar_item', 'Bulk Buy Hat', '', 10, -1, 0)`
		)
			.bind(AVATAR_ID)
			.run()
		await env.DB.prepare(
			`INSERT INTO catalog (item_key, catalog_id, kind, friendly_name, tooltip, rarity, platform_mask, prefab_name)
			 VALUES ('bulk-buy-guid', ?1, 'skin', 'Bulk Buy Skin', '', 0, -1, '[MakerPen]')`
		)
			.bind(SKIN_ID)
			.run()
		await env.DB.prepare(
			`INSERT INTO catalog (item_key, catalog_id, kind, friendly_name, tooltip, rarity, platform_mask, avatar_item_type)
			 VALUES ('bulk-buy-dev,,,', ?1, 'avatar_item', 'Bulk Buy Dev Item', '', -1, -1, 0)`
		)
			.bind(DEV_ID)
			.run()
		// None of those three numbers is a 2025 listing, or the test would be about the file.
		for (const id of [AVATAR_ID, SKIN_ID, DEV_ID]) {
			expect(
				sf32025.StoreItems.find((i) => i.PurchasableItemId === id),
				String(id)
			).toBeUndefined()
		}

		const buy = async (
			version: string | undefined,
			lines: Array<{ id: number; price: number }>,
			sub = '46'
		) =>
			exports.default.fetch(`${ORIGIN}/api/items/bulkpurchase`, {
				method: 'POST',
				headers: {
					...((await bearer(sub, undefined, version)) as Record<string, string>),
					'Content-Type': 'application/json',
				},
				body: JSON.stringify({
					StorefrontType: 3,
					CurrencyType: 2,
					AllowPartialSuccess: false,
					PurchaseItemRequests: lines.map((l) => ({
						ItemPurchaseMethodId: { Type: 0, NumberId: l.id, Guid: null },
						RequestedPrice: l.price,
					})),
				}),
			})
		const outcome = async (res: Response) =>
			((await res.json()) as { Success: boolean; Error?: string }).Success

		// A 2025 listing buys at its list price — the dump's, its sale stripped. The price MUST
		// match: `priceCheck` refuses a line whose posted price differs.
		const res = await buy('20250718.01', [{ id: NEWER_ONLY.id, price: NEWER_ONLY.price }])
		expect(res.status).toBe(200)
		expect(await outcome(res)).toBe(true)

		// A price the storefront does not list is refused, not quietly charged.
		expect(await outcome(await buy('20250718.01', [{ id: NEWER_ONLY.id, price: 1 }]))).toBe(false)

		// Table-only rows are not for sale, whatever their kind and at any price. The catalog says
		// what a thing IS; only the storefront says what is sold.
		for (const [id, price] of [
			[AVATAR_ID, 600],
			[SKIN_ID, 150],
			[DEV_ID, 150],
		] as const) {
			expect(await outcome(await buy('20250718.01', [{ id, price }])), String(id)).toBe(false)
		}

		// And an old build never sees a 2025 number: its storefront 3 is the 2023 file.
		expect(
			await outcome(await buy('20230414', [{ id: NEWER_ONLY.id, price: NEWER_ONLY.price }]))
		).toBe(false)
		expect(
			await outcome(await buy(undefined, [{ id: NEWER_ONLY.id, price: NEWER_ONLY.price }]))
		).toBe(false)

		// Cleaned up: the `catalog` block below counts every row in the table, so rows left behind
		// here would change what it sees.
		await env.DB.prepare('DELETE FROM catalog WHERE catalog_id BETWEEN ?1 AND ?2')
			.bind(AVATAR_ID, DEV_ID)
			.run()
	})

	test('lockeditems/bulk filters by exact AvatarItemDesc, in catalogue order', async () => {
		const ask = async (
			descs: unknown
		): Promise<Array<{ AvatarItemDesc: string; FriendlyName: string }>> => {
			const res = await exports.default.fetch(`${ORIGIN}/api/avatar/v1/lockeditems/bulk`, {
				method: 'POST',
				headers: { 'content-type': 'application/json' },
				body: JSON.stringify(descs === undefined ? {} : { AvatarItemDescriptions: descs }),
			})
			expect(res.status).toBe(200)
			return (await res.json()) as Array<{ AvatarItemDesc: string; FriendlyName: string }>
		}

		// Three real catalogue entries — rows of the seeded slice, which are the loader's own —
		// deliberately asked for OUT of catalogue order.
		const seeded = SEEDED_AVATAR_ITEMS.map((r) => ({ AvatarItemDesc: r.key }))
		const [first, second, third] = [seeded[0]!, seeded[20]!, seeded[45]!]
		// The catalogue the route answers with is every avatar item in the table — the seeded
		// slice, plus whatever the catalog block below has not yet replaced it with.
		const catalogueSize = (await countCatalog(env.DB))[CatalogKind.AvatarItem] ?? 0
		expect(catalogueSize).toBeGreaterThanOrEqual(SEEDED_AVATAR_ITEMS.length)

		const got = await ask([third.AvatarItemDesc, first.AvatarItemDesc, second.AvatarItemDesc])
		expect(got).toHaveLength(3)
		// In CATALOGUE order, not request order: the reference's filter walks the catalogue, so
		// the response must never be read positionally against what was asked for.
		expect(got.map((i) => i.AvatarItemDesc)).toEqual([
			first.AvatarItemDesc,
			second.AvatarItemDesc,
			third.AvatarItemDesc,
		])

		// The match is the WHOLE desc, not the base asset: asking for a plain base does not drag
		// in every colourway built on it.
		const one = await ask([first.AvatarItemDesc])
		expect(one).toHaveLength(1)
		expect(one[0]?.AvatarItemDesc).toBe(first.AvatarItemDesc)

		// A miss is not an error: unknown descs are absent and do not cost the caller the batch.
		expect(
			(await ask(['no-such-desc,,,', first.AvatarItemDesc])).map((i) => i.AvatarItemDesc)
		).toEqual([first.AvatarItemDesc])
		expect(await ask(['no-such-desc,,,'])).toEqual([])

		// EMPTY or absent means the WHOLE catalogue — the reference's "give me everything" case,
		// not a degenerate match-nothing. In the catalogue's record shape: the desc IS the key.
		const whole = await ask([])
		expect(whole).toHaveLength(catalogueSize)
		expect(whole[0]).toMatchObject({ AvatarItemDesc: first.AvatarItemDesc, PlatformMask: -1 })
		expect(await ask(undefined)).toHaveLength(catalogueSize)

		// No auth needed, and a body that will not parse falls back to the catalogue rather than
		// erroring.
		const junk = await exports.default.fetch(`${ORIGIN}/api/avatar/v1/lockeditems/bulk`, {
			method: 'POST',
			headers: { 'content-type': 'application/json' },
			body: 'not json',
		})
		expect(junk.status).toBe(200)
		expect(((await junk.json()) as unknown[]).length).toBe(catalogueSize)
	})

	test('POST /api/items/purchaseInfos prices custom avatar items in tokens', async () => {
		const item = await createCustomAvatarItem(env.DB, {
			customAvatarItemId: crypto.randomUUID(),
			creatorAccountId: 206,
			name: 'Chrome Jacket',
			description: '',
			price: 425,
			baseAvatarItemId: 1,
			baseAvatarItemColor: '#000',
			designFilename: 'design_pi.bin',
			thumbnailImageFilename: 'thumb_pi.png',
			accessibility: 1,
		})
		const res = await exports.default.fetch(`${ORIGIN}/api/items/purchaseInfos`, {
			method: 'POST',
			headers: { ...(await bearer()), 'content-type': 'application/json' },
			body: JSON.stringify({
				Ids: [
					{ itemType: 3, itemId: item.CustomAvatarItemId },
					// Dropped, both of them: an id nothing owns, and a type this doesn't serve. The
					// response is one entry per RESOLVED id, so it is SHORTER than `Ids` rather than
					// carrying a null in their places — the client must not read it positionally.
					{ itemType: 3, itemId: crypto.randomUUID() },
					{ itemType: 1, itemId: item.CustomAvatarItemId },
				],
			}),
		})
		expect(res.status).toBe(200)
		expect(await res.json()).toEqual([
			{
				// The reference echoed back verbatim: camelCase members under a PascalCase key. The
				// client names them that way on both legs and PascalCasing them here loses the id.
				ItemId: { itemType: 3, itemId: item.CustomAvatarItemId },
				// A UGC listing is keyed by guid, so `Type` 1 and `NumberId` null. A storefront's
				// numbered `PurchasableItemId` would be the other side of the union.
				PurchaseMethodId: { Type: 1, NumberId: null, Guid: item.CustomAvatarItemId },
				// RecCenterTokens (2) — the currency the creation UI's price floor is denominated
				// in, and the one the client actually holds a balance in. A room currency (300)
				// would draw a price nothing can pay.
				Prices: [
					{
						CurrencyType: 2,
						Price: 425,
						StorefrontSaleData: { SalePercent: 0, SaleStartDate: null, SaleEndDate: null },
					},
				],
				NewUntil: null,
				AvailableAt: item.CreatedAt,
				AvailableUntil: null,
				CanBeGifted: true,
				CanApplySubscriberDiscount: false,
				SubscribersOnly: false,
				IsFeatured: false,
			},
		])
	})

	test('POST /api/storefronts/v1/purchasableitems answers the served listings verbatim', async () => {
		// One listing of each kind the catalog holds, loaded exactly as `runx catalog load` would.
		const pick = (pred: (l: StoreListing) => boolean) => storeListings.find(pred)!
		const wanted = [
			pick((l) => l.PurchasableItemId === 2594), // an avatar item
			pick((l) => l.GiftDrop.ConsumableItemDesc !== ''),
			pick((l) => l.GiftDrop.EquipmentModificationGuid !== ''),
			pick((l) => (l.GiftDrop.CustomAvatarItemId ?? '') !== ''),
		]
		const ids = new Set(wanted.map((l) => l.PurchasableItemId))
		const rows = buildCatalogLoad(storeListings).rows.filter((r) => ids.has(r.id))
		expect(rows).toHaveLength(wanted.length)
		await env.DB.batch(
			rows.map((row) =>
				env.DB.prepare(
					`INSERT OR REPLACE INTO catalog (${CATALOG_INSERT_COLUMNS.join(', ')})
					 VALUES (${CATALOG_INSERT_COLUMNS.map((_, i) => `?${i + 1}`).join(', ')})`
				).bind(...row.values.map((v) => v ?? null))
			)
		)

		// Request order, unknown ids and repeats dropped, `GiftDropIds` ignored. No token needed.
		const order = [...wanted].reverse().map((l) => l.PurchasableItemId)
		const res = await exports.default.fetch(`${ORIGIN}/api/storefronts/v1/purchasableitems`, {
			method: 'POST',
			headers: { 'content-type': 'application/json' },
			body: JSON.stringify({
				PurchasableItemIds: [order[0], 12_345_678, ...order, order[1]],
				GiftDropIds: null,
			}),
		})
		expect(res.status).toBe(200)
		const body = (await res.json()) as StoreListing[]
		expect(body).toEqual(order.map((id) => storeListings.find((l) => l.PurchasableItemId === id)))
		expect(body.at(-1)?.GiftDrop.FriendlyName).toBe('Hot Dog Suit (Ketchup)')

		// Null ids answer an empty list; a non-array is a malformed body.
		const none = await exports.default.fetch(`${ORIGIN}/api/storefronts/v1/purchasableitems`, {
			method: 'POST',
			headers: { 'content-type': 'application/json' },
			body: JSON.stringify({ PurchasableItemIds: null, GiftDropIds: null }),
		})
		expect(await none.json()).toEqual([])
		const bad = await exports.default.fetch(`${ORIGIN}/api/storefronts/v1/purchasableitems`, {
			method: 'POST',
			headers: { 'content-type': 'application/json' },
			body: JSON.stringify({ PurchasableItemIds: 2594 }),
		})
		expect(bad.status).toBe(400)
	})

	test('POST /api/items/purchaseInfos 400s without Ids and 401s without a token', async () => {
		const bad = await exports.default.fetch(`${ORIGIN}/api/items/purchaseInfos`, {
			method: 'POST',
			headers: { ...(await bearer()), 'content-type': 'application/json' },
			body: JSON.stringify({}),
		})
		expect(bad.status).toBe(400)
		const anon = await exports.default.fetch(`${ORIGIN}/api/items/purchaseInfos`, {
			method: 'POST',
			headers: { 'content-type': 'application/json' },
			body: JSON.stringify({ Ids: [] }),
		})
		expect(anon.status).toBe(401)
	})

	test('GET /paintball-battle-pass/config serves the stub season', async () => {
		const res = await exports.default.fetch(`${ORIGIN}/paintball-battle-pass/config`)
		expect(res.status).toBe(200)
		const config = (await res.json()) as Record<string, unknown>
		expect(config).toMatchObject({
			BattlePassId: 1,
			Name: 'Season 1',
			ValidRoomIds: [112],
			Levels: [{ XpRequired: 100, RewardGiftDropIds: [1] }],
			EventXP: { '1': 10, '2': 25, '3': 50, '4': 100 },
			PermanentBoostTokenPrice: 500,
		})
	})

	test('POST /api/timedCurrencyGrants/update serves the stub grant', async () => {
		const res = await exports.default.fetch(`${ORIGIN}/api/timedCurrencyGrants/update`, {
			method: 'POST',
		})
		expect(res.status).toBe(200)
		expect(await res.json()).toEqual({
			TimedCurrencyGrantId: 1,
			Name: 'Daily Tokens',
			StartTime: '2026-10-01T00:00:00Z',
			EndTime: '2026-12-01T00:00:00Z',
			CurrencyType: 0,
			OfflineRatePerHour: 1,
			OnlineRatePerHour: 5,
			ActiveExperiment: null,
		})
	})

	test('POST /api/distanceMovedRewardTracks/distance is a stub: answers an empty 200', async () => {
		const res = await exports.default.fetch(`${ORIGIN}/api/distanceMovedRewardTracks/distance`, {
			method: 'POST',
			headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
			body: 'distanceMeters=12.5',
		})
		expect(res.status).toBe(200)
		expect(await res.text()).toBe('')
	})

	test('GET /econ/roomEconConfig/:roomId echoes the room and disables sorting tabs', async () => {
		const anon = await exports.default.fetch(`${ORIGIN}/econ/roomEconConfig/92`)
		expect(anon.status).toBe(401)

		const res = await exports.default.fetch(`${ORIGIN}/econ/roomEconConfig/92`, {
			headers: await bearer(),
		})
		expect(res.status).toBe(200)
		expect(await res.json()).toEqual({ RoomId: 92, EnableSortingTabs: false })

		const bad = await exports.default.fetch(`${ORIGIN}/econ/roomEconConfig/nope`, {
			headers: await bearer(),
		})
		expect(bad.status).toBe(400)
	})

	test('2026 owned built-in consumables include the definition identity flag', async () => {
		await grantConsumable(env.DB, 9731, 'test-built-in', 3)
		try {
			for (const version of ['20260323.14', '20250718.01']) {
				const res = await exports.default.fetch(`${ORIGIN}/api/consumables/v2/getUnlocked`, {
					headers: await bearer('9731', undefined, version),
				})
				expect(res.status).toBe(200)
				const [item] = (await res.json()) as Array<Record<string, unknown>>
				expect(item.Count).toBe(3)
				if (version === '20260323.14') expect(item.IsRRO).toBe(true)
				else expect(item).not.toHaveProperty('IsRRO')
			}
		} finally {
			await env.DB.prepare('DELETE FROM consumable WHERE account_id = ?').bind(9731).run()
		}
	})

	test('GET /api/consumables/v1/all serves the consumable definitions', async () => {
		const res = await exports.default.fetch(`${ORIGIN}/api/consumables/v1/all?supportedVersion=2`)
		expect(res.status).toBe(200)
		const body = await res.json<Array<Record<string, unknown>>>()
		expect(body.length).toBeGreaterThan(0)
		expect(body[0]).toMatchObject({
			ConsumableItemId: 1,
			ConsumableItemDesc: 'frOMH6WxDEG1fBqC4_83vg',
			FriendlyName: 'Black & White Camera Film',
		})
		// ConfigurationData is JSON escaped into a string (or null), never a nested object.
		for (const item of body) {
			expect(item.ConfigurationData === null || typeof item.ConfigurationData === 'string').toBe(
				true
			)
		}
	})

	test('GET /api/consumables/v2/getUnlocked 401s without a token, returns []', async () => {
		const anon = await exports.default.fetch(`${ORIGIN}/api/consumables/v2/getUnlocked`)
		expect(anon.status).toBe(401)
		const res = await exports.default.fetch(`${ORIGIN}/api/consumables/v2/getUnlocked`, {
			headers: await bearer(),
		})
		expect(res.status).toBe(200)
		expect(await res.json()).toEqual([])
	})

	test('POST /api/consumables/v1/query/bulk is a stub: resolves nothing, answers []', async () => {
		const res = await exports.default.fetch(
			`${ORIGIN}/api/consumables/v1/query/bulk?configurationVersion=2`,
			{
				method: 'POST',
				headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
				body: 'descriptors=xfeDIDboPES-AS90CCn2xQ&descriptors=test_bad',
			}
		)
		expect(res.status).toBe(200)
		expect(await res.json()).toEqual([])
	})

	test('POST /api/consumables/v1/updateActive is a stub: auth-gated, stores nothing, answers nothing', async () => {
		const before = await env.DB.prepare('SELECT * FROM consumable ORDER BY id').all()
		const body = { Id: 7550, IsActive: true, ActivatedByRoomie: false }

		const anon = await exports.default.fetch(`${ORIGIN}/api/consumables/v1/updateActive`, {
			method: 'POST',
			headers: { 'Content-Type': 'application/json' },
			body: JSON.stringify(body),
		})
		expect(anon.status).toBe(401)

		const res = await exports.default.fetch(`${ORIGIN}/api/consumables/v1/updateActive`, {
			method: 'POST',
			headers: { ...(await bearer('314')), 'Content-Type': 'application/json' },
			body: JSON.stringify(body),
		})
		expect(res.status).toBe(200)
		// No body at all: the client ignores the response entirely.
		expect(await res.text()).toBe('')
		// Nothing is stored yet.
		const after = await env.DB.prepare('SELECT * FROM consumable ORDER BY id').all()
		expect(after.results).toEqual(before.results)
	})

	test('POST /api/consumables/v1/consume reduces the count and deletes the row at zero', async () => {
		// Seed account 313 with two Supreme Pizza instances (counts 3 and 1).
		await grantConsumable(env.DB, 313, 'Supreme Pizza', 3)
		await grantConsumable(env.DB, 313, 'Supreme Pizza', 1)

		type Group = { ConsumableItemDesc: string; Ids: number[]; Count: number }
		const pizza = async (sub = '313'): Promise<Group | undefined> => {
			const groups = (await (
				await exports.default.fetch(`${ORIGIN}/api/consumables/v2/getUnlocked`, {
					headers: await bearer(sub),
				})
			).json()) as Group[]
			return groups.find((g) => g.ConsumableItemDesc === 'Supreme Pizza')
		}
		const consume = async (Id: number, DeltaCount: number, sub = '313') =>
			exports.default.fetch(`${ORIGIN}/api/consumables/v1/consume`, {
				method: 'POST',
				headers: { ...(await bearer(sub)), 'Content-Type': 'application/json' },
				body: JSON.stringify({ Id, DeltaCount }),
			})

		const before = (await pizza())!
		expect(before.Count).toBe(4)
		const [firstId, secondId] = before.Ids // firstId: count 3, secondId: count 1

		// No token → 401.
		expect(
			(
				await exports.default.fetch(`${ORIGIN}/api/consumables/v1/consume`, {
					method: 'POST',
					headers: { 'Content-Type': 'application/json' },
					body: JSON.stringify({ Id: firstId, DeltaCount: 1 }),
				})
			).status
		).toBe(401)

		// Consume 1 from the count-3 instance → it drops to 2, still present.
		expect((await consume(firstId, 1)).status).toBe(200)
		expect((await pizza())!.Count).toBe(3)

		// Consume the whole count-1 instance → its row is deleted.
		await consume(secondId, 1)
		const afterSecond = (await pizza())!
		expect(afterSecond.Ids).not.toContain(secondId)
		expect(afterSecond.Count).toBe(2)

		// Over-consume the remaining instance (delta > count) → row deleted, group gone.
		await consume(firstId, 5)
		expect(await pizza()).toBeUndefined()

		// Consuming a row you don't own is a no-op (scoped to the owner).
		await grantConsumable(env.DB, 314, 'Soda', 2)
		const sodaId = (
			(await (
				await exports.default.fetch(`${ORIGIN}/api/consumables/v2/getUnlocked`, {
					headers: await bearer('314'),
				})
			).json()) as Array<{ Ids: number[] }>
		)[0].Ids[0]
		await consume(sodaId, 2, '313') // account 313 tries to consume 314's row
		const soda = (
			(await (
				await exports.default.fetch(`${ORIGIN}/api/consumables/v2/getUnlocked`, {
					headers: await bearer('314'),
				})
			).json()) as Array<{ Count: number }>
		)[0]
		expect(soda.Count).toBe(2)
	})

	test('GET /api/storefronts/v4/balance/2 401s without a token, returns the token balance', async () => {
		const anon = await exports.default.fetch(`${ORIGIN}/api/storefronts/v4/balance/2`)
		expect(anon.status).toBe(401)
		const res = await exports.default.fetch(`${ORIGIN}/api/storefronts/v4/balance/2`, {
			headers: await bearer(),
		})
		expect(res.status).toBe(200)
		// The starting grant, applied on this first read.
		expect(await res.json()).toEqual([{ CurrencyType: 2, Platform: -2, Balance: 10000 }])
	})

	test('GET /api/storefronts/v4/balance/2 reflects what the player has spent', async () => {
		// Spend from account 7 (a fresh account: the read below grants it first).
		expect(
			await spendCurrency(env.DB, 7, CurrencyType.RecCenterTokens, 2500, DEFAULT_STARTING_TOKENS)
		).toBe(true)
		const res = await exports.default.fetch(`${ORIGIN}/api/storefronts/v4/balance/2`, {
			headers: await bearer('7'),
		})
		expect(await res.json()).toEqual([{ CurrencyType: 2, Platform: -2, Balance: 7500 }])
	})

	test('a spend the player cannot afford changes nothing', async () => {
		const before = await getBalance(
			env.DB,
			8,
			CurrencyType.RecCenterTokens,
			DEFAULT_STARTING_TOKENS
		)
		expect(
			await spendCurrency(
				env.DB,
				8,
				CurrencyType.RecCenterTokens,
				before + 1,
				DEFAULT_STARTING_TOKENS
			)
		).toBe(false)
		expect(await getBalance(env.DB, 8, CurrencyType.RecCenterTokens, DEFAULT_STARTING_TOKENS)).toBe(
			before
		)
	})

	test('the starting grant comes from the STARTING_TOKENS var', async () => {
		// The grant an operator actually runs is the var; DEFAULT_STARTING_TOKENS is only the
		// fallback. `env` is shared by every test in this file, so restore it in `finally`.
		const original = env.STARTING_TOKENS
		try {
			env.STARTING_TOKENS = 250
			const res = await exports.default.fetch(`${ORIGIN}/api/storefronts/v4/balance/2`, {
				headers: await bearer('11'),
			})
			expect(await res.json()).toEqual([{ CurrencyType: 2, Platform: -2, Balance: 250 }])
		} finally {
			env.STARTING_TOKENS = original
		}
	})

	test('the starting grant is not re-granted after spending down to zero', async () => {
		// The grant is INSERT OR IGNORE against the row, not a top-up: a player who spends
		// everything stays at 0 rather than being refilled by their next balance read.
		expect(
			await spendCurrency(env.DB, 9, CurrencyType.RecCenterTokens, 10_000, DEFAULT_STARTING_TOKENS)
		).toBe(true)
		const res = await exports.default.fetch(`${ORIGIN}/api/storefronts/v4/balance/2`, {
			headers: await bearer('9'),
		})
		expect(await res.json()).toEqual([{ CurrencyType: 2, Platform: -2, Balance: 0 }])
	})

	test('GET /api/storefronts/v4/balance for a room-scoped currency returns 0, not a balance', async () => {
		// RoomCurrency (300) is scoped to a room and served elsewhere; this table must not
		// hand out an account-wide balance for it.
		const res = await exports.default.fetch(`${ORIGIN}/api/storefronts/v4/balance/300`, {
			headers: await bearer(),
		})
		expect(res.status).toBe(200)
		expect(await res.json()).toEqual([{ CurrencyType: 300, Platform: -2, Balance: 0 }])
	})

	test('GET /api/storefronts/v3/giftdropstore/3 returns the storefront catalog', async () => {
		const res = await exports.default.fetch(`${ORIGIN}/api/storefronts/v3/giftdropstore/3`)
		expect(res.status).toBe(200)
		expect(await res.json()).toBeTruthy()
	})

	// TEMPORARY, alongside the probe in `econ.app.ts`: the storefront ids are swapped so it can
	// be seen from the client which one the 2025 store actually reads. Delete this with the
	// probe.
	test('storefront 3 serves sf3 to old builds and the merged sf3-2025 to newer ones', async () => {
		const store = async (headers: Record<string, string>) => {
			const res = await exports.default.fetch(`${ORIGIN}/api/storefronts/v3/giftdropstore/3`, {
				headers,
			})
			expect(res.status).toBe(200)
			return (await res.json()) as { StorefrontType: number; StoreItems: unknown[] }
		}
		const at = async (version: string) =>
			(await bearer('42', undefined, version)) as Record<string, string>

		// 20230414 is GAME_VERSION — what the rest of the stack targets — so the cutoff is
		// INCLUSIVE and that build keeps the captured sf3 exactly as it has always had it.
		const legacy = await store(await at('20230414'))
		expect(legacy.StoreItems).toHaveLength(sf3.StoreItems.length)
		// A same-day rebuild sorts by its DATE, not the `.NN` suffix.
		expect((await store(await at('20230414.02'))).StoreItems).toHaveLength(sf3.StoreItems.length)

		// A caller with no readable build gets the captured file too: an unversioned token is the
		// OLD client, so treating "can't prove its version" as "newer" would swap the store out
		// from under the build that needs it.
		expect((await store({})).StoreItems).toHaveLength(sf3.StoreItems.length)
		expect((await store(await bearer())).StoreItems).toHaveLength(sf3.StoreItems.length)
		expect((await store(await at('not-a-build'))).StoreItems).toHaveLength(sf3.StoreItems.length)

		// Later builds get the 2025 store — bigger, and still storefront 3.
		for (const version of ['20230616', '20250424.01', '20250718.01', '20260323.14']) {
			const newer = await store(await at(version))
			expect(newer.StorefrontType, version).toBe(3)
			expect(newer.StoreItems.length, version).toBe(sf32025.StoreItems.length)
			expect(newer.StoreItems.length, version).toBeGreaterThan(sf3.StoreItems.length)
		}

		// A 2025 listing can be bought from storefront 3 by a newer build — the half a
		// listing-only swap breaks. `findStoreItem` resolves the purchase through the same
		// build-aware path the listing does, so an item on the page is an item that can be bought.
		const listing = sf32025.StoreItems.find((i) => i.PurchasableItemId === NEWER_ONLY.id)
		expect(listing).toBeDefined()
		const bought = await exports.default.fetch(`${ORIGIN}/api/storefronts/v2/buyItem`, {
			method: 'POST',
			headers: { ...(await at('20250718.01')), 'Content-Type': 'application/json' },
			body: JSON.stringify({
				StorefrontType: 3,
				PurchasableItemId: NEWER_ONLY.id,
				CurrencyType: 2,
				RequestedPrice: NEWER_ONLY.price,
			}),
		})
		expect(bought.status).toBe(200)

		// The SAME id is not for sale to an old build: its store is the 2023 one, which numbers
		// its items differently and does not list it.
		const refused = await exports.default.fetch(`${ORIGIN}/api/storefronts/v2/buyItem`, {
			method: 'POST',
			headers: { ...(await at('20230414')), 'Content-Type': 'application/json' },
			body: JSON.stringify({
				StorefrontType: 3,
				PurchasableItemId: NEWER_ONLY.id,
				CurrencyType: 2,
				RequestedPrice: NEWER_ONLY.price,
			}),
		})
		expect(refused.status).toBe(404)

		// And the 2023 store's own items still buy for the old build exactly as they always did.
		const legacyBuy = await exports.default.fetch(`${ORIGIN}/api/storefronts/v2/buyItem`, {
			method: 'POST',
			headers: { ...(await at('20230414')), 'Content-Type': 'application/json' },
			body: JSON.stringify({
				StorefrontType: 3,
				PurchasableItemId: SF3_ITEM.id,
				CurrencyType: 2,
				RequestedPrice: SF3_ITEM.price,
			}),
		})
		expect(legacyBuy.status).toBe(200)
	})

	test('sf3 is the frozen 2023 store; sf3-2025 is the 2025 dump with its sale stripped', async () => {
		// Two versions of ONE store: both report storefront 3, because the client asks for 3
		// either way.
		expect(sf3.StorefrontType).toBe(3)
		expect(sf32025.StorefrontType).toBe(3)

		// sf3 is frozen — nothing regenerates it. What it was when it was cut: no equipment (skins
		// are awarded from weekly challenges), the discount expressed only in `SubscriberPrices`,
		// ids unique.
		expect(sf3.SubscriberDiscountPercent).toBe(0)
		expect(
			sf3.StoreItems.filter((i) => (i.GiftDrop.EquipmentModificationGuid ?? '') !== '')
		).toEqual([])

		// sf3-2025 is `Watch_EnumValue_3.json` — the live game's storefront 3 — listing for
		// listing, with its verbatim repeats collapsed. Everything the dump says about an item is
		// in the file: its id, its list price, its subscriber price, its gift drop.
		expect(sf32025.StoreItems.length).toBeGreaterThan(dumpListings.length)
		expect(sf32025.StoreItems.length).toBeGreaterThan(sf3.StoreItems.length)
		const stripSale = (prices: Array<{ StorefrontSaleData: unknown }> | null) =>
			prices?.map((p) => ({ ...p, StorefrontSaleData: null })) ?? null
		for (const [i, listing] of dumpListings.entries()) {
			const served = sf32025.StoreItems[i]!
			expect(served.PurchasableItemId, String(listing.PurchasableItemId)).toBe(
				listing.PurchasableItemId
			)
			// A skin's or a consumable's thumbnail is blanked — the dump names a PNG per item that
			// this server does not have — and a drop with Context -1 (the hair dyes and the dice
			// skins) is served with Context 0. Nothing else about a drop changes.
			const blanked =
				listing.GiftDrop.EquipmentModificationGuid !== '' ||
				listing.GiftDrop.ConsumableItemDesc !== ''
			const expectedDrop = {
				...listing.GiftDrop,
				Context: listing.GiftDrop.Context === -1 ? 0 : listing.GiftDrop.Context,
			}
			expect(served.GiftDrop).toEqual(
				blanked ? { ...expectedDrop, ThumbnailImageName: '' } : expectedDrop
			)
			// The other edit to a listing: the dump was taken mid-sale (80% off nearly everything,
			// no end date), and the client posts the sale price it computes — which this server,
			// which knows only list prices, would refuse as "Price has changed". The `Price` beside
			// it is the list price and stands.
			expect(served.Prices).toEqual(stripSale(listing.Prices))
			expect(served.SubscriberPrices).toEqual(stripSale(listing.SubscriberPrices))
		}
		expect(sf32025.SubscriberDiscountPercent).toBe(storeDump.SubscriberDiscountPercent)

		// After the dump's listings: the equipment skins the game's own store never sold, from
		// `skins.json`, each a listing of its own in the dump's skin shape — rarity 50 and priced
		// from it (the store's own rarity-50 skins run 1000-6000), numbered from a million in
		// capture order. A capture guid the store lists is NOT added again: the capture's names
		// and rarities are wrong wherever the two can be compared, so the listing is the record.
		const dumpSkins = new Set(
			dumpListings.map((l) => l.GiftDrop.EquipmentModificationGuid).filter((g) => g !== '')
		)
		const unlisted = skinsJson.filter((sk) => !dumpSkins.has(sk.ModificationGuid))
		expect(unlisted.length).toBeGreaterThan(100)
		// A gold skin is the one appended listing that differs from `unlistedSkinListing`: its
		// price, checked on its own below.
		const tail = sf32025.StoreItems.slice(dumpListings.length)
		const goldPrice = { CurrencyType: 2, Price: GOLD_SKIN_PRICE, StorefrontSaleData: null }
		const gilded = (l: StoreListing): StoreListing =>
			isGoldSkin(l) ? { ...l, Prices: [goldPrice], SubscriberPrices: [goldPrice] } : l
		expect(tail).toEqual(
			unlisted.map((sk, i) => gilded(unlistedSkinListing(sk, UNLISTED_SKIN_ID_BASE + i)))
		)
		expect(tail[0]).toMatchObject({
			GiftDrop: { Rarity: UNLISTED_SKIN_RARITY, EquipmentPrefabName: unlisted[0]!.PrefabName },
			Prices: [{ CurrencyType: 2, Price: 3000, StorefrontSaleData: null }],
			SubscriberPrices: [{ CurrencyType: 2, Price: 2700, StorefrontSaleData: null }],
		})
		expect(sf32025.StoreItems).toHaveLength(dumpListings.length + unlisted.length)
		// Every skin the capture knows is now sold by this store, once — and no skin, the game's
		// own included, names a thumbnail.
		const soldSkins = storeListings.filter((i) => i.GiftDrop.EquipmentModificationGuid !== '')
		const soldGuids = soldSkins.map((i) => i.GiftDrop.EquipmentModificationGuid)
		expect(new Set(soldGuids).size).toBe(soldGuids.length)
		expect(skinsJson.every((sk) => soldGuids.includes(sk.ModificationGuid))).toBe(true)
		expect(soldSkins.every((i) => i.GiftDrop.ThumbnailImageName === '')).toBe(true)
		expect(soldSkins.length).toBeGreaterThan(unlisted.length)
		// A "(Gold)" skin — thirteen, all from the capture — is a prestige item: 5,000,000 tokens,
		// the same for a subscriber, no sale. A "(Gold)" AVATAR item is priced as the dump has it.
		const goldSkins = soldSkins.filter((i) => i.GiftDrop.FriendlyName.includes('(Gold)'))
		expect(goldSkins.length).toBeGreaterThan(10)
		for (const g of goldSkins) {
			expect(g.Prices, g.GiftDrop.FriendlyName).toEqual([goldPrice])
			expect(g.SubscriberPrices, g.GiftDrop.FriendlyName).toEqual([goldPrice])
		}
		expect(
			soldSkins.filter((i) => !isGoldSkin(i)).every((i) => i.Prices[0]?.Price !== GOLD_SKIN_PRICE)
		).toBe(true)
		const goldAvatar = storeListings.find(
			(i) => i.GiftDrop.AvatarItemDesc !== '' && i.GiftDrop.FriendlyName.includes('(Gold)')
		)!
		expect(goldAvatar.Prices[0]?.Price).not.toBe(GOLD_SKIN_PRICE)

		// Consumables likewise; avatar items keep theirs.
		const consumables = storeListings.filter((i) => i.GiftDrop.ConsumableItemDesc !== '')
		expect(consumables.length).toBeGreaterThan(200)
		expect(consumables.every((i) => i.GiftDrop.ThumbnailImageName === '')).toBe(true)
		expect(
			storeListings.filter(
				(i) => i.GiftDrop.AvatarItemDesc !== '' && (i.GiftDrop.ThumbnailImageName ?? '') !== ''
			).length
		).toBeGreaterThan(2000)
		// The dump's `NextUpdate` was the real store's next rotation, long past; the client
		// refetches after it, and this file is regenerated by hand.
		expect(sf32025.NextUpdate > '2200').toBe(true)

		// Ids are unique within each file: `findStoreItem` resolves a purchase by id, so a
		// repeated id would mean array order decides what the player bought.
		for (const [label, file] of [
			['sf3', sf3],
			['sf3-2025', sf32025],
		] as const) {
			const ids = file.StoreItems.map((i) => i.PurchasableItemId)
			expect(new Set(ids).size, label).toBe(ids.length)
		}

		// A known listing, at the dump's own numbers: Candy Apples, 1801, 95 tokens, 85 for a
		// subscriber — NOT the 2023 store's 2184, and NOT a price computed from its rarity.
		const apples = sf32025.StoreItems.find((i) => i.GiftDrop.FriendlyName === 'Candy Apples')
		expect(apples).toMatchObject({
			PurchasableItemId: 1801,
			GiftDrop: { GiftDropId: 3361, ConsumableItemDesc: 'EmPvh3I6L0uK_1i8Wy_ylQ' },
			Prices: [{ CurrencyType: 2, Price: 95, StorefrontSaleData: null }],
			SubscriberPrices: [{ CurrencyType: 2, Price: 85, StorefrontSaleData: null }],
		})

		// An id with no storefront still 404s, and 1704 is gone — it was a stand-in for a store
		// that turned out to be this one.
		for (const id of [1705, 1704]) {
			const res = await exports.default.fetch(`${ORIGIN}/api/storefronts/v3/giftdropstore/${id}`)
			expect(res.status, String(id)).toBe(404)
		}
	})

	// Item 73 in sf3.json — "Bowtie (White)", 450 RecCenterTokens (CurrencyType 2).
	test('POST /api/storefronts/v2/buyItem 401s without a token', async () => {
		const res = await exports.default.fetch(`${ORIGIN}/api/storefronts/v2/buyItem`, {
			method: 'POST',
			headers: { 'Content-Type': 'application/json' },
			body: JSON.stringify({
				StorefrontType: 3,
				PurchasableItemId: SF3_ITEM.id,
				CurrencyType: 2,
				RequestedPrice: SF3_ITEM.price,
			}),
		})
		expect(res.status).toBe(401)
	})

	test('POST /api/storefronts/v2/buyItem debits, grants the item, and hands back a gift box', async () => {
		// Account 20: fresh, so its first balance touch grants the 10000 default.
		await drainFrames()
		const res = await exports.default.fetch(`${ORIGIN}/api/storefronts/v2/buyItem`, {
			method: 'POST',
			headers: { ...(await bearer('20')), 'Content-Type': 'application/json' },
			body: JSON.stringify({
				StorefrontType: 3,
				PurchasableItemId: SF3_ITEM.id,
				CurrencyType: 2,
				RequestedPrice: SF3_ITEM.price,
			}),
		})
		expect(res.status).toBe(200)
		const body = (await res.json()) as {
			Balance: number
			CurrencyType: number
			BalanceType: number
			BalanceUpdates: Array<{
				Data: Array<{ Id: number; AvatarItemDesc: string }>
			}>
		}
		// `Balance` is the change applied (the negated price), not the resulting total.
		expect(body.Balance).toBe(-SF3_ITEM.price)
		expect(body.CurrencyType).toBe(2)
		expect(body.BalanceType).toBe(-2)
		const gift = body.BalanceUpdates[0].Data[0]
		expect(gift.AvatarItemDesc).not.toBe('')
		expect(gift.Id).toBeGreaterThan(0)

		// A purchase pushes StorefrontBalancePurchase, which SETS one (CurrencyType, Platform)
		// bucket to an absolute value: `Balance` is the resulting total (10000 - 450) and `Delta`
		// is display-only. The bucket key is `Platform`, and it MUST be the -2 the balance
		// endpoint reports below — the client sums its buckets, so a frame naming any other
		// platform (or spelling the key `BalanceType`, which the client's decoder drops) invents
		// a second balance beside the real one. That is what showed a live player 34,100 tokens
		// after spending 900 of 17,500, then 33,200 once the body's -900 landed.
		expect(await drainFrames()).toEqual([
			{
				accountId: 20,
				notificationType: NotificationType.StorefrontBalancePurchase,
				payload: {
					// 1400 = CommercePurchase; -2 = NonPurchasedNotUsableInP2P, the only bucket we use.
					BalanceAddType: 1400,
					Delta: -SF3_ITEM.price,
					Balance: DEFAULT_STARTING_TOKENS - SF3_ITEM.price,
					Platform: -2,
					CurrencyType: 2,
				},
			},
		])

		// The balance endpoint reflects the debit (this is the resulting total, 10000 - 450).
		const bal = await exports.default.fetch(`${ORIGIN}/api/storefronts/v4/balance/2`, {
			headers: await bearer('20'),
		})
		expect(await bal.json()).toEqual([
			{ CurrencyType: 2, Platform: -2, Balance: DEFAULT_STARTING_TOKENS - SF3_ITEM.price },
		])

		// The item is now owned — it leads the v4/items list (owned items prepend the catalog).
		const items = await exports.default.fetch(`${ORIGIN}/api/avatar/v4/items`, {
			headers: await bearer('20'),
		})
		const list = (await items.json()) as Array<{ avatarItemDesc: string; friendlyName: string }>
		expect(list[0].friendlyName).toBe(SF3_ITEM.name)
		expect(list[0].avatarItemDesc).toBe(gift.AvatarItemDesc)

		// And a pending gift box is waiting to be opened.
		const gifts = await exports.default.fetch(`${ORIGIN}/api/avatar/v2/gifts`, {
			headers: await bearer('20'),
		})
		const pending = (await gifts.json()) as Array<{ Id: number; AvatarItemDesc: string }>
		expect(pending).toHaveLength(1)
		expect(pending[0].Id).toBe(gift.Id)
		expect(pending[0].AvatarItemDesc).toBe(gift.AvatarItemDesc)
	})

	test('POST /api/storefronts/v2/buyItem grants a consumable and stacks on re-buy', async () => {
		// Item 574 (Supreme Pizza) in storefront 300 is a consumable — its gift-drop
		// carries a ConsumableItemDesc, not an AvatarItemDesc.
		const consumableDesc = 'wUCIKdJSvEmiQHYMyx4X4w'
		const buy = async () =>
			exports.default.fetch(`${ORIGIN}/api/storefronts/v2/buyItem`, {
				method: 'POST',
				headers: { ...(await bearer('25')), 'Content-Type': 'application/json' },
				body: JSON.stringify({
					StorefrontType: 300,
					PurchasableItemId: 574,
					CurrencyType: 2,
					RequestedPrice: 95,
				}),
			})

		const res = await buy()
		expect(res.status).toBe(200)
		const body = (await res.json()) as {
			Balance: number
			BalanceUpdates: Array<{
				Data: Array<{
					ConsumableItemDesc: string
					AvatarItemDesc: string
					AvatarItemType: number | null
					FromPlayerId: number
				}>
			}>
		}
		// `Balance` is the change applied (the negated price), not the resulting total.
		expect(body.Balance).toBe(-95)
		const drop = body.BalanceUpdates[0].Data[0]
		expect(drop.ConsumableItemDesc).toBe(consumableDesc)
		expect(drop.AvatarItemDesc).toBe('')
		// A consumable's AvatarItemType is NULL, as the store lists it — never 0, which the
		// client reads as an avatar item and fails on ("can't find avatar item").
		expect(drop.AvatarItemType).toBeNull()
		// A self-buy is attributed to the "Coach" system account (id 1).
		expect(drop.FromPlayerId).toBe(1)

		// It's owned as an unlocked consumable — one instance, count 1.
		const unlocked = async () => {
			const r = await exports.default.fetch(`${ORIGIN}/api/consumables/v2/getUnlocked`, {
				headers: await bearer('25'),
			})
			expect(r.status).toBe(200)
			return (await r.json()) as Array<{
				Ids: number[]
				CreatedAts: string[]
				ConsumableItemDesc: string
				Count: number
				InitialCount: number
				IsActive: boolean
				IsTransferable: boolean
			}>
		}
		const first = await unlocked()
		expect(first).toHaveLength(1)
		expect(first[0].ConsumableItemDesc).toBe(consumableDesc)
		expect(first[0].Count).toBe(1)
		expect(first[0].InitialCount).toBe(1)
		expect(first[0].Ids).toHaveLength(1)
		expect(first[0].CreatedAts).toHaveLength(1)
		expect(first[0].IsActive).toBe(false)
		expect(first[0].IsTransferable).toBe(false)

		// A consumable is not an avatar item — it does not show up in v4/items.
		const items = await exports.default.fetch(`${ORIGIN}/api/avatar/v4/items`, {
			headers: await bearer('25'),
		})
		const list = (await items.json()) as Array<{ friendlyName: string }>
		expect(list.every((i) => i.friendlyName !== 'Supreme Pizza')).toBe(true)

		// Buying it again stacks: a second instance, count summed to 2.
		expect((await buy()).status).toBe(200)
		const second = await unlocked()
		expect(second).toHaveLength(1)
		expect(second[0].Count).toBe(2)
		expect(second[0].InitialCount).toBe(2)
		expect(second[0].Ids).toHaveLength(2)
		expect(second[0].CreatedAts).toHaveLength(2)
	})

	// The equipment-purchase test that lived here is gone: skins are awarded from weekly
	// challenges rather than sold, so no storefront lists one and the bulk bag will not resolve
	// one off the catalog either. Equipment GRANTING is still covered — the weekly challenge
	// reward path grants a skin and reads it back through `getUnlocked`.

	test('POST /api/equipment/v1/update favourites from the client’s own body', async () => {
		// The body verbatim as the client sends it — a full echo of the entry it was served,
		// of which only `Favorited` is read.
		const post = async (favorited: boolean, sub = '33') =>
			exports.default.fetch(`${ORIGIN}/api/equipment/v1/update`, {
				method: 'POST',
				headers: { ...(await bearer(sub)), 'Content-Type': 'application/json' },
				body: JSON.stringify([
					{
						PrefabName: '[ShareCamera]',
						ModificationGuid: 'g5u0weNLmkCLeUXFUVn74Q',
						FriendlyName: 'Camera Skin (Comic)',
						Tooltip: 'ShareCamera Comic Debug: 2121',
						Rarity: 5,
						Favorited: favorited,
					},
				]),
			})

		// Nothing owned yet: the guid matches no row, so this is a silent no-op, not an error.
		expect((await post(true)).status).toBe(200)

		await grantEquipment(env.DB, 33, {
			PrefabName: '[ShareCamera]',
			ModificationGuid: 'g5u0weNLmkCLeUXFUVn74Q',
			FriendlyName: 'Camera Skin (Comic)',
			Tooltip: 'ShareCamera Comic Debug: 2121',
			Rarity: 5,
			PlatformMask: -1,
			Favorited: false,
		})
		const owned = async () => {
			const res = await exports.default.fetch(`${ORIGIN}/api/equipment/v2/getUnlocked`, {
				headers: await bearer('33'),
			})
			return (await res.json()) as Array<{ ModificationGuid: string; Favorited: boolean }>
		}
		expect((await owned())[0]?.Favorited).toBe(false)

		expect((await post(true)).status).toBe(200)
		expect((await owned())[0]?.Favorited).toBe(true)
		expect((await post(false)).status).toBe(200)
		expect((await owned())[0]?.Favorited).toBe(false)
	})

	test('equipment/v1/update 401s without a token, 400s on a non-array body (PUT and POST)', async () => {
		for (const method of ['PUT', 'POST'] as const) {
			const anon = await exports.default.fetch(`${ORIGIN}/api/equipment/v1/update`, {
				method,
				headers: { 'Content-Type': 'application/json' },
				body: '[]',
			})
			expect(anon.status).toBe(401)

			const bad = await exports.default.fetch(`${ORIGIN}/api/equipment/v1/update`, {
				method,
				headers: { ...(await bearer('32')), 'Content-Type': 'application/json' },
				body: '{}',
			})
			expect(bad.status).toBe(400)
		}
	})

	test('POST /api/storefronts/v2/buyItem 409s when the sent price no longer matches', async () => {
		const res = await exports.default.fetch(`${ORIGIN}/api/storefronts/v2/buyItem`, {
			method: 'POST',
			headers: { ...(await bearer('21')), 'Content-Type': 'application/json' },
			body: JSON.stringify({
				StorefrontType: 3,
				PurchasableItemId: SF3_ITEM.id,
				CurrencyType: 2,
				RequestedPrice: 1,
			}),
		})
		expect(res.status).toBe(409)
		// Nothing was charged.
		const bal = await exports.default.fetch(`${ORIGIN}/api/storefronts/v4/balance/2`, {
			headers: await bearer('21'),
		})
		expect(await bal.json()).toEqual([{ CurrencyType: 2, Platform: -2, Balance: 10000 }])
	})

	// sf300's item 2089 is 95 tokens in `Prices` and 85 in `SubscriberPrices`. A subscriber's
	// client applies the Plus discount itself, but not to every item, so the server takes any
	// price in the band [85, 95] from a subscriber and charges what they asked to pay.
	const buy2263 = async (headers: Record<string, string>, RequestedPrice: number) =>
		exports.default.fetch(`${ORIGIN}/api/storefronts/v2/buyItem`, {
			method: 'POST',
			headers: { ...headers, 'Content-Type': 'application/json' },
			body: JSON.stringify({
				StorefrontType: 300,
				PurchasableItemId: 2089,
				CurrencyType: 2,
				RequestedPrice,
				CouponConsumablePlayerMappingId: null,
				Gift: null,
			}),
		})

	test('POST /api/storefronts/v2/buyItem charges a subscriber the SubscriberPrices entry', async () => {
		await drainFrames()
		const res = await buy2263(await bearer('322', ['gameClient'], undefined, true), 85)
		expect(res.status).toBe(200)
		expect(((await res.json()) as { Balance: number }).Balance).toBe(-85)
		const bal = await exports.default.fetch(`${ORIGIN}/api/storefronts/v4/balance/2`, {
			headers: await bearer('322'),
		})
		expect(await bal.json()).toEqual([{ CurrencyType: 2, Platform: -2, Balance: 10000 - 85 }])
	})

	test('POST /api/storefronts/v2/buyItem takes 10% off from a subscriber when the catalog lists no discount', async () => {
		// sf3's item 2184 is 95 in BOTH lists, but a subscriber's client may still post
		// floor(95 * 0.9) = 85.
		const res = await exports.default.fetch(`${ORIGIN}/api/storefronts/v2/buyItem`, {
			method: 'POST',
			headers: {
				...(await bearer('325', ['gameClient'], undefined, true)),
				'Content-Type': 'application/json',
			},
			body: JSON.stringify({
				StorefrontType: 3,
				PurchasableItemId: 2184,
				CurrencyType: 2,
				RequestedPrice: 85,
				CouponConsumablePlayerMappingId: null,
				Gift: null,
			}),
		})
		expect(res.status).toBe(200)
		expect(((await res.json()) as { Balance: number }).Balance).toBe(-85)
	})

	test('POST /api/storefronts/v2/buyItem charges a subscriber the full price when their client sends it', async () => {
		// sf3's item 2208 is 150 in both lists and the live client posts 150 for a subscriber:
		// not every item is discounted, so the full price has to stay buyable by a subscriber.
		const res = await exports.default.fetch(`${ORIGIN}/api/storefronts/v2/buyItem`, {
			method: 'POST',
			headers: {
				...(await bearer('326', ['gameClient'], undefined, true)),
				'Content-Type': 'application/json',
			},
			body: JSON.stringify({
				StorefrontType: 3,
				PurchasableItemId: 2208,
				CurrencyType: 2,
				RequestedPrice: 150,
				CouponConsumablePlayerMappingId: null,
				Gift: null,
			}),
		})
		expect(res.status).toBe(200)
		expect(((await res.json()) as { Balance: number }).Balance).toBe(-150)
		const bal = await exports.default.fetch(`${ORIGIN}/api/storefronts/v4/balance/2`, {
			headers: await bearer('326'),
		})
		expect(await bal.json()).toEqual([{ CurrencyType: 2, Platform: -2, Balance: 10000 - 150 }])
	})

	test('POST /api/storefronts/v2/buyItem 409s a subscriber below the discount band', async () => {
		const res = await buy2263(await bearer('323', ['gameClient'], undefined, true), 84)
		expect(res.status).toBe(409)
		// …and above it: a made-up price is a mismatch in either direction.
		const over = await buy2263(await bearer('323', ['gameClient'], undefined, true), 96)
		expect(over.status).toBe(409)
	})

	test('POST /api/storefronts/v2/buyItem 409s a non-subscriber posting the subscriber price', async () => {
		const res = await buy2263(await bearer('324'), 85)
		expect(res.status).toBe(409)
		const ok = await buy2263(await bearer('324'), 95)
		expect(ok.status).toBe(200)
	})

	/** Seed a real account row, so a gift naming this player has somewhere to land. */
	const seedAccount = async (accountId: number, username: string) => {
		await env.DB.prepare('INSERT OR IGNORE INTO account (data) VALUES (?1)')
			.bind(JSON.stringify({ accountId, username, displayName: username }))
			.run()
	}

	/**
	 * Buy one sf3 item with a `Gift` block, as the client posts it. This used to buy an equipment
	 * skin; skins are awarded from weekly challenges rather than sold, so the store no longer
	 * lists one and these tests use an ordinary avatar item — they are about GIFTING either way.
	 */
	const giftBackpack = async (sub: string, gift: Record<string, unknown> | null) =>
		exports.default.fetch(`${ORIGIN}/api/storefronts/v2/buyItem`, {
			method: 'POST',
			headers: { ...(await bearer(sub)), 'Content-Type': 'application/json' },
			body: JSON.stringify({
				StorefrontType: 3,
				PurchasableItemId: SF3_ITEM.id,
				CurrencyType: 2,
				RequestedPrice: SF3_ITEM.price,
				CouponConsumablePlayerMappingId: null,
				Gift: gift,
			}),
		})

	const pendingGifts = async (sub: string) => {
		const res = await exports.default.fetch(`${ORIGIN}/api/avatar/v2/gifts`, {
			headers: await bearer(sub),
		})
		expect(res.status).toBe(200)
		return (await res.json()) as Array<Record<string, unknown>>
	}

	test('POST /api/storefronts/v2/buyItem charges the buyer and hands the item to the gift’s receiver', async () => {
		await seedAccount(205, 'GiftReceiver')
		await drainFrames()
		const res = await giftBackpack('330', {
			ToPlayerId: 205,
			Message: 'hello this is a message',
			Anonymous: false,
			GiftContext: 500,
		})
		expect(res.status).toBe(200)
		// The buyer pays — `Balance` is their change — even though nothing lands on them.
		expect(((await res.json()) as { Balance: number }).Balance).toBe(-SF3_ITEM.price)
		const bal = await exports.default.fetch(`${ORIGIN}/api/storefronts/v4/balance/2`, {
			headers: await bearer('330'),
		})
		expect(await bal.json()).toEqual([
			{ CurrencyType: 2, Platform: -2, Balance: DEFAULT_STARTING_TOKENS - SF3_ITEM.price },
		])

		// The item and its box are the RECEIVER's; the buyer keeps neither. An avatar item lands
		// in the inventory rather than the equipment list — `v4/items` leads with what is owned.
		expect(await pendingGifts('330')).toEqual([])
		const ownedBy = async (sub: string) => {
			const res = await exports.default.fetch(`${ORIGIN}/api/avatar/v4/items`, {
				headers: await bearer(sub),
			})
			return (await res.json()) as Array<{ avatarItemDesc: string; friendlyName: string }>
		}
		expect((await ownedBy('330'))[0]?.friendlyName).not.toBe(SF3_ITEM.name)
		expect((await ownedBy('205'))[0]?.friendlyName).toBe(SF3_ITEM.name)
		const [gift, ...others] = await pendingGifts('205')
		expect(others).toEqual([])
		// The box outlives the request, so it carries who sent it and why — the receiver may
		// only ever meet it in this list.
		expect(gift?.FromPlayerId).toBe(330)
		expect(gift?.GiftContext).toBe(500)
		expect(gift?.Message).toBe('hello this is a message')

		// The receiver has no response to read, so the box is pushed to them.
		const frames = await drainFrames()
		const received = frames.find(
			(f) => f.notificationType === NotificationType.GiftPackageReceivedImmediate
		)
		expect(received?.accountId).toBe(205)
		expect(received?.payload).toMatchObject({
			Id: gift?.Id,
			FromPlayerId: 330,
			GiftContext: 500,
			Message: 'hello this is a message',
			// An avatar item, so the equipment half of the drop is empty and the desc carries it.
			EquipmentModificationGuid: '',
		})
		// …and the spend frame still goes to the BUYER, who is the one who paid.
		const spend = frames.find(
			(f) => f.notificationType === NotificationType.StorefrontBalancePurchase
		)
		expect(spend?.accountId).toBe(330)
	})

	test('POST /api/storefronts/v2/buyItem attributes an anonymous gift to Coach', async () => {
		await seedAccount(206, 'AnonReceiver')
		await drainFrames()
		const res = await giftBackpack('331', {
			ToPlayerId: 206,
			Message: 'guess who',
			Anonymous: true,
		})
		expect(res.status).toBe(200)
		// Anonymous hides the sender from the box, it does not withhold the gift: id 1 is Coach.
		const [gift] = await pendingGifts('206')
		expect(gift?.FromPlayerId).toBe(1)
		expect(gift?.Message).toBe('guess who')
		const received = (await drainFrames()).find(
			(f) => f.notificationType === NotificationType.GiftPackageReceivedImmediate
		)
		expect(received?.payload).toMatchObject({ FromPlayerId: 1 })
	})

	test('POST /api/storefronts/v2/buyItem masks swears in the gift message', async () => {
		await seedAccount(208, 'MaskedReceiver')
		await drainFrames()
		const res = await giftBackpack('334', {
			ToPlayerId: 208,
			Message: 'happy birthday you shit',
			Anonymous: false,
			GiftContext: 500,
		})
		expect(res.status).toBe(200)
		// The buyer writes it and someone else reads it, so it is filtered like any other
		// player-typed string — masked per character, never refused.
		const masked = 'happy birthday you ****'
		expect(
			((await res.json()) as { BalanceUpdates: Array<{ Data: Array<{ Message: string }> }> })
				.BalanceUpdates[0]?.Data[0]?.Message
		).toBe(masked)
		const [gift] = await pendingGifts('208')
		expect(gift?.Message).toBe(masked)
		const received = (await drainFrames()).find(
			(f) => f.notificationType === NotificationType.GiftPackageReceivedImmediate
		)
		expect(received?.payload).toMatchObject({ Message: masked })
	})

	test('POST /api/storefronts/v2/buyItem caps the gift message at the client’s 150 characters', async () => {
		await seedAccount(209, 'LongNoteReceiver')
		await drainFrames()
		// The client's input field stops at 150, so a 200-character note is a client that
		// ignored its own limit — the overrun is dropped, the purchase still goes through.
		const long = 'a'.repeat(140) + 'b'.repeat(60)
		const res = await giftBackpack('335', { ToPlayerId: 209, Message: long, Anonymous: false })
		expect(res.status).toBe(200)
		const [gift] = await pendingGifts('209')
		expect(gift?.Message).toBe(long.slice(0, 150))
		expect((gift?.Message as string).length).toBe(150)
		// An emoji straddling the cut is dropped whole rather than stored as half a character.
		const emoji = `${'x'.repeat(149)}😀tail`
		const second = await giftBackpack('336', { ToPlayerId: 209, Message: emoji, Anonymous: false })
		expect(second.status).toBe(200)
		const notes = (await pendingGifts('209')).map((box) => box.Message)
		expect(notes).toContain('x'.repeat(149))
	})

	test('POST /api/storefronts/v2/buyItem 404s a gift to a player that does not exist', async () => {
		await drainFrames()
		const res = await giftBackpack('332', { ToPlayerId: 999999, Message: 'hi', Anonymous: false })
		expect(res.status).toBe(404)
		expect(await res.json()).toEqual({ error: 'No such player to gift to' })
		// Refused before the debit: the buyer still has every token, and nothing was pushed.
		expect(
			await getBalance(env.DB, 332, CurrencyType.RecCenterTokens, DEFAULT_STARTING_TOKENS)
		).toBe(10000)
		expect(await drainFrames()).toEqual([])
	})

	test('POST /api/storefronts/v2/buyItem gifting to yourself is just a purchase', async () => {
		await seedAccount(333, 'SelfGifter')
		await drainFrames()
		const res = await giftBackpack('333', { ToPlayerId: 333, Message: 'treat', Anonymous: false })
		expect(res.status).toBe(200)
		const [gift] = await pendingGifts('333')
		expect(gift?.FromPlayerId).toBe(333)
		// No hub gift frame: the buyer read the box out of the response.
		expect(
			(await drainFrames()).filter(
				(f) => f.notificationType === NotificationType.GiftPackageReceivedImmediate
			)
		).toEqual([])
	})

	test('POST /api/storefronts/v2/buyItem 404s for an unknown item', async () => {
		const res = await exports.default.fetch(`${ORIGIN}/api/storefronts/v2/buyItem`, {
			method: 'POST',
			headers: { ...(await bearer('22')), 'Content-Type': 'application/json' },
			body: JSON.stringify({
				StorefrontType: 3,
				PurchasableItemId: 9999999,
				CurrencyType: 2,
				RequestedPrice: SF3_ITEM.price,
			}),
		})
		expect(res.status).toBe(404)
	})

	test('POST /api/storefronts/v2/buyItem 400s when the player cannot afford it', async () => {
		// Drain account 23 to 0 first, then try to buy.
		expect(
			await spendCurrency(env.DB, 23, CurrencyType.RecCenterTokens, 10_000, DEFAULT_STARTING_TOKENS)
		).toBe(true)
		const res = await exports.default.fetch(`${ORIGIN}/api/storefronts/v2/buyItem`, {
			method: 'POST',
			headers: { ...(await bearer('23')), 'Content-Type': 'application/json' },
			body: JSON.stringify({
				StorefrontType: 3,
				PurchasableItemId: SF3_ITEM.id,
				CurrencyType: 2,
				RequestedPrice: SF3_ITEM.price,
			}),
		})
		expect(res.status).toBe(400)
		// Still owns nothing (only the default catalog in v4/items).
		const items = await exports.default.fetch(`${ORIGIN}/api/avatar/v4/items`, {
			headers: await bearer('23'),
		})
		const list = (await items.json()) as Array<{ friendlyName: string }>
		expect(list.every((i) => i.friendlyName !== 'Bowtie (White)')).toBe(true)
	})

	// ---- POST /api/items/bulkpurchase ------------------------------------------------
	// The shopping bag: many lines, one storefront, one currency, one debit. Its response is
	// NOT buyItem's — it is the `{ Success, Error, error_id, Value }` envelope, `Value.Balance`
	// is the RESULTING total rather than the change, and each `BalanceUpdates` entry carries
	// its own `UpdateResponse` (0 OK, 2 NotEnoughCredit, 4 NoItemAvailable, 5
	// CouponNotApplicable, 6 RequestedPriceDoesNotMatch, 7 RequestedAmountNotAllowed).

	/** The shape every bulk-purchase response answers with. */
	type BulkBody = {
		Success: boolean
		Error: string | null
		error_id: string | null
		Value: {
			Balance: number
			CurrencyType: number
			Platform: number
			BalanceUpdates: Array<{
				UpdateResponse: number
				Data: {
					GiftPackage: Record<string, unknown> | null
					PurchasableItemId: number | null
					CustomAvatarItem: Record<string, unknown> | null
				}
			}>
		} | null
	}

	/** A bag line, in the shape the client posts one. */
	const line = (numberId: number, requestedPrice: number, extra: Record<string, unknown> = {}) => ({
		ItemPurchaseMethodId: { Type: 0, NumberId: numberId, Guid: null },
		RequestedPrice: requestedPrice,
		Gift: null,
		CouponConsumablePlayerMappingId: null,
		DuplicateItemCount: 1,
		...extra,
	})

	const bulkPurchase = async (sub: string, body: Record<string, unknown>) =>
		exports.default.fetch(`${ORIGIN}/api/items/bulkpurchase`, {
			method: 'POST',
			headers: { ...(await bearer(sub)), 'Content-Type': 'application/json' },
			body: JSON.stringify({
				StorefrontType: 3,
				CurrencyType: 2,
				BypassGiftPackages: false,
				AllowPartialSuccess: true,
				ShoppingBagId: null,
				...body,
			}),
		})

	/** The `UpdateResponse` of every entry, in request order. */
	const codes = (body: BulkBody) => body.Value!.BalanceUpdates.map((u) => u.UpdateResponse)

	test('POST /api/items/bulkpurchase 401s without a token', async () => {
		const res = await exports.default.fetch(`${ORIGIN}/api/items/bulkpurchase`, {
			method: 'POST',
			headers: { 'Content-Type': 'application/json' },
			body: JSON.stringify({
				PurchaseItemRequests: [line(SF3_ITEM.id, SF3_ITEM.price)],
				StorefrontType: 3,
				CurrencyType: 2,
			}),
		})
		expect(res.status).toBe(401)
	})

	test('POST /api/items/bulkpurchase debits the bag once and grants every line', async () => {
		// Account 90: fresh, so its first balance touch grants the 10000 default. Three donuts
		// (a consumable, 100 each — consumables are the only thing that stacks) and one avatar
		// item. The prices come from the fixtures rather than being written out: sf3 is generated
		// now, so a repriced rarity tier must not silently invalidate the arithmetic.
		await drainFrames()
		const res = await bulkPurchase('90', {
			PurchaseItemRequests: [
				line(2182, 100, { DuplicateItemCount: 3 }),
				line(SF3_ITEM.id, SF3_ITEM.price),
			],
			ShoppingBagId: 'bag-1',
		})
		expect(res.status).toBe(200)
		const body = (await res.json()) as BulkBody
		expect(body.Success).toBe(true)
		expect(body.Error).toBe(null)
		expect(body.error_id).toBe(null)
		const value = body.Value!
		// `Balance` here is the RESULTING total, unlike buyItem's change. The
		// bucket is -2, the one `GET /balance` reports — the reference server's 4
		// (RecNetPurchased) would read as a second balance the client adds to the real one.
		expect(value.Balance).toBe(DEFAULT_STARTING_TOKENS - 300 - SF3_ITEM.price)
		expect(value.CurrencyType).toBe(2)
		expect(value.Platform).toBe(-2)

		// ONE entry per REQUESTED item — three donuts are one line, so one entry — in order.
		expect(value.BalanceUpdates).toHaveLength(2)
		expect(codes(body)).toEqual([0, 0])
		expect(value.BalanceUpdates.map((u) => u.Data.PurchasableItemId)).toEqual([2182, SF3_ITEM.id])
		expect(value.BalanceUpdates.every((u) => u.Data.CustomAvatarItem === null)).toBe(true)
		// The box each line produced, as `GiftPackage` carries it: 20 keys, the receiver in
		// `PlayerId`, a self-buy attributed to the "Coach" account (1), and the platform MASK in
		// `Platform` — the balance bucket is the `BalanceType` beside it.
		const box = value.BalanceUpdates[0].Data.GiftPackage!
		expect(Object.keys(box)).toEqual([
			'Id',
			'PlayerId',
			'FromPlayerId',
			'ConsumableItemDesc',
			'AvatarItemType',
			'AvatarItemDesc',
			'CustomAvatarItemId',
			'EquipmentPrefabName',
			'EquipmentModificationGuid',
			'CurrencyType',
			'Currency',
			'Xp',
			'GiftContext',
			'GiftRarity',
			'Message',
			'Signature',
			'IsSignatureValid',
			'Platform',
			'PlatformsToSpawnOn',
			'BalanceType',
		])
		expect(box.Id).toBeGreaterThan(0)
		expect(box.PlayerId).toBe(90)
		expect(box.FromPlayerId).toBe(1)
		expect(box.ConsumableItemDesc).not.toBe('')
		expect(box.Platform).toBe(-1)
		expect(box.BalanceType).toBe(-2)
		expect(value.BalanceUpdates[1].Data.GiftPackage!.AvatarItemDesc).not.toBe('')

		// ONE frame for the whole bag, setting the account-wide bucket to the resulting total —
		// the same total the body reports, so the two agree instead of compounding.
		expect(await drainFrames()).toEqual([
			{
				accountId: 90,
				notificationType: NotificationType.StorefrontBalancePurchase,
				payload: {
					BalanceAddType: 1400,
					Delta: -(300 + SF3_ITEM.price),
					Balance: DEFAULT_STARTING_TOKENS - 300 - SF3_ITEM.price,
					Platform: -2,
					CurrencyType: 2,
				},
			},
		])
		expect(
			await getBalance(env.DB, 90, CurrencyType.RecCenterTokens, DEFAULT_STARTING_TOKENS)
		).toBe(DEFAULT_STARTING_TOKENS - 300 - SF3_ITEM.price)

		// Everything landed: the dress is owned, all three donuts stacked into the one box's
		// grant, and each LINE left one gift box.
		const items = await exports.default.fetch(`${ORIGIN}/api/avatar/v4/items`, {
			headers: await bearer('90'),
		})
		const list = (await items.json()) as Array<{ friendlyName: string }>
		expect(list[0].friendlyName).toBe(SF3_ITEM.name)
		const unlocked = await exports.default.fetch(`${ORIGIN}/api/consumables/v2/getUnlocked`, {
			headers: await bearer('90'),
		})
		const consumables = (await unlocked.json()) as Array<{ Count: number }>
		expect(consumables[0].Count).toBe(3)
		const gifts = await exports.default.fetch(`${ORIGIN}/api/avatar/v2/gifts`, {
			headers: await bearer('90'),
		})
		const pending = (await gifts.json()) as Array<{ Id: number }>
		expect(pending.map((g) => g.Id)).toEqual(
			value.BalanceUpdates.map((u) => u.Data.GiftPackage!.Id)
		)
	})

	test('POST /api/items/bulkpurchase buys the good lines when partial success is allowed', async () => {
		// The second line's price no longer matches the catalog (200, not 1). The bag still
		// succeeds — that entry just comes back non-OK, which is what AllowPartialSuccess means.
		const res = await bulkPurchase('91', {
			PurchaseItemRequests: [line(SF3_ITEM.id, SF3_ITEM.price), line(SF3_CHEAP.id, 1)],
		})
		expect(res.status).toBe(200)
		const body = (await res.json()) as BulkBody
		expect(body.Success).toBe(true)
		expect(body.Error).toBe(null)
		expect(body.Value!.Balance).toBe(DEFAULT_STARTING_TOKENS - SF3_ITEM.price)
		// 6 = RequestedPriceDoesNotMatch. The failed line still names the item it asked for.
		expect(codes(body)).toEqual([0, 6])
		expect(body.Value!.BalanceUpdates[1].Data).toEqual({
			GiftPackage: null,
			PurchasableItemId: SF3_CHEAP.id,
			CustomAvatarItem: null,
		})
		expect(
			await getBalance(env.DB, 91, CurrencyType.RecCenterTokens, DEFAULT_STARTING_TOKENS)
		).toBe(DEFAULT_STARTING_TOKENS - SF3_ITEM.price)
	})

	test('POST /api/items/bulkpurchase charges nothing when a line fails and partial success is off', async () => {
		await drainFrames()
		const res = await bulkPurchase('92', {
			AllowPartialSuccess: false,
			PurchaseItemRequests: [line(SF3_ITEM.id, SF3_ITEM.price), line(SF3_CHEAP.id, 1)],
		})
		expect(res.status).toBe(200)
		const body = (await res.json()) as BulkBody
		expect(body.Success).toBe(false)
		expect(body.Error).toBe('Price has changed')
		expect(body.Value).toBe(null)
		// Untouched: no debit, no item, and no frame for a purchase that did not happen.
		expect(
			await getBalance(env.DB, 92, CurrencyType.RecCenterTokens, DEFAULT_STARTING_TOKENS)
		).toBe(10000)
		const items = await exports.default.fetch(`${ORIGIN}/api/avatar/v4/items`, {
			headers: await bearer('92'),
		})
		const list = (await items.json()) as Array<{ friendlyName: string }>
		expect(list.every((i) => i.friendlyName !== SF3_ITEM.name)).toBe(true)
		expect(await drainFrames()).toEqual([])
	})

	test('POST /api/items/bulkpurchase takes the lines that fit, in request order', async () => {
		// Leave account 93 with enough for the FIRST line and not both, whatever the tiers cost.
		const fitsOne = SF3_ITEM.price + SF3_CHEAP.price - 1
		await getBalance(env.DB, 93, CurrencyType.RecCenterTokens, DEFAULT_STARTING_TOKENS)
		expect(
			await spendCurrency(
				env.DB,
				93,
				CurrencyType.RecCenterTokens,
				DEFAULT_STARTING_TOKENS - fitsOne,
				DEFAULT_STARTING_TOKENS
			)
		).toBe(true)
		const res = await bulkPurchase('93', {
			PurchaseItemRequests: [
				line(SF3_ITEM.id, SF3_ITEM.price),
				line(SF3_CHEAP.id, SF3_CHEAP.price),
			],
		})
		const body = (await res.json()) as BulkBody
		expect(body.Success).toBe(true)
		expect(body.Value!.Balance).toBe(fitsOne - SF3_ITEM.price)
		// 2 = NotEnoughCredit for the line the balance no longer covered.
		expect(codes(body)).toEqual([0, 2])
		expect(body.Value!.BalanceUpdates[1].Data.GiftPackage).toBe(null)
		expect(
			await getBalance(env.DB, 93, CurrencyType.RecCenterTokens, DEFAULT_STARTING_TOKENS)
		).toBe(fitsOne - SF3_ITEM.price)
	})

	test('POST /api/items/bulkpurchase fails the whole bag it cannot afford when partial success is off', async () => {
		// Same shaping as above: enough for one line, not both.
		const affordsOne = SF3_ITEM.price + SF3_CHEAP.price - 1
		await getBalance(env.DB, 94, CurrencyType.RecCenterTokens, DEFAULT_STARTING_TOKENS)
		expect(
			await spendCurrency(
				env.DB,
				94,
				CurrencyType.RecCenterTokens,
				DEFAULT_STARTING_TOKENS - affordsOne,
				DEFAULT_STARTING_TOKENS
			)
		).toBe(true)
		const res = await bulkPurchase('94', {
			AllowPartialSuccess: false,
			PurchaseItemRequests: [
				line(SF3_ITEM.id, SF3_ITEM.price),
				line(SF3_CHEAP.id, SF3_CHEAP.price),
			],
		})
		const body = (await res.json()) as BulkBody
		// Even the line that would have fitted is refused: all of it or none.
		expect(body.Success).toBe(false)
		expect(body.Error).toBe('Insufficient balance')
		expect(body.Value).toBe(null)
		expect(
			await getBalance(env.DB, 94, CurrencyType.RecCenterTokens, DEFAULT_STARTING_TOKENS)
		).toBe(affordsOne)
	})

	test('POST /api/items/bulkpurchase grants without gift boxes when BypassGiftPackages is set', async () => {
		const res = await bulkPurchase('95', {
			BypassGiftPackages: true,
			PurchaseItemRequests: [line(SF3_ITEM.id, SF3_ITEM.price)],
		})
		const body = (await res.json()) as BulkBody
		expect(body.Success).toBe(true)
		expect(body.Value!.Balance).toBe(DEFAULT_STARTING_TOKENS - SF3_ITEM.price)
		// No box was created, so there is none to hand back — the capture's null GiftPackage.
		expect(body.Value!.BalanceUpdates[0]).toEqual({
			UpdateResponse: 0,
			Data: { GiftPackage: null, PurchasableItemId: SF3_ITEM.id, CustomAvatarItem: null },
		})
		const gifts = await exports.default.fetch(`${ORIGIN}/api/avatar/v2/gifts`, {
			headers: await bearer('95'),
		})
		expect((await gifts.json()) as unknown[]).toEqual([])
		// Ownership never depended on the box: the item is owned all the same.
		const items = await exports.default.fetch(`${ORIGIN}/api/avatar/v4/items`, {
			headers: await bearer('95'),
		})
		const list = (await items.json()) as Array<{ friendlyName: string }>
		expect(list[0].friendlyName).toBe(SF3_ITEM.name)
	})

	test('POST /api/items/bulkpurchase announces a box-less consumable with ConsumableMappingAdded', async () => {
		// No box means nothing is ever opened to announce the consumable, so the bag announces it
		// at grant time — without this it didn't show in the client until an inventory refetch.
		// 2182 is a consumable; three copies stack into one granted row.
		await drainFrames()
		const res = await bulkPurchase('951', {
			BypassGiftPackages: true,
			PurchaseItemRequests: [line(2182, 100, { DuplicateItemCount: 3 })],
		})
		expect(((await res.json()) as BulkBody).Success).toBe(true)
		const added = (await drainFrames()).filter(
			(f) => f.notificationType === NotificationType.ConsumableMappingAdded
		)
		expect(added).toHaveLength(1)
		const [frame] = added
		expect(frame!.accountId).toBe(951)
		expect(frame!.payload).toMatchObject({
			// The item's own desc, as the store it was bought from (2023 sf3: Assorted Donuts)
			// lists it — 2026 applies the frame only for a desc it knows.
			ConsumableItemDesc: 'ZuvkidodzkuOfGLDnTOFyg',
			Count: 3,
			InitialCount: 0,
			IsActive: false,
			IsTransferable: false,
			ActivatedByRoomie: false,
			// Must equal the definition's (consumables.json: true) or 2026 throws and drops it.
			IsRRO: true,
		})
		expect((frame!.payload as { Id: number }).Id).toBeGreaterThan(0)

		// With a box, the frame waits for the box to be opened: never sent twice for one grant.
		await drainFrames()
		await bulkPurchase('951', { PurchaseItemRequests: [line(2182, 100)] })
		expect(
			(await drainFrames()).filter(
				(f) => f.notificationType === NotificationType.ConsumableMappingAdded
			)
		).toEqual([])
	})

	test('POST /api/items/bulkpurchase routes a gifted line to its receiver', async () => {
		await seedAccount(207, 'BagReceiver')
		await drainFrames()
		const res = await bulkPurchase('960', {
			PurchaseItemRequests: [
				line(SF3_ITEM.id, SF3_ITEM.price),
				line(2182, 100, {
					Gift: { ToPlayerId: 207, Message: 'from the bag', Anonymous: false, GiftContext: 500 },
				}),
			],
		})
		const body = (await res.json()) as BulkBody
		expect(body.Success).toBe(true)
		// The buyer pays for both lines; only the first one lands on them.
		expect(body.Value!.Balance).toBe(DEFAULT_STARTING_TOKENS - SF3_ITEM.price - 100)
		const [own, gifted] = body.Value!.BalanceUpdates
		expect(own?.Data.GiftPackage).toMatchObject({ PlayerId: 960, FromPlayerId: 1 })
		expect(gifted?.Data.GiftPackage).toMatchObject({
			PlayerId: 207,
			FromPlayerId: 960,
			GiftContext: 500,
		})
		expect(await pendingGifts('960')).toHaveLength(1)
		const [box] = await pendingGifts('207')
		expect(box?.FromPlayerId).toBe(960)
		expect(box?.GiftContext).toBe(500)
		expect(box?.Message).toBe('from the bag')
		// The bag's response is the buyer's; the receiver is told over the hub instead.
		const received = (await drainFrames()).find(
			(f) => f.notificationType === NotificationType.GiftPackageReceivedImmediate
		)
		expect(received?.accountId).toBe(207)
		expect(received?.payload).toMatchObject({ Id: box?.Id, FromPlayerId: 960, GiftContext: 500 })
	})

	// ---- custom avatar items in the bag --------------------------------------------------
	// A line whose `ItemPurchaseMethodId` is a `Guid` (Type 1) names a custom avatar item by its
	// `CustomAvatarItemId`, resolved against the `custom_avatar_item` table rather than the
	// catalog. It is a SALE between players: the price leaves the buyer and lands on the
	// creator, ownership lands in `inventory_custom`, and the gift box names it by
	// `CustomAvatarItemId`.

	/** A guid-keyed bag line, in the shape the client posts one. */
	const customLine = (
		guid: string,
		requestedPrice: number,
		extra: Record<string, unknown> = {}
	) => ({
		ItemPurchaseMethodId: { Type: 1, NumberId: null, Guid: guid },
		RequestedPrice: requestedPrice,
		Gift: null,
		CouponConsumablePlayerMappingId: null,
		DuplicateItemCount: 1,
		...extra,
	})

	/** A published custom item by `creator`, at `price` tokens. */
	const customItem = (creator: number, price: number, accessibility = 1) =>
		createCustomAvatarItem(env.DB, {
			customAvatarItemId: crypto.randomUUID(),
			creatorAccountId: creator,
			name: 'Bag Visor',
			description: '',
			price,
			baseAvatarItemId: 1,
			baseAvatarItemColor: '#fff',
			accessibility,
			designFilename: 'design_x.bin',
			thumbnailImageFilename: 'thumb_x.png',
		})

	const tokens = (accountId: number) =>
		getBalance(env.DB, accountId, CurrencyType.RecCenterTokens, DEFAULT_STARTING_TOKENS)

	test('POST /api/items/bulkpurchase sells a custom avatar item: buyer pays, creator is paid, item is owned', async () => {
		// Buyer 620 and creator 621 are both fresh, so each starts on the default grant — the
		// creator's is seeded before the payout lands, or the credit would create their row and
		// eat their signup tokens.
		const item = await customItem(621, 900)
		await drainFrames()
		const res = await bulkPurchase('620', {
			PurchaseItemRequests: [customLine(item.CustomAvatarItemId, 900)],
		})
		expect(res.status).toBe(200)
		const body = (await res.json()) as BulkBody
		expect(body.Success).toBe(true)
		expect(body.Error).toBe(null)
		const value = body.Value!
		expect(value.Balance).toBe(DEFAULT_STARTING_TOKENS - 900)
		expect(value.Platform).toBe(-2)
		expect(codes(body)).toEqual([0])
		// The entry names the item rather than a catalog id, carries the WHOLE record for the
		// client to render, and a box that holds the item by `CustomAvatarItemId`.
		const data = value.BalanceUpdates[0].Data
		expect(data.PurchasableItemId).toBe(null)
		expect(data.CustomAvatarItem).toEqual({ ...item, PurchaseInfo: null })
		expect(data.GiftPackage).toEqual({
			Id: expect.any(Number),
			PlayerId: 620,
			FromPlayerId: 1,
			ConsumableItemDesc: '',
			AvatarItemType: 0,
			AvatarItemDesc: '',
			CustomAvatarItemId: item.CustomAvatarItemId,
			EquipmentPrefabName: '',
			EquipmentModificationGuid: '',
			CurrencyType: 0,
			Currency: 0,
			Xp: 0,
			GiftContext: 0,
			GiftRarity: 0,
			Message: expect.any(String),
			Signature: null,
			IsSignatureValid: false,
			Platform: -1,
			PlatformsToSpawnOn: -1,
			BalanceType: -2,
		})

		// The money moved both ways.
		expect(await tokens(620)).toBe(DEFAULT_STARTING_TOKENS - 900)
		expect(await tokens(621)).toBe(DEFAULT_STARTING_TOKENS + 900)
		// The creator hears about the sale as a plain update carrying their RESULTING total,
		// then the buyer's one purchase frame for the bag — both set the account-wide bucket.
		expect(await drainFrames()).toEqual([
			{
				accountId: 621,
				notificationType: NotificationType.StorefrontBalanceUpdate,
				payload: { Balance: DEFAULT_STARTING_TOKENS + 900, CurrencyType: 2, Platform: -2 },
			},
			{
				accountId: 620,
				notificationType: NotificationType.StorefrontBalancePurchase,
				payload: {
					BalanceAddType: 1400,
					Delta: -900,
					Balance: DEFAULT_STARTING_TOKENS - 900,
					Platform: -2,
					CurrencyType: 2,
				},
			},
		])

		// Owned now: the item shows on the buyer's owned list, and its box waits to be opened.
		const owned = await exports.default.fetch(`${ORIGIN}/econ/customAvatarItems/v1/owned`, {
			headers: await bearer('620'),
		})
		expect(await owned.json()).toEqual({
			Results: [{ ...item, PurchaseInfo: null }],
			TotalResults: 1,
		})
		const gifts = await exports.default.fetch(`${ORIGIN}/api/avatar/v2/gifts`, {
			headers: await bearer('620'),
		})
		const pending = (await gifts.json()) as Array<Record<string, unknown>>
		expect(pending).toHaveLength(1)
		expect(pending[0]).toMatchObject({
			Id: (data.GiftPackage as { Id: number }).Id,
			CustomAvatarItemId: item.CustomAvatarItemId,
			AvatarItemDesc: '',
		})

		// Buying it again is refused as AlreadyOwned and charges nothing.
		const again = await bulkPurchase('620', {
			PurchaseItemRequests: [customLine(item.CustomAvatarItemId, 900)],
		})
		const againBody = (await again.json()) as BulkBody
		expect(againBody.Success).toBe(false)
		expect(againBody.Error).toBe('Already owned')
		expect(await tokens(620)).toBe(DEFAULT_STARTING_TOKENS - 900)
		expect(await tokens(621)).toBe(DEFAULT_STARTING_TOKENS + 900)
	})

	test('POST /api/items/bulkpurchase gifts a custom avatar item: receiver owns it and gets the box', async () => {
		// Buyer 630 pays, creator 631 is paid, receiver 632 owns it and is handed the box.
		await seedAccount(632, 'CaiGiftReceiver')
		const item = await customItem(631, 200)
		// The receiver already owning it refuses the gift, not the buyer owning it.
		const alreadyThere = await customItem(631, 50)
		await grantCustomAvatarItem(env.DB, 632, alreadyThere.CustomAvatarItemId)
		await drainFrames()
		const gift = { ToPlayerId: 632, Anonymous: false, Message: 'for you', GiftContext: 3 }
		const res = await bulkPurchase('630', {
			PurchaseItemRequests: [
				customLine(item.CustomAvatarItemId, 200, { Gift: gift }),
				customLine(alreadyThere.CustomAvatarItemId, 50, { Gift: gift }),
			],
		})
		const body = (await res.json()) as BulkBody
		expect(body.Success).toBe(true)
		expect(codes(body)).toEqual([0, 3])
		expect(body.Value!.Balance).toBe(DEFAULT_STARTING_TOKENS - 200)
		const box = body.Value!.BalanceUpdates[0].Data.GiftPackage!
		expect(box).toMatchObject({
			PlayerId: 632,
			FromPlayerId: 630,
			CustomAvatarItemId: item.CustomAvatarItemId,
			GiftContext: 3,
			Message: 'for you',
		})
		expect(await tokens(631)).toBe(DEFAULT_STARTING_TOKENS + 200)

		// Ownership and the box are the receiver's, not the buyer's.
		expect(await ownedCustomAvatarItemIds(env.DB, 632, [item.CustomAvatarItemId])).toEqual(
			new Set([item.CustomAvatarItemId.toLowerCase()])
		)
		expect(await ownedCustomAvatarItemIds(env.DB, 630, [item.CustomAvatarItemId])).toEqual(
			new Set()
		)
		const pending = async (account: string) =>
			(await (
				await exports.default.fetch(`${ORIGIN}/api/avatar/v2/gifts`, {
					headers: await bearer(account),
				})
			).json()) as Array<Record<string, unknown>>
		expect(await pending('630')).toEqual([])
		expect(await pending('632')).toEqual([
			expect.objectContaining({ Id: box.Id, CustomAvatarItemId: item.CustomAvatarItemId }),
		])

		// Exactly three frames: the creator's payout, the receiver's box — told as a catalog
		// gift's is, the box naming the item — and the buyer's one purchase frame for the bag.
		expect(await drainFrames()).toEqual([
			{
				accountId: 631,
				notificationType: NotificationType.StorefrontBalanceUpdate,
				payload: { Balance: DEFAULT_STARTING_TOKENS + 200, CurrencyType: 2, Platform: -2 },
			},
			{
				accountId: 632,
				notificationType: NotificationType.GiftPackageReceivedImmediate,
				payload: {
					Id: box.Id,
					FromGiftDropId: 0,
					FromPlayerId: 630,
					ConsumableItemDesc: '',
					AvatarItemDesc: '',
					AvatarItemType: 0,
					CustomAvatarItemId: item.CustomAvatarItemId,
					EquipmentPrefabName: '',
					EquipmentModificationGuid: '',
					CurrencyType: 0,
					Currency: 0,
					Xp: 0,
					Level: 0,
					Platform: -1,
					PlatformsToSpawnOn: -1,
					BalanceType: -2,
					GiftContext: 3,
					GiftRarity: 0,
					Message: 'for you',
				},
			},
			{
				accountId: 630,
				notificationType: NotificationType.StorefrontBalancePurchase,
				payload: {
					BalanceAddType: 1400,
					Delta: -200,
					Balance: DEFAULT_STARTING_TOKENS - 200,
					Platform: -2,
					CurrencyType: 2,
				},
			},
		])
	})

	test('POST /api/items/bulkpurchase lets a creator gift their own custom item', async () => {
		await seedAccount(634, 'CaiCreatorGiftReceiver')
		const item = await customItem(633, 150)
		const res = await bulkPurchase('633', {
			PurchaseItemRequests: [
				customLine(item.CustomAvatarItemId, 150, {
					Gift: { ToPlayerId: 634, Anonymous: true },
				}),
			],
		})
		const body = (await res.json()) as BulkBody
		expect(codes(body)).toEqual([0])
		// Anonymous: from Coach. The creator paid themself, so their balance is back where it was.
		expect(body.Value!.BalanceUpdates[0].Data.GiftPackage).toMatchObject({
			PlayerId: 634,
			FromPlayerId: 1,
		})
		expect(await tokens(633)).toBe(DEFAULT_STARTING_TOKENS)
		const owned = await ownedCustomAvatarItemIds(env.DB, 634, [item.CustomAvatarItemId])
		expect(owned.size).toBe(1)
	})

	test('POST /api/items/bulkpurchase skips a custom item’s box under BypassGiftPackages', async () => {
		const item = await customItem(629, 100)
		const res = await bulkPurchase('628', {
			PurchaseItemRequests: [customLine(item.CustomAvatarItemId, 100)],
			BypassGiftPackages: true,
		})
		const body = (await res.json()) as BulkBody
		expect(codes(body)).toEqual([0])
		expect(body.Value!.BalanceUpdates[0].Data.GiftPackage).toBe(null)
		const gifts = await exports.default.fetch(`${ORIGIN}/api/avatar/v2/gifts`, {
			headers: await bearer('628'),
		})
		expect(await gifts.json()).toEqual([])
	})

	test('POST /api/items/bulkpurchase mixes a custom item into a catalog bag, matching the guid case-insensitively', async () => {
		// The exact bag the client posts from the store: storefront 3, tokens, partial success
		// on. One catalog line and one custom line, the guid upper-cased as the client sometimes
		// sends it, settle together in ONE debit.
		const item = await customItem(623, 100)
		const res = await bulkPurchase('622', {
			PurchaseItemRequests: [
				line(SF3_ITEM.id, SF3_ITEM.price),
				customLine(item.CustomAvatarItemId.toUpperCase(), 100),
			],
		})
		const body = (await res.json()) as BulkBody
		expect(body.Success).toBe(true)
		expect(codes(body)).toEqual([0, 0])
		expect(body.Value!.Balance).toBe(DEFAULT_STARTING_TOKENS - SF3_ITEM.price - 100)
		expect(body.Value!.BalanceUpdates[0].Data.PurchasableItemId).toBe(SF3_ITEM.id)
		expect(body.Value!.BalanceUpdates[0].Data.CustomAvatarItem).toBe(null)
		expect(body.Value!.BalanceUpdates[1].Data.PurchasableItemId).toBe(null)
		expect(body.Value!.BalanceUpdates[1].Data.CustomAvatarItem).toMatchObject({
			CustomAvatarItemId: item.CustomAvatarItemId,
		})
		expect(await tokens(623)).toBe(DEFAULT_STARTING_TOKENS + 100)
	})

	test('POST /api/items/bulkpurchase refuses the custom lines that cannot be sold, per line', async () => {
		const draft = await customItem(625, 100, 0)
		const own = await customItem(624, 100)
		const priced = await customItem(625, 300)
		const res = await bulkPurchase('624', {
			PurchaseItemRequests: [
				// A draft (Accessibility 0) is visible to its creator alone; to a buyer it is no item.
				customLine(draft.CustomAvatarItemId, 100),
				// An id nothing has.
				customLine(crypto.randomUUID(), 100),
				// The buyer's own item: they own it already, and would be paying themself.
				customLine(own.CustomAvatarItemId, 100),
				// A stale price.
				customLine(priced.CustomAvatarItemId, 200),
				// Owned once: no stacking.
				customLine(priced.CustomAvatarItemId, 300, { DuplicateItemCount: 2 }),
				// Gifted to its own creator, who owns it already.
				customLine(priced.CustomAvatarItemId, 300, {
					Gift: { ToPlayerId: 625, Anonymous: false, Message: 'hi' },
				}),
				// And the one good line, which the partial bag still buys.
				customLine(priced.CustomAvatarItemId, 300),
			],
		})
		const body = (await res.json()) as BulkBody
		expect(body.Success).toBe(true)
		// 4 NoItemAvailable, 4, 8 PlayerNotEligible, 6 RequestedPriceDoesNotMatch,
		// 7 RequestedAmountNotAllowed, 8, 0 OK.
		expect(codes(body)).toEqual([4, 4, 8, 6, 7, 8, 0])
		expect(body.Value!.Balance).toBe(DEFAULT_STARTING_TOKENS - 300)
		expect(
			body.Value!.BalanceUpdates.slice(0, 6).every((u) => u.Data.CustomAvatarItem === null)
		).toBe(true)
		expect(await tokens(625)).toBe(DEFAULT_STARTING_TOKENS + 300)

		// Without partial success the first bad line refuses the whole bag, unpaid.
		const strict = await bulkPurchase('627', {
			PurchaseItemRequests: [
				customLine(priced.CustomAvatarItemId, 300),
				customLine(draft.CustomAvatarItemId, 100),
			],
			AllowPartialSuccess: false,
		})
		const strictBody = (await strict.json()) as BulkBody
		expect(strictBody.Success).toBe(false)
		expect(strictBody.Error).toBe('Item not found')
		expect(await tokens(627)).toBe(DEFAULT_STARTING_TOKENS)
		expect(await tokens(625)).toBe(DEFAULT_STARTING_TOKENS + 300)

		// A custom item is priced in tokens only: a bag in another currency cannot buy one.
		const wrongCurrency = await bulkPurchase('627', {
			PurchaseItemRequests: [customLine(priced.CustomAvatarItemId, 300)],
			CurrencyType: 1,
		})
		const wrongBody = (await wrongCurrency.json()) as BulkBody
		expect(wrongBody.Success).toBe(false)
		expect(wrongBody.Error).toBe('Currency type not available for this item')
	})

	test('POST /api/items/bulkpurchase 404s a bag gifting to a player that does not exist', async () => {
		const res = await bulkPurchase('970', {
			PurchaseItemRequests: [
				line(SF3_ITEM.id, SF3_ITEM.price),
				line(2182, 100, { Gift: { ToPlayerId: 999998, Message: 'hi', Anonymous: false } }),
			],
		})
		expect(res.status).toBe(404)
		const body = (await res.json()) as BulkBody
		expect(body.Success).toBe(false)
		expect(body.Error).toBe('No such player to gift to')
		// The whole bag is refused before the debit, the good line included.
		expect(
			await getBalance(env.DB, 970, CurrencyType.RecCenterTokens, DEFAULT_STARTING_TOKENS)
		).toBe(10000)
	})

	test('POST /api/items/bulkpurchase reports per line what it cannot sell', async () => {
		await drainFrames()
		const res = await bulkPurchase('96', {
			PurchaseItemRequests: [
				// A guid-keyed (UGC) item — nothing here sells one, and it has no NumberId to echo.
				line(0, SF3_ITEM.price, {
					ItemPurchaseMethodId: { Type: 1, NumberId: null, Guid: 'a3f1-not-a-catalog-item' },
				}),
				// Nothing issues coupons, so a line claiming one is refused rather than charged full
				// price for a discount it thinks it applied.
				line(SF3_ITEM.id, SF3_ITEM.price, { CouponConsumablePlayerMappingId: 4242 }),
				line(999999, SF3_ITEM.price),
				line(SF3_ITEM.id, SF3_ITEM.price, { DuplicateItemCount: 0 }),
				// An avatar item is owned once — a second copy would grant nothing and charge for it.
				line(SF3_CHEAP.id, SF3_CHEAP.price, { DuplicateItemCount: 2 }),
				// The catalog prices this item in RecCenterTokens only.
				line(2182, 100),
				// …and one that works, so the bag is a partial success rather than a refusal.
				line(SF3_ITEM.id, SF3_ITEM.price),
			],
			CurrencyType: 2,
		})
		expect(res.status).toBe(200)
		const body = (await res.json()) as BulkBody
		expect(body.Success).toBe(true)
		// 4 NoItemAvailable, 5 CouponNotApplicable, 4 NoItemAvailable, 7/7
		// RequestedAmountNotAllowed, 0 OK (the donuts do price in tokens), 0 OK.
		expect(codes(body)).toEqual([4, 5, 4, 7, 7, 0, 0])
		expect(body.Value!.BalanceUpdates[0].Data.PurchasableItemId).toBe(null)
		// Only the two OK lines were charged: the donuts and one avatar item.
		expect(body.Value!.Balance).toBe(DEFAULT_STARTING_TOKENS - 100 - SF3_ITEM.price)
		expect(await drainFrames()).toHaveLength(1)
	})

	test('POST /api/items/bulkpurchase refuses a bag where nothing sells', async () => {
		const res = await bulkPurchase('97', {
			CurrencyType: CurrencyType.LaserTagTickets,
			PurchaseItemRequests: [line(SF3_ITEM.id, SF3_ITEM.price)],
		})
		expect(res.status).toBe(200)
		const body = (await res.json()) as BulkBody
		// Nothing was bought, so this is a refusal rather than a bag of non-OK entries.
		expect(body.Success).toBe(false)
		expect(body.Error).toBe('Currency type not available for this item')
		expect(body.Value).toBe(null)
	})

	test('POST /api/items/bulkpurchase 400s on a request it cannot evaluate', async () => {
		// Same envelope on a 400, so a client that only parses this shape still reads the error.
		const empty = await bulkPurchase('98', { PurchaseItemRequests: [] })
		expect(empty.status).toBe(400)
		const emptyBody = (await empty.json()) as BulkBody
		expect(emptyBody).toMatchObject({ Success: false, error_id: null, Value: null })
		expect(emptyBody.Error).toBe('PurchaseItemRequests must be a non-empty array')
		// A room-scoped currency is not an account balance we can debit.
		const roomCurrency = await bulkPurchase('98', {
			CurrencyType: CurrencyType.RoomCurrency,
			PurchaseItemRequests: [line(SF3_ITEM.id, SF3_ITEM.price)],
		})
		expect(roomCurrency.status).toBe(400)
		expect(((await roomCurrency.json()) as BulkBody).Error).toBe('Currency type is not spendable')
		// Over `Econ.BulkPurchaseCap` (200 copies) — the same cap the client reads from its
		// game config. Consumables are what can be asked for in that quantity.
		const over = await bulkPurchase('98', {
			PurchaseItemRequests: [line(2182, 100, { DuplicateItemCount: 201 })],
		})
		expect(over.status).toBe(400)
		expect(((await over.json()) as BulkBody).Error).toBe('A bulk purchase is capped at 200 items')
		expect(
			await getBalance(env.DB, 98, CurrencyType.RecCenterTokens, DEFAULT_STARTING_TOKENS)
		).toBe(10000)
	})

	/**
	 * The StorefrontBalanceUpdate (and other) frames the worker has pushed since the last
	 * drain, read back off the stub hub in vitest.config.ts. Notification sends are
	 * best-effort — the worker logs and swallows a hub failure — so this is the only way a
	 * test sees what was actually pushed.
	 */
	const drainFrames = async (): Promise<
		Array<{ accountId: number; notificationType: number; payload: Record<string, unknown> }>
	> =>
		(
			env.RECFLARE_NOTIFICATIONS_HUB.getByName('global') as unknown as {
				drainFrames(): Promise<
					Array<{ accountId: number; notificationType: number; payload: Record<string, unknown> }>
				>
			}
		).drainFrames()

	// buyInvention is a GET with query params — that is how the client sends it.
	const buyInvention = async (sub: string, inventionId: number, requestedPrice = 0) =>
		exports.default.fetch(
			`${ORIGIN}/api/storefronts/v2/buyInvention?inventionId=${inventionId}&requestedPrice=${requestedPrice}`,
			{ headers: await bearer(sub) }
		)

	test('GET /api/storefronts/v2/buyInvention 401s without a token', async () => {
		const res = await exports.default.fetch(
			`${ORIGIN}/api/storefronts/v2/buyInvention?inventionId=8&requestedPrice=0`
		)
		expect(res.status).toBe(401)
	})

	test('GET /api/storefronts/v2/buyInvention records ownership of a free invention', async () => {
		const res = await buyInvention('50', 8)
		expect(res.status).toBe(200)
		const body = (await res.json()) as {
			BalanceUpdateResponse: {
				Balance: number
				BalanceType: number
				CurrencyType: number
				BalanceUpdates: Array<{ UpdateResponse: number; Data: { InventionId: number } }>
			}
			InventionResponse: {
				Status: number
				Invention: { InventionId: number; Name: string; NumDownloads: number }
				InventionVersion: { InventionId: number; VersionNumber: number }
			}
		}
		// Nothing was debited, so `Balance` is the resulting total — the untouched starting
		// grant — not a change, unlike buyItem's.
		expect(body.BalanceUpdateResponse.Balance).toBe(DEFAULT_STARTING_TOKENS)
		expect(body.BalanceUpdateResponse.CurrencyType).toBe(CurrencyType.RecCenterTokens)
		expect(body.BalanceUpdateResponse.BalanceType).toBe(-2)
		expect(body.BalanceUpdateResponse.BalanceUpdates[0].Data.InventionId).toBe(8)
		expect(body.InventionResponse.Status).toBe(0)
		expect(body.InventionResponse.Invention.Name).toBe('Invention 8')
		expect(body.InventionResponse.InventionVersion.VersionNumber).toBe(1)

		expect(await getOwnedInventionIds(env.DB, 50)).toEqual([8])

		// `NumDownloads` is the number of players who have it, re-derived on the grant:
		// the response carries it and so does the stored record.
		const storedDownloads = async (): Promise<number> =>
			(
				await env.DB.prepare(
					"SELECT json_extract(data, '$.NumDownloads') AS n FROM invention WHERE id = 8"
				).first<{ n: number }>()
			)?.n ?? -1
		expect(body.InventionResponse.Invention.NumDownloads).toBe(1)
		expect(await storedDownloads()).toBe(1)

		// Owning an invention is boolean: buying it again is a conflict, not a second row —
		// and not a second download.
		expect((await buyInvention('50', 8)).status).toBe(409)
		expect(await getOwnedInventionIds(env.DB, 50)).toEqual([8])
		expect(await storedDownloads()).toBe(1)
	})

	test('GET /api/storefronts/v2/buyInvention pays the creator the buyer’s tokens', async () => {
		// Invention 9 costs 250 and was made by account 999. Buying it moves 250 tokens from
		// the buyer to that creator — no house cut, so the two sides are equal and opposite.
		await drainFrames()
		const res = await buyInvention('51', 9, 250)
		expect(res.status).toBe(200)
		const body = (await res.json()) as { BalanceUpdateResponse: { Balance: number } }
		// `Balance` is the buyer's RESULTING total, so it already has the debit in it.
		expect(body.BalanceUpdateResponse.Balance).toBe(DEFAULT_STARTING_TOKENS - 250)
		expect(
			await getBalance(env.DB, 51, CurrencyType.RecCenterTokens, DEFAULT_STARTING_TOKENS)
		).toBe(DEFAULT_STARTING_TOKENS - 250)
		// The creator had never touched their balance: they keep their starting grant AND get
		// paid, rather than the payout standing in for the grant.
		expect(
			await getBalance(env.DB, 999, CurrencyType.RecCenterTokens, DEFAULT_STARTING_TOKENS)
		).toBe(DEFAULT_STARTING_TOKENS + 250)
		expect(await getOwnedInventionIds(env.DB, 51)).toEqual([9])

		// Both sides get a frame carrying their RESULTING TOTAL, into the same -2 bucket the
		// balance endpoint reports — a StorefrontBalance* push SETS that bucket, so sending the
		// change (250 / -250) would set their whole balance to it. The creator sold, so theirs is
		// a plain update; the buyer bought, so theirs is a purchase frame with a display-only
		// `Delta`. Note the key is `Platform`: the client renames `BalanceType` away and drops it.
		expect(await drainFrames()).toEqual([
			{
				accountId: 999,
				notificationType: NotificationType.StorefrontBalanceUpdate,
				payload: {
					Balance: DEFAULT_STARTING_TOKENS + 250,
					CurrencyType: CurrencyType.RecCenterTokens,
					Platform: -2,
				},
			},
			{
				accountId: 51,
				notificationType: NotificationType.StorefrontBalancePurchase,
				payload: {
					BalanceAddType: 1400,
					Delta: -250,
					Balance: DEFAULT_STARTING_TOKENS - 250,
					Platform: -2,
					CurrencyType: CurrencyType.RecCenterTokens,
				},
			},
		])
	})

	test('GET /api/storefronts/v2/buyInvention rejects a stale price and an unaffordable one', async () => {
		// Sending 0 for the 250-token invention 9 is a stale (or tampered) price.
		expect((await buyInvention('53', 9, 0)).status).toBe(409)

		// Account 54 can't afford it: nothing is debited, nobody is paid, nothing is owned.
		await spendCurrency(
			env.DB,
			54,
			CurrencyType.RecCenterTokens,
			DEFAULT_STARTING_TOKENS,
			DEFAULT_STARTING_TOKENS
		)
		const creatorBefore = await getBalance(
			env.DB,
			999,
			CurrencyType.RecCenterTokens,
			DEFAULT_STARTING_TOKENS
		)
		expect((await buyInvention('54', 9, 250)).status).toBe(400)
		expect(
			await getBalance(env.DB, 54, CurrencyType.RecCenterTokens, DEFAULT_STARTING_TOKENS)
		).toBe(0)
		expect(
			await getBalance(env.DB, 999, CurrencyType.RecCenterTokens, DEFAULT_STARTING_TOKENS)
		).toBe(creatorBefore)
		expect(await getOwnedInventionIds(env.DB, 53)).toEqual([])
		expect(await getOwnedInventionIds(env.DB, 54)).toEqual([])
	})

	test('GET /api/storefronts/v2/buyInvention rejects drafts, self-buys and unknown ids', async () => {
		// Unpublished — a draft is not on sale, free or not.
		expect((await buyInvention('52', 10)).status).toBe(403)
		// Account 60 created invention 11; a creator already owns it.
		expect((await buyInvention('60', 11)).status).toBe(400)
		expect((await buyInvention('52', 9999)).status).toBe(404)
		// Missing/non-numeric inventionId.
		const res = await exports.default.fetch(`${ORIGIN}/api/storefronts/v2/buyInvention`, {
			headers: await bearer('52'),
		})
		expect(res.status).toBe(400)
		expect(await getOwnedInventionIds(env.DB, 52)).toEqual([])
		expect(await getOwnedInventionIds(env.DB, 60)).toEqual([])
	})

	// The 2025 client posts the same purchase as a JSON body — and wants a DIFFERENT response
	// back: the v9 save envelope, and a balance bucket keyed `Platform`. The settlement is
	// shared with v2, so these pin the envelope and the money moving, not the rules v2 covers.
	const buyInventionV3 = async (sub: string, body: unknown) =>
		exports.default.fetch(`${ORIGIN}/api/storefronts/v3/buyInvention`, {
			method: 'POST',
			headers: { ...(await bearer(sub)), 'Content-Type': 'application/json' },
			body: JSON.stringify(body),
		})

	test('POST /api/storefronts/v3/buyInvention 401s without a token', async () => {
		const res = await exports.default.fetch(`${ORIGIN}/api/storefronts/v3/buyInvention`, {
			method: 'POST',
			headers: { 'Content-Type': 'application/json' },
			body: JSON.stringify({ InventionId: 8, RequestedPrice: 0 }),
		})
		expect(res.status).toBe(401)
	})

	test('POST /api/storefronts/v3/buyInvention answers the v9 envelope, not v2’s', async () => {
		const res = await buyInventionV3('55', { InventionId: 8, RequestedPrice: 0 })
		expect(res.status).toBe(200)
		const body = (await res.json()) as {
			InventionResponse: {
				Value: {
					Status: number
					Invention: Record<string, unknown>
					InventionVersion: unknown
					TagsResponse: unknown
				} | null
				Success: boolean
				Error: string | null
				error_id: string | null
			}
			BalanceUpdateResponse: {
				Balance: number
				CurrencyType: number
				Platform: number
				BalanceType?: number
				BalanceUpdates: Array<{ UpdateResponse: number; Data: { InventionId: number } }>
			}
		}

		// The v9 SAVE envelope: `Value` under `{ Success, Error, error_id }`. `Value` is never
		// null under `Success: true` — the client dereferences `Value.Invention` unguarded.
		expect(body.InventionResponse).toMatchObject({ Success: true, Error: null, error_id: null })
		expect(body.InventionResponse.Value?.Status).toBe(0)
		expect(body.InventionResponse.Value?.Invention.InventionId).toBe(8)
		expect(body.InventionResponse.Value?.Invention.Name).toBe('Invention 8')
		// The 28-key `RRInvention`, not the stored record: the version rides nowhere here, and
		// `IsPublished` is a stored field this projection drops.
		expect(body.InventionResponse.Value?.Invention.CurrentVersion).toBeUndefined()
		expect(body.InventionResponse.Value?.Invention.IsPublished).toBeUndefined()
		expect(body.InventionResponse.Value?.Invention.LatestVersionNumber).toBe(1)
		// A buy mints no version and takes no tags — present and null, not absent.
		expect(body.InventionResponse.Value).toHaveProperty('InventionVersion', null)
		expect(body.InventionResponse.Value).toHaveProperty('TagsResponse', null)

		// `BalanceResponseDTO`: the bucket key is `Platform`. Spelling it `BalanceType` (which is
		// what v2 sends) would be dropped by the client's decoder and default this balance into
		// bucket 0, beside the -2 the socket frames set — a phantom second balance.
		expect(body.BalanceUpdateResponse.Platform).toBe(-2)
		expect(body.BalanceUpdateResponse.BalanceType).toBeUndefined()
		// Nothing was debited, so `Balance` is the resulting total, not a change.
		expect(body.BalanceUpdateResponse.Balance).toBe(DEFAULT_STARTING_TOKENS)
		expect(body.BalanceUpdateResponse.CurrencyType).toBe(CurrencyType.RecCenterTokens)
		expect(body.BalanceUpdateResponse.BalanceUpdates[0].Data.InventionId).toBe(8)

		expect(await getOwnedInventionIds(env.DB, 55)).toEqual([8])
		// Owning it is boolean here too — the route shares v2's settlement.
		expect((await buyInventionV3('55', { InventionId: 8, RequestedPrice: 0 })).status).toBe(409)
	})

	test('GET v2 and POST v3 buyInvention answer the SAME buy in different envelopes', async () => {
		// The one thing that must not drift: two builds buying the same invention get the same
		// invention back, shaped for each. v2 serves the stored record under a bare status
		// envelope; v3 serves the 28-key projection under the v9 one. Don't unify them.
		const v2 = (await (await buyInvention('58', 8)).json()) as {
			InventionResponse: { Status: number; Invention: Record<string, unknown> }
			BalanceUpdateResponse: { BalanceType: number; Platform?: number }
		}
		const v3 = (await (
			await buyInventionV3('59', { InventionId: 8, RequestedPrice: 0 })
		).json()) as {
			InventionResponse: { Value: { Invention: Record<string, unknown> } | null }
			BalanceUpdateResponse: { Platform: number; BalanceType?: number }
		}
		expect(v2.InventionResponse.Invention.InventionId).toBe(8)
		expect(v3.InventionResponse.Value?.Invention.InventionId).toBe(8)
		// v2 keeps the nested version; v3's projection lifts it away entirely.
		expect(v2.InventionResponse.Invention.CurrentVersion).toBeDefined()
		expect(v3.InventionResponse.Value?.Invention.CurrentVersion).toBeUndefined()
		// The bucket is spelled differently on each, and each spells exactly one.
		expect(v2.BalanceUpdateResponse).toMatchObject({ BalanceType: -2 })
		expect(v2.BalanceUpdateResponse.Platform).toBeUndefined()
		expect(v3.BalanceUpdateResponse).toMatchObject({ Platform: -2 })
		expect(v3.BalanceUpdateResponse.BalanceType).toBeUndefined()
	})

	test('POST /api/storefronts/v3/buyInvention pays the creator and pushes both sides', async () => {
		await drainFrames()
		// Creator 999 has already been paid by the v2 tests above, so their resulting total is
		// read rather than assumed — it is the payout ADDED to whatever they had.
		const creatorBefore = await getBalance(
			env.DB,
			999,
			CurrencyType.RecCenterTokens,
			DEFAULT_STARTING_TOKENS
		)
		const res = await buyInventionV3('56', { InventionId: 9, RequestedPrice: 250 })
		expect(res.status).toBe(200)
		const body = (await res.json()) as { BalanceUpdateResponse: { Balance: number } }
		expect(body.BalanceUpdateResponse.Balance).toBe(DEFAULT_STARTING_TOKENS - 250)
		expect(
			await getBalance(env.DB, 56, CurrencyType.RecCenterTokens, DEFAULT_STARTING_TOKENS)
		).toBe(DEFAULT_STARTING_TOKENS - 250)
		expect(
			await getBalance(env.DB, 999, CurrencyType.RecCenterTokens, DEFAULT_STARTING_TOKENS)
		).toBe(creatorBefore + 250)
		expect(await getOwnedInventionIds(env.DB, 56)).toEqual([9])

		// Same two frames as the v2 buy, each carrying its player's RESULTING total into the -2
		// bucket: the creator sold (a plain update), the buyer bought (a purchase frame).
		expect(await drainFrames()).toEqual([
			{
				accountId: 999,
				notificationType: NotificationType.StorefrontBalanceUpdate,
				payload: {
					Balance: creatorBefore + 250,
					CurrencyType: CurrencyType.RecCenterTokens,
					Platform: -2,
				},
			},
			{
				accountId: 56,
				notificationType: NotificationType.StorefrontBalancePurchase,
				payload: {
					BalanceAddType: 1400,
					Delta: -250,
					Balance: DEFAULT_STARTING_TOKENS - 250,
					Platform: -2,
					CurrencyType: CurrencyType.RecCenterTokens,
				},
			},
		])
	})

	test('POST /api/storefronts/v3/buyInvention rejects a stale price and a bad body', async () => {
		// A body is the only difference from v2, so the price check reads it the same way: an
		// absent RequestedPrice is 0, which does not match the 250-token invention 9.
		expect((await buyInventionV3('57', { InventionId: 9 })).status).toBe(409)
		expect((await buyInventionV3('57', { InventionId: 9, RequestedPrice: 0 })).status).toBe(409)
		// No InventionId, and no body at all.
		expect((await buyInventionV3('57', { RequestedPrice: 0 })).status).toBe(400)
		const res = await exports.default.fetch(`${ORIGIN}/api/storefronts/v3/buyInvention`, {
			method: 'POST',
			headers: { ...(await bearer('57')), 'Content-Type': 'application/json' },
		})
		expect(res.status).toBe(400)
		expect(await getOwnedInventionIds(env.DB, 57)).toEqual([])
	})

	test('POST /api/avatar/v2/gifts/consume opens the box the way the client sends it', async () => {
		// Buy an item for account 24, then consume the box the way the client does: on the
		// econ host, with a form body (`Id=..&UnlockedLevel=..`).
		const buy = await exports.default.fetch(`${ORIGIN}/api/storefronts/v2/buyItem`, {
			method: 'POST',
			headers: { ...(await bearer('24')), 'Content-Type': 'application/json' },
			body: JSON.stringify({
				StorefrontType: 3,
				PurchasableItemId: SF3_ITEM.id,
				CurrencyType: 2,
				RequestedPrice: SF3_ITEM.price,
			}),
		})
		const bought = (await buy.json()) as {
			BalanceUpdates: Array<{ Data: Array<{ Id: number }> }>
		}
		const giftId = bought.BalanceUpdates[0].Data[0].Id

		const res = await exports.default.fetch(`${ORIGIN}/api/avatar/v2/gifts/consume/`, {
			method: 'POST',
			headers: {
				...(await bearer('24')),
				'Content-Type': 'application/x-www-form-urlencoded',
			},
			body: new URLSearchParams({ Id: String(giftId), UnlockedLevel: '0' }),
		})
		expect(res.status).toBe(200)
		expect(await res.json()).toEqual({ error: '', success: true, value: null })

		// The box is gone; the item stays owned (it was granted at purchase, not on open).
		const gifts = await exports.default.fetch(`${ORIGIN}/api/avatar/v2/gifts`, {
			headers: await bearer('24'),
		})
		expect(await gifts.json()).toEqual([])
		const items = await exports.default.fetch(`${ORIGIN}/api/avatar/v4/items`, {
			headers: await bearer('24'),
		})
		const list = (await items.json()) as Array<{ friendlyName: string }>
		expect(list.some((i) => i.friendlyName === SF3_ITEM.name)).toBe(true)

		// Opening it again is a harmless no-op — still 200.
		const again = await exports.default.fetch(`${ORIGIN}/api/avatar/v2/gifts/consume/`, {
			method: 'POST',
			headers: {
				...(await bearer('24')),
				'Content-Type': 'application/x-www-form-urlencoded',
			},
			body: new URLSearchParams({ Id: String(giftId) }),
		})
		expect(again.status).toBe(200)
	})

	test('POST /api/avatar/v2/gifts/consume opens a consumable box (fires ConsumableMappingAdded)', async () => {
		// Buy a consumable (Supreme Pizza, item 574 in storefront 300) for account 26 —
		// its gift box carries a ConsumableItemDesc, so opening it notifies the client.
		const buy = await exports.default.fetch(`${ORIGIN}/api/storefronts/v2/buyItem`, {
			method: 'POST',
			headers: { ...(await bearer('26')), 'Content-Type': 'application/json' },
			body: JSON.stringify({
				StorefrontType: 300,
				PurchasableItemId: 574,
				CurrencyType: 2,
				RequestedPrice: 95,
			}),
		})
		expect(buy.status).toBe(200)
		const giftId = (
			(await buy.json()) as { BalanceUpdates: Array<{ Data: Array<{ Id: number }> }> }
		).BalanceUpdates[0].Data[0].Id

		// Opening the box succeeds and fires the ConsumableMappingAdded push (which no-ops
		// against the test hub stub — this asserts the notify path doesn't throw).
		const res = await exports.default.fetch(`${ORIGIN}/api/avatar/v2/gifts/consume`, {
			method: 'POST',
			headers: { ...(await bearer('26')), 'Content-Type': 'application/x-www-form-urlencoded' },
			body: new URLSearchParams({ Id: String(giftId) }),
		})
		expect(res.status).toBe(200)
		expect(await res.json()).toEqual({ error: '', success: true, value: null })

		// The box is gone; the consumable stays owned (granted at purchase).
		expect(
			await (
				await exports.default.fetch(`${ORIGIN}/api/avatar/v2/gifts`, {
					headers: await bearer('26'),
				})
			).json()
		).toEqual([])
		const unlocked = (await (
			await exports.default.fetch(`${ORIGIN}/api/consumables/v2/getUnlocked`, {
				headers: await bearer('26'),
			})
		).json()) as Array<{ ConsumableItemDesc: string }>
		expect(unlocked.length).toBeGreaterThan(0)
	})

	test('POST /api/avatar/v2/gifts/consume 403s when the box belongs to another player', async () => {
		// Account 27 buys an item, producing a gift box owned by 27.
		const buy = await exports.default.fetch(`${ORIGIN}/api/storefronts/v2/buyItem`, {
			method: 'POST',
			headers: { ...(await bearer('27')), 'Content-Type': 'application/json' },
			body: JSON.stringify({
				StorefrontType: 3,
				PurchasableItemId: SF3_ITEM.id,
				CurrencyType: 2,
				RequestedPrice: SF3_ITEM.price,
			}),
		})
		const giftId = (
			(await buy.json()) as { BalanceUpdates: Array<{ Data: Array<{ Id: number }> }> }
		).BalanceUpdates[0].Data[0].Id

		// Account 28 trying to open 27's box is forbidden — and 27 keeps it.
		const forbidden = await exports.default.fetch(`${ORIGIN}/api/avatar/v2/gifts/consume`, {
			method: 'POST',
			headers: { ...(await bearer('28')), 'Content-Type': 'application/x-www-form-urlencoded' },
			body: new URLSearchParams({ Id: String(giftId) }),
		})
		expect(forbidden.status).toBe(403)
		const stillThere = (await (
			await exports.default.fetch(`${ORIGIN}/api/avatar/v2/gifts`, { headers: await bearer('27') })
		).json()) as Array<{ Id: number }>
		expect(stillThere.some((g) => g.Id === giftId)).toBe(true)

		// The owner (27) opens it fine, and re-opening the now-gone box is a harmless 200.
		const ok = await exports.default.fetch(`${ORIGIN}/api/avatar/v2/gifts/consume`, {
			method: 'POST',
			headers: { ...(await bearer('27')), 'Content-Type': 'application/x-www-form-urlencoded' },
			body: new URLSearchParams({ Id: String(giftId) }),
		})
		expect(ok.status).toBe(200)
		const again = await exports.default.fetch(`${ORIGIN}/api/avatar/v2/gifts/consume`, {
			method: 'POST',
			headers: { ...(await bearer('27')), 'Content-Type': 'application/x-www-form-urlencoded' },
			body: new URLSearchParams({ Id: String(giftId) }),
		})
		expect(again.status).toBe(200)
	})

	test('GET /api/challenge/v2/getCurrent returns the weekly challenge', async () => {
		const res = await exports.default.fetch(`${ORIGIN}/api/challenge/v2/getCurrent`)
		expect(res.status).toBe(200)
		const body = (await res.json()) as { ChallengeMapId: number; Challenges: unknown[] }
		expect(body.ChallengeMapId).toBe(weekly.ChallengeMapId)
		expect(body.Challenges).toHaveLength(weekly.Challenges.length)
	})

	test('the rotation is a pure function of the week', async () => {
		const at = new Date('2026-08-25T12:00:00Z')
		// Same instant, same rotation — and any instant in the same week, too. Two players
		// served different challenges for one `ChallengeMapId` would disagree about who has
		// finished the week.
		expect(buildRotation(at)).toEqual(buildRotation(at))
		const laterSameWeek = new Date('2026-08-26T20:59:59Z')
		expect(rotationIndex(laterSameWeek)).toBe(rotationIndex(at))
		expect(buildRotation(laterSameWeek).Challenges).toEqual(buildRotation(at).Challenges)

		// …and the week rolls at Wednesday 21:00 UTC, one map id at a time.
		const nextWeek = new Date('2026-08-26T21:00:00Z')
		expect(rotationIndex(nextWeek)).toBe(rotationIndex(at) + 1)
		expect(buildRotation(nextWeek).ChallengeMapId).toBe(buildRotation(at).ChallengeMapId + 1)
		expect(buildRotation(nextWeek).StartAt).toBe(buildRotation(at).EndAt)
	})

	test('the weekly gift pool leaves out the sandbox dice', async () => {
		// The pool is the catalog's skins, and a sixth of them are `[Sandbox_D4]`…`[Sandbox_D20]`
		// recolours. A week themed on "Sandbox D8 (Pewter)" spends its headline reward on a die, so
		// those prefabs are excluded — everything else is fair game.
		const res = await exports.default.fetch(`${ORIGIN}/api/challenge/v2/getCurrent`)
		expect(res.status).toBe(200)
		const week = (await res.json()) as {
			ChallengeThemeString: string
			Gift: { EquipmentPrefabName: string }
		}
		expect(week.Gift.EquipmentPrefabName.startsWith('[Sandbox_')).toBe(false)
		expect(week.ChallengeThemeString).not.toMatch(/^Sandbox D/)

		// It still rolls something: excluding the dice must not empty the pool, which would leave
		// the week themed on nothing.
		expect(week.ChallengeThemeString).not.toBe('')
	})

	test('the week is themed on the name of the item it rolls', async () => {
		// `ChallengeThemeString` is the reward's catalog FriendlyName. The static file ships it
		// empty on purpose — a generated week's gift isn't known until it is rolled — so the
		// theming happens where the pick does.
		const pool = [
			{
				GiftDropId: 11,
				EquipmentPrefabName: '[ShareCamera]',
				EquipmentModificationGuid: 'guid-a',
				Rarity: 30,
				FriendlyName: 'Camera Skin (Comic)',
			},
			{
				GiftDropId: 12,
				EquipmentPrefabName: '[Boombox]',
				EquipmentModificationGuid: 'guid-b',
				Rarity: 20,
				FriendlyName: 'Boombox (Neon)',
			},
		]
		const at = new Date('2026-08-25T12:00:00Z')
		const themed = withWeeklyGift(buildRotation(at), pool)
		const rolled = pool.find((p) => p.GiftDropId === themed.Gift.GiftDropId)
		expect(rolled).toBeDefined()
		expect(themed.ChallengeThemeString).toBe(rolled!.FriendlyName)

		// An empty pool (the catalog didn't load) leaves the rotation as it was rather than
		// theming the week on nothing.
		expect(withWeeklyGift(buildRotation(at), []).ChallengeThemeString).toBe(
			buildRotation(at).ChallengeThemeString
		)

		// And over the live catalog the route serves a real name, not the placeholder.
		const served = (await (
			await exports.default.fetch(`${ORIGIN}/api/challenge/v2/getCurrent`)
		).json()) as { ChallengeThemeString: string }
		expect(served.ChallengeThemeString).not.toBe('')
	})

	test('every generated week is five valid, distinct challenges', async () => {
		// Walk two years of rotations: the pool, the constraints and the tree builders all have
		// to hold for every week, not just this one.
		for (let week = 0; week < 104; week++) {
			const at = new Date(Date.UTC(2026, 0, 7, 21, 0, 0) + week * 7 * 24 * 60 * 60 * 1000)
			const rotation = buildRotation(at)
			const where = `week ${week}`
			expect(rotation.Challenges, where).toHaveLength(5)
			// Ids have to be unique within a rotation — `challenge_status` is keyed by them.
			const ids = rotation.Challenges.map((ch) => ch.ChallengeId)
			expect(new Set(ids).size, where).toBe(ids.length)
			// One room per week: five ways to say "play Paintball" is not a rotation.
			const scenes = rotation.Challenges.flatMap((ch) => sceneIdsOf(ch.Config))
			expect(new Set(scenes).size, where).toBe(scenes.length)
			for (const challenge of rotation.Challenges) {
				// A malformed tree fails SILENTLY in the client — the challenge just never
				// completes — so the shape is asserted here rather than discovered in game.
				const tree = JSON.parse(challenge.Config) as { ct: number; t?: number }
				expect([0, 1], `${where} ${challenge.Name}`).toContain(tree.ct)
				if (tree.ct === 1) expect(tree.t, `${where} ${challenge.Name}`).toBeGreaterThan(0)
				expect(sceneIdsOf(challenge.Config).length, `${where} ${challenge.Name}`).toBeGreaterThan(0)
				// The copy is generated from the same inputs as the tree, so it can't drift — but a
				// counter still has to say out loud how far it counts.
				if (tree.ct === 1) expect(challenge.Description, where).toContain(String(tree.t))
				expect(challenge.Tooltip.length, `${where} ${challenge.Name}`).toBeGreaterThan(0)
				expect(challenge.Complete, `${where} ${challenge.Name}`).toBe(false)
			}
		}
	})

	/** Every `ct:7` scene id in a rule tree, however deep the tree nests them. */
	function sceneIdsOf(config: string): string[] {
		const scenes: string[] = []
		const walk = (node: unknown): void => {
			if (Array.isArray(node)) return node.forEach(walk)
			if (node === null || typeof node !== 'object') return
			const record = node as { ct?: number; vs?: Array<{ l?: string }> }
			if (record.ct === 7)
				for (const value of record.vs ?? []) if (value.l !== undefined) scenes.push(value.l)
			for (const value of Object.values(record)) walk(value)
		}
		walk(JSON.parse(config))
		return scenes
	}

	test('GET /api/storefronts/v1/adcarouselitems returns the carousel items', async () => {
		const res = await exports.default.fetch(`${ORIGIN}/api/storefronts/v1/adcarouselitems`)
		expect(res.status).toBe(200)
		const body = (await res.json()) as Array<{ AdCarouselItemId: number }>
		expect(Array.isArray(body)).toBe(true)
		expect(body[0]).toHaveProperty('AdCarouselItemId')
	})

	test('GET /api/gamerewards/v1/pending returns []', async () => {
		const res = await exports.default.fetch(`${ORIGIN}/api/gamerewards/v1/pending`)
		expect(res.status).toBe(200)
		expect(await res.json()).toEqual([])
	})

	test('POST /api/challenge/v2/updateProgress echoes the challenge and its stored completion', async () => {
		// Post the live rotation's own challenge and rule tree — what the client actually
		// sends — so editing static/weekly-challenge.json can't quietly stale this test.
		const challenge = CURRENT_CHALLENGE
		const res = await exports.default.fetch(`${ORIGIN}/api/challenge/v2/updateProgress`, {
			method: 'POST',
			headers: { ...(await bearer('70')), 'Content-Type': 'application/json' },
			body: JSON.stringify({
				ChallengeMapId: String(weekly.ChallengeMapId),
				ChallengeId: String(challenge.ChallengeId),
				Config: challenge.Config,
				// .NET's bool.ToString() — the capitalized string, which `Boolean("False")`
				// would read as complete.
				Complete: 'False',
			}),
		})
		expect(res.status).toBe(200)
		expect(await res.json()).toEqual({
			ChallengeMapId: weekly.ChallengeMapId,
			ChallengeId: challenge.ChallengeId,
			Config: challenge.Config,
			Complete: false,
		})
	})

	test('POST /api/challenge/v2/updateProgress is 401 without a token', async () => {
		const res = await exports.default.fetch(`${ORIGIN}/api/challenge/v2/updateProgress`, {
			method: 'POST',
			headers: { 'Content-Type': 'application/json' },
			body: JSON.stringify({ ChallengeMapId: '17', ChallengeId: '49', Complete: 'True' }),
		})
		expect(res.status).toBe(401)
	})

	test('a completed challenge persists and getCurrent stamps it for that player only', async () => {
		const completedId = CURRENT_CHALLENGE.ChallengeId
		const bearerHeaders = await bearer('71')
		const posted = await exports.default.fetch(`${ORIGIN}/api/challenge/v2/updateProgress`, {
			method: 'POST',
			headers: { ...bearerHeaders, 'Content-Type': 'application/json' },
			body: JSON.stringify({
				ChallengeMapId: String(weekly.ChallengeMapId),
				ChallengeId: completedId,
				Complete: 'True',
			}),
		})
		expect(posted.status).toBe(200)

		const mine = await exports.default.fetch(`${ORIGIN}/api/challenge/v2/getCurrent`, {
			headers: bearerHeaders,
		})
		const body = (await mine.json()) as {
			Challenges: Array<{ ChallengeId: number; Complete: boolean }>
		}
		// Only the reported one is stamped; the rest of the rotation is untouched.
		expect(body.Challenges.filter((ch) => ch.Complete).map((ch) => ch.ChallengeId)).toEqual([
			completedId,
		])

		// A different player, and an anonymous caller, still see the static catalog.
		const other = await exports.default.fetch(`${ORIGIN}/api/challenge/v2/getCurrent`, {
			headers: await bearer('72'),
		})
		const otherBody = (await other.json()) as { Challenges: Array<{ Complete: boolean }> }
		expect(otherBody.Challenges.some((ch) => ch.Complete)).toBe(false)
		const anon = await exports.default.fetch(`${ORIGIN}/api/challenge/v2/getCurrent`)
		const anonBody = (await anon.json()) as { Challenges: Array<{ Complete: boolean }> }
		expect(anonBody.Challenges.some((ch) => ch.Complete)).toBe(false)
	})

	test('completion latches within a rotation but resets on a new one', async () => {
		const headers = { ...(await bearer('73')), 'Content-Type': 'application/json' }
		// A challenge id of its own, so this says nothing about the live rotation.
		const post = (ChallengeMapId: string, Complete: string) =>
			exports.default.fetch(`${ORIGIN}/api/challenge/v2/updateProgress`, {
				method: 'POST',
				headers,
				body: JSON.stringify({ ChallengeMapId, ChallengeId: '9001', Complete }),
			})
		const completeOf = async (res: Response) =>
			((await res.json()) as { Complete: boolean }).Complete

		expect(await completeOf(await post('17', 'True'))).toBe(true)
		// A later report that says "not complete" must not un-finish it.
		expect(await completeOf(await post('17', 'False'))).toBe(true)
		// …but the same challenge id in the NEXT rotation starts over.
		expect(await completeOf(await post('18', 'False'))).toBe(false)
		expect(await completeOf(await post('18', 'True'))).toBe(true)
	})

	test('the reported Config is stored and served back over the static rule tree', async () => {
		const challenge = CURRENT_CHALLENGE
		const bearerHeaders = await bearer('78')
		const headers = { ...bearerHeaders, 'Content-Type': 'application/json' }
		// The client posts the catalog's tree with its own running count written into it —
		// `cc` on the counter — which is the progress that has to survive the session.
		const inProgress = challenge.Config.replace(/}$/, ',"cc":1}')
		expect(inProgress).not.toBe(challenge.Config)
		const post = (body: Record<string, string>) =>
			exports.default.fetch(`${ORIGIN}/api/challenge/v2/updateProgress`, {
				method: 'POST',
				headers,
				body: JSON.stringify({
					ChallengeMapId: String(weekly.ChallengeMapId),
					ChallengeId: String(challenge.ChallengeId),
					...body,
				}),
			})
		const reported = await post({ Config: inProgress, Complete: 'False' })
		expect(await reported.json()).toEqual({
			ChallengeMapId: weekly.ChallengeMapId,
			ChallengeId: challenge.ChallengeId,
			Config: inProgress,
			Complete: false,
		})

		const configOf = async () => {
			const res = await exports.default.fetch(`${ORIGIN}/api/challenge/v2/getCurrent`, {
				headers: bearerHeaders,
			})
			const body = (await res.json()) as {
				Challenges: Array<{ ChallengeId: number; Config: string }>
			}
			return body.Challenges.find((ch) => ch.ChallengeId === challenge.ChallengeId)?.Config
		}
		expect(await configOf()).toBe(inProgress)

		// A report carrying no tree is not a reset — the stored progress stays, and is echoed.
		const noConfig = await post({ Complete: 'False' })
		expect(((await noConfig.json()) as { Config: string }).Config).toBe(inProgress)
		expect(await configOf()).toBe(inProgress)

		// Challenges this player never reported keep the authored tree, and so does everyone else.
		const anon = await exports.default.fetch(`${ORIGIN}/api/challenge/v2/getCurrent`)
		const anonBody = (await anon.json()) as { Challenges: Array<{ Config: string }> }
		expect(anonBody.Challenges.map((ch) => ch.Config)).toEqual(
			weekly.Challenges.map((ch) => ch.Config)
		)
	})

	/**
	 * How many of the rotation's challenges earn the gift — three, unless the rotation
	 * publishes fewer or declares itself all-or-nothing (`CHALLENGES_REQUIRED_FOR_GIFT`).
	 */
	const REQUIRED_FOR_GIFT = weekly.CompletedRequired
		? weekly.Challenges.length
		: Math.min(3, weekly.Challenges.length)

	/** Report the live rotation's challenges complete, for one player. */
	async function finishTheRotation(sub: string) {
		const headers = { ...(await bearer(sub)), 'Content-Type': 'application/json' }
		const ids = weekly.Challenges.map((challenge) => challenge.ChallengeId)
		const report = (challengeId: number) =>
			exports.default.fetch(`${ORIGIN}/api/challenge/v2/updateProgress`, {
				method: 'POST',
				headers,
				body: JSON.stringify({
					ChallengeMapId: String(weekly.ChallengeMapId),
					ChallengeId: String(challengeId),
					Complete: 'True',
				}),
			})
		return { ids, report }
	}

	/**
	 * The reward this week advertises, read back from the route that shows it to the client.
	 * The gift is rolled from the storefront catalog rather than authored, so the assertion
	 * that matters is that the box a player receives carries what the rotation promised.
	 */
	async function advertisedGift() {
		const res = await exports.default.fetch(`${ORIGIN}/api/challenge/v2/getCurrent`)
		return ((await res.json()) as { Gift: Record<string, string & number> }).Gift
	}

	/** A player's unopened gift boxes, as the client reads them back. */
	async function giftBoxes(sub: string) {
		const res = await exports.default.fetch(`${ORIGIN}/api/avatar/v2/gifts`, {
			headers: await bearer(sub),
		})
		return (await res.json()) as Array<{
			Id: number
			Message: string
			EquipmentModificationGuid: string
			AvatarItemDesc: string
			ConsumableItemDesc: string
			GiftRarity: number
			GiftContext: number
			Currency: number
			CurrencyType: number
		}>
	}

	test('completing enough of the rotation grants its gift, once', async () => {
		// The live rotation, so this follows whatever this week generated.
		const gift = await advertisedGift()
		const { ids, report } = await finishTheRotation('74')
		// The threshold can't ask for more than the week publishes: a five-challenge week asks
		// for three, and a rotation of three or fewer asks for all of them.
		expect(REQUIRED_FOR_GIFT).toBeLessThanOrEqual(ids.length)
		for (const id of ids.slice(0, REQUIRED_FOR_GIFT - 1)) {
			expect((await report(id)).status).toBe(200)
		}
		// One short of the threshold — the gift isn't due yet, even though challenges remain
		// unfinished either way.
		expect(await giftBoxes('74')).toEqual([])
		await drainFrames()

		expect((await report(ids[REQUIRED_FOR_GIFT - 1] ?? 0)).status).toBe(200)
		const won = await giftBoxes('74')
		expect(won).toHaveLength(1)
		expect(won[0]?.Message).toBe('Weekly challenge complete!')
		expect(won[0]?.EquipmentModificationGuid).toBe(gift.EquipmentModificationGuid)

		// The client is told the moment the set is finished, rather than finding the box the
		// next time it reads the gifts list. `Immediate` (31), from Coach (1).
		const frames = await drainFrames()
		expect(frames).toHaveLength(1)
		expect(frames[0]?.accountId).toBe(74)
		expect(frames[0]?.notificationType).toBe(NotificationType.GiftPackageReceivedImmediate)
		expect(frames[0]?.payload).toEqual({
			Id: won[0]?.Id,
			FromGiftDropId: 0,
			FromPlayerId: 1,
			ConsumableItemDesc: '',
			AvatarItemDesc: gift.AvatarItemDesc,
			// The week's reward is a SKIN, so this is null whatever the block says: a 0 would
			// send the client looking for an avatar item that does not exist.
			AvatarItemType: gift.AvatarItemDesc === '' ? null : gift.AvatarItemType,
			EquipmentPrefabName: gift.EquipmentPrefabName,
			EquipmentModificationGuid: gift.EquipmentModificationGuid,
			CurrencyType: 0,
			Currency: 0,
			Xp: 0,
			Level: 0,
			Platform: -1,
			PlatformsToSpawnOn: -1,
			BalanceType: -2,
			GiftContext: gift.GiftContext,
			// The catalog's rarity for the item — which is also what the generated block carries,
			// since the week's gift is drawn from the catalog itself.
			GiftRarity: gift.GiftRarity,
			Message: 'Weekly challenge complete!',
		})

		// The reward is the item, not the box: it lands in the inventory unopened.
		const unlocked = await exports.default.fetch(`${ORIGIN}/api/equipment/v2/getUnlocked`, {
			headers: await bearer('74'),
		})
		const owned = (await unlocked.json()) as Array<{ ModificationGuid: string }>
		expect(owned.map((e) => e.ModificationGuid)).toContain(gift.EquipmentModificationGuid)

		// Finishing the REST of the set, and re-reporting what's already done (which the client
		// keeps doing), must not mint a second reward.
		for (const id of ids) expect((await report(id)).status).toBe(200)
		expect(await giftBoxes('74')).toHaveLength(1)
	})

	test('a player who already owns the rotation’s gift rolls the fallback box instead', async () => {
		// Own the reward up front — the case the rotation's `FallbackGiftName` exists for.
		const gift = await advertisedGift()
		await grantEquipment(env.DB, 75, {
			ModificationGuid: gift.EquipmentModificationGuid,
			PrefabName: gift.EquipmentPrefabName,
			FriendlyName: 'The week’s reward, already owned',
			Tooltip: '',
			Rarity: 5,
			PlatformMask: -1,
			Favorited: false,
		})

		const { ids, report } = await finishTheRotation('75')
		for (const id of ids.slice(0, REQUIRED_FOR_GIFT - 1)) {
			expect((await report(id)).status).toBe(200)
		}
		await drainFrames()
		expect((await report(ids[REQUIRED_FOR_GIFT - 1] ?? 0)).status).toBe(200)

		const won = await giftBoxes('75')
		expect(won).toHaveLength(1)
		// Something they don't have, at the tier `FallbackGiftName` names ("4-Star Box" → 30),
		// rather than a second copy of the gift.
		const rolled = won[0]
		expect(rolled?.EquipmentModificationGuid).not.toBe(gift.EquipmentModificationGuid)
		expect(rolled?.GiftRarity).toBe(30)
		expect(
			(rolled?.AvatarItemDesc ?? '') !== '' || (rolled?.EquipmentModificationGuid ?? '') !== ''
		).toBe(true)

		// The frame announces what was ROLLED, not the box that promised it — so the client
		// pops the item they actually won.
		const frames = await drainFrames()
		expect(frames).toHaveLength(1)
		expect(frames[0]?.notificationType).toBe(NotificationType.GiftPackageReceivedImmediate)
		expect(frames[0]?.payload).toMatchObject({
			Id: rolled?.Id,
			FromPlayerId: 1,
			GiftRarity: 30,
			AvatarItemDesc: rolled?.AvatarItemDesc,
			EquipmentModificationGuid: rolled?.EquipmentModificationGuid,
			Message: 'Weekly challenge complete!',
		})
	})

	test('buying a query drop rolls a real item into the buyer’s inventory', async () => {
		// sf2's "4-Star Unique Box" (539) — an `IsQuery` drop with no item fields of its own,
		// which before the roll existed debited the buyer and granted nothing.
		const res = await exports.default.fetch(`${ORIGIN}/api/storefronts/v2/buyItem`, {
			method: 'POST',
			headers: { ...(await bearer('76')), 'Content-Type': 'application/json' },
			body: JSON.stringify({
				StorefrontType: 2,
				PurchasableItemId: 539,
				CurrencyType: CurrencyType.RecCenterTokens,
				RequestedPrice: 800,
			}),
		})
		expect(res.status).toBe(200)

		// The RESPONSE describes what the roll landed on, not the box that was bought: the
		// client draws the purchase from this entry, and the box's own fields are all empty.
		const bought = (await res.json()) as {
			BalanceUpdates: Array<{
				Data: Array<{
					AvatarItemDesc: string
					EquipmentModificationGuid: string
					GiftRarity: number
				}>
			}>
		}
		const entry = bought.BalanceUpdates[0]?.Data[0]
		expect(entry?.GiftRarity).toBe(30)
		expect(`${entry?.AvatarItemDesc ?? ''}${entry?.EquipmentModificationGuid ?? ''}`).not.toBe('')

		const boxes = await giftBoxes('76')
		expect(boxes).toHaveLength(1)
		// The box shows what was rolled — a real 4-star item, not the empty box drop.
		expect(boxes[0]?.GiftRarity).toBe(30)
		expect(entry?.AvatarItemDesc).toBe(boxes[0]?.AvatarItemDesc)
		const key = (box?: { AvatarItemDesc: string; EquipmentModificationGuid: string }) =>
			`${box?.AvatarItemDesc ?? ''}|${box?.EquipmentModificationGuid ?? ''}`
		expect(key(boxes[0])).not.toBe('|')

		// …and it is already in their inventory, unopened box or not.
		const items = await exports.default.fetch(`${ORIGIN}/api/avatar/v4/items`, {
			headers: await bearer('76'),
		})
		// v4 serves the camelCase DTO, unlike the PascalCase records on the gift box.
		const owned = (await items.json()) as Array<{ avatarItemDesc: string }>
		if ((boxes[0]?.AvatarItemDesc ?? '') !== '') {
			expect(owned.map((i) => i.avatarItemDesc)).toContain(boxes[0]?.AvatarItemDesc)
		}

		// A second box can't roll the same prize: "an item that you don't have" excludes what
		// the first roll just granted. Two draws from a 244-item pool could collide by chance,
		// so this only holds because the pool is filtered by ownership.
		const second = await exports.default.fetch(`${ORIGIN}/api/storefronts/v2/buyItem`, {
			method: 'POST',
			headers: { ...(await bearer('76')), 'Content-Type': 'application/json' },
			body: JSON.stringify({
				StorefrontType: 2,
				PurchasableItemId: 539,
				CurrencyType: CurrencyType.RecCenterTokens,
				RequestedPrice: 800,
			}),
		})
		expect(second.status).toBe(200)
		const after = await giftBoxes('76')
		expect(after).toHaveLength(2)
		expect(key(after[0])).not.toBe(key(after[1]))
	})

	test('buying sf3’s Uncommon Random box answers with the rolled item', async () => {
		// The purchase that came back as an empty box: an sf3 query drop, rolled out of the very
		// catalog it sells in.
		const res = await exports.default.fetch(`${ORIGIN}/api/storefronts/v2/buyItem`, {
			method: 'POST',
			headers: { ...(await bearer('77')), 'Content-Type': 'application/json' },
			body: JSON.stringify({
				StorefrontType: 3,
				PurchasableItemId: 2455,
				CurrencyType: CurrencyType.RecCenterTokens,
				RequestedPrice: 200,
				CouponConsumablePlayerMappingId: null,
				Gift: null,
			}),
		})
		expect(res.status).toBe(200)
		const body = (await res.json()) as {
			BalanceUpdates: Array<{
				Data: Array<{ Id: number; AvatarItemDesc: string; GiftRarity: number }>
			}>
		}
		const entry = body.BalanceUpdates[0]?.Data[0]
		// Uncommon: rarity 10, and a real item rather than the box's empty fields.
		expect(entry?.GiftRarity).toBe(10)
		expect(entry?.AvatarItemDesc).not.toBe('')

		const boxes = await giftBoxes('77')
		expect(boxes).toHaveLength(1)
		expect(boxes[0]?.Id).toBe(entry?.Id)
		expect(boxes[0]?.AvatarItemDesc).toBe(entry?.AvatarItemDesc)
	})

	test('POST /api/gamerewards/v1/request claims once an hour per reward type and activity — FirstActivityOfDay once a day per player', async () => {
		const headers = {
			...(await bearer('80')),
			'Content-Type': 'application/x-www-form-urlencoded',
		}
		const request = (body: string) =>
			exports.default.fetch(`${ORIGIN}/api/gamerewards/v1/request`, {
				method: 'POST',
				headers,
				body,
			})
		const statusOf = (rewardType: string, giftContext = '') =>
			env.DB.prepare(
				`SELECT granted_at, grant_count FROM reward_status
				 WHERE account_id = 80 AND reward_type = ?1 AND gift_context = ?2`
			)
				.bind(rewardType, giftContext)
				.first<{ granted_at: string; grant_count: number }>()

		// A claim answers the empty list the client accepts — the reward rides in a gift box.
		const first = await request(
			'rewardType=FirstActivityOfDay&Message=First%20Game%20of%20the%20Day'
		)
		expect(first.status).toBe(200)
		expect(await first.json()).toEqual([])
		const claimed = await statusOf('FirstActivityOfDay')
		expect(claimed?.grant_count).toBe(1)

		// Asking again inside the day claims nothing — and must not push the cooldown out,
		// or a client that retries in a loop would never become eligible. It is the PLAYER's
		// first activity of the day, so another activity doesn't claim it either, and writes
		// no row of its own.
		expect((await request('rewardType=FirstActivityOfDay&Message=again')).status).toBe(200)
		expect((await request('rewardType=FirstActivityOfDay&giftContext=Soccer')).status).toBe(200)
		expect(await statusOf('FirstActivityOfDay')).toEqual(claimed)
		expect(await statusOf('FirstActivityOfDay', 'Soccer')).toBeNull()

		// A different type has its own cooldown — and so does each `giftContext` within a type:
		// Soccer and Paintball are separate rows that each claim once.
		expect(
			(
				await request(
					'rewardType=PostGameActivity&Message=Activity%20completed%21&giftContext=Soccer'
				)
			).status
		).toBe(200)
		expect((await statusOf('PostGameActivity', 'Soccer'))?.grant_count).toBe(1)
		expect(
			(
				await request(
					'rewardType=PostGameActivity&Message=Activity%20completed%21&giftContext=Paintball'
				)
			).status
		).toBe(200)
		expect((await statusOf('PostGameActivity', 'Paintball'))?.grant_count).toBe(1)

		// …but the same activity again inside the hour claims nothing.
		const soccer = await statusOf('PostGameActivity', 'Soccer')
		expect((await request('rewardType=PostGameActivity&giftContext=Soccer')).status).toBe(200)
		expect(await statusOf('PostGameActivity', 'Soccer')).toEqual(soccer)

		// A contextless ask is its own bucket (`''`), not a wildcard over the two above.
		expect((await request('rewardType=PostGameActivity&Message=no%20context')).status).toBe(200)
		expect((await statusOf('PostGameActivity'))?.grant_count).toBe(1)
		expect((await request('rewardType=PostGameActivity&Message=again')).status).toBe(200)
		expect((await statusOf('PostGameActivity'))?.grant_count).toBe(1)

		// Once the hour has passed, an hourly type claims again — but FirstActivityOfDay waits
		// out the whole day.
		const age = (rewardType: string, ms: number) =>
			env.DB.prepare(
				'UPDATE reward_status SET granted_at = ?1 WHERE account_id = 80 AND reward_type = ?2'
			)
				.bind(new Date(Date.now() - ms).toISOString(), rewardType)
				.run()
		await age('PostGameActivity', 61 * 60 * 1000)
		expect((await request('rewardType=PostGameActivity&giftContext=Soccer')).status).toBe(200)
		expect((await statusOf('PostGameActivity', 'Soccer'))?.grant_count).toBe(2)
		await age('FirstActivityOfDay', 61 * 60 * 1000)
		expect((await request('rewardType=FirstActivityOfDay&Message=later')).status).toBe(200)
		expect((await statusOf('FirstActivityOfDay'))?.grant_count).toBe(1)
		await age('FirstActivityOfDay', 25 * 60 * 60 * 1000)
		expect((await request('rewardType=FirstActivityOfDay&Message=tomorrow')).status).toBe(200)
		expect((await statusOf('FirstActivityOfDay'))?.grant_count).toBe(2)
	})

	test('a claimed game reward pays XP into a gift box, and announces it', async () => {
		const request = async (body: string) =>
			exports.default.fetch(`${ORIGIN}/api/gamerewards/v1/request`, {
				method: 'POST',
				headers: {
					...(await bearer('82')),
					'Content-Type': 'application/x-www-form-urlencoded',
				},
				body,
			})
		/** Age the cooldown so the next ask is eligible again. */
		const passADay = () =>
			env.DB.prepare(
				"UPDATE reward_status SET granted_at = ?1 WHERE account_id = 82 AND reward_type = 'FirstActivityOfDay'"
			)
				.bind(new Date(Date.now() - 25 * 60 * 60 * 1000).toISOString())
				.run()
		/** The reward's own boxes — not the token box (GiftContext 51) each claim also pays. */
		const rewardBoxes = async () => (await giftBoxes('82')).filter((b) => b.GiftContext !== 51)
		/** Frames bar the token payout's balance update and box. */
		const rewardFrames = async () =>
			(await drainFrames()).filter(
				(f) =>
					f.notificationType !== NotificationType.StorefrontBalanceUpdate &&
					(f.payload as { GiftContext?: number }).GiftContext !== 51
			)

		await drainFrames()
		expect((await getProgression(env.DB, 82)).XP).toBe(0)
		const res = await request('rewardType=FirstActivityOfDay&Message=First%20Game%20of%20the%20Day')
		expect(res.status).toBe(200)
		expect(await res.json()).toEqual([])

		// 10 XP is exactly what level 1 costs, so a fresh player's first reward is a level-up.
		expect(await getProgression(env.DB, 82)).toEqual({ PlayerId: 82, Level: 2, XP: 0 })

		// Two reward boxes: the XP itself, carrying the message the client asked to show and no
		// item — a game reward is not an item — then the level-up's. (The tokens come in a box
		// of their own.)
		const first = await rewardBoxes()
		expect(first).toHaveLength(2)
		expect(first[0]).toMatchObject({
			Xp: 10,
			Message: 'First Game of the Day',
			AvatarItemDesc: '',
			EquipmentModificationGuid: '',
			ConsumableItemDesc: '',
		})

		// The box, then the bar, then the level-up box.
		const frames = await rewardFrames()
		expect(frames.map((f) => f.notificationType)).toEqual([
			NotificationType.GiftPackageReceivedImmediate,
			NotificationType.PlayerProgressionLevelUpdate,
			NotificationType.GiftPackageReceivedImmediate,
		])
		expect(frames[0]?.accountId).toBe(82)
		expect(frames[0]?.payload).toMatchObject({
			Id: first[0]?.Id,
			FromPlayerId: 1,
			Xp: 10,
			// GiftContext.GameRewards — the box came from gameplay, not a purchase.
			GiftContext: 50,
			Message: 'First Game of the Day',
		})
		expect(frames[1]?.payload).toEqual({ PlayerId: 82, Level: 2, XP: 0 })

		// Level 2 pays 2-Star Clothing per the published table: an AVATAR ITEM, never an
		// equipment skin, which is what the avatar-only roll is for.
		const clothingBox = first[1]
		expect(clothingBox?.Message).toBe('Level 2!')
		expect(clothingBox?.AvatarItemDesc).not.toBe('')
		expect(clothingBox?.EquipmentModificationGuid).toBe('')
		expect(clothingBox?.ConsumableItemDesc).toBe('')
		expect(clothingBox?.GiftRarity).toBe(10)

		const items = await exports.default.fetch(`${ORIGIN}/api/avatar/v4/items`, {
			headers: await bearer('82'),
		})
		// v4 serves the camelCase DTO, unlike the PascalCase records on the gift box.
		const owned = (await items.json()) as Array<{ avatarItemDesc: string }>
		expect(owned.map((i) => i.avatarItemDesc)).toContain(clothingBox?.AvatarItemDesc)

		// An on-cooldown ask pays nothing: no more boxes, no frames, no more XP.
		const boxCount = (await giftBoxes('82')).length
		expect((await request('rewardType=FirstActivityOfDay&Message=again')).status).toBe(200)
		expect(await getProgression(env.DB, 82)).toEqual({ PlayerId: 82, Level: 2, XP: 0 })
		expect(await giftBoxes('82')).toHaveLength(boxCount)
		expect(await drainFrames()).toEqual([])

		// The next reward reaches level 3, which the table pays as a CONSUMABLE rather than
		// clothing — rolled without a rarity, since the table names none for them.
		await passADay()
		expect((await request('rewardType=FirstActivityOfDay&Message=Second')).status).toBe(200)
		expect(await getProgression(env.DB, 82)).toEqual({ PlayerId: 82, Level: 3, XP: 0 })

		const afterLevel3 = await giftBoxes('82')
		const consumableBox = afterLevel3[afterLevel3.length - 1]
		expect(consumableBox?.Message).toBe('Level 3!')
		expect(consumableBox?.ConsumableItemDesc).not.toBe('')
		expect(consumableBox?.AvatarItemDesc).toBe('')
		expect(consumableBox?.EquipmentModificationGuid).toBe('')

		const consumables = await exports.default.fetch(`${ORIGIN}/api/consumables/v2/getUnlocked`, {
			headers: await bearer('82'),
		})
		const held = (await consumables.json()) as Array<{ ConsumableItemDesc: string }>
		expect(held.map((cons) => cons.ConsumableItemDesc)).toContain(consumableBox?.ConsumableItemDesc)
	})

	test('a giftContext naming a quest-rewards.json key pays one of that activity’s rewards', async () => {
		const request = async (body: string) =>
			exports.default.fetch(`${ORIGIN}/api/gamerewards/v1/request`, {
				method: 'POST',
				headers: {
					...(await bearer('83')),
					'Content-Type': 'application/x-www-form-urlencoded',
				},
				body,
			})
		await drainFrames()

		// Quest_Goblin_S: forty avatar-item rewards, all at the goblin quest's S-rank context.
		const goblin = await request(
			'rewardType=PostGameActivity&Message=Quest%20complete&giftContext=Quest_Goblin_S'
		)
		expect(goblin.status).toBe(200)
		expect(await goblin.json()).toEqual([])
		// Three boxes: the quest reward, the PostGameActivity tokens (covered below), and — 10 XP
		// being level 1's whole cost — the level-2 box.
		const boxes = await giftBoxes('83')
		expect(boxes).toHaveLength(3)
		const box = boxes[0]
		expect(box).toMatchObject({ Xp: 10, Message: 'Quest complete', GiftContext: 4003 })
		expect(boxes[1]).toMatchObject({ GiftContext: 51, Currency: 250 })
		expect(boxes[2]?.Message).toBe('Level 2!')
		expect(box?.AvatarItemDesc).not.toBe('')
		const row = questRewards.Quest_Goblin_S.find((r) => r.AvatarItemDesc === box?.AvatarItemDesc)
		expect(row).toBeDefined()
		expect(box?.GiftRarity).toBe(row?.GiftRarity)
		// …and the item is in the inventory, not just on the box.
		const items = await exports.default.fetch(`${ORIGIN}/api/avatar/v4/items`, {
			headers: await bearer('83'),
		})
		const owned = (await items.json()) as Array<{ avatarItemDesc: string }>
		expect(owned.map((i) => i.avatarItemDesc)).toContain(box?.AvatarItemDesc)
		// The box announces the activity's context, not the generic GameRewards one.
		const frames = await drainFrames()
		expect(frames[0]?.notificationType).toBe(NotificationType.GiftPackageReceivedImmediate)
		expect(frames[0]?.payload).toMatchObject({
			GiftContext: 4003,
			AvatarItemDesc: box?.AvatarItemDesc,
		})

		// Lasertag's single reward is 50 Laser Tag tickets: credited to the balance, no item.
		const before = await getBalance(
			env.DB,
			83,
			CurrencyType.LaserTagTickets,
			DEFAULT_STARTING_TOKENS
		)
		expect((await request('rewardType=PostGameActivity&giftContext=Lasertag')).status).toBe(200)
		expect(
			await getBalance(env.DB, 83, CurrencyType.LaserTagTickets, DEFAULT_STARTING_TOKENS)
		).toBe(before + 50)
		const ticketBox = (await giftBoxes('83')).find(
			(b) => b.CurrencyType === CurrencyType.LaserTagTickets
		)
		expect(ticketBox).toMatchObject({
			Currency: 50,
			CurrencyType: CurrencyType.LaserTagTickets,
			AvatarItemDesc: '',
			GiftContext: 9000,
		})
		const ticketFrames = await drainFrames()
		expect(ticketFrames.map((f) => f.notificationType)).toContain(
			NotificationType.StorefrontBalanceUpdate
		)

		// An activity the table doesn't know pays the plain XP box, as before — the last
		// GameRewards box, behind Bowling's own tokens.
		expect((await request('rewardType=PostGameActivity&giftContext=Bowling')).status).toBe(200)
		const plain = (await giftBoxes('83')).findLast((b) => b.GiftContext === 50)
		expect(plain).toMatchObject({ Xp: 10, AvatarItemDesc: '', Currency: 0, GiftContext: 50 })

		// A reward the player already owns is never drawn again: Dodgeball has three rows, so
		// three claims hand over all three, and a fourth — nothing left to give — pays the
		// plain XP box rather than a duplicate.
		const dodgeball = questRewards.Dodgeball.map((r) => r.AvatarItemDesc)
		const handed: string[] = []
		for (let i = 0; i < 4; i++) {
			await env.DB.prepare(
				"DELETE FROM reward_status WHERE account_id = 83 AND gift_context = 'Dodgeball'"
			).run()
			expect((await request('rewardType=PostGameActivity&giftContext=Dodgeball')).status).toBe(200)
			const latest = (await giftBoxes('83')).findLast(
				(b) => b.GiftContext === 8000 || b.GiftContext === 50
			)
			if (i < 3) handed.push(latest?.AvatarItemDesc as string)
			else expect(latest).toMatchObject({ AvatarItemDesc: '', GiftContext: 50 })
		}
		expect(handed.toSorted()).toEqual(dodgeball.toSorted())
	})

	test('PostGameActivity/PostQuestActivity pay 250 tokens, up to 1250 per player per 24h', async () => {
		const request = async (body: string) =>
			exports.default.fetch(`${ORIGIN}/api/gamerewards/v1/request`, {
				method: 'POST',
				headers: {
					...(await bearer('84')),
					'Content-Type': 'application/x-www-form-urlencoded',
				},
				body,
			})
		const tokens = () =>
			getBalance(env.DB, 84, CurrencyType.RecCenterTokens, DEFAULT_STARTING_TOKENS)
		const tokenBoxes = async () => (await giftBoxes('84')).filter((b) => b.GiftContext === 51)
		const allowance = () =>
			env.DB.prepare(
				"SELECT granted_at, grant_count FROM reward_status WHERE account_id = 84 AND reward_type = '$tokens'"
			).first<{ granted_at: string; grant_count: number }>()
		await drainFrames()
		const start = await tokens()

		// FirstActivityOfDay pays its 250 OUTSIDE the allowance: no allowance row, and the cap
		// below is still five claims' worth on top of it.
		expect((await request('rewardType=FirstActivityOfDay&giftContext=Soccer')).status).toBe(200)
		expect(await tokens()).toBe(start + 250)
		expect(await allowance()).toBeNull()
		await drainFrames()
		const base = start + 250

		// PostGameActivity: +250, in a box of its own after the reward's, credited to the
		// balance and announced as such.
		expect((await request('rewardType=PostGameActivity&giftContext=Soccer')).status).toBe(200)
		expect(await tokens()).toBe(base + 250)
		const boxes = (await tokenBoxes()).slice(1)
		expect(boxes).toHaveLength(1)
		expect(boxes[0]).toMatchObject({
			Currency: 250,
			CurrencyType: CurrencyType.RecCenterTokens,
			Xp: 0,
			AvatarItemDesc: '',
			Message: 'Activity bonus!',
		})
		// The balance frame carries the resulting total, and the token box is announced like
		// any other.
		const frames = await drainFrames()
		expect(
			frames.findLast((f) => f.notificationType === NotificationType.StorefrontBalanceUpdate)
				?.payload
		).toMatchObject({ CurrencyType: CurrencyType.RecCenterTokens, Balance: base + 250 })
		expect(
			frames.filter((f) => f.notificationType === NotificationType.GiftPackageReceivedImmediate)
		).toContainEqual(
			expect.objectContaining({
				payload: expect.objectContaining({ Currency: 250, GiftContext: 51, Id: boxes[0]?.Id }),
			})
		)
		const opened = (await allowance())?.granted_at
		expect(await allowance()).toMatchObject({ grant_count: 250 })

		// PostQuestActivity counts the same, and the allowance is the player's, whatever the
		// activity — a contextless ask included.
		for (const body of [
			'rewardType=PostQuestActivity&giftContext=Quest_Goblin_S',
			'rewardType=PostGameActivity',
			'rewardType=PostGameActivity&giftContext=Paintball',
			'rewardType=PostGameActivity&giftContext=Bowling',
		]) {
			expect((await request(body)).status).toBe(200)
		}
		expect(await tokens()).toBe(base + 1250)
		// The window keeps its start as the total grows.
		expect(await allowance()).toEqual({ granted_at: opened, grant_count: 1250 })

		// At the cap: the claim still pays its XP box, but no tokens.
		const before = (await giftBoxes('84')).length
		expect((await request('rewardType=PostGameActivity&giftContext=Dodgeball')).status).toBe(200)
		expect(await tokens()).toBe(base + 1250)
		expect(await tokenBoxes()).toHaveLength(6)
		expect((await giftBoxes('84')).length).toBeGreaterThan(before)
		expect(await allowance()).toMatchObject({ grant_count: 1250 })

		// Once the window is 24h old, the next claim opens a fresh one.
		await env.DB.prepare(
			"UPDATE reward_status SET granted_at = ?1 WHERE account_id = 84 AND reward_type = '$tokens'"
		)
			.bind(new Date(Date.now() - 25 * 60 * 60 * 1000).toISOString())
			.run()
		expect((await request('rewardType=PostGameActivity&giftContext=Basketball')).status).toBe(200)
		expect(await tokens()).toBe(base + 1500)
		const reopened = await allowance()
		expect(reopened?.grant_count).toBe(250)
		expect((reopened?.granted_at ?? '') > (opened ?? '')).toBe(true)
	})

	test('game-reward XP stops at 150 per player per 24h, FirstActivityOfDay aside', async () => {
		const request = async (body: string) =>
			exports.default.fetch(`${ORIGIN}/api/gamerewards/v1/request`, {
				method: 'POST',
				headers: {
					...(await bearer('85')),
					'Content-Type': 'application/x-www-form-urlencoded',
				},
				body,
			})
		const xp = async () => {
			const { Level, XP } = await getProgression(env.DB, 85)
			return { Level, XP }
		}
		const allowance = () =>
			env.DB.prepare(
				"SELECT granted_at, grant_count FROM reward_status WHERE account_id = 85 AND reward_type = '$xp'"
			).first<{ granted_at: string; grant_count: number }>()
		const rewardBoxes = async () =>
			(await giftBoxes('85')).filter((b) => b.GiftContext !== 51 && !b.Message?.startsWith('Level'))

		// A claim's XP draws on the allowance.
		expect((await request('rewardType=PostGameActivity&giftContext=Soccer')).status).toBe(200)
		expect(await allowance()).toMatchObject({ grant_count: 10 })
		expect(await xp()).toEqual({ Level: 2, XP: 0 })

		// One claim short of the cap: the next pays its 10 and fills it.
		await env.DB.prepare(
			"UPDATE reward_status SET grant_count = 140 WHERE account_id = 85 AND reward_type = '$xp'"
		).run()
		expect((await request('rewardType=PostGameActivity&giftContext=Paintball')).status).toBe(200)
		expect(await allowance()).toMatchObject({ grant_count: 150 })
		expect(await xp()).toEqual({ Level: 3, XP: 0 })
		const boxesAtCap = (await rewardBoxes()).length
		await drainFrames()

		// At the cap: no XP, no progression frame, and — nothing else to carry — no reward box.
		// The tokens are their own allowance and still pay.
		const tokensBefore = await getBalance(
			env.DB,
			85,
			CurrencyType.RecCenterTokens,
			DEFAULT_STARTING_TOKENS
		)
		expect((await request('rewardType=PostGameActivity&giftContext=Bowling')).status).toBe(200)
		expect(await xp()).toEqual({ Level: 3, XP: 0 })
		expect(await allowance()).toMatchObject({ grant_count: 150 })
		expect(await rewardBoxes()).toHaveLength(boxesAtCap)
		expect(
			await getBalance(env.DB, 85, CurrencyType.RecCenterTokens, DEFAULT_STARTING_TOKENS)
		).toBe(tokensBefore + 250)
		expect((await drainFrames()).map((f) => f.notificationType)).not.toContain(
			NotificationType.PlayerProgressionLevelUpdate
		)

		// An activity with a prize still hands it over, in a box carrying no XP.
		expect((await request('rewardType=PostQuestActivity&giftContext=Quest_Goblin_S')).status).toBe(
			200
		)
		const quest = (await rewardBoxes()).at(-1)
		expect(quest).toMatchObject({ GiftContext: 4003, Xp: 0 })
		expect(quest?.AvatarItemDesc).not.toBe('')
		expect(await xp()).toEqual({ Level: 3, XP: 0 })

		// FirstActivityOfDay's XP is a bonus on top of the cap.
		expect((await request('rewardType=FirstActivityOfDay&giftContext=Soccer')).status).toBe(200)
		expect(await xp()).toEqual({ Level: 4, XP: 0 })
		expect(await allowance()).toMatchObject({ grant_count: 150 })

		// Once the window is 24h old, the next claim opens a fresh one.
		await env.DB.prepare(
			"UPDATE reward_status SET granted_at = ?1 WHERE account_id = 85 AND reward_type = '$xp'"
		)
			.bind(new Date(Date.now() - 25 * 60 * 60 * 1000).toISOString())
			.run()
		expect((await request('rewardType=PostGameActivity&giftContext=Basketball')).status).toBe(200)
		expect(await allowance()).toMatchObject({ grant_count: 10 })
		expect(await xp()).toEqual({ Level: 4, XP: 10 })
	})

	test('POST /api/gamerewards/v1/request is 401 without a token, and ignores a typeless ask', async () => {
		const anon = await exports.default.fetch(`${ORIGIN}/api/gamerewards/v1/request`, {
			method: 'POST',
			headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
			body: 'rewardType=FirstActivityOfDay&Message=First%20Game%20of%20the%20Day',
		})
		expect(anon.status).toBe(401)

		// No reward type: nothing to gate, so no row keyed on an empty string.
		const typeless = await exports.default.fetch(`${ORIGIN}/api/gamerewards/v1/request`, {
			method: 'POST',
			headers: {
				...(await bearer('81')),
				'Content-Type': 'application/x-www-form-urlencoded',
			},
			body: 'Message=First%20Game%20of%20the%20Day',
		})
		expect(typeless.status).toBe(200)
		expect(await typeless.json()).toEqual([])
		const rows = await env.DB.prepare(
			'SELECT COUNT(*) AS count FROM reward_status WHERE account_id = 81'
		).first<{ count: number }>()
		expect(rows?.count).toBe(0)
	})

	test('GET /api/roomkeys/v1/mine lists the keys the caller holds, across rooms', async () => {
		const mine = async (sub: string | null) =>
			exports.default.fetch(
				`${ORIGIN}/api/roomkeys/v1/mine`,
				sub === null ? undefined : { headers: await bearer(sub) }
			)
		expect((await mine(null)).status).toBe(401)
		expect(await (await mine('7601')).json()).toEqual([])

		const insert = async (roomId: number, name: string, imageName: string) =>
			(await env.DB.prepare(
				`INSERT INTO room_key
					(replication_id, room_id, key_type, name, description, price, purchase_currency_id, image_name, created_at)
				 VALUES ('0f8c3a7e-1d42-4b90-9c11-7a6e5d2b8f03', ?1, 'Key', ?2, '', 0, NULL, ?3, '2026-10-14T12:00:00Z')
				 RETURNING room_key_id`
			)
				.bind(roomId, name, imageName)
				.first<{ room_key_id: number }>())!.room_key_id
		const a = await insert(12, 'VIP Key', '')
		const b = await insert(2511, 'Art Key', 'key.png')
		const notHeld = await insert(12, 'Other', '')
		for (const [key, account] of [
			[b, 7601],
			[a, 7601],
			[notHeld, 7602],
		]) {
			await env.DB.prepare(
				"INSERT INTO room_key_player (room_key_id, account_id, awarded_at) VALUES (?1, ?2, '')"
			)
				.bind(key, account)
				.run()
		}

		const res = await mine('7601')
		expect(res.status).toBe(200)
		const keys = (await res.json()) as Array<Record<string, unknown>>
		expect(keys).toEqual([
			{
				RoomKeyId: a,
				ReplicationId: '0f8c3a7e-1d42-4b90-9c11-7a6e5d2b8f03',
				RoomId: 12,
				Name: 'VIP Key',
				Description: '',
				Price: 0,
				PurchaseCurrencyId: null,
				CreatedAt: '2026-10-14T12:00:00Z',
				ImageName: '',
				Type: 0,
				IsGiftable: false,
				Visibility: 0,
			},
			expect.objectContaining({ RoomKeyId: b, RoomId: 2511, ImageName: 'key.png' }),
		])
		// Member order as the client was observed receiving it.
		expect(Object.keys(keys[0]!)).toEqual([
			'RoomKeyId',
			'ReplicationId',
			'RoomId',
			'Name',
			'Description',
			'Price',
			'PurchaseCurrencyId',
			'CreatedAt',
			'ImageName',
			'Type',
			'IsGiftable',
			'Visibility',
		])

		await env.DB.prepare('DELETE FROM room_key_player').run()
		await env.DB.prepare('DELETE FROM room_key').run()
	})

	test('GET /api/subscriptionseasons/v1/seasons/current returns []', async () => {
		const res = await exports.default.fetch(`${ORIGIN}/api/subscriptionseasons/v1/seasons/current`)
		expect(res.status).toBe(200)
		expect(await res.json()).toEqual([])
	})

	const getSubscription = async (headers: Record<string, string> = {}) =>
		exports.default.fetch(`${ORIGIN}/api/CampusCard/v1/UpdateAndGetSubscription`, {
			method: 'POST',
			headers,
		})

	// Fixed values, and no auth: the client reads this while assembling the RR+ page, so a
	// 401 would only be a way for that load to stall.
	test('GET /api/incentivizedreferrals/progress reports an untouched referral track', async () => {
		const res = await exports.default.fetch(`${ORIGIN}/api/incentivizedreferrals/progress`, {
			headers: await bearer('207'),
		})
		expect(res.status).toBe(200)
		// The payload is nested under `value`, unlike econ's flat balance bodies.
		expect(await res.json()).toEqual({
			success: true,
			value: { ReferralsVerifiedCount: 0, PlayerReferralRewards: [] },
		})
	})

	test('GET /api/incentivizedreferrals/progress 401s without a bearer token', async () => {
		const res = await exports.default.fetch(`${ORIGIN}/api/incentivizedreferrals/progress`)
		expect(res.status).toBe(401)
		expect(await res.text()).toBe('')
	})

	test('GET /api/influencerpartnerprogram/influencers lists every isInfluencer account', async () => {
		const seed = async (accountId: number, isInfluencer: boolean | undefined) => {
			await env.DB.prepare('INSERT OR IGNORE INTO account (data) VALUES (?1)')
				.bind(
					JSON.stringify({
						accountId,
						username: `Influencer${accountId}`,
						...(isInfluencer === undefined ? {} : { isInfluencer }),
					})
				)
				.run()
		}
		await seed(8103, true)
		await seed(8101, true)
		await seed(8102, false) // explicitly not one
		await seed(8104, undefined) // flag never set

		const res = await exports.default.fetch(
			`${ORIGIN}/api/influencerpartnerprogram/influencers?take=1000`,
			{ headers: await bearer('207') }
		)
		expect(res.status).toBe(200)
		// An object around the list, not a bare array — unlike its single-account siblings
		// below, whose whole body is a bare tier number. Lowest id first; the whole list is
		// one page, so the continuation token is null rather than absent.
		expect(await res.json()).toEqual({ InfluencerIds: [8101, 8103], ContinuationToken: null })

		// The list is read through the `is_influencer` generated column's partial index
		// (auth migration 0012), so the mirrored schema has to carry it — and the planner
		// has to pick it over a scan of the account table.
		const plan = await env.DB.prepare(
			'EXPLAIN QUERY PLAN SELECT account_id FROM account WHERE is_influencer = 1 ORDER BY account_id'
		).all<{ detail: string }>()
		expect(plan.results.map((r) => r.detail).join('\n')).toContain('idx_account_is_influencer')

		// Revoking drops the account from the list on the next read — no cache in between.
		await updateAccount(env.DB, 8103, { isInfluencer: false })
		const after = await exports.default.fetch(
			`${ORIGIN}/api/influencerpartnerprogram/influencers?take=1000`,
			{ headers: await bearer('207') }
		)
		expect(await after.json()).toEqual({ InfluencerIds: [8101], ContinuationToken: null })
	})

	test('GET /api/influencerpartnerprogram/influencers 401s without a bearer token', async () => {
		const res = await exports.default.fetch(`${ORIGIN}/api/influencerpartnerprogram/influencers`)
		expect(res.status).toBe(401)
	})

	test('POST /api/influencerpartnerprogram/support picks the ONE influencer the caller supports', async () => {
		const seed = async (accountId: number, isInfluencer: boolean) => {
			await env.DB.prepare('INSERT OR IGNORE INTO account (data) VALUES (?1)')
				.bind(JSON.stringify({ accountId, username: `Support${accountId}`, isInfluencer }))
				.run()
		}
		await seed(8201, true)
		await seed(8202, true)
		await seed(8203, false) // a player, not an influencer
		await seed(8204, false) // the supporter
		const support = async (body: string, sub = '8204') =>
			exports.default.fetch(`${ORIGIN}/api/influencerpartnerprogram/support`, {
				method: 'POST',
				headers: { ...(await bearer(sub)), 'content-type': 'application/x-www-form-urlencoded' },
				body,
			})
		const my = async (sub = '8204') => {
			const res = await exports.default.fetch(
				`${ORIGIN}/api/influencerpartnerprogram/myinfluencer`,
				{
					headers: await bearer(sub),
				}
			)
			expect(res.status).toBe(200)
			return res.text()
		}

		// Nobody picked yet: a bare 0, the whole body.
		expect(await my()).toBe('0')

		// The raw form body the client posts. The reply is a bare status envelope — no `Value`;
		// the pick is read back from `…/myinfluencer`.
		const res = await support('influencerAccountId=8201')
		expect(res.status).toBe(200)
		expect(res.headers.get('content-type')).toContain('application/json')
		expect(await res.json()).toEqual({ Success: true, Error: null, error_id: null })
		expect(await my()).toBe('8201')
		expect((await getAccount(env.DB, 8204))?.supportedInfluencerId).toBe(8201)

		// One pick per player: posting again REPLACES it.
		expect((await support('influencerAccountId=8202')).status).toBe(200)
		expect(await my()).toBe('8202')

		// Only an influencer can be supported, and not oneself. Each refusal is a 400 that
		// leaves the pick alone.
		expect((await support('influencerAccountId=8203')).status).toBe(400) // not an influencer
		expect((await support('influencerAccountId=99999999')).status).toBe(400) // no such account
		expect((await support('influencerAccountId=8204')).status).toBe(400) // oneself
		expect((await support('influencerAccountId=8201', '8201')).status).toBe(400) // an influencer, oneself
		expect((await support('influencerAccountId=nope')).status).toBe(400)
		expect((await support('')).status).toBe(400)
		expect(await my()).toBe('8202')

		// Anyone can read anyone's pick, as the same bare number.
		const theirs = await exports.default.fetch(
			`${ORIGIN}/api/influencerpartnerprogram/influencer?accountId=8204`,
			{ headers: await bearer('206') }
		)
		expect(theirs.status).toBe(200)
		expect(await theirs.text()).toBe('8202')
	})

	test('POST /api/influencerpartnerprogram/remove unsets the pick it names', async () => {
		for (const [accountId, isInfluencer] of [
			[8211, true],
			[8212, true],
			[8213, false],
		] as const) {
			await env.DB.prepare('INSERT OR IGNORE INTO account (data) VALUES (?1)')
				.bind(JSON.stringify({ accountId, username: `Remove${accountId}`, isInfluencer }))
				.run()
		}
		const post = async (path: 'support' | 'remove', body: string, sub = '8213') =>
			exports.default.fetch(`${ORIGIN}/api/influencerpartnerprogram/${path}`, {
				method: 'POST',
				headers: { ...(await bearer(sub)), 'content-type': 'application/x-www-form-urlencoded' },
				body,
			})
		const my = async () => {
			const res = await exports.default.fetch(
				`${ORIGIN}/api/influencerpartnerprogram/myinfluencer`,
				{ headers: await bearer('8213') }
			)
			return res.text()
		}

		expect((await post('support', 'influencerAccountId=8211')).status).toBe(200)
		expect(await my()).toBe('8211')

		// Naming someone other than the current pick is a no-op success: the pick stays.
		const other = await post('remove', 'influencerAccountId=8212')
		expect(other.status).toBe(200)
		expect(await other.json()).toEqual({ Success: true, Error: null, error_id: null })
		expect(await my()).toBe('8211')

		// Naming the current pick clears it: the same envelope, and `…/myinfluencer` is 0
		// again. The field is DROPPED from the account, not written as 0.
		const res = await post('remove', 'influencerAccountId=8211')
		expect(res.status).toBe(200)
		expect(res.headers.get('content-type')).toContain('application/json')
		expect(await res.json()).toEqual({ Success: true, Error: null, error_id: null })
		expect(await my()).toBe('0')
		const account = await getAccount(env.DB, 8213)
		expect(account).not.toBeNull()
		expect('supportedInfluencerId' in account!).toBe(false)

		// Removing with nothing picked is also a no-op success.
		expect((await post('remove', 'influencerAccountId=8211')).status).toBe(200)
		expect(await my()).toBe('0')

		// A body that names no integer is a 400.
		expect((await post('remove', 'influencerAccountId=nope')).status).toBe(400)
		expect((await post('remove', '')).status).toBe(400)

		// Unauthenticated is a 401.
		const anon = await exports.default.fetch(`${ORIGIN}/api/influencerpartnerprogram/remove`, {
			method: 'POST',
			headers: { 'content-type': 'application/x-www-form-urlencoded' },
			body: 'influencerAccountId=8211',
		})
		expect(anon.status).toBe(401)
	})

	test('GET /api/influencerpartnerprogram/influencer answers 0 for nobody, 400 for no accountId', async () => {
		// An account that has picked nobody, and one that does not exist, both support nobody.
		for (const accountId of ['206', '99999999']) {
			const res = await exports.default.fetch(
				`${ORIGIN}/api/influencerpartnerprogram/influencer?accountId=${accountId}`,
				{ headers: await bearer('206') }
			)
			expect(res.status, accountId).toBe(200)
			// The id is the WHOLE body — a bare number, not `{ Id: 0 }` or a string.
			expect(res.headers.get('content-type')).toContain('application/json')
			expect(await res.text()).toBe('0')
		}
		for (const query of ['', '?accountId=', '?accountId=abc']) {
			const res = await exports.default.fetch(
				`${ORIGIN}/api/influencerpartnerprogram/influencer${query}`,
				{ headers: await bearer('206') }
			)
			expect(res.status, query).toBe(400)
		}
	})

	test('the influencer support routes 401 without a bearer token', async () => {
		// Auth is checked before anything is answered, so an unauthenticated caller is told
		// that rather than handed an id.
		for (const path of ['influencer?accountId=206', 'myinfluencer']) {
			const res = await exports.default.fetch(`${ORIGIN}/api/influencerpartnerprogram/${path}`)
			expect(res.status, path).toBe(401)
			expect(await res.text()).toBe('')
		}
		const post = await exports.default.fetch(`${ORIGIN}/api/influencerpartnerprogram/support`, {
			method: 'POST',
			headers: { 'content-type': 'application/x-www-form-urlencoded' },
			body: 'influencerAccountId=8201',
		})
		expect(post.status).toBe(401)
	})

	test('GET /api/makerai/checkfreetrialeligibility answers a bare false', async () => {
		const res = await exports.default.fetch(`${ORIGIN}/api/makerai/checkfreetrialeligibility`, {
			headers: await bearer('206'),
		})
		expect(res.status).toBe(200)
		expect(res.headers.get('content-type')).toContain('application/json')
		// The whole body is the boolean — not `{ value: false }`, not an envelope.
		expect(await res.text()).toBe('false')
	})

	test('GET /api/makerai/checkfreetrialeligibility 401s without a bearer token', async () => {
		const res = await exports.default.fetch(`${ORIGIN}/api/makerai/checkfreetrialeligibility`)
		expect(res.status).toBe(401)
		expect(await res.text()).toBe('')
	})

	test('GET /api/CampusCard/v1/SignUpBonus returns the running bonus, unauthenticated', async () => {
		const res = await exports.default.fetch(`${ORIGIN}/api/CampusCard/v1/SignUpBonus`)
		expect(res.status).toBe(200)
		expect(await res.json()).toEqual({
			RRPlusSignUpBonusId: 3,
			MinFreeItemsPrice: 6000,
			MaxFreeItemsPrice: 10000,
		})
	})

	test('POST /api/CampusCard/v1/UpdateAndGetSubscription gives a developer a Gold year', async () => {
		const res = await getSubscription(await bearer('205', ['gameClient'], undefined, true))
		expect(res.status).toBe(200)
		const body = (await res.json()) as {
			Subscription: Record<string, unknown>
			PlatformAccountSubscribedPlayerId: null
		}
		expect(body.PlatformAccountSubscribedPlayerId).toBeNull()
		expect(body.Subscription).toMatchObject({
			SubscriptionId: 1,
			// The subscribed player is the caller, not a fixed id.
			RecNetPlayerId: 205,
			// -1 All: no store sold this. 0 = Gold (1 is Platinum), 1 = Year.
			PlatformType: -1,
			PlatformId: '',
			PlatformPurchaseId: '',
			Level: 0,
			Period: 1,
			IsAutoRenewing: true,
		})

		// The subscription runs a year from the call rather than to a hard-coded date, so it
		// cannot lapse on a day nobody is expecting.
		const created = new Date(body.Subscription.CreatedAt as string)
		const expires = new Date(body.Subscription.ExpirationDate as string)
		expect(body.Subscription.ModifiedAt).toBe(body.Subscription.CreatedAt)
		expect(expires.getTime()).toBeGreaterThan(Date.now())
		expect(expires.getUTCFullYear()).toBe(created.getUTCFullYear() + 1)
		expect(expires.getUTCMonth()).toBe(created.getUTCMonth())
		expect(expires.getUTCDate()).toBe(created.getUTCDate())
	})

	test('POST /api/CampusCard/v1/UpdateAndGetSubscription is {} without the developer role', async () => {
		// A plain player's token: valid, no elevated role, and no `hasPlus` on the account.
		expect(await (await getSubscription(await bearer('206', ['gameClient']))).json()).toEqual({})
		// A token with no `role` claim at all.
		expect(await (await getSubscription(await bearer('206'))).json()).toEqual({})
		// No token: "not subscribed" rather than 401, so a loading client isn't stalled.
		const anon = await getSubscription()
		expect(anon.status).toBe(200)
		expect(await anon.json()).toEqual({})
	})

	// Plus reaches this worker as the token's `rn.plus` claim, which `auth` stamps from
	// `account.hasPlus` at login. Nothing here reads the account, so this is the whole
	// mechanism — and the reason a player who claims on the website has to sign in again.
	//
	// The token carries only `gameClient`, exactly as a game client's does.
	test('POST /api/CampusCard/v1/UpdateAndGetSubscription honours the rn.plus claim', async () => {
		const res = await getSubscription(await bearer('9208', ['gameClient'], undefined, true))
		expect(res.status).toBe(200)
		const body = (await res.json()) as { Subscription: Record<string, unknown> }
		expect(body.Subscription).toMatchObject({
			SubscriptionId: 1,
			RecNetPlayerId: 9208,
			PlatformType: -1,
			Level: 0,
			Period: 1,
			IsAutoRenewing: true,
		})
	})

	// The `developer` role used to BE the subscription, as a stand-in while nothing else
	// could confer one. Now that Plus has a real source it is one thing with one source, and
	// an elevated account is not a subscriber unless it also holds `rn.plus`. Pinned because
	// nothing else would fail if the old shortcut came back: it would silently hand Plus (and
	// the 10% discount) to every operator account.
	test('the developer role alone is not a Rec Room Plus subscription', async () => {
		const dev = await getSubscription(await bearer('9210', ['gameClient', 'developer']))
		expect(dev.status).toBe(200)
		expect(await dev.json()).toEqual({})

		// …and it buys nothing at the subscriber price either, so the report and the buy path
		// agree. 85 is the SubscriberPrices entry for sf300's 2089; 95 is the list price.
		const discounted = await buy2263(await bearer('9211', ['gameClient', 'developer']), 85)
		expect(discounted.status).toBe(409)
	})

	// Plus is priced, not just displayed: the same claim gates the subscriber discount band
	// on a buy. A subscriber whose client applied the discount itself and then had the
	// purchase refused as a price mismatch is exactly what one definition prevents, so the
	// CampusCard report and the buy must never disagree.
	test('an rn.plus token is charged the subscriber price', async () => {
		const res = await buy2263(await bearer('9326', ['gameClient'], undefined, true), 85)
		expect(res.status).toBe(200)
		expect(((await res.json()) as { Balance: number }).Balance).toBe(-85)

		// The same request without the claim is refused, so the discount really comes from
		// `rn.plus` and not from the band being open to everyone.
		const plain = await buy2263(await bearer('9327', ['gameClient']), 85)
		expect(plain.status).toBe(409)
	})

	test('unknown path returns 404', async () => {
		const res = await exports.default.fetch(`${ORIGIN}/nope`)
		expect(res.status).toBe(404)
	})

	test('GET /openapi.json documents every route', async () => {
		const res = await exports.default.fetch(`${ORIGIN}/openapi.json`)
		expect(res.status).toBe(200)
		const spec = (await res.json()) as {
			openapi: string
			paths: Record<string, Record<string, { summary?: string }>>
		}
		expect(spec.openapi).toMatch(/^3\.1/)

		// The spec route hides itself.
		expect(spec.paths['/openapi.json']).toBeUndefined()

		// Every route the worker serves is described. This is the drift guard: adding a
		// route without a describeRoute() block fails here rather than silently shipping
		// an incomplete spec. Hono's `:param` syntax becomes OpenAPI's `{param}`; the
		// `.on(['GET','POST'], …)` cleargroup route contributes both methods.
		const documented = new Set(
			Object.entries(spec.paths).flatMap(([path, ops]) =>
				Object.keys(ops).map((method) => `${method.toUpperCase()} ${path}`)
			)
		)
		expect([...documented].sort()).toEqual([
			'GET /api/CampusCard/v1/SignUpBonus',
			'GET /api/avatar/v1/defaultbaseavataritems',
			'GET /api/avatar/v1/defaultunlocked',
			'GET /api/avatar/v2',
			'GET /api/avatar/v2/gifts',
			'GET /api/avatar/v2/{id}',
			'GET /api/avatar/v3/saved',
			'GET /api/avatar/v4/items',
			'GET /api/challenge/v2/getCurrent',
			'GET /api/checklist/v1/current',
			'GET /api/checklist/v2/current',
			'GET /api/consumables/v1/all',
			'GET /api/consumables/v2/getUnlocked',
			'GET /api/equipment/v2/getUnlocked',
			'GET /api/gamerewards/v1/pending',
			'GET /api/incentivizedreferrals/progress',
			'GET /api/influencerpartnerprogram/influencer',
			'GET /api/influencerpartnerprogram/influencers',
			'GET /api/influencerpartnerprogram/myinfluencer',
			'GET /api/itemWishlists/v1/wishlist/me',
			'GET /api/itemWishlists/v1/wishlist/{accountId}',
			'GET /api/makerai/checkfreetrialeligibility',
			'GET /api/objectives/v1/cleargroup',
			'GET /api/objectives/v1/myprogress',
			'GET /api/roomconsumables/v1/roomConsumable/room/{roomId}',
			'GET /api/roomconsumables/v1/roomConsumable/room/{roomId}/me',
			'GET /api/roomcurrencies/v1/currencies',
			'GET /api/roomcurrencies/v1/getAllBalances',
			'GET /api/roomcurrencies/v1/getBalance',
			'GET /api/roomcurrencies/v1/getPurchaseOffersBatch',
			'GET /api/roomkeys/v1/mine',
			'GET /api/roomkeys/v1/room',
			'GET /api/storefronts/v1/adcarouselitems',
			'GET /api/storefronts/v1/buyRoomKey',
			'GET /api/storefronts/v2/buyInvention',
			'GET /api/storefronts/v3/giftdropstore/{id}',
			'GET /api/storefronts/v4/balance/{currencyType}',
			'GET /api/subscriptionseasons/v1/seasons/current',
			'GET /api/ugcPurchasables/v1/items/room/{roomId}',
			'GET /econ/customAvatarItems/v1/owned',
			'GET /econ/customAvatarItems/v1/ownedby/{accountId}',
			'GET /econ/roomEconConfig/{roomId}',
			'GET /econ/roomGiftDropShops/room/{roomId}',
			'GET /econ/roomInventory/room/{roomId}',
			'GET /econ/roomInventory/room/{roomId}/player',
			'GET /econ/roomInventoryItemTags/room/{roomId}',
			'GET /econ/roomOffer/room/{roomId}',
			'GET /econ/roomOffer/room/{roomId}/purchaseCounts',
			'GET /paintball-battle-pass/config',
			'POST /api/CampusCard/v1/UpdateAndGetSubscription',
			'POST /api/avatar/v1/lockeditems/bulk',
			'POST /api/avatar/v2/gifts/consume',
			'POST /api/avatar/v2/set',
			'POST /api/avatar/v3/saved/set',
			'POST /api/avatar/v4/saved/set',
			'POST /api/challenge/v2/updateProgress',
			'POST /api/checklist/v1/complete',
			'POST /api/checklist/v2/complete',
			'POST /api/consumables/v1/consume',
			'POST /api/consumables/v1/query/bulk',
			'POST /api/consumables/v1/updateActive',
			'POST /api/distanceMovedRewardTracks/distance',
			'POST /api/equipment/v1/update',
			'POST /api/gamerewards/v1/request',
			'POST /api/influencerpartnerprogram/remove',
			'POST /api/influencerpartnerprogram/support',
			'POST /api/itemWishlists/v1/isonwishlist/bulk',
			'POST /api/itemWishlists/v1/wishlist/add',
			'POST /api/itemWishlists/v1/wishlist/remove',
			'POST /api/items/bulkpurchase',
			'POST /api/items/purchaseInfos',
			'POST /api/objectives/v1/cleargroup',
			'POST /api/objectives/v1/updateobjective',
			'POST /api/roomCurrencies/v2/purchase',
			'POST /api/roomconsumables/v1/roomConsumable/awardBulk',
			'POST /api/roomcurrencies/v1/awardCurrency/bulk',
			'POST /api/roomcurrencies/v1/createCurrency',
			'POST /api/roomcurrencies/v1/createPurchaseOffer',
			'POST /api/roomcurrencies/v1/deletePurchaseOffer',
			'POST /api/roomcurrencies/v1/updateCurrency',
			'POST /api/roomkeys/v1/awardbulk',
			'POST /api/roomkeys/v1/create',
			'POST /api/roomkeys/v1/owns/bulk',
			'POST /api/storefronts/v1/PurchaseRoomKeyWithCurrency',
			'POST /api/storefronts/v1/purchasableitems',
			'POST /api/storefronts/v2/buyItem',
			'POST /api/storefronts/v3/buyInvention',
			'POST /api/timedCurrencyGrants/update',
			'POST /api/ugcPurchasables/v1/items/bulk',
			'POST /circuitsRoomRewards/grantRoomBadge',
			'PUT /api/equipment/v1/update',
			'PUT /api/roomconsumables/v1/roomConsumable',
			'PUT /api/roomconsumables/v1/roomConsumable/{id}/consume',
			'PUT /api/roomconsumables/v1/roomconsumable/{id}/purchase/{via}',
			'PUT /api/roomkeys/v1/updateAll',
		])

		// Every operation carries a summary — a path present but undescribed is not
		// documentation.
		for (const ops of Object.values(spec.paths)) {
			for (const op of Object.values(ops)) expect(op.summary).toBeTruthy()
		}
	})
})

// The item catalog. Loaded by migration, not written at runtime, so these exercise the SHAPE of
// the table and its query helpers against a handful of hand-seeded rows; the drift test at the
// end is what pins the thousands of real ones.
describe('catalog', () => {
	// One row of each kind, plus the cases that decided the schema: an avatar_item_id shared by
	// two rows and absent from a third, and keys that are alpha strings rather than GUIDs.
	//
	// Starts from an EMPTY table: the suite-wide setup seeds skins for the weekly-challenge gift
	// pool, and the exact counts and lists below are about these rows alone. This block is the
	// last in the file, so clearing is safe.
	beforeAll(async () => {
		await env.DB.prepare('DELETE FROM catalog').run()
		const insert = (row: unknown[]) =>
			env.DB.prepare(
				`INSERT INTO catalog (
					item_key, catalog_id, kind, friendly_name, tooltip, rarity, platform_mask,
					thumbnail_image, avatar_item_type, avatar_item_id, is_base_avatar_item, tag_list,
					created_at, prefab_name, unlocked_level
				) VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7, ?8, ?9, ?10, ?11, ?12, ?13, ?14, ?15)`
			)
				.bind(...row)
				.run()

		// `catalog_id` is handed out by the loader as 1..N over the captures. These seeds number
		// themselves the same way but from a base far above N, so a test that inserts a REAL
		// capture row (which carries its own low id) cannot collide with a seed — the constraint
		// under test should only ever fire on something the test meant to collide.
		let nextId = 900_001

		/** An avatar item: `item_key` is its `AvatarItemDesc`, the skin columns stay null. */
		const avatarItem = (
			desc: string,
			name: string,
			tooltip: string | null,
			rarity: number,
			type: number,
			id: number | null,
			tag: string | null,
			createdAt: string | null,
			thumb: string | null
		) =>
			insert([
				desc,
				nextId++,
				'avatar_item',
				name,
				tooltip,
				rarity,
				-1,
				thumb,
				type,
				id,
				0,
				tag,
				createdAt,
				null,
				null,
			])

		/** A skin: `item_key` is its `ModificationGuid`, the avatar columns stay null. */
		const skin = (guid: string, name: string, tooltip: string | null, prefab: string) =>
			insert([
				guid,
				nextId++,
				'skin',
				name,
				tooltip,
				0,
				-1,
				'',
				null,
				null,
				null,
				null,
				null,
				prefab,
				0,
			])

		await avatarItem(
			'_OWVy3z6iU-M3-zbQgSLig,,,',
			'Vampire Hunter Gloves (Blue)',
			// NULL, not '' — the two are different values in the capture and the client's DTO serves
			// the difference through.
			null,
			10,
			0,
			835,
			null,
			'2018-11-01T17:51:50.733Z',
			'cimomkml6k4toyowd1voh7hqm.png'
		)
		await avatarItem(
			'002a0f2f-1a24-4439-b578-470818ef8325,,,',
			'Turkey Sweater',
			'',
			50,
			0,
			1570,
			'thanksgiving',
			'2020-10-28T00:37:27.263Z',
			'4g2r02n1g5w09re7hl1ba2yyi.png'
		)
		// These two share avatar_item_id 9503 — the reason that column keys nothing.
		await avatarItem(
			'c5010738-41fa-4eca-aeac-e24adaa29789,',
			'Helmet Hair',
			'',
			-1,
			0,
			9503,
			null,
			null,
			null
		)
		await avatarItem(
			'60067e91-18b8-43ab-ae20-a8ea74c757bf,KUAMuM41hk-YLZoqTiKncA',
			'Green Cheer Sash',
			'',
			-1,
			0,
			9503,
			null,
			null,
			null
		)
		// A hair dye: AvatarItemType 1, NO avatar_item_id at all, and a desc that is a bare alpha
		// string with no commas. Still perfectly keyed.
		await avatarItem(
			'pQNfh-3DsEGWfiIls6Qf6g',
			'Permanent Hair Dye (Pirate Gold)',
			'',
			0,
			1,
			null,
			null,
			null,
			null
		)

		await skin('19ef59c7-f74b-4c63-935a-1d4b1abd8518', 'Disc (Coop)', '', '[DiscGolfDisc]')
		// An alpha-string key, from before the game moved to GUIDs.
		await skin('bfrFOdnHzEaIwHqem2dXkg', 'Confetti Gun (Gold)', null, '[PaintballGun] Confetti')
	})

	test('an avatar item reads back by its desc, nullable fields intact', async () => {
		const item = await getAvatarItem(env.DB, '_OWVy3z6iU-M3-zbQgSLig,,,')
		expect(item).toEqual({
			AvatarItemDesc: '_OWVy3z6iU-M3-zbQgSLig,,,',
			AvatarItemType: 0,
			PlatformMask: -1,
			FriendlyName: 'Vampire Hunter Gloves (Blue)',
			// The one the column may never be defaulted to '' for.
			Tooltip: null,
			Rarity: 10,
			TagList: null,
			AvatarItemId: 835,
			IsBaseAvatarItem: false,
			CreatedAt: '2018-11-01T17:51:50.733Z',
			ThumbnailImage: 'cimomkml6k4toyowd1voh7hqm.png',
		})
		expect(await getAvatarItem(env.DB, 'nothing-has-this-desc')).toBeNull()
	})

	test('a skin reads back by its guid, and an alpha-string key is just as good', async () => {
		expect(await getSkin(env.DB, '19ef59c7-f74b-4c63-935a-1d4b1abd8518')).toEqual({
			PrefabName: '[DiscGolfDisc]',
			ModificationGuid: '19ef59c7-f74b-4c63-935a-1d4b1abd8518',
			UnlockedLevel: 0,
			// The catalog does not store this: it is a PLAYER's flag, and the capture recorded one
			// account's. It is overwritten from the player's own `equipment` row.
			Favorited: false,
			PlatformMask: -1,
			FriendlyName: 'Disc (Coop)',
			Tooltip: '',
			Rarity: 0,
			ThumbnailImage: '',
		})

		// 191 of the skins are keyed by the short alpha-string ids the game used before GUIDs. The
		// column is TEXT and compared as text, so these need no special handling — which is exactly
		// why nothing here parses or validates a key's shape.
		const gold = await getSkin(env.DB, 'bfrFOdnHzEaIwHqem2dXkg')
		expect(gold?.FriendlyName).toBe('Confetti Gun (Gold)')
		// Skins carry NULL tooltips too, so the projection must not flatten them to ''.
		expect(gold?.Tooltip).toBeNull()

		expect((await getSkinsForPrefab(env.DB, '[DiscGolfDisc]')).map((s) => s.FriendlyName)).toEqual([
			'Disc (Coop)',
		])
		expect(await getSkin(env.DB, 'no-such-guid')).toBeNull()
	})

	test('one key spans both kinds, and asking for the wrong kind gets null, not a mangled row', async () => {
		// The lookup the inventory wants: a player's owned things are ids of exactly this shape and
		// the row says which kind each turned out to be. No join, no guessing.
		const owned = await getCatalogItems(env.DB, [
			'19ef59c7-f74b-4c63-935a-1d4b1abd8518',
			'_OWVy3z6iU-M3-zbQgSLig,,,',
			// Unknown keys are SKIPPED rather than left as holes, so the result is shorter than the
			// input and must never be read positionally.
			'nothing-owns-this',
		])
		expect(owned.map((r) => [r.kind, r.friendly_name])).toEqual([
			['skin', 'Disc (Coop)'],
			['avatar_item', 'Vampire Hunter Gloves (Blue)'],
		])
		expect(await getCatalogItems(env.DB, [])).toEqual([])

		// A key is unique across BOTH kinds, so a typed accessor handed the other kind's key answers
		// null rather than projecting a skin into an avatar item's shape.
		expect(await getAvatarItem(env.DB, '19ef59c7-f74b-4c63-935a-1d4b1abd8518')).toBeNull()
		expect(await getSkin(env.DB, '_OWVy3z6iU-M3-zbQgSLig,,,')).toBeNull()
		expect(() => toCatalogSkin({ ...(owned[1] as CatalogRow) })).toThrow(/not a skin/)
	})

	test('avatar_item_id is carried as data and keys nothing', async () => {
		// Two seeded rows share 9503 (five real ones do), and the hair dye has no id at all. Keying
		// the table on it would have silently dropped four of those five at load time, which is why
		// it is stored, not indexed, and never looked up by.
		const shared = await searchCatalog(env.DB, CatalogKind.AvatarItem, 'a')
		expect(shared.filter((r) => r.avatar_item_id === 9503)).toHaveLength(2)
		const dye = await getAvatarItem(env.DB, 'pQNfh-3DsEGWfiIls6Qf6g')
		expect(dye?.AvatarItemId).toBeNull()
		expect(dye?.AvatarItemType).toBe(1)
	})

	test('search is case-insensitive, scoped to one kind, and takes wildcards literally', async () => {
		const hits = await searchCatalog(env.DB, CatalogKind.AvatarItem, 'HAIR')
		expect(hits.map((r) => r.friendly_name)).toEqual([
			'Helmet Hair',
			'Permanent Hair Dye (Pirate Gold)',
		])

		// `kind` scopes it: the same needle against skins finds nothing, so a skin search can never
		// surface a wearable.
		expect(await searchCatalog(env.DB, CatalogKind.Skin, 'hair')).toEqual([])
		expect(
			(await searchCatalog(env.DB, CatalogKind.Skin, 'disc')).map((r) => r.prefab_name)
		).toEqual(['[DiscGolfDisc]'])

		// A needle of LIKE metacharacters matches them literally rather than everything — the escape
		// is what stops a player typing `%` from pulling the whole catalog back.
		expect(await searchCatalog(env.DB, CatalogKind.AvatarItem, '%')).toEqual([])
		expect(await searchCatalog(env.DB, CatalogKind.AvatarItem, '_')).toEqual([])
		// A hit that really does contain the character still matches, so escaping didn't break it.
		expect((await searchCatalog(env.DB, CatalogKind.AvatarItem, 'cheer')).length).toBe(1)
	})

	test('seasonal rows come back by tag, and counts are per kind', async () => {
		expect((await getAvatarItemsByTag(env.DB, 'thanksgiving')).map((i) => i.FriendlyName)).toEqual([
			'Turkey Sweater',
		])
		expect(await getAvatarItemsByTag(env.DB, 'halloween')).toEqual([])
		expect(await countCatalog(env.DB)).toEqual({ avatar_item: 5, skin: 2 })
	})

	test('the key is unique across both kinds, so a collision is refused', async () => {
		// A second avatar item with the same desc...
		await expect(
			env.DB.prepare(
				`INSERT INTO catalog (item_key, kind, friendly_name, rarity, platform_mask)
				 VALUES ('_OWVy3z6iU-M3-zbQgSLig,,,', 'avatar_item', 'Impostor', 0, -1)`
			).run()
		).rejects.toThrow()

		// ...a second skin with the same guid...
		await expect(
			env.DB.prepare(
				`INSERT INTO catalog (item_key, kind, friendly_name, rarity, platform_mask, prefab_name)
				 VALUES ('bfrFOdnHzEaIwHqem2dXkg', 'skin', 'Impostor', 0, -1, '[PaintballGun]')`
			).run()
		).rejects.toThrow()

		// ...and a skin claiming an avatar item's key. The kinds share ONE key space, which is what
		// lets an owned id be resolved without first knowing what kind of thing it is.
		await expect(
			env.DB.prepare(
				`INSERT INTO catalog (item_key, kind, friendly_name, rarity, platform_mask, prefab_name)
				 VALUES ('_OWVy3z6iU-M3-zbQgSLig,,,', 'skin', 'Impostor', 0, -1, '[MakerPen]')`
			).run()
		).rejects.toThrow()

		expect(await countCatalog(env.DB)).toEqual({ avatar_item: 5, skin: 2 })
	})

	test('baseAsset takes the first field of an AvatarItemDesc', async () => {
		// `<baseAsset>,<color>,<texture>,` — the base asset is what decides whether the client can
		// draw an item at all, so it is read off the key rather than stored twice.
		expect(baseAsset('_OWVy3z6iU-M3-zbQgSLig,,,')).toBe('_OWVy3z6iU-M3-zbQgSLig')
		expect(baseAsset('60067e91-18b8-43ab-ae20-a8ea74c757bf,KUAMuM41hk-YLZoqTiKncA')).toBe(
			'60067e91-18b8-43ab-ae20-a8ea74c757bf'
		)
		// A dye's desc is a bare alpha string with no commas at all; it is still the base asset.
		expect(baseAsset('pQNfh-3DsEGWfiIls6Qf6g')).toBe('pQNfh-3DsEGWfiIls6Qf6g')
	})

	// The migration builds the TABLE; `runx catalog load` fills it. These two are the seam
	// between them: the schema the tests build must be the schema the migration builds, and the
	// loader must produce rows that schema accepts.
	test('the migrations and CATALOG_SCHEMA_DDL build the same table', async () => {
		// Both migrations together: 0015 builds the table, 0016 adds `catalog_id`. They are
		// separate because 0015 was already applied, and an edit there would never re-run — which
		// is exactly the drift this test exists to catch. `CATALOG_SCHEMA_DDL` declares the end
		// state in one CREATE, so it is compared against the pair.
		const migrations = `${catalogStructureSql}\n${catalogIdSql}\n${catalogListingSql}`

		// Compared on identifiers rather than text, since the two are formatted differently, and
		// `catalog_id` arrives via ALTER rather than inside the CREATE.
		for (const column of CATALOG_INSERT_COLUMNS) {
			expect(migrations, column).toContain(column)
			expect(CATALOG_SCHEMA_DDL[0], column).toContain(`\t\t${column} `)
		}
		expect(catalogStructureSql).toContain('item_key TEXT PRIMARY KEY')
		expect(CATALOG_SCHEMA_DDL[0]).toContain('item_key TEXT PRIMARY KEY')
		expect(catalogIdSql).toContain('ALTER TABLE catalog ADD COLUMN catalog_id INTEGER')
		expect(catalogListingSql).toContain('ALTER TABLE catalog ADD COLUMN listing TEXT')
		for (const index of [
			'idx_catalog_name',
			'idx_catalog_prefab',
			'idx_catalog_tag',
			'idx_catalog_id',
		]) {
			expect(migrations, index).toContain(index)
			expect(CATALOG_SCHEMA_DDL.join('\n'), index).toContain(index)
		}

		// STRUCTURE ONLY. The catalog's contents change as the game's item list does, which is not
		// a schema change — rows here would mean a migration and a deploy per refresh. If this
		// fails, someone put data back into a migration instead of reloading it.
		expect(migrations).not.toContain('INSERT INTO catalog')
		expect(migrations).not.toContain('DELETE FROM catalog')
	})

	test('the loader maps the served store and the skin capture onto the columns it declares', async () => {
		const { rows, collisions, skipped } = buildCatalogLoad(storeListings)

		// Every row carries exactly one value per declared column, in that order — the loader
		// renders them positionally, so a column added to one side and not the other is a silent
		// mis-load rather than an error.
		expect(rows.every((r) => r.values.length === CATALOG_INSERT_COLUMNS.length)).toBe(true)
		const keyAt = CATALOG_INSERT_COLUMNS.indexOf('item_key')
		const kindAt = CATALOG_INSERT_COLUMNS.indexOf('kind')
		expect(rows.every((r) => r.values[keyAt] === r.key)).toBe(true)

		// One key space, every kind, no collisions between them. A listing loads as the kind of
		// the ONE item id it carries; the rows come out in store order.
		expect(new Set(rows.map((r) => r.key)).size).toBe(rows.length)
		const kinds = rows.map((r) => r.values[kindAt])
		const listed = (pick: (l: StoreListing) => string) =>
			new Set(storeListings.map(pick).filter((k) => k !== '')).size
		expect(kinds.filter((k) => k === 'avatar_item')).toHaveLength(
			listed((l) => l.GiftDrop.AvatarItemDesc)
		)
		expect(kinds.filter((k) => k === 'consumable')).toHaveLength(
			listed((l) => l.GiftDrop.ConsumableItemDesc)
		)
		expect(rows[0]?.label).toBe(`${storeListings[0]!.GiftDrop.FriendlyName} (avatar item)`)

		// Skins: every guid the served store lists, which is every guid the capture holds too —
		// the store file carries the capture's unlisted skins as listings of their own (see the
		// file test) — so the loader never reads `skins.json` at all. A skin the game's own store
		// sold keeps the store's name and rarity, not the capture's, which disagree on every row.
		const listedSkins = new Set(
			storeListings.map((l) => l.GiftDrop.EquipmentModificationGuid).filter((g) => g !== '')
		)
		const capturedSkins = new Set(skinsJson.map((sk) => sk.ModificationGuid))
		expect([...capturedSkins].every((g) => listedSkins.has(g))).toBe(true)
		expect(kinds.filter((k) => k === 'skin')).toHaveLength(listedSkins.size)
		const both = dumpListings.find(
			(l) =>
				l.GiftDrop.EquipmentModificationGuid !== '' &&
				capturedSkins.has(l.GiftDrop.EquipmentModificationGuid)
		)!
		const row = rows.find((r) => r.key === both.GiftDrop.EquipmentModificationGuid)!
		expect(row.id).toBe(both.PurchasableItemId)
		expect(row.values[CATALOG_INSERT_COLUMNS.indexOf('friendly_name')]).toBe(
			both.GiftDrop.FriendlyName
		)
		expect(row.values[CATALOG_INSERT_COLUMNS.indexOf('rarity')]).toBe(both.GiftDrop.Rarity)

		// First-party custom items load as rows of their own, keyed by guid: the item is
		// `api`'s `custom_avatar_item` record, but its LISTING has to resolve by number too.
		expect(kinds.filter((k) => k === 'custom_avatar_item')).toHaveLength(
			listed((l) => l.GiftDrop.CustomAvatarItemId ?? '')
		)

		// Every row carries its listing verbatim, so the store's own JSON comes back out.
		const listingAt = CATALOG_INSERT_COLUMNS.indexOf('listing')
		const byPurchasableId = new Map(storeListings.map((l) => [l.PurchasableItemId, l]))
		expect(
			rows.every(
				(r) =>
					r.values[listingAt] === JSON.stringify(byPurchasableId.get(r.id)) &&
					r.values[listingAt] !== undefined
			)
		).toBe(true)

		// What the store lists that is NOT a catalog item is counted, not loaded: loot boxes,
		// token bundles — and the PACKS, a consumable listed again under another number with a
		// count. Every listing is accounted for: a row, a skipped count, or nothing else.
		expect(skipped.custom_avatar_item).toBeUndefined()
		expect(skipped.query).toBe(storeListings.filter((l) => l.GiftDrop.IsQuery).length)
		expect(skipped.consumable_pack).toBeGreaterThan(0)
		expect(
			storeListings.find((l) => l.GiftDrop.FriendlyName === 'Disco Dance Break 3-Pack')?.GiftDrop
				.ConsumableItemDesc
		).toBe(
			storeListings.find((l) => l.GiftDrop.FriendlyName === 'Disco Dance Break')?.GiftDrop
				.ConsumableItemDesc
		)
		expect(rows.length + Object.values(skipped).reduce((a, b) => a + b, 0)).toBe(
			storeListings.length
		)

		// The served store repeats no key, so nothing collides. The report is still wired: a
		// repeat is a defect rather than something the table models, so the loader keeps the
		// first and RETURNS the rest for the caller to report, because a collision that vanishes
		// quietly is the exact failure the single key exists to prevent. (The dump's own verbatim
		// repeats never reach it: the served file has them collapsed.)
		expect(collisions).toEqual([])
		const first = storeListings[0]!
		const twice = buildCatalogLoad([first, { ...first, PurchasableItemId: 999_999 }])
		expect(twice.rows).toHaveLength(1)
		expect(twice.rows[0]?.id).toBe(first.PurchasableItemId)
		expect(twice.collisions).toEqual([
			{
				key: first.GiftDrop.AvatarItemDesc,
				kept: twice.rows[0]!.label,
				dropped: twice.rows[0]!.label,
			},
		])
		// And one number naming two different things is refused outright, not resolved by order.
		expect(() =>
			buildCatalogLoad([
				first,
				{ ...storeListings[1]!, PurchasableItemId: first.PurchasableItemId },
			])
		).toThrow(/names two items/)

		// The skin that was once pasted over an avatar item's row lives in skins.json where it
		// belongs.
		expect(skinsJson.filter((s) => s.FriendlyName === 'Disc (Coop)')).toHaveLength(1)
	})

	test('catalog_id is the listing’s PurchasableItemId, always', async () => {
		const { rows } = buildCatalogLoad(storeListings)

		// A row's number IS its listing's `PurchasableItemId` — the number sf3-2025.json sells it
		// under — so nothing has to be kept in step between the file and the table. No row is
		// numbered by the loader: the skins the game's own store never sold are LISTINGS in the
		// served file, numbered there from `UNLISTED_SKIN_ID_BASE`.
		const byId = new Map(sf32025.StoreItems.map((i) => [i.PurchasableItemId, i]))
		expect(rows.length).toBeGreaterThan(2500)
		for (const row of rows) {
			const drop = byId.get(row.id)?.GiftDrop
			expect(drop, String(row.id)).toBeDefined()
			expect(
				[
					drop!.AvatarItemDesc,
					drop!.ConsumableItemDesc,
					drop!.EquipmentModificationGuid,
					drop!.CustomAvatarItemId,
				],
				String(row.id)
			).toContain(row.key)
		}
		expect(new Set(rows.map((r) => r.id)).size).toBe(rows.length)
		const appended = rows.filter((r) => r.id >= UNLISTED_SKIN_ID_BASE)
		expect(appended.length).toBeGreaterThan(0)
		expect(appended.every((r) => r.values[CATALOG_INSERT_COLUMNS.indexOf('kind')] === 'skin')).toBe(
			true
		)
		expect(
			appended.every(
				(r) => r.values[CATALOG_INSERT_COLUMNS.indexOf('rarity')] === UNLISTED_SKIN_RARITY
			)
		).toBe(true)

		// The id in the row object and the id in the values it renders are the same number — the
		// loader binds `values` positionally, so a mismatch would write one and report the other.
		const idAt = CATALOG_INSERT_COLUMNS.indexOf('catalog_id')
		expect(rows.every((r) => r.values[idAt] === r.id)).toBe(true)

		// It reads back by number, and the number is NOT the item's identity: `item_key` is. A
		// caller that stored an id across a load would resolve to a different item or to nothing,
		// which is why nothing may persist it.
		const seeded = await getCatalogItemById(env.DB, 900_001)
		expect(seeded?.item_key).toBe('_OWVy3z6iU-M3-zbQgSLig,,,')
		expect(await getCatalogItemById(env.DB, 12_345_678)).toBeNull()

		// Unique where set. Two rows may not share a handle — a number that names two items is
		// useless as a handle.
		await expect(
			env.DB.prepare(
				`INSERT INTO catalog (item_key, catalog_id, kind, friendly_name, rarity, platform_mask)
				 VALUES ('id-collision-probe', 900001, 'skin', 'Impostor', 0, -1)`
			).run()
		).rejects.toThrow()

		// But NULL is allowed any number of times: the index is partial, because a row is
		// un-numbered in the window between existing and a load numbering it, and the loader
		// clears every id before handing out new ones so a merge cannot collide with stale ones.
		for (const key of ['unnumbered-a', 'unnumbered-b']) {
			await env.DB.prepare(
				`INSERT INTO catalog (item_key, kind, friendly_name, rarity, platform_mask)
				 VALUES (?1, 'skin', 'Not Yet Numbered', 0, -1)`
			)
				.bind(key)
				.run()
		}
		expect((await getCatalogItem(env.DB, 'unnumbered-a'))?.catalog_id).toBeNull()
		expect((await getCatalogItem(env.DB, 'unnumbered-b'))?.catalog_id).toBeNull()
		await env.DB.prepare("DELETE FROM catalog WHERE item_key LIKE 'unnumbered-%'").run()
	})

	// `runx catalog load` MERGES by default so a partial capture can add a few items without
	// wiping the rest, and REPLACES only when told to. Both halves of that live in the CLI's SQL,
	// so this exercises the upsert itself — the CLI's own statement, built from the same column
	// list, against the same schema.
	//
	// MUST STAY LAST in this block: the replace half empties the table, including the rows the
	// other catalog tests are seeded with.
	test('a merge inserts, refreshes and preserves; a replace removes', async () => {
		const columns = CATALOG_INSERT_COLUMNS.join(', ')
		const binds = CATALOG_INSERT_COLUMNS.map((_, i) => `?${i + 1}`).join(', ')
		// Every column but the conflict target, derived from the column list exactly as the CLI
		// derives it.
		const conflictUpdate = CATALOG_INSERT_COLUMNS.filter((c) => c !== 'item_key')
			.map((c) => `${c} = excluded.${c}`)
			.join(', ')

		/** The CLI's statement: a full-width insert that upserts on the key. */
		const upsert = (values: CatalogValue[]) =>
			env.DB.prepare(
				`INSERT INTO catalog (${columns}) VALUES (${binds})
				 ON CONFLICT(item_key) DO UPDATE SET ${conflictUpdate}`
			)
				.bind(...values.map((v) => v ?? null))
				.run()

		/** A skin row in column order, so a column added to the table lands here too. */
		const skinValues = (key: string, name: string, rarity: number): CatalogValue[] =>
			CATALOG_INSERT_COLUMNS.map((c) =>
				c === 'item_key'
					? key
					: c === 'kind'
						? CatalogKind.Skin
						: c === 'friendly_name'
							? name
							: c === 'rarity'
								? rarity
								: c === 'platform_mask'
									? -1
									: c === 'prefab_name'
										? '[MakerPen]'
										: null
			)

		// A row nothing in a later load will mention — the one that proves a merge is not a wipe.
		await upsert(skinValues('untouched-by-any-load', 'Hand-Added Sentinel', 0))

		// Insert: a key the table has never seen.
		await upsert(skinValues('merge-test-new', 'Freshly Datamined', 7))
		expect((await getCatalogItem(env.DB, 'merge-test-new'))?.friendly_name).toBe(
			'Freshly Datamined'
		)

		// Refresh: the SAME key again with different values updates in place rather than either
		// erroring on the key or piling up a second row.
		const before = await countCatalog(env.DB)
		await upsert(skinValues('merge-test-new', 'Renamed By Refresh', 42))
		const refreshed = await getCatalogItem(env.DB, 'merge-test-new')
		expect(refreshed?.friendly_name).toBe('Renamed By Refresh')
		expect(refreshed?.rarity).toBe(42)
		expect(await countCatalog(env.DB)).toEqual(before)

		// Preserve: neither of those touched the sentinel. This is the whole point of the default
		// — a capture holding two items must not delete the other three thousand.
		expect((await getCatalogItem(env.DB, 'untouched-by-any-load'))?.friendly_name).toBe(
			'Hand-Added Sentinel'
		)

		// Every column but the key is carried by the refresh. Derived rather than written out, so
		// a column added to the table and forgotten would silently stop being merged.
		for (const column of CATALOG_INSERT_COLUMNS) {
			expect(conflictUpdate.includes(`${column} = excluded.${column}`), column).toBe(
				column !== 'item_key'
			)
		}

		// Replace: `DELETE FROM catalog` first, and the sentinel goes with everything else. That is
		// why it is opt-in — pointed at a partial capture it removes whatever the file omits.
		const { rows } = buildCatalogLoad(storeListings)
		await env.DB.prepare('DELETE FROM catalog').run()
		await upsert((rows[0] as CatalogLoadRow).values)
		expect(await getCatalogItem(env.DB, 'untouched-by-any-load')).toBeNull()
		expect(await getCatalogItem(env.DB, 'merge-test-new')).toBeNull()
		expect(await countCatalog(env.DB)).toEqual({ avatar_item: 1 })
	})
})

/**
 * The operator's Plus token reload (`just reload-plus`), which is SQL text rather than a
 * helper because it is run through `wrangler d1 execute`. Exercised here against a real D1
 * so the upsert's two halves — "existing row gains the amount" and "missing row is created
 * with the signup grant folded in" — are pinned, and so the `has_plus` generated column the
 * statement depends on is proven to exist in the mirrored schema.
 */
describe('plus token reload', () => {
	const seed = async (accountId: number, hasPlus: boolean | undefined) => {
		await env.DB.prepare('INSERT OR IGNORE INTO account (data) VALUES (?1)')
			.bind(
				JSON.stringify({
					accountId,
					username: `Plus${accountId}`,
					...(hasPlus === undefined ? {} : { hasPlus }),
				})
			)
			.run()
	}

	test('credits every hasPlus account once, folding the signup grant into new rows', async () => {
		await seed(8001, true) // subscriber with an existing balance
		await seed(8002, true) // subscriber who has never touched econ: no balance row
		await seed(8003, false) // explicitly not a subscriber
		await seed(8004, undefined) // flag never set
		await env.DB.prepare(
			'INSERT OR REPLACE INTO balance (account_id, currency_type, amount) VALUES (8001, 2, 250)'
		).run()
		await env.DB.prepare(
			'INSERT OR REPLACE INTO balance (account_id, currency_type, amount) VALUES (8003, 2, 250)'
		).run()

		// The read half: subscribers only, with the pending grant shown as a NULL balance.
		const members = await env.DB.prepare(PLUS_MEMBERS_SQL).all<{
			account_id: number
			username: string
			amount: number | null
		}>()
		expect(members.results.filter((r) => r.account_id >= 8001 && r.account_id <= 8004)).toEqual([
			{ account_id: 8001, username: 'Plus8001', amount: 250 },
			{ account_id: 8002, username: 'Plus8002', amount: null },
		])

		const res = await env.DB.prepare(plusReloadSql(1000, 500)).all<{
			account_id: number
			amount: number
		}>()
		const credited = res.results.filter((r) => r.account_id >= 8001 && r.account_id <= 8004)
		expect(credited).toEqual(
			expect.arrayContaining([
				{ account_id: 8001, amount: 1250 },
				{ account_id: 8002, amount: 1500 },
			])
		)
		expect(credited).toHaveLength(2)

		// The non-subscribers were left exactly as they were, and the fresh row is now a real
		// grant: `ensureStartingBalances` sees it and does not grant again.
		expect(await getBalance(env.DB, 8003, CurrencyType.RecCenterTokens, 500)).toBe(250)
		expect(await getBalance(env.DB, 8004, CurrencyType.RecCenterTokens, 500)).toBe(500)
		expect(await getBalance(env.DB, 8002, CurrencyType.RecCenterTokens, 500)).toBe(1500)
	})

	test('rejects a non-positive amount or a negative grant before touching the database', () => {
		expect(() => plusReloadSql(0, 500)).toThrow('positive integer')
		expect(() => plusReloadSql(1.5, 500)).toThrow('positive integer')
		expect(() => plusReloadSql(100, -1)).toThrow('non-negative integer')
	})
})

// ---- Discord supporter gift ----------------------------------------------------------------

// The cron: every account whose Discord link holds a role mapped in DISCORD_ROLE_TOKENS is
// boxed its best role's tokens, every time it fires. Driven through `grantDiscordRoleGifts`
// with the var set on a copy of the bindings.
describe('discord role gift', () => {
	const ROLE_A = '1077000000000000001'
	const ROLE_B = '1077000000000000002'
	const UNMAPPED = '1077000000000000009'
	const MAP = `${ROLE_A}=2500,${ROLE_B}=10000`

	const giftEnv = (map: string | undefined): Env => ({ ...env, DISCORD_ROLE_TOKENS: map }) as Env

	const drainFrames = async (): Promise<
		Array<{ accountId: number; notificationType: number; payload: Record<string, unknown> }>
	> =>
		(
			env.RECFLARE_NOTIFICATIONS_HUB.getByName('global') as unknown as {
				drainFrames(): Promise<
					Array<{ accountId: number; notificationType: number; payload: Record<string, unknown> }>
				>
			}
		).drainFrames()

	/**
	 * The run reads EVERY Discord link, and the table is shared across this file, so each
	 * test starts from only its own rows.
	 */
	const onlyDiscordLinks = async (
		links: Array<[accountId: number, userId: string, roles: string[]]>
	) => {
		await env.DB.prepare('DELETE FROM platform_account WHERE platform = ?1')
			.bind(PlatformType.Discord)
			.run()
		for (const [accountId, userId, roles] of links) {
			await linkPlatformIdentity(env.DB, accountId, PlatformType.Discord, userId, roles)
		}
	}

	const tokens = (accountId: number) =>
		getBalance(env.DB, accountId, CurrencyType.RecCenterTokens, DEFAULT_STARTING_TOKENS)

	test('parses the role map, keeping the last amount for a repeated role and skipping bad entries', () => {
		expect(parseRoleTokens(MAP)).toEqual({
			roles: [
				{ roleId: ROLE_A, tokens: 2500 },
				{ roleId: ROLE_B, tokens: 10000 },
			],
			rejected: [],
		})
		// Whitespace and commas both separate; a role named twice keeps its LAST amount.
		expect(parseRoleTokens(` ${ROLE_A}=1, ${ROLE_B}=2\n${ROLE_A}=3 `).roles).toEqual([
			{ roleId: ROLE_A, tokens: 3 },
			{ roleId: ROLE_B, tokens: 2 },
		])
		// A role's NAME, a zero, a negative, a fraction and a bare id are each one rejected
		// entry, and the good ones beside them still parse.
		expect(
			parseRoleTokens(`supporter=100,${ROLE_A}=0,${ROLE_B}=-5,1=1.5,${UNMAPPED},${ROLE_A}=250`)
		).toEqual({
			roles: [{ roleId: ROLE_A, tokens: 250 }],
			rejected: ['supporter=100', `${ROLE_A}=0`, `${ROLE_B}=-5`, '1=1.5', UNMAPPED],
		})
		expect(parseRoleTokens(undefined)).toEqual({ roles: [], rejected: [] })
		expect(parseRoleTokens('')).toEqual({ roles: [], rejected: [] })
	})

	test('does nothing until a role is mapped', async () => {
		await onlyDiscordLinks([[9301, '900000000000000301', [ROLE_A]]])
		await drainFrames()
		await expect(
			grantDiscordRoleGifts(giftEnv(undefined), DEFAULT_STARTING_TOKENS)
		).resolves.toMatchObject({ skipped: true, granted: 0 })
		// A map with nothing valid in it is off too, not a run that pays nobody.
		await expect(
			grantDiscordRoleGifts(giftEnv('supporter=100'), DEFAULT_STARTING_TOKENS)
		).resolves.toMatchObject({ skipped: true, granted: 0 })
		expect(await tokens(9301)).toBe(DEFAULT_STARTING_TOKENS)
		expect(await getPendingGifts(env.DB, 9301)).toEqual([])
		expect(await drainFrames()).toEqual([])
	})

	// The deployed test config maps no role, so the real handler takes the "off" path: pinned
	// so a deploy without the var is a logged no-op and not a scheduled error.
	test('runs from the scheduled handler and stays off without the var', async () => {
		await onlyDiscordLinks([[9301, '900000000000000301', [ROLE_A]]])
		const ctx = createExecutionContext()
		await scheduled(createScheduledController(), env, ctx)
		await waitOnExecutionContext(ctx)
		expect(await tokens(9301)).toBe(DEFAULT_STARTING_TOKENS)
		expect(await getPendingGifts(env.DB, 9301)).toEqual([])
	})

	test('boxes each holder of a mapped role its best role’s tokens, one box per account', async () => {
		await onlyDiscordLinks([
			[9311, '900000000000000311', [ROLE_A]],
			[9312, '900000000000000312', [ROLE_B, UNMAPPED]],
			[9313, '900000000000000313', [ROLE_A, ROLE_B]],
			[9314, '900000000000000314', [UNMAPPED]],
			[9315, '900000000000000315', []],
		])
		// A Steam link on a paid account is not a Discord link and carries no roles.
		await linkPlatformIdentity(env.DB, 9311, PlatformType.Steam, '76561190000009311')
		await drainFrames()

		const summary = await grantDiscordRoleGifts(giftEnv(MAP), DEFAULT_STARTING_TOKENS)
		expect(summary).toEqual({
			skipped: false,
			roles: 2,
			links: 5,
			granted: 3,
			tokens: 2500 + 10000 + 10000,
			failed: 0,
		})

		// The balance is the signup grant PLUS the gift: the grant is seeded first, so a
		// never-touched balance doesn't start from the gift alone. Two mapped roles pay the
		// HIGHER one, not both.
		expect(await tokens(9311)).toBe(DEFAULT_STARTING_TOKENS + 2500)
		expect(await tokens(9312)).toBe(DEFAULT_STARTING_TOKENS + 10000)
		expect(await tokens(9313)).toBe(DEFAULT_STARTING_TOKENS + 10000)
		expect(await tokens(9314)).toBe(DEFAULT_STARTING_TOKENS)
		expect(await tokens(9315)).toBe(DEFAULT_STARTING_TOKENS)

		// One box: from the Coach, tokens and nothing else, `AvatarItemType` NULL so the
		// client doesn't go looking for an avatar item.
		const boxes = await getPendingGifts(env.DB, 9313)
		expect(boxes).toHaveLength(1)
		expect(boxes[0]).toMatchObject({
			FromPlayerId: 1,
			GiftContext: 0,
			CurrencyType: CurrencyType.RecCenterTokens,
			Currency: 10000,
			AvatarItemDesc: '',
			AvatarItemType: null,
			ConsumableItemDesc: '',
			EquipmentModificationGuid: '',
			Xp: 0,
			Message: DISCORD_ROLE_GIFT_MESSAGE,
		})
		expect(await getPendingGifts(env.DB, 9314)).toEqual([])

		// Per box: the balance frame first — the RESULTING total into the -2 bucket, keyed
		// `Platform` — then the box's announcement carrying the same amount the box does.
		const frames = await drainFrames()
		expect(frames.filter((f) => f.accountId === 9311)).toEqual([
			{
				accountId: 9311,
				notificationType: NotificationType.StorefrontBalanceUpdate,
				payload: {
					Balance: DEFAULT_STARTING_TOKENS + 2500,
					CurrencyType: CurrencyType.RecCenterTokens,
					Platform: -2,
				},
			},
			{
				accountId: 9311,
				notificationType: NotificationType.GiftPackageReceivedImmediate,
				payload: expect.objectContaining({
					Id: (await getPendingGifts(env.DB, 9311))[0]!.Id,
					FromPlayerId: 1,
					Currency: 2500,
					CurrencyType: CurrencyType.RecCenterTokens,
					AvatarItemType: null,
					GiftContext: 0,
					Message: DISCORD_ROLE_GIFT_MESSAGE,
					BalanceType: -2,
				}),
			},
		])
		expect(frames.map((f) => f.accountId)).toEqual([9311, 9311, 9312, 9312, 9313, 9313])
	})

	// The same grant, paid to ONE account on demand: what `www`'s benefits claim calls on an
	// account's first Discord link, with the roles Discord just served rather than a stored
	// link. Same map, same best-role pick, same box; null — and no writes — when nothing maps.
	test('pays one account its role’s gift on demand', async () => {
		await onlyDiscordLinks([])
		await drainFrames()
		await expect(grantDiscordRoleGift(giftEnv(undefined), 9331, [ROLE_A], 100)).resolves.toBeNull()
		await expect(grantDiscordRoleGift(giftEnv(MAP), 9331, [UNMAPPED], 100)).resolves.toBeNull()
		expect(await getPendingGifts(env.DB, 9331)).toEqual([])
		expect(await drainFrames()).toEqual([])

		await expect(
			grantDiscordRoleGift(giftEnv(MAP), 9331, [ROLE_A, ROLE_B], DEFAULT_STARTING_TOKENS)
		).resolves.toEqual({ roleId: ROLE_B, tokens: 10000 })
		expect(await tokens(9331)).toBe(DEFAULT_STARTING_TOKENS + 10000)
		expect(await getPendingGifts(env.DB, 9331)).toMatchObject([
			{ Currency: 10000, AvatarItemType: null, Message: DISCORD_ROLE_GIFT_MESSAGE },
		])
		expect((await drainFrames()).map((f) => [f.accountId, f.notificationType])).toEqual([
			[9331, NotificationType.StorefrontBalanceUpdate],
			[9331, NotificationType.GiftPackageReceivedImmediate],
		])
	})

	// One box per ACCOUNT, not per link: a player who linked two Discord identities is paid
	// once, the best role across both. And more accounts than one round pays (30) are all
	// paid once, each with their own box, with two frames apiece in link order.
	test('pays an account with two links once, and more accounts than one round holds', async () => {
		const many = Array.from({ length: 40 }, (_, i) => 9400 + i)
		await onlyDiscordLinks([
			[9341, '900000000000000341', [ROLE_A]],
			[9341, '900000000000000342', [ROLE_B]],
			...many.map((id): [number, string, string[]] => [id, `9000000000000${id}`, [ROLE_A]]),
		])
		await drainFrames()

		const summary = await grantDiscordRoleGifts(giftEnv(MAP), DEFAULT_STARTING_TOKENS)
		expect(summary).toEqual({
			skipped: false,
			roles: 2,
			links: 42,
			granted: 41,
			tokens: 10000 + 40 * 2500,
			failed: 0,
		})
		expect(await tokens(9341)).toBe(DEFAULT_STARTING_TOKENS + 10000)
		expect(await getPendingGifts(env.DB, 9341)).toMatchObject([{ Currency: 10000 }])

		const frames = await drainFrames()
		expect(frames.map((f) => f.accountId)).toEqual([9341, 9341, ...many.flatMap((id) => [id, id])])
		const boxIds = new Set<number>()
		for (const id of many) {
			expect(await tokens(id)).toBe(DEFAULT_STARTING_TOKENS + 2500)
			const boxes = await getPendingGifts(env.DB, id)
			expect(boxes).toHaveLength(1)
			boxIds.add(boxes[0]!.Id)
			const own = frames.filter((f) => f.accountId === id)
			expect(own[0]!.payload).toEqual({
				Balance: DEFAULT_STARTING_TOKENS + 2500,
				CurrencyType: CurrencyType.RecCenterTokens,
				Platform: -2,
			})
			expect(own[1]!.payload).toMatchObject({ Id: boxes[0]!.Id, Currency: 2500 })
		}
		expect(boxIds.size).toBe(many.length)
	})

	test('every run pays again — the schedule is the cadence — and a lapsed role is not paid', async () => {
		await onlyDiscordLinks([
			[9321, '900000000000000321', [ROLE_A]],
			[9322, '900000000000000322', [ROLE_A]],
		])
		await grantDiscordRoleGifts(giftEnv(MAP), DEFAULT_STARTING_TOKENS)
		// www's sweep found 9322 no longer holds the role; 9323 claimed in between.
		await linkPlatformIdentity(env.DB, 9322, PlatformType.Discord, '900000000000000322', [])
		await linkPlatformIdentity(env.DB, 9323, PlatformType.Discord, '900000000000000323', [ROLE_B])

		const summary = await grantDiscordRoleGifts(giftEnv(MAP), DEFAULT_STARTING_TOKENS)
		expect(summary).toMatchObject({ granted: 2, tokens: 2500 + 10000 })
		expect(await tokens(9321)).toBe(DEFAULT_STARTING_TOKENS + 5000)
		expect(await tokens(9322)).toBe(DEFAULT_STARTING_TOKENS + 2500)
		expect(await tokens(9323)).toBe(DEFAULT_STARTING_TOKENS + 10000)
		expect(await getPendingGifts(env.DB, 9321)).toHaveLength(2)
		expect(await getPendingGifts(env.DB, 9322)).toHaveLength(1)
	})
})

test('2026 current subscription season supplies a nonempty disabled-season DTO', async () => {
	const res = await exports.default.fetch(`${ORIGIN}/api/subscriptionseasons/v1/seasons/current`, {
		headers: await bearer('42', undefined, '20260323.14'),
	})
	expect(res.status).toBe(200)
	expect(await res.json()).toEqual({
		SubscriptionSeasonId: '00000000-0000-0000-0000-000000000000',
		Name: '',
		ImageName: '',
		StartAt: '0001-01-01T00:00:00Z',
		NextSeasonStart: null,
		Milestones: [],
	})
})
