@echo off
rem Only clears stale HTTP name-server cache entries from this local test.
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0revival\reset-old-recnet-cache.ps1"
if errorlevel 1 echo Cache reset did not finish. Your local account was not removed.
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0revival\bootstrap.ps1"
set "result=%errorlevel%"
if not "%result%"=="0" echo The test stopped. Keep the error text above.
pause
exit /b %result%
