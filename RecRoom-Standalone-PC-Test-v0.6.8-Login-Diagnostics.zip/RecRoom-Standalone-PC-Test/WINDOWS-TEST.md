# Standalone desktop test v0.6.8 local connection test

**Game launch is enabled at the user's explicit request. Native Windows gameplay remains unverified.**

1. Close the previous launcher and game.
2. Copy all updated package files over the existing test folder. Keep `.revival` to preserve the local account, downloaded files and game installation.
3. Run **Play.cmd**. The launcher uses the updated v0.6.7 files.

The hidden game window fix is retained: the background-service `windowsHide` flag is not applied to the GUI game process. Background services stay hidden; the game now starts with `windowsHide: false` and Unity windowed 1280x720 command-line options. It also includes `Fix-Game-Window.cmd` to recover an already-running window when Windows exposes a top-level game window. The desktop launcher and portable runtime bootstrap remain enabled. The native HTTP download fixes, pinned portable 7-Zip extraction and fully consumed loopback service checks remain in place. A recognized completed installation is verified and reused; first setup still downloads about 4 GB and requires about 20 GB free.

A local account is created automatically. This configuration requires no Steam application or Steam login. `Play-VR.cmd` explains the current desktop-only scope.

The user-reported Defender detection has not been independently classified as malware or a false positive. This update does not change antivirus or firewall settings, restore quarantined files or add security exclusions. Checksums establish file identity, not malware safety.

Keep the launcher's console open. First IL2CPP interop generation can take several minutes. If setup stops, retain the error and `.revival/logs`. Game diagnostics are in `.revival/game/BepInEx/LogOutput.log`.

Backend and relay startup were verified separately without running the native game. In-game loading, multiplayer, voice and VR still require native Windows evidence.

## If you can hear the game but cannot see it

1. While the game is still running, double-click `Fix-Game-Window.cmd`. It only targets the RecRoom process inside this test folder and tries to restore its window onto your primary monitor.
2. If the recovery tool says no normal window exists, end `RecRoom.exe` in Task Manager, then use the updated `Play.cmd` (do not delete `.revival`).
3. If the game process remains active but no Unity window appears, inspect `.revival/game/BepInEx/LogOutput.log` and `.revival/logs/game-console.log`. The cause may be an engine initialization or GPU/display issue, not merely a hidden window.

This fix has been statically checked but has not been verified on a live Windows game here.

## RecNet notebook error after game becomes visible

This is a **backend/client compatibility problem**, separate from the hidden-window fix. While `Play.cmd` and game remain open, run `Check-RecNet.cmd` and share `.revival/logs/recnet-check.txt`. The report checks the local server and game plugin without copying private logs. See `RECNET-ERROR.md`. The current update changes the local endpoint protocol from HTTP to HTTPS and clears only the stale local HTTP name-server cache (with backup). This is a targeted attempt to address the supplied `Invalid URI scheme` log; an actual successful in-game connection is not yet verified.

## If Play reports another launcher is active

A stale or invalid saved process ID is recovered automatically. New launchers hold a Windows named pipe that Windows releases when the process exits, including crashes. Older numeric locks are checked against the actual launcher script before blocking a restart.

When a launcher really is active, Play shows recovery instructions and tries to restore the game window from this test folder. It does not start a second copy or kill any process. Keep the original Play console open while playing. To restart, close the game and that original console, then run Play.cmd once.

If the process check is unavailable, the error identifies the saved PID. Close the earlier Play window and retry. A Windows restart also clears running launchers; your .revival folder should be kept.

The launcher regressions pass in the Linux verification environment. Windows named-pipe acquisition, PowerShell process inspection, automatic window recovery and gameplay still require native Windows verification.

## v0.6.7 notification connection correction

The screenshot and loader log showed the in-game account was recognized, but the
SignalR notification hub repeatedly returned 403 `untrusted_local_host`. The local
backend previously checked WebSocket `wss:` origins against an advertised `https:`
origin and would reject that scheme if it reached the worker unchanged. This update
accepts only corresponding `wss:`/`ws:` **upgrade requests** with the exact configured
loopback host and port, and preserves WebSocket request metadata when forwarding.

There are also 404 responses, but their endpoint paths were not in the supplied
log. The backend now writes a sanitized `[REVIVAL-404]` route hint, and
`Check-RecNet.cmd` checks the notification negotiation route (200 expected), plain
HTTP hub route (426 expected), and API configuration route (200 expected).
The fix has not been tested against the native Windows game. Its login screen
`code: note` may remain until the actual failing 404 route is identified.
Do not delete `.revival` or reinstall the game for this update.

## v0.6.8 additional SignalR compatibility and diagnostics

The previous WebSocket URL fix only accepted wss/ws schemes on the exact
advertised host. Wrangler's local HTTPS/WebSocket reverse proxy may also
normalize the internal request to HTTP or a different loopback alias. This
update tolerates those variants ONLY on `/notify/hub/v1` and its `/negotiate`
route, with the exact configured port and known loopback hosts; all other
service routes retain the original strict-origin policy.

The `/healthz` response now includes `backendPatch: v0.6.8`; the diagnostic
script reports the observed patch version and sanitized 403/404 route metadata
from the backend log, without printing raw URL paths, account IDs, secrets,
passwords or token-bearing request queries. The changes are unverified in
Rec Room on Windows, so `code: note` may still occur.
