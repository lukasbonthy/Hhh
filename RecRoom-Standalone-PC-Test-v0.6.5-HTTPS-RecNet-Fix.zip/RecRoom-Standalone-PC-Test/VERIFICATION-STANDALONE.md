## v0.6.3 GUI window fix (Windows test pending)

The owned-process runner now accepts `windowsHide` per process, defaulting to true for background services. The actual `RecRoom.exe` game process opts out with `windowsHide: false` and starts Unity in 1280x720 windowed mode. `Fix-Game-Window.cmd` can try restoring a preexisting hidden window. Native Windows gameplay has not been verified here.

# Standalone verification record

**Current status: v0.6.3 launch remains enabled and an invisible-window workaround was added. Native Windows gameplay remains unverified.**

The application-level withdrawal policy added in v0.6.1 was removed from the downloader, installer, native platform configuration and both launch entry points. Desktop launchers and the portable runtime bootstrap were restored. The pinned platform download URL was restored. The four tests enforcing the removed withdrawal policy were removed with that policy.

Current checks:

- All 37 Node checks passed with zero skips. Two new real HTTP transport regressions were observed failing with the earlier application blacklist and passing after its removal. Failed downloads preserve existing cached bytes and local account data.
- The relay readiness and occupied-service regressions still pass. These previously reproduced the exact uncaught Node 24.22.1 `assert(!this.paused)` stack. Startup and CLI probes now drain bounded responses through native loopback HTTP(S).
- A read-only reviewer compared the current source against the exact saved v0.6.1 ZIP and independently passed 22 relevant checks. No blocking or important finding was reported. Integrity pins, HTTPS checks, native-library backup/tamper checks, installation verification and the crash fixes remain intact.
- The source baseline was recovered from the saved v0.6.1 archive and its exact SHA256 was verified before restoration. Prebuilt connector files remain unchanged and match their recorded fingerprints.

Retained verification from the earlier implementation:

- Real backend and Luxon relay startup/readiness passed and owned processes stopped cleanly. The real relay response body was 29058 bytes. No native game or flagged platform library was executed in that test.
- Local worker integration passed 16 tests. Connector checks passed 19 URI rewrite cases and 11 credential-scope cases. Local login uses ordinary password verification; cloud platform-ticket validation was not weakened.
- The exact game archive and native/runtime installation were previously checksum-verified. The full dependency archive was extracted with both official Linux 7zz and a reduced 7zr built from verified official source; the expected regular x64 library fingerprint matched.
- An earlier full upstream run passed 1826 tests and hit one 5000 ms timeout in `apps/rooms/src/test/integration/api.test.ts > Studio source revision permissions > keeps drafts and historical source behind save-history permissions`. Its isolated rerun passed with 1.12 seconds of test execution. That room-service implementation was not modified by this restoration.

The user-reported Defender detection remains independently unclassified. No false-positive or malware-safety finding is asserted. Checksum verification establishes identity, not malware safety. The restored code does not add antivirus exclusions, change firewall rules or restore quarantined files.

Not assessed by the restoration review: Defender classification, dependency malware safety, actual Windows bootstrap execution, native game launch, gameplay, multiplayer, voice or VR. Wine initialization in the available environment was blocked before startup with `wineserver: socket: Operation not permitted`.
