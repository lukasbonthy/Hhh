# Standalone desktop test v0.6.5 HTTPS RecNet diagnostic fix

**Game launch is enabled at the user's explicit request. Native Windows gameplay remains unverified.**

1. Close the previous launcher and game.
2. Copy all updated package files over the existing test folder. Keep `.revival` to preserve the local account, downloaded files and game installation.
3. Run **Play.cmd**. The console identifies version **v0.6.5**.

This version fixes the hidden game window caused by applying the background-service `windowsHide` flag to the GUI game process. Background services stay hidden; the game now starts with `windowsHide: false` and Unity windowed 1280x720 command-line options. It also includes `Fix-Game-Window.cmd` to recover an already-running window when Windows exposes a top-level game window. The desktop launcher and portable runtime bootstrap remain enabled. The native HTTP download fixes, pinned portable 7-Zip extraction and fully consumed loopback service checks remain in place. A recognized completed installation is verified and reused; first setup still downloads about 4 GB and requires about 20 GB free.

A local account is created automatically. This configuration requires no Steam application or Steam login. `Play-VR.cmd` explains the current desktop-only scope.

The user-reported Defender detection has not been independently classified as malware or a false positive. This update does not change antivirus or firewall settings, restore quarantined files or add security exclusions. Checksums establish file identity, not malware safety.

Keep the launcher's console open. First IL2CPP interop generation can take several minutes. If setup stops, retain the error and `.revival/logs`. Game diagnostics are in `.revival/game/BepInEx/LogOutput.log`.

Backend and relay startup were verified separately without running the native game. In-game loading, multiplayer, voice and VR still require native Windows evidence.

## If you can hear the game but cannot see it

1. While the game is still running, double-click `Fix-Game-Window.cmd`. It only targets the RecRoom process inside this test folder and tries to restore its window onto your primary monitor.
2. If the recovery tool says no normal window exists, end `RecRoom.exe` in Task Manager, then use the updated `Play.cmd` (do not delete `.revival`).
3. If the game process remains active but no Unity window appears, inspect `.revival/game/BepInEx/LogOutput.log` and `.revival/logs/game-console.log`. The cause may be an engine initialization or GPU/display issue, not merely a hidden window.

This fix has been statically checked but has not been verified on a live Windows game here.

## RecNet notebook error after game becomes visible

This is a **backend/client compatibility problem**, separate from the hidden-window fix. While `Play.cmd` and game remain open, run `Check-RecNet.cmd` and share `.revival/logs/recnet-check.txt`. The report checks the local server and game plugin without copying private logs. See `RECNET-ERROR.md`. The current update changes the local endpoint protocol from HTTP to HTTPS and clears only the stale local HTTP name-server cache (with backup). This is a targeted attempt to address the supplied `Invalid URI scheme` log; an actual successful in-game connection is not yet verified.
