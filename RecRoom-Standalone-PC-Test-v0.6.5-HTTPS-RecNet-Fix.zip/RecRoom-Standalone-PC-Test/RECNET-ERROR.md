# RecNet `notebook` / Invalid URI scheme (v0.6.5 HTTPS test)

The supplied game log shows a working BepInEx loader and plugin, but its cached name-server response advertises **`http://127.0.0.1:8787`**. This 20230414 client then rejects API requests with `Invalid URI scheme` before they are dispatched. It is consistent with the game requiring HTTPS endpoints.

Version v0.6.5 changes the bundled Wrangler backend and all advertised RecNet endpoints to **`https://127.0.0.1:8787`**, with TLS on the local service. Since Wrangler's development TLS certificate is self-signed, the helper tools accept that certificate **only on loopback requests**. No system certificate trust settings, firewall settings, or Windows Defender settings are changed. The bundled game plugin's pre-existing TLS handling has not been validated with Wrangler's certificate on the user's actual game build.

1. Fully close RecRoom.exe and the old Play.cmd window before copying in updated files.
2. Extract the update **into the existing folder**, replacing project files only, and **keep `.revival`**.
3. Run `Play.cmd`. It will clear only the specific stale local HTTP name-server PlayerPrefs entry, if present (after backing it up), and migrate the local `config.json` to the HTTPS endpoint. The local account, installed game, and backend database are retained.
4. If the game still says `notebook`, keep the launcher running and run `Check-RecNet.cmd`. Share `.revival/logs/recnet-check.txt` and only the **error lines** from `.revival/game/BepInEx/LogOutput.log`. Raw HTTP logs may contain passwords or session tokens; do not share them.

To confirm the local server is listening, open `https://127.0.0.1:8787/healthz` in a browser while Play.cmd is open; a certificate warning is expected for the development HTTPS server. This does not prove the game trusts the certificate or can authenticate. Don't install/trust a root certificate or disable security software as a workaround.

**Limitations:** This addresses the observed protocol mismatch, but connection, authentication, actual gameplay and multiplayer remain unverified on Windows. It is possible a different client-to-server or certificate compatibility problem will appear next. `.revival/config-before-https.json` contains a backup of the old local configuration, while `.revival/logs/recnet-cache-backup-*.json` stores any stale cache values that were removed. Do not delete `.revival` or download the game again to investigate this error.
