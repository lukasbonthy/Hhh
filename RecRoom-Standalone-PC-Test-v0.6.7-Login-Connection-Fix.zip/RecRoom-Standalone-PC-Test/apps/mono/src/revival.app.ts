import ai from '../../ai/src/ai.app'
import cards from '../../cards/src/cards.app'
import datacollection from '../../datacollection/src/datacollection.app'
import discovery from '../../discovery/src/discovery.app'
import econ from '../../econ/src/econ.app'
import img from '../../img/src/img.app'
import leaderboard from '../../leaderboard/src/leaderboard.app'
import link from '../../link/src/link.app'
import lists from '../../lists/src/lists.app'
import platformnotifications from '../../platformnotifications/src/platformnotifications.app'
import roomcomments from '../../roomcomments/src/roomcomments.app'
import { localPasswordLogin } from './local-login'
import { localEndpoints, localOrigin, rebaseLocalResponse, trustedLocalRequestUrl } from './local-routing'
import core from './mono.app'

import type { Env } from './context'

const extras = {
	ai,
	cards,
	datacollection,
	discovery,
	econ,
	img,
	leaderboard,
	link,
	lists,
	platformnotifications,
	roomcomments,
}

const coreServices = new Set([
	'accounts',
	'api',
	'auth',
	'cdn',
	'studiocdn',
	'chat',
	'clubs',
	'commerce',
	'match',
	'notify',
	'ns',
	'playersettings',
	'rooms',
	'storage',
])

function staticAssets(env: Env, service: string): Fetcher {
	return {
		fetch(input: Request | string | URL) {
			if (!env.REVIVAL_ASSETS)
				return Promise.resolve(new Response('Static assets are not prepared', { status: 503 }))
			const request = input instanceof Request ? input : new Request(input)
			const url = new URL(request.url)
			url.pathname = `/${service}${url.pathname}`
			return env.REVIVAL_ASSETS.fetch(new Request(url, request))
		},
	} as Fetcher
}

export async function localFetch(
	request: Request,
	env: Env,
	ctx: ExecutionContext
): Promise<Response> {
	let origin: string
	try {
		origin = localOrigin(env.REVIVAL_PUBLIC_ORIGIN ?? '')
	} catch {
		return Response.json({ error: 'invalid_local_origin' }, { status: 503 })
	}
	const url = new URL(request.url)
	const isWebSocketUpgrade = request.headers.get('upgrade')?.toLowerCase() === 'websocket'
	if (!trustedLocalRequestUrl(url, origin, isWebSocketUpgrade)) {
		// Metadata only: never log a request body, query, credential or session token.
		console.warn('[REVIVAL-ORIGIN-REJECT]', {
			protocol: url.protocol,
			hostMatches: url.host === new URL(origin).host,
			service: url.pathname.split('/')[1] || '(root)',
			websocketUpgrade: isWebSocketUpgrade,
		})
		return Response.json({ error: 'untrusted_local_host' }, { status: 403 })
	}
	const domain = env.DOMAIN || 'revival.invalid'
	if (url.pathname === '/' || url.pathname === '/ns' || url.pathname === '/ns/') {
		return Response.json(localEndpoints(origin, domain, env.SUBDOMAINS || '{"moderation":"api"}'))
	}
	if (url.pathname === '/healthz') {
		await env.DB.prepare('SELECT 1').first()
		return Response.json({
			backend: 'ok',
			clientBuild: '20230414',
			discovery: origin,
			gameplayVerified: false,
			voiceVerified: false,
		})
	}
	const [, service, ...rest] = url.pathname.split('/')
	if (
		!service ||
		!/^[a-z][a-z0-9-]*$/.test(service) ||
		(!Object.hasOwn(extras, service) && !coreServices.has(service))
	) {
		console.warn('[REVIVAL-404]', { method: request.method, service: '(unknown)' })
		return Response.json({ error: 'unknown_service' }, { status: 404 })
	}
	url.protocol = 'https:'
	url.hostname = `${service}.${domain}`
	url.port = ''
	url.pathname = `/${rest.join('/')}`
	const localLogin = request.headers.get('X-Revival-Local-Login')
	// Clone from the original Request so Cloudflare retains WebSocket upgrade
	// metadata instead of losing it in a reconstructed request init object.
	const forwarded: Request = new Request(url, request)
	forwarded.headers.delete('host')
	forwarded.headers.delete('X-Revival-Local-Login')
	const shared = {
		...env,
		DOMAIN: domain,
		SUBDOMAINS: env.SUBDOMAINS || '{"moderation":"api"}',
		// Stop recursive dispatch when the unchanged cloud facade handles the core services.
		REVIVAL_PUBLIC_ORIGIN: undefined,
		NAME: service,
		...(env.REVIVAL_JWT_SECRET
			? {
					JWT_SECRET: { get: async () => env.REVIVAL_JWT_SECRET! } as SecretsStoreSecret,
					META_APP_SECRET: { get: async () => '' } as SecretsStoreSecret,
				}
			: {}),
		ASSETS: staticAssets(env, service),
	}
	const handler = extras[service as keyof typeof extras]
	const adapted =
		service === 'auth' ? await localPasswordLogin(forwarded.clone(), localLogin, shared, ctx) : null
	const response =
		adapted ??
		(handler
			? await handler.fetch(forwarded, shared, ctx)
			: await core.fetch(forwarded, shared, ctx))
	if (response.status === 404) {
		// Keep query strings, account identifiers and bodies out of support logs.
		const pathParts = url.pathname.split('/').filter(Boolean)
		const safePath = pathParts.slice(0, 3).map((part) =>
			/^[a-z][a-z0-9-]{0,32}$/i.test(part) ? part : '[id]'
		).join('/')
		console.warn('[REVIVAL-404]', { method: request.method, service, path: safePath })
	}
	return rebaseLocalResponse(response, domain, origin)
}
