import ai from '../../ai/src/ai.app'
import cards from '../../cards/src/cards.app'
import datacollection from '../../datacollection/src/datacollection.app'
import discovery from '../../discovery/src/discovery.app'
import econ from '../../econ/src/econ.app'
import img from '../../img/src/img.app'
import leaderboard from '../../leaderboard/src/leaderboard.app'
import link from '../../link/src/link.app'
import lists from '../../lists/src/lists.app'
import platformnotifications from '../../platformnotifications/src/platformnotifications.app'
import roomcomments from '../../roomcomments/src/roomcomments.app'
import { localEndpoints, localOrigin, rebaseLocalResponse } from './local-routing'
import core from './mono.app'

import type { Env } from './context'

const extras = {
	ai,
	cards,
	datacollection,
	discovery,
	econ,
	img,
	leaderboard,
	link,
	lists,
	platformnotifications,
	roomcomments,
}

const coreServices = new Set([
	'accounts',
	'api',
	'auth',
	'cdn',
	'studiocdn',
	'chat',
	'clubs',
	'commerce',
	'match',
	'notify',
	'ns',
	'playersettings',
	'rooms',
	'storage',
])

function staticAssets(env: Env, service: string): Fetcher {
	return {
		fetch(input: Request | string | URL) {
			if (!env.REVIVAL_ASSETS)
				return Promise.resolve(new Response('Static assets are not prepared', { status: 503 }))
			const request = input instanceof Request ? input : new Request(input)
			const url = new URL(request.url)
			url.pathname = `/${service}${url.pathname}`
			return env.REVIVAL_ASSETS.fetch(new Request(url, request))
		},
	} as Fetcher
}

export async function localFetch(
	request: Request,
	env: Env,
	ctx: ExecutionContext
): Promise<Response> {
	let origin: string
	try {
		origin = localOrigin(env.REVIVAL_PUBLIC_ORIGIN ?? '')
	} catch {
		return Response.json({ error: 'invalid_local_origin' }, { status: 503 })
	}
	const url = new URL(request.url)
	if (url.origin !== origin)
		return Response.json({ error: 'untrusted_local_host' }, { status: 403 })
	const domain = env.DOMAIN || 'revival.invalid'
	if (url.pathname === '/' || url.pathname === '/ns' || url.pathname === '/ns/') {
		return Response.json(localEndpoints(origin, domain, env.SUBDOMAINS || '{"moderation":"api"}'))
	}
	if (url.pathname === '/healthz') {
		await env.DB.prepare('SELECT 1').first()
		return Response.json({
			backend: 'ok',
			clientBuild: '20230414',
			discovery: origin,
			gameplayVerified: false,
			voiceVerified: false,
		})
	}
	const [, service, ...rest] = url.pathname.split('/')
	if (
		!service ||
		!/^[a-z][a-z0-9-]*$/.test(service) ||
		(!Object.hasOwn(extras, service) && !coreServices.has(service))
	) {
		return Response.json({ error: 'unknown_service' }, { status: 404 })
	}
	url.protocol = 'https:'
	url.hostname = `${service}.${domain}`
	url.port = ''
	url.pathname = `/${rest.join('/')}`
	const headers = new Headers(request.headers)
	headers.delete('host')
	const forwarded: Request = new Request(url, {
		method: request.method,
		headers,
		body: request.body,
		redirect: request.redirect,
		cf: request.cf,
	})
	const shared = {
		...env,
		DOMAIN: domain,
		SUBDOMAINS: env.SUBDOMAINS || '{"moderation":"api"}',
		// Stop recursive dispatch when the unchanged cloud facade handles the core services.
		REVIVAL_PUBLIC_ORIGIN: undefined,
		NAME: service,
		...(env.REVIVAL_JWT_SECRET
			? {
					JWT_SECRET: { get: async () => env.REVIVAL_JWT_SECRET! } as SecretsStoreSecret,
					META_APP_SECRET: { get: async () => '' } as SecretsStoreSecret,
				}
			: {}),
		ASSETS: staticAssets(env, service),
	}
	const handler = extras[service as keyof typeof extras]
	const response = handler
		? await handler.fetch(forwarded, shared, ctx)
		: await core.fetch(forwarded, shared, ctx)
	return rebaseLocalResponse(response, domain, origin)
}
