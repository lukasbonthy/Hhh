# Verification of the refreshed PC test ZIP

The temporary attachment expired, so this archive was recreated from the retained backend and the recorded PC launcher implementation. It is a refreshed build, not a byte-for-byte copy of the earlier ZIP.

The corrected profile selects **RecRoom.exe**, the x64 Unity player in the pinned 20230414 archive. **Recroom_Release.exe** is its x86 EasyAntiCheat launcher; stale manifests selecting it with RecRoom_Data are refused. The published MIT connector is transformed only after its exact SHA-256 matches, and calls the tested .NET 6 URI adapter. Source and notices are included.

Checks repeated for this refreshed build:

- 11 Node tests passed, including dual-executable selection and stale EAC refusal.
- 12 local worker tests passed with real local bindings.
- 19 standalone C# URI checks passed.
- TypeScript checking passed.
- Managed adapter compilation and emitted connector IL verification passed.
- Installer checks passed for streamed download checksums, corrupt-cache preservation, archive path rejection, workspace dependency detection and owned-child cleanup.
- Distribution archive is checked for required entry points, prebuilt hashes and exclusion of runtime state/secrets/game binaries.

Earlier preparation of this profile fully downloaded the 4,080,598,359-byte game archive, verified its published MD5 and native-file SHA-256 fingerprints, extracted it and enrolled 232 required/runtime files. Backend HTTP persistence and automatic relay/backend startup were also exercised. Those multi-gigabyte preparation checks were not repeated merely to reissue the download. The full upstream suite previously passed 1827 tests with a 30-second test budget.

**No native Windows gameplay, scene loading, multiplayer movement, voice or VR has been verified here.** The ZIP is a PC test candidate. BepInEx must generate interop during its first Windows launch. Steam with Rec Room in the user's library is required; the original Steam app ID is preserved. No credentials, original accounts or missing online rooms are recovered.

Generated secrets, databases, downloaded game/runtime files, node_modules and build products are excluded. The only included DLLs are the MIT connector and our managed adapter. Optional upstream web/Studio services are not mounted by the local facade; a healthy backend does not prove every advertised service works.
