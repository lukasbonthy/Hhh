# Run the PC test

Extract the entire ZIP, open Steam, then double-click **Play.cmd**. Keep its console open while playing. For PCVR, connect your headset through your usual PC VR setup and use **Play-VR.cmd**.

Requirements: Windows 10/11 x64, internet, Steam with Rec Room in your library, and about **20 GB free during setup**. No manual Node or .NET installation is required.

First run downloads the matching **20230414** game (about **4 GB**), portable Node, BepInEx and backend dependencies. It verifies downloads/native files, installs the prebuilt connector, prepares the backend and relay, then launches **RecRoom.exe**, the x64 Unity game. Recroom_Release.exe is the EAC launcher for this archive and is refused. BepInEx automatically generates interop on the first game launch; allow several minutes.

Later launches reuse the installation and data. Close the game normally; the console stops only backend/relay processes that it started. Do not open separate Start-Server or Start-Relay windows when using Play.cmd.

This is a test candidate. Previous preparation, backend and relay checks passed; native Windows scene loading, multiplayer, voice and VR remain unverified. The package does not recover original accounts or online rooms, or publish a community server.

If startup fails, keep the error text and .revival/logs. BepInEx writes .revival/game/BepInEx/LogOutput.log. Do not share secrets.json, databases or authentication tokens. Modified enrolled files are refused rather than silently replaced.

The public game mirror is the one referenced by RecFlare's April 2023 installer. Its published archive MD5 plus SHA-256 fingerprints of native code and metadata are checked. Included DLLs contain the MIT connector and managed adapter only. Proprietary game binaries are downloaded at setup, not bundled here. Original Steam app ID is preserved.
