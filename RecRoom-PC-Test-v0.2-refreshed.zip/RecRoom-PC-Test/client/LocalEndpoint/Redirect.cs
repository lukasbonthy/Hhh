namespace RecRoom.LocalEndpoint;
public static class Redirect
{
    public static string Rewrite(string original, string configured) =>
        RecNetPlugin.Patches.NameserverRedirect.Rewrite(original, configured);
}
