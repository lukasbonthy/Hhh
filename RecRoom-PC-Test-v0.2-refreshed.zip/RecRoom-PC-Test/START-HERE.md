# Rec Room local revival foundation

For automatic Windows setup, read WINDOWS-TEST.md and run Play.cmd. The remaining instructions describe the source/manual alternative.

This package adds a local PC/PCVR workflow to RecFlare. It includes the existing backend source, our local service facade, persistent database/storage setup, a checksum-pinned Luxon relay installer, and the client connector source with a local-address fix.

It does **not** include Rec Room itself. A running backend or relay is not proof that the game is playable. In-game loading, multiplayer synchronization, voice, and VR remain to be verified with the exact client.

## Start the local backend

Install [Node.js 24](https://nodejs.org/en/download). On Windows, run `Setup.cmd`, then keep `Start-Server.cmd` and `Start-Relay.cmd` open in separate windows.

The equivalent terminal commands are:

```sh
npx --yes pnpm@10.14.0 install --frozen-lockfile
node revival/cli.mjs setup
node --use-env-proxy revival/cli.mjs relay-install
node revival/cli.mjs start
```

In another terminal:

```sh
node revival/cli.mjs relay-start
node revival/cli.mjs doctor
```

The backend advertises `http://127.0.0.1:8787`; the relay dashboard is `http://127.0.0.1:5088`. This is a local development profile, not an internet-facing community deployment. The relay configuration advertises loopback addresses; check your firewall before adapting it to public hosting. Luxon's UDP sockets may bind all interfaces even though its advertised addresses and dashboard are local.

## Connect the real game

The first target is the operator-declared **20230414** Windows build. The upstream server and patch documents disagree on its Steam manifest identifier, so this package deliberately does not supply an unverified game download command or claim an authoritative client fingerprint.

1. Supply the exact PC game installation from your own available files.
2. Set up BepInEx 6 for that IL2CPP installation and launch it once to generate `BepInEx/interop`.
3. With the game closed and a .NET SDK installed, build our connector:

   ```powershell
   .\Build-ClientPatch.ps1 -GamePath 'C:\Games\RecRoom'
   ```

4. Enroll the local file fingerprints:

   ```powershell
   node revival/cli.mjs enroll-client --game-dir 'C:\Games\RecRoom' --build 20230414
   node revival/cli.mjs verify-client
   ```

5. Keep the backend and relay running, then use `Launch-Desktop.cmd` or `Launch-VR.cmd`.

Enrollment records your declared build and hashes the critical local files. It detects later changes; it is not independent proof of their origin or of compatibility. A receipt from our connector build is required, because the original connector rewrites only a hostname and loses the local protocol/port. The full connector cannot be compiled or tested here without the matching game-generated interop DLLs.

The launcher writes our connection settings to `BepInEx/config/net.rec.plugin.cfg`, preserving unrelated settings and keeping a `.pre-revival` copy of an existing file. It uses an explicit UDP name-server port of **5058**; TCP **4533** is a separate relay proxy, not the port for the connector's UDP transport.

The reused connector contains client-local compatibility changes for the retired service, including certificate/signature behavior inherited from upstream. This package does not change system certificate stores or antivirus settings. Use it with the designated revival profile; the source remains inspectable in `client/RecNetPlugin`.

## Data and verification

`.revival/` contains your generated signing key, account/room database, uploaded files, relay configuration, and client fingerprint manifest. Back up that folder. Repeated setup preserves the key and skips previously applied migrations; changed migration history is refused before new migrations run. Local data is not included in the source package.

Useful checks:

```sh
node --test revival/node-tests/*.test.mjs
node node_modules/vitest/vitest.mjs run --config apps/mono/vitest.revival.config.ts
node revival/smoke.mjs
dotnet run --project client/ConnectionTests
```

`smoke.mjs` starts its own temporary backend and checks actual HTTP behavior and restart persistence. It does not emulate game clients. `client/ConnectionTests` checks the standalone URI helper and targets .NET 10; it does not replace a build against the game's interop assemblies.

See `revival/upstream-lock.json` for the upstream revisions and relay checksums. Backend/connector licensing is MIT; Luxon is BSD-3-Clause. Original notices are preserved. `VERIFICATION.md` records the results and remaining gates for this version.
