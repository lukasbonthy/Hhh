@echo off
setlocal
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0revival\bootstrap.ps1" -VR
echo.
echo Session ended. See .revival\logs if the game could not start.
pause
