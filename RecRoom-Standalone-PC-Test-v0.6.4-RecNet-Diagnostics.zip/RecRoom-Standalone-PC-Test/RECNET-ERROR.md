# "Failed to connect to RecNet" / notebook

This is a different problem from the previously invisible game window. The game has started, but it reports it cannot complete RecNet initialization. It does not prove whether the failed step is the local backend, patched RecNet redirect, local account login, or another client/service incompatibility.

1. Leave `Play.cmd` open and leave the game at the error screen.
2. Double-click `Check-RecNet.cmd`.
3. Open `.revival/logs/recnet-check.txt` and share its contents. The summary checks loopback HTTP responses, game configuration, required plugin files, and *counts* of errors in the last part of BepInEx's log. It does not include passwords, tokens, or raw HTTP payloads.
4. If backend `/healthz` shows `NO RESPONSE`, check the Play console and `.revival/logs/backend.log`. If it shows HTTP 200 but RecNet still fails, inspect plugin load markers. A missing BepInEx log suggests the mod loader never initialized; a present log with load exceptions suggests an injection/dependency issue.

For a quick manual test on the same PC while Play.cmd is open, open `http://127.0.0.1:8787/healthz` in a browser. With the default configuration it should return JSON containing `"backend":"ok"`. If it does not, the local backend is not reachable at that address. A custom loopback port may be used if `.revival/config.json` has been edited.

Keep `.revival` (which contains your local account, installed client, and caches). Do **not** delete it or reinstall 4 GB just to diagnose this error. Do not disable antivirus or add firewall exclusions to get past a protection alert. Native Windows gameplay has not been verified by this package's authors.
